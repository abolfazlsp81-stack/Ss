<?php
/**
 * Plugin Name: Modern Profile Hub
 * Description: ورود و ثبت‌نام موبایلی، داشبورد نقش‌محور، فروش دوره و نوبت‌دهی درمانگران.
 * Version: 28.3.11
 * Author: Custom Development
 * Text Domain: modern-profile-hub
 * Requires at least: 6.2
 * Requires PHP: 7.4
 */

defined('ABSPATH') || exit;

// اگر نسخه دیگری از همین افزونه به اشتباه هم‌زمان فعال باشد، از Fatal ناشی از
// تعریف دوباره کلاس‌ها جلوگیری می‌کنیم تا سایت از دسترس خارج نشود.
if (defined('MPH_VERSION')) return;

define('MPH_VERSION', '28.3.11');
define('MPH_FILE', __FILE__);
define('MPH_DIR', plugin_dir_path(__FILE__));
define('MPH_URL', plugin_dir_url(__FILE__));
define('MPH_LOGO_URL', apply_filters('mph_logo_url', get_option('mph_logo_url', 'https://nikandishan-institute.ir/wp-content/uploads/2026/04/IMG_20250508_214816_350.png')));

require_once MPH_DIR . 'includes/class-mph-helpers.php';
require_once MPH_DIR . 'includes/class-mph-security.php';
require_once MPH_DIR . 'includes/class-mph-operation-lock.php';
require_once MPH_DIR . 'includes/class-mph-payment-attempts.php';
require_once MPH_DIR . 'includes/class-mph-tutor.php';
require_once MPH_DIR . 'includes/class-mph-certificates.php';
require_once MPH_DIR . 'includes/class-mph-payments.php';
require_once MPH_DIR . 'includes/class-mph-courses.php';
require_once MPH_DIR . 'includes/class-mph-commerce.php';
require_once MPH_DIR . 'includes/class-mph-edit-guard.php';
require_once MPH_DIR . 'includes/class-mph-course-lifecycle.php';
require_once MPH_DIR . 'includes/class-mph-playback.php';
require_once MPH_DIR . 'includes/class-mph-portal-health.php';
require_once MPH_DIR . 'includes/class-mph-bale-native.php';
require_once MPH_DIR . 'includes/class-mph-private-files.php';
require_once MPH_DIR . 'includes/class-mph-shared-cart.php';
require_once MPH_DIR . 'includes/class-mph-checkout.php';
require_once MPH_DIR . 'includes/class-mph-payment-result.php';
require_once MPH_DIR . 'includes/class-mph-discounts.php';
require_once MPH_DIR . 'includes/class-mph-tickets.php';
require_once MPH_DIR . 'includes/class-mph-calendar.php';
require_once MPH_DIR . 'includes/class-mph-payouts.php';
require_once MPH_DIR . 'includes/class-mph-appointment-lock.php';
require_once MPH_DIR . 'includes/class-mph-appointment-repository.php';
require_once MPH_DIR . 'includes/class-mph-appointments.php';
require_once MPH_DIR . 'includes/class-mph-appointment-cart.php';
require_once MPH_DIR . 'includes/class-mph-notices.php';
require_once MPH_DIR . 'includes/class-mph-safir.php';
require_once MPH_DIR . 'includes/class-mph-sms.php';
require_once MPH_DIR . 'includes/class-mph-quizzes.php';
require_once MPH_DIR . 'includes/class-mph-manager.php';
require_once MPH_DIR . 'includes/class-mph-updater.php';
require_once MPH_DIR . 'includes/class-mph-growth.php';
require_once MPH_DIR . 'includes/class-mph-backup.php';
require_once MPH_DIR . 'includes/class-mph-web-notifications.php';
require_once MPH_DIR . 'includes/class-mph-bale-sync.php';
require_once MPH_DIR . 'includes/class-mph-bale-runtime.php';
require_once MPH_DIR . 'includes/class-mph-xlsx.php';
require_once MPH_DIR . 'includes/class-mph-auth.php';
require_once MPH_DIR . 'includes/class-mph-password-recovery.php';
require_once MPH_DIR . 'includes/class-mph-factory-reset.php';
require_once MPH_DIR . 'includes/class-mph-health.php';
require_once MPH_DIR . 'includes/class-mph-roles.php';
require_once MPH_DIR . 'includes/class-mph-menu-alerts.php';
require_once MPH_DIR . 'includes/class-mph-forum.php';
require_once MPH_DIR . 'includes/class-mph-dashboard.php';
require_once MPH_DIR . 'includes/class-mph-admin.php';

final class MPH_Plugin {
    const UPGRADE_HOOK = 'mph_run_deferred_upgrade';
    const UPGRADE_PENDING = 'mph_upgrade_pending';
    const UPGRADE_PHASE = 'mph_upgrade_phase';

    public static function init() {
        add_action('init', array(__CLASS__, 'maybe_schedule_upgrade'), 1);
        add_action(self::UPGRADE_HOOK, array(__CLASS__, 'run_upgrade_phase'));
        MPH_Helpers::init();
        MPH_Security::init();
        MPH_Roles::init();
        MPH_Certificates::init();
        MPH_Payments::init();
        MPH_Courses::init();
        MPH_Commerce::init();
        MPH_Edit_Guard::init();
        MPH_Course_Lifecycle::init();
        MPH_Playback::init();
        MPH_Portal_Health::init();
        MPH_Private_Files::init();
        MPH_Shared_Cart::init();
        MPH_Payment_Result::init();
        MPH_Discounts::init();
        MPH_Tickets::init();
        MPH_Calendar::init();
        MPH_Payouts::init();
        MPH_Appointments::init();
        MPH_Notices::init();
        MPH_Safir::init();
        MPH_SMS::init();
        MPH_Quizzes::init();
        MPH_Manager::init();
        MPH_Updater::init();
        MPH_Growth::init();
        MPH_Backup::init();
        MPH_Web_Notifications::init();
        MPH_Bale_Sync::init();
        MPH_Auth::init();
        MPH_Password_Recovery::init();
        MPH_Factory_Reset::init();
        MPH_Health::init();
        MPH_Menu_Alerts::init();
    if (class_exists('MPH_Forum')) MPH_Forum::init();
        MPH_Dashboard::init();
        MPH_Admin::init();
    }

    /**
     * بروزرسانی دیتابیس هرگز داخل درخواست عمومی یا فعال‌سازی اجرا نمی‌شود.
     * هر مرحله در یک درخواست مستقل WP-Cron انجام می‌شود تا محدودیت زمان/حافظه
     * هاست باعث خطای بحرانی کل سایت نشود.
     */
    public static function maybe_schedule_upgrade() {
        if (get_option(MPH_Helpers::DB_VERSION) === MPH_VERSION) return;
        if (!get_option(self::UPGRADE_PENDING)) {
            update_option(self::UPGRADE_PENDING, 1, false);
            update_option(self::UPGRADE_PHASE, 1, false);
        }
        self::schedule_upgrade(5);
    }

    private static function schedule_upgrade($delay = 10) {
        if (!wp_next_scheduled(self::UPGRADE_HOOK)) {
            wp_schedule_single_event(time() + max(1, absint($delay)), self::UPGRADE_HOOK);
        }
    }

    public static function run_upgrade_phase() {
        if (get_option(MPH_Helpers::DB_VERSION) === MPH_VERSION) {
            delete_option(self::UPGRADE_PENDING);
            delete_option(self::UPGRADE_PHASE);
            return;
        }
        if (get_transient('mph_upgrade_lock')) return;
        set_transient('mph_upgrade_lock', 1, 5 * MINUTE_IN_SECONDS);
        $phase = max(1, absint(get_option(self::UPGRADE_PHASE, 1)));
        try {
            if ($phase === 1) {
                MPH_Security::install();
            } elseif ($phase === 2) {
                if (!MPH_Tickets::maybe_install()) throw new RuntimeException('Ticket tables were not created completely.');
            } elseif ($phase === 3) {
                if (!MPH_Notices::maybe_install()) throw new RuntimeException('Announcement table was not created completely.');
            } elseif ($phase === 4) {
                if (!MPH_Bale_Sync::install()) throw new RuntimeException('Bale synchronization tables were not created completely.');
            } else {
                MPH_Safir::install();
                MPH_Admin::install_defaults();
                // Only the upgrade coordinator may mark the whole plugin ready.
                // Individual modules keep their own schema/default versions so an
                // early visit to an admin page cannot skip pending table installs.
                update_option(MPH_Helpers::DB_VERSION, MPH_VERSION, false);
                delete_option(self::UPGRADE_PENDING);
                delete_option(self::UPGRADE_PHASE);
                delete_option('mph_last_upgrade_error');
                MPH_Calendar::maybe_schedule_existing();
                MPH_Growth::rewrites();
                flush_rewrite_rules(false);
                return;
            }
            update_option(self::UPGRADE_PHASE, $phase + 1, false);
            self::schedule_upgrade(10);
        } catch (Throwable $error) {
            update_option('mph_last_upgrade_error', array(
                'phase' => $phase,
                'message' => sanitize_text_field($error->getMessage()),
                'time' => current_time('mysql'),
            ), false);
            self::schedule_upgrade(300);
        } finally {
            delete_transient('mph_upgrade_lock');
        }
    }

    public static function activate() {
        add_role('mph_instructor', 'مدرس', array('read' => true, 'upload_files' => true));
        add_role('mph_therapist', 'درمانگر', array('read'=>true,'upload_files'=>true,'mph_manage_appointments'=>true));
        add_role('mph_manager', 'مدیر مجموعه', array(
            'read' => true, 'list_users' => true, 'upload_files' => true, 'mph_manage_portal' => true,
            'manage_tutor' => true, 'manage_woocommerce' => true, 'view_woocommerce_reports' => true,
            'edit_posts' => true, 'edit_others_posts' => true, 'edit_published_posts' => true, 'publish_posts' => true,
            'delete_posts' => true, 'delete_others_posts' => true, 'edit_shop_coupons' => true,
            'edit_others_shop_coupons' => true, 'publish_shop_coupons' => true, 'read_private_shop_coupons' => true,
            'delete_shop_coupons' => true,
            'mph_manage_members' => true, 'mph_manage_courses' => true, 'mph_manage_reports' => true,
            'mph_manage_support' => true, 'mph_manage_appointments' => true,
        ));
        $administrator = get_role('administrator');
        if ($administrator) $administrator->add_cap('mph_manage_courses');
        update_option(self::UPGRADE_PENDING, 1, false);
        update_option(self::UPGRADE_PHASE, 1, false);
        self::schedule_upgrade(5);
        MPH_Growth::activate();
    }

    public static function deactivate() {
        wp_clear_scheduled_hook(MPH_Security::CRON_HOOK);
        wp_clear_scheduled_hook('mph_reconcile_pending_payments');
        wp_clear_scheduled_hook('mph_private_file_migrate');
        wp_clear_scheduled_hook(self::UPGRADE_HOOK);
        wp_clear_scheduled_hook(MPH_Calendar::SYNC_HOOK);
    }
}

register_activation_hook(MPH_FILE, array('MPH_Plugin', 'activate'));
register_deactivation_hook(MPH_FILE, array('MPH_Plugin', 'deactivate'));
MPH_Plugin::init();
