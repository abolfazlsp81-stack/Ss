<?php
defined('ABSPATH') || exit;

/**
 * موتور مستقل تیکت افزونه.
 *
 * هر تیکت یک گفت‌وگوی مشترک دارد و پیام‌های کاربر، مدیر، مدرس و درمانگر در جدول
 * mph_ticket_messages با ticket_id یکسان ذخیره می‌شوند. نقش پاسخ‌دهنده از
 * نمای فعال پنل دریافت و دوباره در سمت سرور اعتبارسنجی می‌شود؛ در نتیجه
 * حساب‌های چندنقشی نیز همیشه از همان پنلی که در آن هستند پاسخ می‌دهند.
 */
final class MPH_Tickets {
    const POST_TYPE = 'mph_ticket';
    const REPLY_TYPE = 'mph_ticket_reply';
    const DB_VERSION = '4.0.0';
    const LEGACY_MIGRATION_OPTION = 'mph_ticket_legacy_migrated_v25';
    const MAX_FILE_SIZE = 2097152;

    public static function init() {
        add_action('init', array(__CLASS__, 'register_legacy_types'), 5);
        add_action('init', array(__CLASS__, 'migrate_legacy'), 30);
        add_action('wp_enqueue_scripts', array(__CLASS__, 'register_assets'));
        add_action('wp_ajax_mph_ticket_v8_create', array(__CLASS__, 'ajax_create'));
        add_action('wp_ajax_mph_ticket_v8_reply', array(__CLASS__, 'ajax_reply'));
        add_action('wp_ajax_mph_ticket_v8_read', array(__CLASS__, 'ajax_mark_read'));
        add_action('wp_ajax_mph_ticket_v10_alert', array(__CLASS__, 'ajax_alert_status'));
        add_action('admin_post_mph_ticket_v8_file', array(__CLASS__, 'download_attachment'));
        add_action('template_redirect', array(__CLASS__, 'prevent_portal_cache'), 1);
    }

    public static function register_legacy_types() {
        register_post_type(self::POST_TYPE, array(
            'label' => 'تیکت‌های قدیمی',
            'public' => false,
            'show_ui' => false,
            'supports' => array('title', 'editor', 'author'),
        ));
        register_post_type(self::REPLY_TYPE, array(
            'label' => 'پاسخ‌های قدیمی',
            'public' => false,
            'show_ui' => false,
            'supports' => array('editor', 'author', 'page-attributes'),
        ));
    }

    public static function register_assets() {
        wp_register_script('mph-tickets-v11', MPH_URL . 'assets/js/tickets.js', array(), MPH_VERSION, true);
    }

    public static function maybe_install() {
        if (get_option('mph_ticket_db_version') === self::DB_VERSION && self::tables_ready()) return true;

        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $charset = $wpdb->get_charset_collate();
        $tickets = self::tickets_table();
        $messages = self::messages_table();

        dbDelta("CREATE TABLE {$tickets} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            user_id bigint(20) unsigned NOT NULL,
            subject varchar(190) NOT NULL,
            message longtext NOT NULL,
            origin_role varchar(20) NOT NULL DEFAULT 'user',
            department varchar(30) NOT NULL DEFAULT 'other',
            priority varchar(20) NOT NULL DEFAULT 'normal',
            status varchar(20) NOT NULL DEFAULT 'open',
            assigned_instructor_id bigint(20) unsigned NOT NULL DEFAULT 0,
            assigned_therapist_id bigint(20) unsigned NOT NULL DEFAULT 0,
            attachment_id bigint(20) unsigned NOT NULL DEFAULT 0,
            user_unread tinyint(1) NOT NULL DEFAULT 0,
            manager_unread tinyint(1) NOT NULL DEFAULT 0,
            instructor_unread tinyint(1) NOT NULL DEFAULT 0,
            therapist_unread tinyint(1) NOT NULL DEFAULT 0,
            legacy_id bigint(20) unsigned NOT NULL DEFAULT 0,
            created_at datetime NOT NULL,
            updated_at datetime NOT NULL,
            PRIMARY KEY  (id),
            KEY user_id (user_id),
            KEY assigned_instructor_id (assigned_instructor_id),
            KEY assigned_therapist_id (assigned_therapist_id),
            KEY status (status),
            KEY updated_at (updated_at),
            KEY status_updated (status, updated_at),
            KEY legacy_id (legacy_id)
        ) {$charset};");

        dbDelta("CREATE TABLE {$messages} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            ticket_id bigint(20) unsigned NOT NULL,
            author_id bigint(20) unsigned NOT NULL,
            author_role varchar(20) NOT NULL DEFAULT 'manager',
            message longtext NOT NULL,
            attachment_id bigint(20) unsigned NOT NULL DEFAULT 0,
            legacy_key varchar(60) NOT NULL DEFAULT '',
            created_at datetime NOT NULL,
            PRIMARY KEY  (id),
            KEY ticket_id (ticket_id),
            KEY ticket_created (ticket_id, created_at),
            KEY author_id (author_id),
            KEY legacy_key (legacy_key)
        ) {$charset};");

        if (!self::tables_ready(true)) return false;

        // برچسب فرستنده پیام‌های سیستمی نسخه‌های قبل را یک‌بار اصلاح می‌کند.
        $wpdb->query("UPDATE {$tickets} SET origin_role='manager' WHERE origin_role='user' AND status='answered' AND department IN ('role','certificate','system')");
        $wpdb->query("UPDATE {$tickets} SET origin_role='instructor' WHERE origin_role='user' AND status='answered' AND department='announcement'");

        update_option('mph_ticket_db_version', self::DB_VERSION, false);
        return true;
    }

    /** انتقال یک‌باره اطلاعات نسخه‌های قدیمی؛ داده قبلی حذف نمی‌شود. */
    public static function migrate_legacy() {
        if (get_option(self::LEGACY_MIGRATION_OPTION)) {
            return;
        }
        // Installation is coordinated by the deferred upgrader (or the ticket
        // renderer). The regular init hook must never mark a missing table as
        // migrated or run a heavy schema change on an anonymous request.
        if (get_option('mph_ticket_db_version') !== self::DB_VERSION || !self::tables_ready()) return;

        global $wpdb;
        $migration_ok = true;
        $legacy = get_posts(array(
            'post_type' => self::POST_TYPE,
            'post_status' => 'publish',
            'numberposts' => -1,
            'orderby' => 'ID',
            'order' => 'ASC',
        ));

        foreach ($legacy as $post) {
            $ticket_id = absint($wpdb->get_var($wpdb->prepare(
                'SELECT id FROM ' . self::tickets_table() . ' WHERE legacy_id=%d LIMIT 1',
                $post->ID
            )));

            if (!$ticket_id) {
                $wpdb->insert(self::tickets_table(), array(
                    'user_id' => $post->post_author,
                    'subject' => $post->post_title,
                    'message' => $post->post_content,
                    'origin_role' => 'user',
                    'department' => get_post_meta($post->ID, '_mph_ticket_department', true) ?: 'other',
                    'priority' => get_post_meta($post->ID, '_mph_ticket_priority', true) ?: 'normal',
                    'status' => get_post_meta($post->ID, '_mph_ticket_status', true) ?: 'open',
                    'assigned_instructor_id' => absint(get_post_meta($post->ID, '_mph_ticket_assigned_instructor', true)),
                    'assigned_therapist_id' => 0,
                    'attachment_id' => absint(get_post_meta($post->ID, '_mph_ticket_attachment_id', true)),
                    'user_unread' => absint(get_post_meta($post->ID, '_mph_ticket_unread_user', true)),
                    'manager_unread' => 1,
                    'instructor_unread' => absint(get_post_meta($post->ID, '_mph_ticket_unread_teacher', true)),
                    'therapist_unread' => 0,
                    'legacy_id' => $post->ID,
                    'created_at' => $post->post_date,
                    'updated_at' => $post->post_modified,
                ), array('%d', '%s', '%s', '%s', '%s', '%s', '%s', '%d', '%d', '%d', '%d', '%d', '%d', '%d', '%d', '%s', '%s'));
                $ticket_id = absint($wpdb->insert_id);
                if (!$ticket_id) {
                    $migration_ok = false;
                    break;
                }
            }

            if ($ticket_id) {
                if (!self::migrate_legacy_messages($post->ID, $ticket_id)) {
                    $migration_ok = false;
                    break;
                }
            }
        }

        // از یک نشانگر تازه استفاده می‌کنیم تا نصب‌هایی که نسخه‌های قبلی
        // زودتر از ساخته‌شدن جدول، مهاجرت را تمام‌شده علامت زده بودند نیز
        // دوباره و به‌شکل idempotent بررسی شوند.
        if ($migration_ok) update_option(self::LEGACY_MIGRATION_OPTION, 1, false);
    }

    private static function migrate_legacy_messages($legacy_ticket_id, $ticket_id) {
        global $wpdb;
        $posts = get_posts(array(
            'post_type' => self::REPLY_TYPE,
            'post_status' => 'publish',
            'post_parent' => $legacy_ticket_id,
            'numberposts' => -1,
            'orderby' => 'date',
            'order' => 'ASC',
        ));

        foreach ($posts as $post) {
            $key = 'post_' . $post->ID;
            if ($wpdb->get_var($wpdb->prepare('SELECT id FROM ' . self::messages_table() . ' WHERE legacy_key=%s LIMIT 1', $key))) {
                continue;
            }
            $inserted = $wpdb->insert(self::messages_table(), array(
                'ticket_id' => $ticket_id,
                'author_id' => $post->post_author,
                'author_role' => self::normalize_role(get_post_meta($post->ID, '_mph_reply_role', true)),
                'message' => $post->post_content,
                'attachment_id' => absint(get_post_meta($post->ID, '_mph_reply_attachment_id', true)),
                'legacy_key' => $key,
                'created_at' => $post->post_date,
            ), array('%d', '%d', '%s', '%s', '%d', '%s', '%s'));
            if (!$inserted) return false;
        }

        $comments = get_comments(array(
            'post_id' => $legacy_ticket_id,
            'type' => 'mph_ticket_reply',
            'status' => 'approve',
            'order' => 'ASC',
        ));

        foreach ($comments as $comment) {
            $key = 'comment_' . $comment->comment_ID;
            if ($wpdb->get_var($wpdb->prepare('SELECT id FROM ' . self::messages_table() . ' WHERE legacy_key=%s LIMIT 1', $key))) {
                continue;
            }
            $inserted = $wpdb->insert(self::messages_table(), array(
                'ticket_id' => $ticket_id,
                'author_id' => $comment->user_id,
                'author_role' => self::normalize_role(get_comment_meta($comment->comment_ID, '_mph_reply_role', true)),
                'message' => $comment->comment_content,
                'attachment_id' => absint(get_comment_meta($comment->comment_ID, '_mph_reply_attachment_id', true)),
                'legacy_key' => $key,
                'created_at' => $comment->comment_date,
            ), array('%d', '%d', '%s', '%s', '%d', '%s', '%s'));
            if (!$inserted) return false;
        }

        return true;
    }

    public static function render($mode) {
        $mode = in_array($mode, array('user', 'manager', 'instructor', 'therapist'), true) ? $mode : 'user';
        self::enqueue_assets();
        if (!self::maybe_install()) {
            return '<section class="mph-section mph-ticket-system"><div class="mph-empty mph-ticket-db-error"><span class="dashicons dashicons-database-remove"></span><p>ساخت جدول‌های تیکت کامل نشده است. مدیر سایت از «سلامت و امنیت» عملیات نگهداری را اجرا کند.</p></div></section>';
        }
        self::migrate_legacy();
        $tickets = self::query_tickets($mode, get_current_user_id());
        $counts = self::status_counts($tickets);
        $staff = $mode === 'manager' ? get_users(array(
            'role__in' => array('mph_instructor', 'tutor_instructor', 'mph_therapist'),
            'orderby' => 'display_name',
        )) : array();

        ob_start();
        ?>
        <section class="mph-section mph-ticket-system is-<?php echo esc_attr($mode); ?>" data-ticket-mode="<?php echo esc_attr($mode); ?>">
            <?php if (in_array($mode, array('instructor', 'therapist'), true)) : ?>
                <div class="mph-instructor-ticket-head">
                    <span class="dashicons <?php echo $mode === 'therapist' ? 'dashicons-heart' : 'dashicons-businessperson'; ?>"></span>
                    <div>
                        <h3>تیکت‌های من و گفت‌وگوهای ارجاع‌شده</h3>
                        <p>درخواست‌های ثبت‌شده توسط شما و تیکت‌هایی که مدیر برای پاسخ ارجاع داده است.</p>
                    </div>
                    <b><?php echo count($tickets); ?></b>
                </div>
            <?php else : ?>
                <div class="mph-section-heading">
                    <div>
                        <h3><?php echo $mode === 'manager' ? 'مرکز مستقل پشتیبانی' : 'پشتیبانی و پیگیری'; ?></h3>
                        <p><?php echo $mode === 'manager' ? 'مدیر، مدرس و درمانگر روی همان گفت‌وگوی مشترک پاسخ می‌دهند.' : 'درخواست را ثبت کنید و پاسخ پشتیبانی را در همین گفت‌وگو ادامه دهید.'; ?></p>
                    </div>
                    <span class="dashicons dashicons-sos"></span>
                </div>
                <?php echo self::stats_html($counts, count($tickets)); ?>
            <?php endif; ?>

            <?php echo self::new_ticket_form($mode); ?>

            <?php if (self::has_alert($mode)) : ?>
                <form class="mph-ticket-read" data-mph-ticket-action="mph_ticket_v8_read">
                    <input type="hidden" name="ticket_mode" value="<?php echo esc_attr($mode); ?>">
                    <button type="submit" class="mph-secondary"><span class="dashicons dashicons-yes-alt"></span> پاسخ‌ها را خواندم</button>
                    <div class="mph-message" aria-live="polite"></div>
                </form>
            <?php endif; ?>

            <?php echo self::toolbar_html($counts, count($tickets), $mode); ?>
            <div class="mph-ticket-list">
                <div class="mph-ticket-list-head">
                    <h4><?php echo $mode === 'manager' ? 'همه تیکت‌ها' : (in_array($mode, array('instructor', 'therapist'), true) ? 'تیکت‌های ارجاعی' : 'تیکت‌های من'); ?></h4>
                    <span data-ticket-visible-count><?php echo count($tickets); ?> مورد</span>
                </div>
                <?php
                if (!$tickets) {
                    echo self::empty_html($mode);
                }
                foreach ($tickets as $ticket) {
                    echo self::ticket_card($ticket, $mode, $staff);
                }
                ?>
                <div class="mph-ticket-filter-empty" hidden><span class="dashicons dashicons-search"></span><p>تیکتی با این فیلتر پیدا نشد.</p></div>
            </div>
        </section>
        <?php
        return ob_get_clean();
    }

    private static function new_ticket_form($mode = 'user') {
        $mode = in_array($mode, array('user', 'instructor', 'therapist', 'manager'), true) ? $mode : 'user';
        $caption = $mode === 'user'
            ? 'برای شروع گفت‌وگو کلیک کنید'
            : 'درخواست خود را بدون تغییر نقش ثبت کنید';
        ob_start();
        ?>
        <details class="mph-ticket-compose">
            <summary><span class="dashicons dashicons-plus-alt2"></span><b>ثبت تیکت جدید</b><small><?php echo esc_html($caption); ?></small></summary>
            <form class="mph-form mph-new-ticket" data-mph-ticket-action="mph_ticket_v8_create" enctype="multipart/form-data">
                <input type="hidden" name="ticket_mode" value="<?php echo esc_attr($mode); ?>">
                <div class="mph-field-grid">
                    <label><?php echo MPH_Helpers::required('موضوع'); ?><input name="ticket_subject" maxlength="120" required></label>
                    <label><?php echo MPH_Helpers::required('دسته‌بندی'); ?>
                        <select name="ticket_department" required>
                            <option value="">انتخاب کنید</option>
                            <option value="education">آموزشی</option>
                            <option value="payment">پرداخت و سفارش</option>
                            <option value="technical">فنی</option>
                            <option value="other">سایر</option>
                        </select>
                    </label>
                </div>
                <div class="mph-field-grid">
                    <label>اولویت
                        <select name="ticket_priority">
                            <option value="normal">عادی</option>
                            <option value="important">مهم</option>
                            <option value="urgent">فوری</option>
                        </select>
                    </label>
                    <label>پیوست <small>(اختیاری، حداکثر ۲ مگابایت)</small><input type="file" name="ticket_attachment" data-ticket-file data-mph-max-file="<?php echo absint(self::MAX_FILE_SIZE); ?>" accept="image/jpeg,image/png,image/webp,image/gif,application/pdf,.doc,.docx,.xls,.xlsx,.txt"></label>
                    <div class="mph-ticket-file-state" data-ticket-file-state aria-live="polite"><span class="mph-ticket-file-empty">فایلی انتخاب نشده است.</span></div>
                </div>
                <label><?php echo MPH_Helpers::required('متن درخواست'); ?><textarea name="ticket_message" maxlength="5000" required></textarea></label>
                <button class="mph-primary" type="submit"><span class="dashicons dashicons-email-alt"></span> ثبت تیکت</button>
                <div class="mph-message" aria-live="polite"></div>
            </form>
        </details>
        <?php
        return ob_get_clean();
    }

    private static function toolbar_html($counts, $total, $mode = 'user') {
        ob_start();
        ?>
        <div class="mph-ticket-toolbar">
            <div class="mph-ticket-filters" role="group" aria-label="فیلتر وضعیت تیکت">
                <button type="button" class="is-active" data-ticket-filter="all">همه <b><?php echo absint($total); ?></b></button>
                <button type="button" data-ticket-filter="open">در انتظار <b><?php echo absint($counts['open']); ?></b></button>
                <button type="button" data-ticket-filter="forwarded">ارجاعی <b><?php echo absint($counts['forwarded']); ?></b></button>
                <button type="button" data-ticket-filter="answered">پاسخ‌داده <b><?php echo absint($counts['answered']); ?></b></button>
                <button type="button" data-ticket-filter="closed">بسته <b><?php echo absint($counts['closed']); ?></b></button>
            </div>
            <div class="mph-ticket-tools">
                <label class="mph-ticket-search"><span class="dashicons dashicons-search"></span><input type="search" data-ticket-search placeholder="جست‌وجوی شماره، موضوع یا نام"></label>
                <label class="mph-ticket-sort"><span class="dashicons dashicons-sort"></span><span>مرتب‌سازی</span>
                    <select data-ticket-sort aria-label="مرتب‌سازی تیکت‌ها">
                        <option value="updated-desc" <?php echo selected($mode !== 'manager', true, false); ?>>جدیدترین بروزرسانی</option>
                        <option value="updated-asc">قدیمی‌ترین بروزرسانی</option>
                        <option value="id-desc">شماره: نزولی</option>
                        <option value="id-asc">شماره: صعودی</option>
                        <option value="priority-desc" <?php echo selected($mode === 'manager', true, false); ?>>اولویت: فوری‌تر</option>
                        <option value="unanswered-first">پاسخ‌داده‌نشده ابتدا</option>
                        <option value="answered-first">پاسخ‌داده‌شده ابتدا</option>
                        <option value="unread-desc">خوانده‌نشده‌ها اول</option>
                        <option value="status-asc">وضعیت پاسخ</option>
                    </select>
                </label>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }

    private static function ticket_card($ticket, $mode, $staff = array()) {
        $owner = get_user_by('id', $ticket->user_id);
        $messages = self::messages($ticket->id);
        $owner_name = $owner ? MPH_Helpers::display_name($owner) : 'کاربر حذف‌شده';
        $search = implode(' ', array($ticket->id, $ticket->subject, $owner_name, self::department_label($ticket->department)));
        $is_owner = absint($ticket->user_id) === get_current_user_id();
        $unread = ($is_owner && !empty($ticket->user_unread))
            || (!$is_owner && $mode === 'manager' && !empty($ticket->manager_unread))
            || (!$is_owner && $mode === 'instructor' && !empty($ticket->instructor_unread))
            || (!$is_owner && $mode === 'therapist' && !empty($ticket->therapist_unread));
        $last_message = $messages ? $messages[count($messages) - 1] : null;
        $last_role = $last_message ? self::normalize_role($last_message->author_role) : self::normalize_role($ticket->origin_role ?: 'user');
        $last_body = $last_message ? $last_message->message : $ticket->message;
        $message_count = count($messages) + 1;
        $details_id = 'mph-ticket-details-' . absint($ticket->id) . '-' . esc_attr($mode);
        $priority_rank = array('normal'=>1, 'important'=>2, 'urgent'=>3);
        $status_rank = array('open'=>1, 'forwarded'=>2, 'answered'=>3, 'closed'=>4);
        $updated_timestamp = strtotime($ticket->updated_at) ?: 0;
        $answered = in_array($ticket->status, array('answered','closed'), true);
        $ticket_hue = 195 + (absint($ticket->id) % 8) * 11;

        ob_start();
        ?>
        <article class="mph-ticket-card is-priority-<?php echo esc_attr($ticket->priority); ?><?php echo $unread ? ' has-unread' : ''; ?>" style="--mph-ticket-hue:<?php echo absint($ticket_hue); ?>" data-ticket-id="<?php echo absint($ticket->id); ?>" data-ticket-status="<?php echo esc_attr($ticket->status); ?>" data-ticket-search="<?php echo esc_attr($search); ?>" data-ticket-updated="<?php echo absint($updated_timestamp); ?>" data-ticket-priority="<?php echo absint($priority_rank[$ticket->priority] ?? 1); ?>" data-ticket-unread="<?php echo $unread ? '1' : '0'; ?>" data-ticket-answered="<?php echo $answered?'1':'0'; ?>" data-ticket-status-rank="<?php echo absint($status_rank[$ticket->status] ?? 9); ?>">
            <header class="mph-ticket-summary">
                <button type="button" class="mph-ticket-toggle" data-ticket-toggle aria-expanded="false" aria-controls="<?php echo esc_attr($details_id); ?>">
                    <span class="mph-ticket-summary-main">
                        <span class="mph-ticket-title"><b>#<?php echo absint($ticket->id); ?> — <?php echo esc_html($ticket->subject); ?></b></span>
                        <small><?php echo esc_html(($mode !== 'user' ? $owner_name . ' — ' : '') . self::department_label($ticket->department) . ' — ' . date_i18n('Y/m/d H:i', strtotime($ticket->updated_at))); ?></small>
                        <span class="mph-ticket-preview"><b><?php echo esc_html(self::role_label($last_role)); ?>:</b> <?php echo esc_html(wp_trim_words(wp_strip_all_tags($last_body), 14, '…')); ?></span>
                    </span>
                    <span class="mph-ticket-badges">
                        <?php if ($unread) : ?><span class="mph-ticket-new">پاسخ جدید</span><?php endif; ?>
                        <span class="mph-ticket-message-count"><?php echo absint($message_count); ?> پیام</span>
                        <span class="mph-ticket-priority is-<?php echo esc_attr($ticket->priority); ?>"><?php echo esc_html(self::priority_label($ticket->priority)); ?></span>
                        <span class="mph-ticket-status is-<?php echo esc_attr($ticket->status); ?>"><?php echo esc_html(self::status_label($ticket->status)); ?></span>
                        <span class="dashicons dashicons-arrow-down-alt2 mph-ticket-chevron" aria-hidden="true"></span>
                    </span>
                </button>
            </header>

            <div class="mph-ticket-details" id="<?php echo esc_attr($details_id); ?>" hidden>
                <div class="mph-ticket-conversation">
                    <?php echo self::message_bubble(array(
                        'author_id' => $ticket->user_id,
                        'author_role' => $ticket->origin_role ?: 'user',
                        'message' => $ticket->message,
                        'attachment_id' => $ticket->attachment_id,
                        'created_at' => $ticket->created_at,
                    ), $ticket->id); ?>

                    <?php foreach ($messages as $message) : ?>
                        <?php echo self::message_bubble($message, $ticket->id); ?>
                    <?php endforeach; ?>
                </div>

                <?php if ($ticket->assigned_instructor_id) : ?>
                    <?php $teacher = get_user_by('id', $ticket->assigned_instructor_id); ?>
                    <div class="mph-ticket-assigned"><span class="dashicons dashicons-randomize"></span> ارجاع‌شده به مدرس <b><?php echo esc_html($teacher ? MPH_Helpers::display_name($teacher) : 'حذف‌شده'); ?></b></div>
                <?php elseif (!empty($ticket->assigned_therapist_id)) : ?>
                    <?php $therapist = get_user_by('id', $ticket->assigned_therapist_id); ?>
                    <div class="mph-ticket-assigned"><span class="dashicons dashicons-randomize"></span> ارجاع‌شده به درمانگر <b><?php echo esc_html($therapist ? MPH_Helpers::display_name($therapist) : 'حذف‌شده'); ?></b></div>
                <?php endif; ?>

                <?php echo self::reply_form($ticket, $mode, $staff); ?>
            </div>
        </article>
        <?php
        return ob_get_clean();
    }

    private static function message_bubble($message, $ticket_id) {
        $role = self::normalize_role(is_object($message) ? $message->author_role : $message['author_role']);
        $author_id = absint(is_object($message) ? $message->author_id : $message['author_id']);
        $body = is_object($message) ? $message->message : $message['message'];
        $attachment_id = absint(is_object($message) ? $message->attachment_id : $message['attachment_id']);
        $created_at = is_object($message) ? $message->created_at : $message['created_at'];
        $author = get_user_by('id', $author_id);

        ob_start();
        ?>
        <div class="mph-ticket-reply is-<?php echo esc_attr($role); ?>">
            <div class="mph-ticket-reply-meta">
                <span class="mph-ticket-avatar"><?php echo get_avatar($author_id, 36, '', '', array('class' => 'mph-ticket-avatar-image')); ?></span>
                <b><?php echo esc_html($author ? MPH_Helpers::display_name($author) : self::role_label($role)); ?></b>
                <span class="mph-ticket-role"><?php echo esc_html(self::role_label($role)); ?></span>
                <time><?php echo esc_html(date_i18n('Y/m/d H:i', strtotime($created_at))); ?></time>
            </div>
            <div class="mph-ticket-reply-body"><?php echo wpautop(esc_html($body)); ?></div>
            <?php if ($attachment_id) : ?><?php echo self::attachment_html($ticket_id, $attachment_id); ?><?php endif; ?>
        </div>
        <?php
        return ob_get_clean();
    }

    private static function reply_form($ticket, $mode, $staff) {
        $is_closed = $ticket->status === 'closed';
        ob_start();
        ?>
        <form class="mph-form mph-ticket-reply-form" data-mph-ticket-action="mph_ticket_v8_reply" enctype="multipart/form-data">
            <input type="hidden" name="ticket_id" value="<?php echo absint($ticket->id); ?>">
            <input type="hidden" name="ticket_mode" value="<?php echo esc_attr($mode); ?>">
            <div class="mph-ticket-reply-title">
                <span class="dashicons dashicons-format-chat"></span>
                <b><?php echo $mode === 'user' ? ($is_closed ? 'بازکردن دوباره و ادامه گفت‌وگو' : 'ادامه گفت‌وگو') : 'پاسخ در همین گفت‌وگو'; ?></b>
            </div>
            <label>متن پیام<textarea name="ticket_reply" maxlength="5000" placeholder="پیام خود را بنویسید…"></textarea></label>
            <div class="mph-field-grid">
                <label>پیوست <small>(اختیاری، حداکثر ۲ مگابایت)</small><input type="file" name="ticket_attachment" data-ticket-file data-mph-max-file="<?php echo absint(self::MAX_FILE_SIZE); ?>" accept="image/jpeg,image/png,image/webp,image/gif,application/pdf,.doc,.docx,.xls,.xlsx,.txt"></label>
                <div class="mph-ticket-file-state" data-ticket-file-state aria-live="polite"><span class="mph-ticket-file-empty">فایلی انتخاب نشده است.</span></div>
            </div>

            <?php if ($mode === 'manager') : ?>
                <div class="mph-forward-box">
                    <label class="mph-check"><input type="checkbox" name="forward_to_staff" value="1" data-ticket-forward> ارجاع یا تغییر پاسخ‌گو</label>
                    <select name="assigned_staff" disabled>
                        <option value="">مدرس یا درمانگر را انتخاب کنید</option>
                        <optgroup label="مدرس‌ها">
                            <?php foreach ($staff as $person) : if (!self::is_instructor_user($person)) continue; ?>
                                <option value="instructor:<?php echo absint($person->ID); ?>" <?php selected(absint($ticket->assigned_instructor_id), absint($person->ID)); ?>><?php echo esc_html(MPH_Helpers::display_name($person)); ?></option>
                            <?php endforeach; ?>
                        </optgroup>
                        <optgroup label="درمانگرها">
                            <?php foreach ($staff as $person) : if (!self::is_therapist_user($person)) continue; ?>
                                <option value="therapist:<?php echo absint($person->ID); ?>" <?php selected(absint($ticket->assigned_therapist_id ?? 0), absint($person->ID)); ?>><?php echo esc_html(MPH_Helpers::display_name($person)); ?></option>
                            <?php endforeach; ?>
                        </optgroup>
                    </select>
                </div>
            <?php endif; ?>

            <div class="mph-ticket-reply-actions">
                <button type="submit" class="mph-primary"><span class="dashicons dashicons-arrow-left-alt"></span> <?php echo $mode === 'user' ? 'ارسال پیام' : 'ثبت پاسخ'; ?></button>
                <?php if (!$is_closed) : ?>
                    <button type="submit" class="mph-ticket-close-button" name="ticket_operation" value="close"><span class="dashicons dashicons-dismiss"></span> بستن تیکت</button>
                <?php endif; ?>
            </div>
            <div class="mph-message" aria-live="polite"></div>
        </form>
        <?php
        return ob_get_clean();
    }

    public static function ajax_create() {
        self::verify_ajax();
        if (!is_user_logged_in()) {
            wp_send_json_error(array('message' => 'ابتدا وارد شوید.'), 401);
        }
        if (!self::maybe_install()) wp_send_json_error(array('message'=>'جدول‌های تیکت آماده نیستند؛ مدیر سایت سلامت افزونه را بررسی کند.'),503);
        if (!MPH_Security::allow('ticket_create', 10, HOUR_IN_SECONDS, 'u:'.get_current_user_id())) wp_send_json_error(array('message'=>'تعداد تیکت‌های ثبت‌شده بیش از حد مجاز است. کمی بعد دوباره تلاش کنید.'),429);

        $subject = MPH_Helpers::posted('ticket_subject');
        $message = MPH_Helpers::posted('ticket_message', 'textarea');
        $department = MPH_Helpers::posted('ticket_department', 'key');
        $priority = MPH_Helpers::posted('ticket_priority', 'key');
        $mode = MPH_Helpers::posted('ticket_mode', 'key') ?: 'user';

        if (!self::can_create_as($mode)) {
            wp_send_json_error(array('message' => 'نقش فعال برای ثبت تیکت معتبر نیست.'), 403);
        }
        if (!$subject || !$message || !in_array($department, array('education', 'payment', 'technical', 'other'), true) || !in_array($priority, array('normal', 'important', 'urgent'), true)) {
            wp_send_json_error(array('message' => 'اطلاعات تیکت کامل نیست.'));
        }

        $attachment = self::handle_upload('ticket_attachment');
        if (is_wp_error($attachment)) {
            wp_send_json_error(array('message' => $attachment->get_error_message()));
        }

        global $wpdb;
        $now = current_time('mysql');
        $ok = $wpdb->insert(self::tickets_table(), array(
            'user_id' => get_current_user_id(),
            'subject' => $subject,
            'message' => $message,
            'origin_role' => $mode,
            'department' => $department,
            'priority' => $priority,
            'status' => 'open',
            'attachment_id' => $attachment,
            'user_unread' => 0,
            'manager_unread' => $mode === 'manager' ? 0 : 1,
            'created_at' => $now,
            'updated_at' => $now,
        ), array('%d', '%s', '%s', '%s', '%s', '%s', '%s', '%d', '%d', '%d', '%s', '%s'));

        if (!$ok) {
            if ($attachment) {
                wp_delete_attachment($attachment, true);
            }
            wp_send_json_error(array('message' => 'ذخیره تیکت در پایگاه داده انجام نشد.'));
        }

        $ticket_id = absint($wpdb->insert_id);
        if($attachment)MPH_Private_Files::bind($attachment,'ticket',$ticket_id,get_current_user_id());
        self::notify_admin($ticket_id);
        wp_send_json_success(array('message' => 'تیکت ثبت شد.', 'html' => self::render($mode), 'focusTicket' => $ticket_id, 'uploadComplete' => (bool) $attachment));
    }

    public static function ajax_reply() {
        self::verify_ajax();
        if (!is_user_logged_in()) {
            wp_send_json_error(array('message' => 'ابتدا وارد شوید.'), 401);
        }
        if (!self::maybe_install()) wp_send_json_error(array('message'=>'جدول‌های تیکت آماده نیستند؛ مدیر سایت سلامت افزونه را بررسی کند.'),503);

        $ticket_id = absint($_POST['ticket_id'] ?? 0);
        $mode = MPH_Helpers::posted('ticket_mode', 'key');
        $ticket = self::get_ticket($ticket_id);

        if (!$ticket) {
            wp_send_json_error(array('message' => 'تیکت پیدا نشد.'));
        }
        if (!self::can_reply_as($ticket, $mode)) {
            wp_send_json_error(array('message' => 'اجازه پاسخ‌گویی در این نقش را ندارید.'), 403);
        }
        if (!MPH_Security::allow('ticket_reply', 40, 10 * MINUTE_IN_SECONDS, 'u:'.get_current_user_id().'|t:'.$ticket_id)) wp_send_json_error(array('message'=>'تعداد پیام‌های ارسالی بیش از حد مجاز است. کمی بعد دوباره تلاش کنید.'),429);

        $message = MPH_Helpers::posted('ticket_reply', 'textarea');
        $has_file = !empty($_FILES['ticket_attachment']['name']) || !empty($_POST['mph_attachment_id']);
        $forward = $mode === 'manager' && (!empty($_POST['forward_to_staff']) || !empty($_POST['forward_to_instructor']));
        $staff_type = '';
        $staff_id = 0;
        if ($forward) {
            $selection = sanitize_text_field(wp_unslash($_POST['assigned_staff'] ?? ''));
            // Compatibility with forms cached from version 24.x.
            if (!$selection && !empty($_POST['assigned_instructor'])) $selection = 'instructor:' . absint($_POST['assigned_instructor']);
            if (preg_match('/^(instructor|therapist):(\d+)$/', $selection, $matches)) {
                $staff_type = $matches[1];
                $staff_id = absint($matches[2]);
            }
        }
        $operation = MPH_Helpers::posted('ticket_operation', 'key');
        $close_ticket = $operation === 'close';
        if ($close_ticket) {
            $forward = false;
            $staff_type = '';
            $staff_id = 0;
        }

        if (!$message && !$has_file && !$forward && !$close_ticket) {
            wp_send_json_error(array('message' => 'متن پیام، پیوست، ارجاع یا بستن تیکت را مشخص کنید.'));
        }

        if ($forward) {
            $staff_user = get_user_by('id', $staff_id);
            $valid = $staff_type === 'instructor' ? self::is_instructor_user($staff_user) : ($staff_type === 'therapist' && self::is_therapist_user($staff_user));
            if (!$staff_user || !$valid) wp_send_json_error(array('message' => 'یک مدرس یا درمانگر معتبر انتخاب کنید.'));
        }

        $attachment = self::handle_upload('ticket_attachment');
        if (is_wp_error($attachment)) {
            wp_send_json_error(array('message' => $attachment->get_error_message()));
        }

        global $wpdb;
        $now = current_time('mysql');
        $has_new_message = (bool) ($message || $attachment);
        $wpdb->query('START TRANSACTION');

        if ($has_new_message) {
            $inserted = $wpdb->insert(self::messages_table(), array(
                'ticket_id' => $ticket_id,
                'author_id' => get_current_user_id(),
                'author_role' => $mode,
                'message' => $message ?: 'یک پیوست ارسال شد.',
                'attachment_id' => $attachment,
                'created_at' => $now,
            ), array('%d', '%d', '%s', '%s', '%d', '%s'));

            if (!$inserted) {
                $wpdb->query('ROLLBACK');
                if ($attachment) {
                    wp_delete_attachment($attachment, true);
                }
                wp_send_json_error(array('message' => 'ذخیره پاسخ در پایگاه داده انجام نشد.'));
            }
        }

        $update = array('updated_at' => $now);

        // مدیرِ سازنده نیز می‌تواند تیکت خودش را به یک پاسخ‌گو ارجاع دهد؛
        // در سایر عملیات، صاحب تیکت همیشه مانند درخواست‌دهنده رفتار می‌کند.
        $is_requester = absint($ticket->user_id) === get_current_user_id() && !$forward;
        if ($is_requester) {
            $has_assignment = absint($ticket->assigned_instructor_id) || absint($ticket->assigned_therapist_id ?? 0);
            $update['status'] = $close_ticket ? 'closed' : ($has_assignment ? 'forwarded' : 'open');
            $update['user_unread'] = 0;
            $update['manager_unread'] = 1;
            $update['instructor_unread'] = !$close_ticket && absint($ticket->assigned_instructor_id) ? 1 : 0;
            $update['therapist_unread'] = !$close_ticket && absint($ticket->assigned_therapist_id ?? 0) ? 1 : 0;
        } elseif (in_array($mode, array('instructor', 'therapist'), true)) {
            $update['status'] = $close_ticket ? 'closed' : 'answered';
            $update['user_unread'] = 1;
            $update['manager_unread'] = 1;
            $update[$mode === 'therapist' ? 'therapist_unread' : 'instructor_unread'] = 0;
        } else {
            $update['status'] = $close_ticket ? 'closed' : ($forward ? 'forwarded' : 'answered');
            $update['user_unread'] = 1;
            $update['manager_unread'] = 0;
            if ($forward) {
                $update['assigned_instructor_id'] = $staff_type === 'instructor' ? $staff_id : 0;
                $update['assigned_therapist_id'] = $staff_type === 'therapist' ? $staff_id : 0;
                $update['instructor_unread'] = $staff_type === 'instructor' ? 1 : 0;
                $update['therapist_unread'] = $staff_type === 'therapist' ? 1 : 0;
            } else {
                $update['instructor_unread'] = 0;
                $update['therapist_unread'] = 0;
            }
        }

        $formats = array();
        foreach ($update as $key => $value) $formats[] = in_array($key, array('updated_at', 'status'), true) ? '%s' : '%d';
        $updated = $wpdb->update(self::tickets_table(), $update, array('id' => $ticket_id), $formats, array('%d'));
        if ($updated === false) {
            $wpdb->query('ROLLBACK');
            if ($attachment) {
                wp_delete_attachment($attachment, true);
            }
            wp_send_json_error(array('message' => 'به‌روزرسانی تیکت انجام نشد.'));
        }

        $wpdb->query('COMMIT');
        if($attachment)MPH_Private_Files::bind($attachment,'ticket',$ticket_id,(int)$ticket->user_id);

        if ($is_requester) {
            if ($close_ticket) {
                self::notify_admin_status($ticket_id, 'درخواست‌دهنده تیکت را بست.');
            } else {
                self::notify_admin($ticket_id, true);
                if (absint($ticket->assigned_instructor_id)) {
                    self::notify_staff($ticket_id, $ticket->assigned_instructor_id, 'instructor', true);
                } elseif (absint($ticket->assigned_therapist_id ?? 0)) {
                    self::notify_staff($ticket_id, $ticket->assigned_therapist_id, 'therapist', true);
                }
            }
        } else {
            self::notify_user($ticket_id, $close_ticket);
            if ($forward) {
                self::notify_staff($ticket_id, $staff_id, $staff_type);
            }
        }

        $staff_label = $staff_type === 'therapist' ? 'درمانگر' : 'مدرس';
        $success = $close_ticket ? 'تیکت بسته شد.' : ($forward ? 'تیکت به '.$staff_label.' ارجاع شد و همان گفت‌وگو برای او باز است.' : ($is_requester ? 'پیام ارسال شد و تیکت در انتظار پاسخ قرار گرفت.' : 'پاسخ ثبت شد و وضعیت به «پاسخ داده‌شده» تغییر کرد.'));
        wp_send_json_success(array('message' => $success, 'html' => self::render($mode), 'focusTicket' => $ticket_id, 'uploadComplete' => (bool) $attachment));
    }

    /** بررسی سبک اعلان برای نمایش پاسخ تازه بدون رفرش صفحه. */
    public static function ajax_alert_status() {
        self::verify_ajax();
        if (!is_user_logged_in()) {
            wp_send_json_error(array('message' => 'دسترسی ندارید.'), 403);
        }

        $mode = MPH_Helpers::posted('ticket_mode', 'key');
        if ($mode === 'user') {
            $allowed = true;
        } elseif ($mode === 'instructor') {
            $allowed = self::current_user_is_instructor();
        } elseif ($mode === 'therapist') {
            $allowed = self::current_user_is_therapist();
        } elseif ($mode === 'manager') {
            $allowed = self::is_manager();
        } else {
            $allowed = false;
        }

        if (!$allowed) {
            wp_send_json_error(array('message' => 'نقش فعال معتبر نیست.'), 403);
        }

        wp_send_json_success(array(
            'hasAlert' => self::has_alert($mode, get_current_user_id()),
        ));
    }

    public static function ajax_mark_read() {
        self::verify_ajax();
        if (!is_user_logged_in()) {
            wp_send_json_error(array('message' => 'دسترسی ندارید.'), 403);
        }

        $mode = MPH_Helpers::posted('ticket_mode', 'key');
        $user_id = get_current_user_id();
        global $wpdb;

        if ($mode === 'user') {
            $updated=$wpdb->query($wpdb->prepare('UPDATE '.self::tickets_table().' SET user_unread=0 WHERE user_id=%d AND user_unread=1',$user_id));
        } elseif ($mode === 'instructor' && self::current_user_is_instructor()) {
            $updated=$wpdb->query($wpdb->prepare('UPDATE '.self::tickets_table().' SET user_unread=IF(user_id=%d,0,user_unread), instructor_unread=IF(assigned_instructor_id=%d,0,instructor_unread) WHERE (user_id=%d AND user_unread=1) OR (assigned_instructor_id=%d AND instructor_unread=1)',$user_id,$user_id,$user_id,$user_id));
        } elseif ($mode === 'therapist' && self::current_user_is_therapist()) {
            $updated=$wpdb->query($wpdb->prepare('UPDATE '.self::tickets_table().' SET user_unread=IF(user_id=%d,0,user_unread), therapist_unread=IF(assigned_therapist_id=%d,0,therapist_unread) WHERE (user_id=%d AND user_unread=1) OR (assigned_therapist_id=%d AND therapist_unread=1)',$user_id,$user_id,$user_id,$user_id));
        } elseif ($mode === 'manager' && self::is_manager()) {
            $updated=$wpdb->query($wpdb->prepare('UPDATE '.self::tickets_table().' SET manager_unread=0, user_unread=IF(user_id=%d,0,user_unread) WHERE manager_unread=1 OR (user_id=%d AND user_unread=1)',$user_id,$user_id));
        } else {
            wp_send_json_error(array('message' => 'نمای فعال برای خواندن پیام معتبر نیست.'), 403);
        }
        if($updated===false)wp_send_json_error(array('message'=>'پاک‌کردن اعلان پاسخ‌ها در پایگاه داده انجام نشد.'));
        $wpdb->flush();

        wp_send_json_success(array(
            'message' => 'پیام‌های جدید خوانده شدند.',
            'html' => self::render($mode),
            'clearTicketAlert' => true,
            'hasAlert' => false,
        ));
    }

    public static function has_alert($mode, $user_id = 0) {
        if (!self::tables_ready()) return false;
        global $wpdb;
        $user_id = $user_id ?: get_current_user_id();

        if ($mode === 'user') {
            $sql = $wpdb->prepare('SELECT id FROM ' . self::tickets_table() . ' WHERE user_id=%d AND user_unread=1 LIMIT 1', $user_id);
        } elseif ($mode === 'instructor') {
            $sql = $wpdb->prepare('SELECT id FROM ' . self::tickets_table() . ' WHERE (user_id=%d AND user_unread=1) OR (assigned_instructor_id=%d AND instructor_unread=1) LIMIT 1', $user_id, $user_id);
        } elseif ($mode === 'therapist') {
            $sql = $wpdb->prepare('SELECT id FROM ' . self::tickets_table() . ' WHERE (user_id=%d AND user_unread=1) OR (assigned_therapist_id=%d AND therapist_unread=1) LIMIT 1', $user_id, $user_id);
        } elseif ($mode === 'manager' && self::is_manager()) {
            $sql = $wpdb->prepare('SELECT id FROM ' . self::tickets_table() . ' WHERE manager_unread=1 OR (user_id=%d AND user_unread=1) LIMIT 1', $user_id);
        } else {
            return false;
        }

        return (bool) $wpdb->get_var($sql);
    }

    public static function notification_payload($mode,$user_id=0) {
        if(!self::tables_ready())return array();$mode=in_array($mode,array('user','instructor','therapist','manager'),true)?$mode:'user';$user_id=absint($user_id?:get_current_user_id());if(!$user_id)return array();global$wpdb;$table=self::tickets_table();
        if($mode==='manager'&&self::is_manager())$sql="SELECT * FROM {$table} WHERE manager_unread=1 OR (user_id=%d AND user_unread=1) ORDER BY updated_at DESC LIMIT 1";
        elseif($mode==='instructor')$sql="SELECT * FROM {$table} WHERE (user_id=%d AND user_unread=1) OR (assigned_instructor_id=%d AND instructor_unread=1) ORDER BY updated_at DESC LIMIT 1";
        elseif($mode==='therapist')$sql="SELECT * FROM {$table} WHERE (user_id=%d AND user_unread=1) OR (assigned_therapist_id=%d AND therapist_unread=1) ORDER BY updated_at DESC LIMIT 1";
        else$sql="SELECT * FROM {$table} WHERE user_id=%d AND user_unread=1 ORDER BY updated_at DESC LIMIT 1";
        $args=in_array($mode,array('instructor','therapist'),true)?array($user_id,$user_id):array($user_id);$ticket=$wpdb->get_row($wpdb->prepare($sql,$args));if(!$ticket)return array();$stamp=strtotime($ticket->updated_at)?:time();return array('id'=>'ticket-'.$ticket->id.'-'.$stamp,'type'=>'ticket','title'=>'تیکت #'.absint($ticket->id).' — '.$ticket->subject,'body'=>self::status_label($ticket->status).' · '.self::priority_label($ticket->priority),'panel'=>'ticket_support','timestamp'=>$stamp,'icon'=>'dashicons-sos');
    }

    public static function manager_counts() {
        if (!self::tables_ready()) return array('total'=>0, 'open'=>0);
        global $wpdb;
        $total = absint($wpdb->get_var('SELECT COUNT(*) FROM ' . self::tickets_table()));
        $open = absint($wpdb->get_var("SELECT COUNT(*) FROM " . self::tickets_table() . " WHERE status IN ('open','forwarded')"));
        return array('total' => $total, 'open' => $open);
    }

    /** ساخت پیام‌های سیستمی از ماژول‌های نقش، پرداخت، گواهی و اطلاعیه. */
    public static function create_system_notification($user_id, $subject, $message, $department = 'system') {
        $user_id = absint($user_id);
        if (!$user_id || !get_user_by('id', $user_id) || !$subject || !$message) {
            return false;
        }
        if (class_exists('MPH_Growth') && !MPH_Growth::allows($user_id, 'inapp')) return false;

        if (!self::maybe_install()) return false;
        global $wpdb;
        $now = current_time('mysql');
        $department = sanitize_key($department);
        $ok = $wpdb->insert(self::tickets_table(), array(
            'user_id' => $user_id,
            'subject' => sanitize_text_field($subject),
            'message' => sanitize_textarea_field($message),
            'origin_role' => $department === 'announcement' ? 'instructor' : 'manager',
            'department' => $department,
            'priority' => 'normal',
            'status' => 'answered',
            'user_unread' => 1,
            'created_at' => $now,
            'updated_at' => $now,
        ), array('%d', '%s', '%s', '%s', '%s', '%s', '%s', '%d', '%s', '%s'));

        return $ok ? absint($wpdb->insert_id) : false;
    }

    public static function create_system_notifications($user_ids, $subject, $message, $department = 'system') {
        $ids = array_values(array_unique(array_filter(array_map('absint', (array) $user_ids))));
        if (!$ids || !$subject || !$message) {
            return 0;
        }

        if (!self::maybe_install()) return 0;
        global $wpdb;
        $table = self::tickets_table();
        $subject = sanitize_text_field($subject);
        $message = sanitize_textarea_field($message);
        $department = sanitize_key($department);
        $now = current_time('mysql');
        $created = 0;

        foreach (array_chunk($ids, 100) as $chunk) {
            $parts = array();
            $values = array();
            foreach ($chunk as $user_id) {
                $parts[] = '(%d,%s,%s,%s,%s,%s,%s,%d,%s,%s)';
                array_push($values, $user_id, $subject, $message, $department === 'announcement' ? 'instructor' : 'manager', $department, 'normal', 'answered', 1, $now, $now);
            }
            $sql = "INSERT INTO {$table} (user_id,subject,message,origin_role,department,priority,status,user_unread,created_at,updated_at) VALUES " . implode(',', $parts);
            $result = $wpdb->query($wpdb->prepare($sql, ...$values));
            if ($result) {
                $created += absint($result);
            }
        }

        return $created;
    }

    public static function prevent_portal_cache() {
        if (!is_user_logged_in() || !is_singular()) {
            return;
        }
        $settings = get_option(MPH_Helpers::SETTINGS, array());
        if (absint($settings['account_page_id'] ?? 0) !== get_queried_object_id()) {
            return;
        }
        if (!defined('DONOTCACHEPAGE')) {
            define('DONOTCACHEPAGE', true);
        }
        nocache_headers();
    }

    public static function download_attachment() {
        if (!is_user_logged_in()) {
            auth_redirect();
        }

        $ticket_id = absint($_GET['ticket_id'] ?? 0);
        $attachment_id = absint($_GET['attachment_id'] ?? 0);
        $nonce = sanitize_text_field(wp_unslash($_GET['_wpnonce'] ?? ''));

        if (!$ticket_id || !$attachment_id || !wp_verify_nonce($nonce, 'mph_ticket_v8_file_' . $ticket_id . '_' . $attachment_id)) {
            wp_die('لینک معتبر نیست.', '', array('response' => 403));
        }

        $ticket = self::get_ticket($ticket_id);
        if (!$ticket || !self::can_access($ticket)) {
            wp_die('دسترسی ندارید.', '', array('response' => 403));
        }
        if (!self::attachment_belongs($ticket_id, $attachment_id)) {
            wp_die('فایل متعلق به این تیکت نیست.', '', array('response' => 403));
        }

        $path = get_attached_file($attachment_id);
        if (!$path || !is_readable($path)) {
            wp_die('فایل پیدا نشد.', '', array('response' => 404));
        }

        while (ob_get_level()) {
            ob_end_clean();
        }
        nocache_headers();
        header('Content-Type: ' . (get_post_mime_type($attachment_id) ?: 'application/octet-stream'));
        header('X-Content-Type-Options: nosniff');
        header('Content-Disposition: attachment; filename="' . sanitize_file_name(basename($path)) . '"');
        header('Content-Length: ' . filesize($path));
        readfile($path);
        exit;
    }

    private static function query_tickets($mode, $user_id) {
        global $wpdb;
        $table = self::tickets_table();
        if ($mode === 'manager') {
            $sql = "SELECT * FROM {$table} ORDER BY FIELD(priority,'urgent','important','normal'), updated_at DESC LIMIT 100";
        } elseif ($mode === 'instructor') {
            $sql = $wpdb->prepare("SELECT * FROM {$table} WHERE user_id=%d OR assigned_instructor_id=%d ORDER BY IF(user_id=%d,user_unread,instructor_unread) DESC, updated_at DESC LIMIT 100", $user_id, $user_id, $user_id);
        } elseif ($mode === 'therapist') {
            $sql = $wpdb->prepare("SELECT * FROM {$table} WHERE user_id=%d OR assigned_therapist_id=%d ORDER BY IF(user_id=%d,user_unread,therapist_unread) DESC, updated_at DESC LIMIT 100", $user_id, $user_id, $user_id);
        } else {
            $sql = $wpdb->prepare("SELECT * FROM {$table} WHERE user_id=%d ORDER BY user_unread DESC, updated_at DESC LIMIT 100", $user_id);
        }
        return $wpdb->get_results($sql);
    }

    private static function messages($ticket_id) {
        global $wpdb;
        return $wpdb->get_results($wpdb->prepare(
            'SELECT * FROM ' . self::messages_table() . ' WHERE ticket_id=%d ORDER BY created_at ASC, id ASC',
            $ticket_id
        ));
    }

    private static function get_ticket($id) {
        global $wpdb;
        return $wpdb->get_row($wpdb->prepare('SELECT * FROM ' . self::tickets_table() . ' WHERE id=%d LIMIT 1', $id));
    }

    private static function status_counts($tickets) {
        $counts = array('open' => 0, 'forwarded' => 0, 'answered' => 0, 'closed' => 0);
        foreach ($tickets as $ticket) {
            if (isset($counts[$ticket->status])) {
                $counts[$ticket->status]++;
            }
        }
        return $counts;
    }

    private static function stats_html($counts, $total) {
        return '<div class="mph-ticket-stats"><div><b>' . absint($total) . '</b><span>همه</span></div><div><b>' . absint($counts['open']) . '</b><span>در انتظار</span></div><div><b>' . absint($counts['forwarded']) . '</b><span>ارجاع‌شده</span></div><div><b>' . absint($counts['answered']) . '</b><span>پاسخ‌داده‌شده</span></div></div>';
    }

    private static function empty_html($mode) {
        $message = $mode === 'manager' ? 'هنوز تیکتی ثبت نشده است.' : (in_array($mode, array('instructor', 'therapist'), true) ? 'هنوز تیکتی ثبت نکرده‌اید و موردی هم به شما ارجاع نشده است.' : 'هنوز تیکتی ندارید.');
        return '<div class="mph-empty"><span class="dashicons dashicons-sos"></span><p>' . esc_html($message) . '</p></div>';
    }

    public static function enqueue_assets() {
        if (!wp_script_is('mph-tickets-v11', 'registered')) self::register_assets();
        wp_enqueue_script('mph-tickets-v11');
        static $localized = false;
        if (!$localized) {
            wp_localize_script('mph-tickets-v11', 'MPH_TICKET_DATA', self::client_data());
            $localized = true;
        }
    }

    public static function client_data($mode='') {
        return array(
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('mph_ticket_nonce'),
            'working' => 'در حال ارسال…',
            'connectionError' => 'پاسخ معتبر از سرور دریافت نشد.',
            'maxFile' => self::MAX_FILE_SIZE,
            'mode' => $mode ? MPH_Helpers::allowed_mode($mode) : MPH_Helpers::current_mode(),
            'pollInterval' => 30000,
            'requestTimeout' => 45000,
        );
    }

    private static function verify_ajax() {
        nocache_headers();
        if (!check_ajax_referer('mph_ticket_nonce', 'nonce', false)) {
            wp_send_json_error(array('message' => 'نشست منقضی شده؛ صفحه را تازه‌سازی کنید.'), 403);
        }
    }

    private static function tickets_table() {
        global $wpdb;
        return $wpdb->prefix . 'mph_tickets';
    }

    private static function messages_table() {
        global $wpdb;
        return $wpdb->prefix . 'mph_ticket_messages';
    }

    public static function tables_ready($refresh = false) {
        static $ready = null;
        if (!$refresh && $ready !== null) return $ready;

        global $wpdb;
        foreach (array(self::tickets_table(), self::messages_table()) as $table) {
            if ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $table)) !== $table) return $ready = false;
        }

        $ticket_columns = (array) $wpdb->get_col('SHOW COLUMNS FROM ' . self::tickets_table(), 0);
        $message_columns = (array) $wpdb->get_col('SHOW COLUMNS FROM ' . self::messages_table(), 0);
        $required_ticket_columns = array(
            'id', 'user_id', 'subject', 'message', 'origin_role', 'department',
            'priority', 'status', 'assigned_instructor_id', 'assigned_therapist_id',
            'attachment_id', 'user_unread', 'manager_unread', 'instructor_unread',
            'therapist_unread', 'legacy_id', 'created_at', 'updated_at',
        );
        $required_message_columns = array(
            'id', 'ticket_id', 'author_id', 'author_role', 'message',
            'attachment_id', 'legacy_key', 'created_at',
        );

        return $ready = !array_diff($required_ticket_columns, $ticket_columns)
            && !array_diff($required_message_columns, $message_columns);
    }

    private static function handle_upload($field) {
        if (!empty($_POST['mph_attachment_id'])) return MPH_Private_Files::staged(absint($_POST['mph_attachment_id']),'ticket');
        if (empty($_FILES[$field]['name'])) {
            return 0;
        }

        $file = $_FILES[$field];
        if (!empty($file['error'])) {
            return new WP_Error('upload_error', 'آپلود فایل انجام نشد.');
        }
        if (absint($file['size']) > self::MAX_FILE_SIZE) {
            return new WP_Error('large', 'حجم فایل باید حداکثر ۲ مگابایت باشد.');
        }

        $allowed = array(
            'jpg|jpeg|jpe' => 'image/jpeg',
            'png' => 'image/png',
            'gif' => 'image/gif',
            'webp' => 'image/webp',
            'pdf' => 'application/pdf',
            'txt' => 'text/plain',
            'doc' => 'application/msword',
            'docx' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
            'xls' => 'application/vnd.ms-excel',
            'xlsx' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        );

        $safe_name = sanitize_file_name($file['name']);
        $check = wp_check_filetype_and_ext($file['tmp_name'], $safe_name, $allowed);
        if (empty($check['type']) || empty($check['ext'])) {
            return new WP_Error('type', 'فرمت فایل مجاز نیست.');
        }
        $file['name'] = $safe_name;
        $_FILES[$field]['name'] = $safe_name;
        $inspection = apply_filters('mph_ticket_file_is_safe', true, $file, $check);
        if (is_wp_error($inspection)) return $inspection;
        if ($inspection !== true) return new WP_Error('unsafe_file', 'فایل پیوست توسط کنترل امنیتی رد شد.');

        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/media.php';
        require_once ABSPATH . 'wp-admin/includes/image.php';
        $id = media_handle_upload($field, 0, array(), array('test_form' => false, 'mimes' => $allowed));
        if (is_wp_error($id)) {
            return $id;
        }

        $path = get_attached_file($id);
        if (!$path || !is_readable($path) || filesize($path) > self::MAX_FILE_SIZE) {
            wp_delete_attachment($id, true);
            return new WP_Error('invalid', 'فایل آپلودشده معتبر نیست یا بیشتر از ۲ مگابایت است.');
        }

        $secured=MPH_Private_Files::protect($id,'draft',0,get_current_user_id());
        if(is_wp_error($secured)){wp_delete_attachment($id,true);return $secured;}
        update_post_meta($id,'_mph_upload_purpose','ticket');
        return absint($id);
    }

    private static function attachment_html($ticket_id, $attachment_id) {
        $url = wp_nonce_url(
            admin_url('admin-post.php?action=mph_ticket_v8_file&ticket_id=' . absint($ticket_id) . '&attachment_id=' . absint($attachment_id)),
            'mph_ticket_v8_file_' . absint($ticket_id) . '_' . absint($attachment_id)
        );
        $mime = (string) get_post_mime_type($attachment_id);
        $name = basename((string) get_attached_file($attachment_id));
        $preview = strpos($mime, 'image/') === 0
            ? wp_get_attachment_image($attachment_id, 'thumbnail', false, array('alt' => 'پیوست'))
            : '<span class="dashicons dashicons-media-document"></span>';

        return '<a class="mph-ticket-attachment" href="' . esc_url($url) . '">' . $preview . '<span><b>' . esc_html($name) . '</b><small>دانلود پیوست</small></span><span class="dashicons dashicons-download"></span></a>';
    }

    private static function attachment_belongs($ticket_id, $attachment_id) {
        global $wpdb;
        if (absint($wpdb->get_var($wpdb->prepare('SELECT attachment_id FROM ' . self::tickets_table() . ' WHERE id=%d', $ticket_id))) === $attachment_id) {
            return true;
        }
        return (bool) $wpdb->get_var($wpdb->prepare(
            'SELECT id FROM ' . self::messages_table() . ' WHERE ticket_id=%d AND attachment_id=%d LIMIT 1',
            $ticket_id,
            $attachment_id
        ));
    }

    public static function file_access($ticket_id,$file_id,$user_id) {
        $ticket=self::get_ticket(absint($ticket_id));if(!$ticket || !self::attachment_belongs(absint($ticket_id),absint($file_id)))return false;
        $user_id=absint($user_id);return $user_id>0 && ((int)$ticket->user_id===$user_id || user_can($user_id,'manage_options') || user_can($user_id,'mph_manage_portal') || ((int)$ticket->assigned_instructor_id===$user_id && self::is_instructor_user(get_user_by('id',$user_id))) || ((int)($ticket->assigned_therapist_id??0)===$user_id && self::is_therapist_user(get_user_by('id',$user_id))));
    }

    private static function can_access($ticket) {
        return absint($ticket->user_id) === get_current_user_id()
            || self::is_manager()
            || (self::current_user_is_instructor() && absint($ticket->assigned_instructor_id) === get_current_user_id())
            || (self::current_user_is_therapist() && absint($ticket->assigned_therapist_id ?? 0) === get_current_user_id());
    }

    private static function can_reply_as($ticket, $mode) {
        if (absint($ticket->user_id) === get_current_user_id()) return self::can_create_as($mode);
        if ($mode === 'user') return false;
        if ($mode === 'manager') {
            return self::is_manager();
        }
        if ($mode === 'instructor') {
            return self::current_user_is_instructor() && absint($ticket->assigned_instructor_id) === get_current_user_id();
        }
        if ($mode === 'therapist') {
            return self::current_user_is_therapist() && absint($ticket->assigned_therapist_id ?? 0) === get_current_user_id();
        }
        return false;
    }

    private static function can_create_as($mode) {
        if (!is_user_logged_in()) return false;
        if ($mode === 'user') return true;
        if ($mode === 'instructor') return self::current_user_is_instructor();
        if ($mode === 'therapist') return self::current_user_is_therapist();
        if ($mode === 'manager') return self::is_manager();
        return false;
    }

    private static function is_manager() {
        return MPH_Helpers::has_role('mph_manager') || current_user_can('mph_manage_portal') || current_user_can('manage_options') || (class_exists('MPH_Manager') && MPH_Manager::is_portal_super_admin());
    }

    private static function current_user_is_instructor() {
        $user = wp_get_current_user();
        return self::is_instructor_user($user);
    }

    private static function is_instructor_user($user) {
        if (!$user || empty($user->ID)) {
            return false;
        }
        $roles = (array) $user->roles;
        return in_array('mph_instructor', $roles, true) || in_array('tutor_instructor', $roles, true);
    }

    private static function current_user_is_therapist() {
        return self::is_therapist_user(wp_get_current_user());
    }

    private static function is_therapist_user($user) {
        return $user && !empty($user->ID) && in_array('mph_therapist', (array) $user->roles, true);
    }

    private static function normalize_role($role) {
        $role = sanitize_key((string) $role);
        if (in_array($role, array('user', 'subscriber', 'customer', 'student'), true)) {
            return 'user';
        }
        if (in_array($role, array('instructor', 'teacher', 'mph_instructor', 'tutor_instructor'), true)) {
            return 'instructor';
        }
        if (in_array($role, array('therapist', 'mph_therapist'), true)) return 'therapist';
        return 'manager';
    }

    private static function role_label($role) {
        $labels = array('user' => 'کاربر', 'manager' => 'مدیر', 'instructor' => 'مدرس', 'therapist' => 'درمانگر');
        return $labels[self::normalize_role($role)] ?? 'پشتیبانی';
    }

    private static function status_label($status) {
        $labels = array(
            'open' => 'در انتظار پاسخ',
            'forwarded' => 'در انتظار پاسخ‌گوی ارجاعی',
            'answered' => 'پاسخ داده‌شده',
            'closed' => 'بسته‌شده',
        );
        return $labels[$status] ?? 'در حال بررسی';
    }

    private static function priority_label($priority) {
        $labels = array('normal' => 'عادی', 'important' => 'مهم', 'urgent' => 'فوری');
        return $labels[$priority] ?? 'عادی';
    }

    private static function department_label($department) {
        $labels = array(
            'education' => 'آموزشی',
            'payment' => 'پرداخت و سفارش',
            'technical' => 'فنی',
            'role' => 'نقش کاربری',
            'certificate' => 'گواهی‌نامه',
            'announcement' => 'اطلاعیه مدرس',
            'system' => 'پیام سیستمی',
            'other' => 'سایر',
        );
        return $labels[$department] ?? 'سایر';
    }

    private static function notify_admin($id, $is_reply = false) {
        $email = get_option('admin_email');
        if (is_email($email)) {
            wp_mail($email, ($is_reply ? 'پیام جدید کاربر در تیکت #' : 'تیکت جدید #') . $id, $is_reply ? 'کاربر پیام تازه‌ای در گفت‌وگوی تیکت ثبت کرده است.' : 'یک تیکت جدید ثبت شده است.');
        }
    }

    private static function notify_admin_status($id, $message) {
        $email = get_option('admin_email');
        if (is_email($email)) {
            wp_mail($email, 'تغییر وضعیت تیکت #' . $id, sanitize_text_field($message));
        }
    }

    private static function notify_staff($id, $user_id, $staff_type = 'instructor', $is_reply = false) {
        $user = get_user_by('id', $user_id);
        if ($user && is_email($user->user_email) && strpos($user->user_email, '.invalid') === false) {
            $label = $staff_type === 'therapist' ? 'درمانگر' : 'مدرس';
            wp_mail($user->user_email, ($is_reply ? 'پیام جدید در تیکت #' : 'ارجاع تیکت #') . $id, $is_reply ? 'کاربر در تیکت ارجاع‌شده پیام تازه‌ای فرستاد.' : 'یک تیکت برای پاسخ به شما به‌عنوان '.$label.' ارجاع شد.');
        }
    }

    private static function notify_user($id, $closed = false) {
        $ticket = self::get_ticket($id);
        $user = $ticket ? get_user_by('id', $ticket->user_id) : false;
        if ($user && is_email($user->user_email) && strpos($user->user_email, '.invalid') === false) {
            wp_mail($user->user_email, ($closed ? 'بسته‌شدن تیکت #' : 'پاسخ تیکت #') . $id, $closed ? 'تیکت شما توسط پشتیبانی بسته شد.' : 'پاسخ جدیدی در گفت‌وگوی تیکت شما ثبت شد.');
        }
    }
}
