<?php
defined('ABSPATH') || exit;

/** مرکز سلامت فنی، امنیت و پرداخت افزونه در پیشخوان وردپرس. */
final class MPH_Health {
    public static function init() {
        add_action('admin_menu', array(__CLASS__, 'menu'), 20);
        add_action('admin_post_mph_health_action', array(__CLASS__, 'handle_action'));
    }

    public static function menu() {
        add_submenu_page('mph','سلامت و امنیت','سلامت و امنیت','manage_options','mph-health',array(__CLASS__,'page'));
    }

    public static function page() {
        if (!current_user_can('manage_options')) wp_die('دسترسی ندارید.');
        $checks=self::checks();$passed=0;foreach($checks as$check)if($check['status']==='good')$passed++;
        $score=$checks?(int)round(100*$passed/count($checks)):0;$last=get_option('mph_last_payment_reconciliation',array());
        $notice=sanitize_text_field(wp_unslash($_GET['mph_health_notice']??'')); ?>
        <div class="wrap mph-admin mph-health-admin" dir="rtl">
            <header class="mph-admin-head"><span class="dashicons dashicons-shield-alt"></span><div><h1>مرکز سلامت و امنیت</h1><p>کنترل یک‌جای زیرساخت، ایمیل، پرداخت، زمان‌بندی و ثبت رخدادها</p></div><div class="mph-health-score is-<?php echo $score>=90?'good':($score>=70?'warn':'bad'); ?>"><strong><?php echo esc_html($score); ?></strong><span>امتیاز سلامت</span></div></header>
            <?php if($notice): ?><div class="notice notice-success is-dismissible"><p><?php echo esc_html($notice); ?></p></div><?php endif; ?>
            <div class="mph-health-grid"><?php foreach($checks as$check): ?><article class="is-<?php echo esc_attr($check['status']); ?>"><span class="dashicons <?php echo esc_attr($check['icon']); ?>"></span><div><h3><?php echo esc_html($check['label']); ?></h3><p><?php echo esc_html($check['message']); ?></p></div><i><?php echo $check['status']==='good'?'سالم':($check['status']==='warn'?'نیازمند توجه':'خطا'); ?></i></article><?php endforeach; ?></div>
            <div class="mph-health-columns">
                <section class="mph-admin-box"><div class="mph-builder-head"><div><h2>اقدام‌های نگهداری</h2><p>کنترل‌ها با nonce و دسترسی مدیریت اجرا می‌شوند.</p></div></div>
                    <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" class="mph-health-actions"><?php wp_nonce_field('mph_health_action'); ?><input type="hidden" name="action" value="mph_health_action"><button class="button button-primary" name="task" value="test_mail"><span class="dashicons dashicons-email-alt"></span>ارسال ایمیل آزمایشی</button><button class="button" name="task" value="reconcile"><span class="dashicons dashicons-update"></span>تطبیق پرداخت‌های باز</button><button class="button" name="task" value="maintenance"><span class="dashicons dashicons-admin-tools"></span>اجرای نگهداری</button></form>
                    <p class="mph-health-foot">آخرین تطبیق: <?php echo !empty($last['time'])?esc_html(wp_date('Y/m/d H:i',absint($last['time']),wp_timezone())):'هنوز اجرا نشده'; ?><?php if(!empty($last['result'])&&is_array($last['result'])): ?> — بررسی <?php echo absint($last['result']['checked']??0); ?>، تأیید <?php echo absint($last['result']['paid']??0); ?><?php endif; ?></p>
                </section>
                <section class="mph-admin-box"><div class="mph-builder-head"><div><h2>سیاست نگهداری فایل</h2><p>فیش‌های قدیمی پس از پایان مهلت حذف می‌شوند؛ سوابق سفارش باقی می‌ماند.</p></div></div><form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" class="mph-health-setting"><?php wp_nonce_field('mph_health_action'); ?><input type="hidden" name="action" value="mph_health_action"><input type="hidden" name="task" value="save_retention"><label>نگهداری فیش (روز)<input type="number" min="30" max="730" name="retention_days" value="<?php echo esc_attr(max(30,absint(get_option('mph_receipt_retention_days',180)))); ?>"></label><button class="button button-primary">ذخیره سیاست</button></form></section>
            </div>
            <?php self::security_log(); ?>
        </div><?php
    }

    public static function handle_action() {
        if(!current_user_can('manage_options'))wp_die('دسترسی ندارید.','',array('response'=>403));check_admin_referer('mph_health_action');$task=sanitize_key(wp_unslash($_POST['task']??''));$message='عملیات انجام شد.';
        if($task==='test_mail'){$email=sanitize_email(get_option('admin_email'));$sent=$email&&wp_mail($email,'آزمایش ایمیل افزونه | '.get_bloginfo('name'),"این پیام برای کنترل مسیر ارسال ایمیل مدیریت ایجاد شده است.\nزمان: ".current_time('mysql'),MPH_Password_Recovery::management_headers());$message=$sent?'ایمیل آزمایشی از نشانی مدیریت ارسال شد.':'ارسال ایمیل ناموفق بود؛ SMTP و ایمیل مدیریت را بررسی کنید.';MPH_Security::audit($sent?'health_mail_test_sent':'health_mail_test_failed','to='.MPH_Security::mask_email($email));}
        elseif($task==='reconcile'){$result=MPH_Payments::reconcile_pending_orders(50,true);$message='تطبیق کامل شد: '.absint($result['checked']).' بررسی و '.absint($result['paid']).' پرداخت تأیید شد.';}
        elseif($task==='maintenance'){MPH_Security::daily_maintenance();$tickets=MPH_Tickets::maybe_install();$notices=MPH_Notices::maybe_install();$message=$tickets&&$notices?'پاک‌سازی دوره‌ای، بازسازی جدول‌ها، قفل‌ها و کنترل پرداخت انجام شد.':'نگهداری اجرا شد اما یک جدول کامل ساخته نشد؛ دسترسی نوشتن پایگاه‌داده را بررسی کنید.';}
        elseif($task==='save_retention'){$days=max(30,min(730,absint($_POST['retention_days']??180)));update_option('mph_receipt_retention_days',$days,false);$message='سیاست نگهداری فیش روی '.$days.' روز تنظیم شد.';}
        wp_safe_redirect(add_query_arg(array('page'=>'mph-health','mph_health_notice'=>$message),admin_url('admin.php')));exit;
    }

    private static function checks() {
        global $wpdb,$wp_version;$settings=get_option(MPH_Helpers::SETTINGS,array());$page_id=absint($settings['account_page_id']??0);$tables=array($wpdb->prefix.'mph_security_log',$wpdb->prefix.'mph_slot_locks',$wpdb->prefix.'mph_tickets',$wpdb->prefix.'mph_ticket_messages',$wpdb->prefix.'mph_announcements');$tables_ok=true;foreach($tables as$table)if($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$table))!==$table)$tables_ok=false;
        $email=sanitize_email(get_option('admin_email'));$gateways=MPH_Payments::enabled_names();$cron=!defined('DISABLE_WP_CRON')||!DISABLE_WP_CRON;$crypto=function_exists('sodium_crypto_secretbox')||function_exists('openssl_encrypt');$chain=self::verify_log_chain();
        return array(
            array('label'=>'نسخه PHP','status'=>version_compare(PHP_VERSION,'7.4','>=')?'good':'bad','message'=>'نسخه فعال: '.PHP_VERSION,'icon'=>'dashicons-editor-code'),
            array('label'=>'نسخه وردپرس','status'=>version_compare($wp_version,'6.2','>=')?'good':'warn','message'=>'نسخه فعال: '.$wp_version,'icon'=>'dashicons-wordpress'),
            array('label'=>'ارتباط امن HTTPS','status'=>is_ssl()?'good':'bad','message'=>is_ssl()?'صفحات با TLS بارگذاری می‌شوند.':'HTTPS فعال نیست؛ ورود و پرداخت در خطر است.','icon'=>'dashicons-lock'),
            array('label'=>'WooCommerce','status'=>class_exists('WooCommerce')?'good':'bad','message'=>class_exists('WooCommerce')?'موتور سفارش و پرداخت در دسترس است.':'WooCommerce فعال نیست.','icon'=>'dashicons-cart'),
            array('label'=>'Tutor LMS','status'=>function_exists('tutor')||defined('TUTOR_VERSION')?'good':'warn','message'=>(function_exists('tutor')||defined('TUTOR_VERSION'))?'اتصال دوره در دسترس است.':'Tutor LMS شناسایی نشد.','icon'=>'dashicons-welcome-learn-more'),
            array('label'=>'برگه حساب مستقل','status'=>$page_id&&get_post_status($page_id)==='publish'?'good':'bad','message'=>$page_id?'برگه شناسه '.$page_id.' بررسی شد.':'برگه حساب انتخاب نشده است.','icon'=>'dashicons-admin-page'),
            array('label'=>'ایمیل مدیریت','status'=>is_email($email)?'good':'bad','message'=>is_email($email)?MPH_Security::mask_email($email):'نشانی معتبر ثبت نشده است.','icon'=>'dashicons-email-alt'),
            array('label'=>'زمان‌بندی پس‌زمینه','status'=>$cron?'good':'warn','message'=>$cron?'Cron برای پاک‌سازی و تطبیق پرداخت فعال است.':'WP-Cron غیرفعال است؛ cron سرور لازم است.','icon'=>'dashicons-backup'),
            array('label'=>'جداول تراکنشی','status'=>$tables_ok&&MPH_Tickets::tables_ready()&&MPH_Notices::table_ready()?'good':'bad','message'=>$tables_ok&&MPH_Tickets::tables_ready()&&MPH_Notices::table_ready()?'قفل رزرو، تیکت، اعلان و رخداد امنیتی آماده‌اند.':'یک یا چند جدول یا ستون افزونه ساخته نشده است.','icon'=>'dashicons-database'),
            array('label'=>'رمزنگاری داده حساس','status'=>$crypto?'good':'bad','message'=>$crypto?(function_exists('sodium_crypto_secretbox')?'Libsodium فعال است.':'AES-256-GCM فعال است.'):'موتور رمزنگاری در دسترس نیست.','icon'=>'dashicons-shield'),
            array('label'=>'زنجیره رخداد امنیتی','status'=>$chain?'good':'bad','message'=>$chain?'هش رخدادهای اخیر معتبر است.':'تغییر غیرمنتظره در گزارش رخداد دیده شد.','icon'=>'dashicons-privacy'),
            array('label'=>'درگاه پرداخت','status'=>$gateways?'good':'warn','message'=>$gateways?'فعال: '.implode('، ',$gateways):'کلید درگاه ثبت نشده است.','icon'=>'dashicons-money-alt'),
            array('label'=>'صف پردازش ایمیل','status'=>function_exists('as_enqueue_async_action')?'good':'warn','message'=>function_exists('as_enqueue_async_action')?'Action Scheduler فعال است.':'ارسال صفی با WP-Cron انجام می‌شود.','icon'=>'dashicons-controls-repeat'),
        );
    }

    private static function verify_log_chain() {
        global $wpdb;$table=$wpdb->prefix.'mph_security_log';if($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$table))!==$table)return false;$rows=$wpdb->get_results("SELECT * FROM {$table} ORDER BY id DESC LIMIT 300",ARRAY_A);if(!$rows)return true;$rows=array_reverse($rows);$previous=null;
        foreach($rows as$row){$calculated=hash_hmac('sha256',implode('|',array($row['created_at'],absint($row['user_id']),$row['ip_hash'],$row['event'],$row['details'],$row['previous_hash'])),wp_salt('auth'));if(!hash_equals((string)$row['row_hash'],$calculated))return false;if($previous!==null&&!hash_equals((string)$row['previous_hash'],$previous))return false;$previous=(string)$row['row_hash'];}return true;
    }

    private static function security_log() {
        global $wpdb;$rows=$wpdb->get_results("SELECT created_at,user_id,event,details FROM {$wpdb->prefix}mph_security_log ORDER BY id DESC LIMIT 30"); ?>
        <section class="mph-admin-box mph-security-log"><div class="mph-builder-head"><div><h2>آخرین رخدادهای امنیتی</h2><p>نشانی IP خام ذخیره نمی‌شود؛ جزئیات با زنجیره HMAC محافظت می‌شوند.</p></div></div><div class="mph-table-wrap"><table class="widefat striped"><thead><tr><th>زمان</th><th>رخداد</th><th>کاربر</th><th>جزئیات امن</th></tr></thead><tbody><?php if(!$rows): ?><tr><td colspan="4">هنوز رخدادی ثبت نشده است.</td></tr><?php endif;foreach($rows as$row): ?><tr><td><?php echo esc_html(get_date_from_gmt($row->created_at,'Y/m/d H:i')); ?></td><td><code><?php echo esc_html($row->event); ?></code></td><td><?php echo absint($row->user_id)?:'—'; ?></td><td><?php echo esc_html($row->details?:'—'); ?></td></tr><?php endforeach; ?></tbody></table></div></section><?php
    }
}
