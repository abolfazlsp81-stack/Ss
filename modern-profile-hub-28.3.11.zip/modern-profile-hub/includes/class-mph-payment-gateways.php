<?php
defined('ABSPATH') || exit;
if (!class_exists('WC_Payment_Gateway')) return;

abstract class MPH_WC_Gateway_Base extends WC_Payment_Gateway {
    protected $credential = '';

    public function __construct() {
        $this->has_fields = false;
        $this->supports = array('products');
        $this->enabled = 'yes';
        add_action('woocommerce_api_' . strtolower(get_class($this)), array($this, 'handle_callback'));
    }

    public function is_available() {
        return $this->credential !== '' && parent::is_available();
    }

    protected function callback_url($order_id) {
        return add_query_arg('mph_order', absint($order_id), WC()->api_request_url(get_class($this)));
    }

    protected function success($order, $reference, $note = '') {
        if (!$order->is_paid()) $order->payment_complete((string) $reference);
        if ($note) $order->add_order_note($note);
        if (class_exists('MPH_Security')) MPH_Security::audit('payment_callback_verified','order='.$order->get_id().';gateway='.$this->id.';ref='.hash('sha256',(string)$reference),$order->get_user_id());
        if (class_exists('MPH_Shared_Cart')) MPH_Shared_Cart::consume_order($order->get_id());
        wp_safe_redirect($this->get_return_url($order));
        exit;
    }

    protected function failure($order, $message) {
        $message = sanitize_text_field($message);
        if ($order) $order->add_order_note('خطای درگاه ' . $this->method_title . ': ' . $message);
        if ($order && class_exists('MPH_Security')) MPH_Security::audit('payment_callback_failed','order='.$order->get_id().';gateway='.$this->id.';reason='.sanitize_key(substr($message,0,80)),$order->get_user_id());
        if (function_exists('wc_add_notice')) wc_add_notice($message, 'error');
        $url = $order && class_exists('MPH_Payment_Result') ? MPH_Payment_Result::url($order) : MPH_Commerce::cart_redirect();
        wp_safe_redirect($url);
        exit;
    }

    protected function valid_order_from_request() {
        nocache_headers();
        $order_id = absint($_REQUEST['mph_order'] ?? 0);
        $order = $order_id ? wc_get_order($order_id) : false;
        if (!$order || $order->get_payment_method() !== $this->id) return false;
        return $order;
    }
}

final class MPH_Gateway_Zarinpal extends MPH_WC_Gateway_Base {
    public function __construct() {
        $this->id = 'mph_zarinpal';$this->method_title = 'زرین‌پال';$this->method_description = 'پرداخت امن با Merchant ID ثبت‌شده در پروفایل مدرن';
        $this->title = 'پرداخت آنلاین زرین‌پال';$this->description = 'پرداخت با کارت‌های عضو شتاب از طریق زرین‌پال';
        $this->credential = trim((string) MPH_Payments::get('zarinpal_merchant'));
        parent::__construct();
    }

    public function process_payment($order_id) {
        $result = MPH_Payment_Attempts::request($order_id);
        if (is_wp_error($result)) {wc_add_notice($result->get_error_message(),'error');return array('result'=>'failure');}
        return $result;
    }

    public function handle_callback() {
        $order=$this->valid_order_from_request();
        if (!$order) $this->failure(false,'سفارش معتبر نیست.');
        $status=sanitize_text_field(wp_unslash($_GET['Status']??''));
        $authority=sanitize_text_field(wp_unslash($_GET['Authority']??''));
        $result=MPH_Payment_Attempts::verify($order->get_id(),$authority,$status);
        if (is_wp_error($result)) $this->failure($order,$result->get_error_message());
        $this->success(wc_get_order($order->get_id()),$result['reference']);
    }
}

final class MPH_Gateway_IDPay extends MPH_WC_Gateway_Base {
    public function __construct() {
        $this->id='mph_idpay';$this->method_title='IDPay';$this->method_description='پرداخت با API Key ثبت‌شده در پروفایل مدرن';
        $this->title='پرداخت آنلاین IDPay';$this->description='پرداخت با کارت‌های عضو شتاب از طریق IDPay';
        $this->credential=trim((string)MPH_Payments::get('idpay_api_key'));
        parent::__construct();
    }

    private function headers(){return array('X-API-KEY'=>$this->credential,'X-SANDBOX'=>MPH_Payments::get('idpay_sandbox')?'1':'0');}

    public function process_payment($order_id) {
        $order=wc_get_order($order_id);if(!$order)return array('result'=>'failure');$amount=MPH_Payments::amount($order,'IRR');if(is_wp_error($amount)){wc_add_notice($amount->get_error_message(),'error');return array('result'=>'failure');}
        $response=MPH_Payments::post_json('https://api.idpay.ir/v1.1/payment',array('order_id'=>(string)$order_id,'amount'=>$amount,'name'=>$order->get_formatted_billing_full_name(),'phone'=>$order->get_billing_phone(),'mail'=>$order->get_billing_email(),'desc'=>'پرداخت سفارش #'.$order->get_order_number(),'callback'=>$this->callback_url($order_id)),$this->headers());
        if(is_wp_error($response)||empty($response['id'])||empty($response['link'])){wc_add_notice(MPH_Payments::error_message($response,'ساخت تراکنش IDPay انجام نشد.'),'error');return array('result'=>'failure');}
        $token=sanitize_text_field($response['id']);$order->update_meta_data('_mph_gateway_token',$token);$order->update_meta_data('_mph_gateway_amount',$amount);$order->update_meta_data('_mph_gateway_currency','IRR');$order->save();
        return array('result'=>'success','redirect'=>esc_url_raw($response['link']));
    }

    public function handle_callback() {
        $order=$this->valid_order_from_request();if(!$order)$this->failure(false,'سفارش معتبر نیست.');
        $token=sanitize_text_field(wp_unslash($_REQUEST['id']??''));$stored=(string)$order->get_meta('_mph_gateway_token');$returned_order=absint($_REQUEST['order_id']??0);if(!$token||!$stored||!hash_equals($stored,$token)||$returned_order!==$order->get_id())$this->failure($order,'شناسه بازگشت IDPay معتبر نیست.');
        if($order->is_paid())$this->success($order,$order->get_transaction_id());
        $response=MPH_Payments::post_json('https://api.idpay.ir/v1.1/payment/verify',array('id'=>$token,'order_id'=>(string)$order->get_id()),$this->headers());
        if(is_wp_error($response))$this->failure($order,'ارتباط با درگاه قطع شد؛ نتیجه پرداخت باید دوباره بررسی شود.');
        $status=absint($response['status']??0);$verified_amount=absint($response['amount']??0);$stored_amount=absint($order->get_meta('_mph_gateway_amount'));
        if(!is_wp_error($response)&&$status===100&&$verified_amount===$stored_amount){$ref=sanitize_text_field((string)($response['payment']['track_id']??$response['track_id']??$token));$this->success($order,$ref,'پرداخت IDPay تأیید شد. کد رهگیری: '.$ref);}
        $this->failure($order,MPH_Payments::error_message($response,$verified_amount!==$stored_amount?'مبلغ بازگشتی IDPay با سفارش یکسان نیست.':'تأیید پرداخت IDPay انجام نشد.'));
    }
}
