<?php
defined('ABSPATH') || exit;

final class MPH_Manager {
    const SUPER_ADMIN_OPTION = 'mph_portal_super_admin_user_id';

    public static function init() {
        add_action('wp_ajax_mph_manager_role_decision', array(__CLASS__, 'ajax_role_decision'));
        add_action('wp_ajax_mph_manager_settings', array(__CLASS__, 'ajax_settings'));
        add_action('wp_ajax_mph_manager_course_save', array(__CLASS__, 'ajax_course_save'));
        add_action('wp_ajax_mph_manager_user_roles', array(__CLASS__, 'ajax_user_roles'));
        add_action('wp_ajax_mph_manager_super_admin', array(__CLASS__, 'ajax_super_admin'));
        add_action('wp_ajax_mph_manager_public_profile', array(__CLASS__, 'ajax_public_profile'));
        add_action('admin_post_mph_export_members', array(__CLASS__, 'export_members'));
        add_action('admin_post_mph_export_public_profiles', array(__CLASS__, 'export_public_profiles'));
    }

    public static function render($id) {
        if (!self::can_manage()) return '<div class="mph-empty">دسترسی مدیریت مجموعه را ندارید.</div>';
        if ($id === 'manage_members') return self::members().self::role_editor();
        if ($id === 'manage_teachers') return self::teachers().self::public_profiles('instructor');
        if ($id === 'manage_courses') return self::courses();
        if ($id === 'manage_requests') return self::requests();
        if ($id === 'payment_receipts') return MPH_Commerce::render_manager();
        if ($id === 'staff_payouts') return MPH_Payouts::render_manager();
        if ($id === 'manager_settings') return self::settings();
        if ($id === 'discount_codes') return MPH_Discounts::render_manager();
        return self::settings();
    }

    public static function ajax_role_decision(){MPH_Helpers::verify_ajax();if(!self::can_manage())wp_send_json_error(array('message'=>'دسترسی ندارید.'),403);$request_id=absint($_POST['request_id']??0);$decision=MPH_Helpers::posted('decision','key');$post=get_post($request_id);if(!$post||$post->post_type!==MPH_Roles::POST_TYPE)wp_send_json_error(array('message'=>'درخواست پیدا نشد.'));if($decision==='approve')$ok=MPH_Roles::approve($request_id);elseif($decision==='reject')$ok=MPH_Roles::reject($request_id);else wp_send_json_error(array('message'=>'عملیات معتبر نیست.'));if(!$ok)wp_send_json_error(array('message'=>'انجام عملیات ممکن نبود.'));$return=MPH_Helpers::posted('return_panel','key');wp_send_json_success(array('message'=>$decision==='approve'?'نقش تأیید و نتیجه برای کاربر تیکت شد.':'درخواست رد و نتیجه برای کاربر تیکت شد.','html'=>$return==='manage_teachers'?self::teachers():self::requests()));}

    public static function ajax_settings(){MPH_Helpers::verify_ajax();if(!self::can_manage())wp_send_json_error(array('message'=>'دسترسی ندارید.'),403);$id=get_current_user_id();$first=MPH_Helpers::posted('first_name');$last=MPH_Helpers::posted('last_name');$education=MPH_Helpers::posted('education');$major=MPH_Helpers::posted('major');$address=MPH_Helpers::posted('address','textarea');if(!$first||!$last||!$education||!$major||!$address)wp_send_json_error(array('message'=>'فیلدهای ستاره‌دار را کامل کنید.'));if(!MPH_Helpers::valid_person_name($first)||!MPH_Helpers::valid_person_name($last))wp_send_json_error(array('message'=>'نام و نام خانوادگی باید شامل حروف باشند و نمی‌توانند فقط عدد باشند.'));$saved=wp_update_user(array('ID'=>$id,'first_name'=>$first,'last_name'=>$last,'display_name'=>trim($first.' '.$last)));if(is_wp_error($saved))wp_send_json_error(array('message'=>$saved->get_error_message()));foreach(array('education'=>$education,'major'=>$major,'birth_year'=>MPH_Helpers::posted('birth_year'),'postal_code'=>MPH_Helpers::posted('postal_code'),'address'=>$address)as$key=>$value)update_user_meta($id,'mph_'.$key,$value);$card=preg_replace('/[^0-9۰-۹ -]/u','',MPH_Helpers::posted('bank_card'));$card_owner=MPH_Helpers::posted('bank_card_owner');if(($card&&!$card_owner)||(!$card&&$card_owner))wp_send_json_error(array('message'=>'شماره کارت و نام صاحب کارت باید با هم تکمیل شوند.'));if(current_user_can('manage_options')||MPH_Helpers::has_role('mph_manager')){MPH_Security::update_secret_option('mph_bank_card_number',$card);MPH_Security::update_secret_option('mph_bank_card_owner',$card_owner);}MPH_Tutor::sync_profile($id,get_user_meta($id,'mph_phone',true),$major,$address);wp_send_json_success(array('message'=>'تنظیمات و اطلاعات مدیر ذخیره شد.','html'=>self::settings()));}

    private static function members() {
        $filter=MPH_Helpers::posted('member_role','key');if(!$filter&&isset($_GET['member_role']))$filter=sanitize_key(wp_unslash($_GET['member_role']));if(!isset(self::managed_roles()[$filter]))$filter='';$users=self::logical_users($filter,300);$all=self::logical_users('',-1);$export=wp_nonce_url(admin_url('admin-post.php?action=mph_export_members&role='.rawurlencode($filter)),'mph_export_members');
        ob_start(); ?><section class="mph-section mph-manager-live"><div class="mph-section-heading"><div><h3>اعضای سایت</h3><p>فقط چهار نقش پنل: کاربر، مدرس، درمانگر و مدیر</p></div><span class="dashicons dashicons-groups"></span></div><div class="mph-manager-summary"><div><b><?php echo count($all); ?></b><span>کل اعضا</span></div><div><b><?php echo count(self::logical_users('instructor',-1)); ?></b><span>مدرس</span></div><div><b><?php echo count(self::logical_users('manager',-1)); ?></b><span>مدیر</span></div></div><div class="mph-table-toolbar"><form data-member-filter><label>تفکیک نقش<select name="member_role"><option value="">همه چهار نقش</option><?php foreach(self::managed_roles()as$role=>$label): ?><option value="<?php echo esc_attr($role); ?>" <?php selected($filter,$role); ?>><?php echo esc_html($label); ?></option><?php endforeach; ?></select></label></form><a class="mph-primary mph-export-link" href="<?php echo esc_url($export); ?>"><span class="dashicons dashicons-media-spreadsheet"></span> خروجی Excel</a></div><div class="mph-tutor-table mph-wide-table"><table><thead><tr><th>عضو</th><th>تلفن</th><th>ایمیل</th><th>تحصیلات</th><th>رشته</th><th>سال تولد</th><th>کد پستی</th><th>آدرس</th><th>نقش‌ها</th><th>عضویت</th></tr></thead><tbody><?php if(!$users): ?><tr><td colspan="10">عضوی در این گروه نیست.</td></tr><?php endif;foreach($users as$user): ?><tr><td><div class="mph-member-cell"><?php echo get_avatar($user->ID,36); ?><b><?php echo esc_html(MPH_Helpers::display_name($user)); ?></b></div></td><td><?php echo esc_html(get_user_meta($user->ID,'mph_phone',true)?:'—'); ?></td><td><?php echo esc_html($user->user_email?:'—'); ?></td><td><?php echo esc_html(get_user_meta($user->ID,'mph_education',true)?:'—'); ?></td><td><?php echo esc_html(get_user_meta($user->ID,'mph_major',true)?:'—'); ?></td><td><?php echo esc_html(get_user_meta($user->ID,'mph_birth_year',true)?:'—'); ?></td><td><?php echo esc_html(get_user_meta($user->ID,'mph_postal_code',true)?:'—'); ?></td><td class="mph-address-cell"><?php echo esc_html(get_user_meta($user->ID,'mph_address',true)?:'—'); ?></td><td><?php echo esc_html(self::role_names($user)); ?></td><td><?php echo esc_html(date_i18n('Y/m/d',strtotime($user->user_registered))); ?></td></tr><?php endforeach; ?></tbody></table></div></section><?php return ob_get_clean();
    }

    public static function export_members(){if(!self::can_manage()||!wp_verify_nonce(sanitize_text_field(wp_unslash($_GET['_wpnonce']??'')),'mph_export_members'))wp_die('دسترسی ندارید.','',array('response'=>403));$role=sanitize_key(wp_unslash($_GET['role']??''));if(!isset(self::managed_roles()[$role]))$role='';$users=self::logical_users($role,-1);while(ob_get_level())ob_end_clean();nocache_headers();header('Content-Type: text/csv; charset=UTF-8');header('Content-Disposition: attachment; filename="members-'.wp_date('Y-m-d').'.csv"');$out=fopen('php://output','w');fwrite($out,"\xEF\xBB\xBF");fputcsv($out,array('نام','نام خانوادگی','نام نمایشی','تلفن','ایمیل','تحصیلات','رشته','سال تولد','کد پستی','آدرس','نقش‌ها','تاریخ عضویت'));foreach($users as$user){$row=array($user->first_name,$user->last_name,MPH_Helpers::display_name($user),get_user_meta($user->ID,'mph_phone',true),$user->user_email,get_user_meta($user->ID,'mph_education',true),get_user_meta($user->ID,'mph_major',true),get_user_meta($user->ID,'mph_birth_year',true),get_user_meta($user->ID,'mph_postal_code',true),get_user_meta($user->ID,'mph_address',true),self::role_names($user),$user->user_registered);fputcsv($out,array_map(array(__CLASS__,'csv_safe'),$row));}fclose($out);exit;}

    private static function csv_safe($value){$value=(string)$value;return preg_match('/^[=+\-@]/u',$value)?"'".$value:$value;}

    private static function teachers() {$teachers=get_users(array('role__in'=>array('mph_instructor','tutor_instructor'),'orderby'=>'display_name'));ob_start(); ?><section class="mph-section mph-manager-live"><div class="mph-section-heading"><div><h3>مدرسین</h3><p>مدرسین فعال و صفحه حرفه‌ای عمومی آن‌ها</p></div><span class="dashicons dashicons-businessperson"></span></div><div class="mph-manager-card-grid mph-teacher-grid"><?php if(!$teachers)echo self::fallback_card('هنوز مدرس فعالی وجود ندارد.','درخواست‌های تأییدشده در این بخش نمایش داده می‌شوند.','dashicons-businessperson');foreach($teachers as$teacher):$courses=MPH_Tutor::instructor_course_count($teacher->ID); ?><article><div><?php echo get_avatar($teacher->ID,80); ?><span class="dashicons dashicons-yes-alt"></span></div><h4><?php echo esc_html(MPH_Helpers::display_name($teacher)); ?></h4><p><?php echo esc_html(get_user_meta($teacher->ID,'mph_major',true)?:'رشته ثبت نشده'); ?></p><small><?php echo absint($courses); ?> دوره · <?php echo esc_html(get_user_meta($teacher->ID,'mph_phone',true)?:'بدون تلفن'); ?></small><a class="mph-secondary" target="_blank" rel="noopener" href="<?php echo esc_url(MPH_Growth::instructor_url($teacher)); ?>">پروفایل عمومی مدرس</a></article><?php endforeach; ?></div></section><?php return ob_get_clean();}

    private static function courses() {
        if (!MPH_Tutor::active()) return '<section class="mph-section">'.self::fallback_card('Tutor LMS فعال نیست.','پس از فعال‌سازی Tutor، دوره‌های واقعی اینجا نمایش داده می‌شوند.','dashicons-warning').'</section>';
        $type = tutor()->course_post_type;
        $courses = get_posts(array('post_type'=>$type,'post_status'=>array('publish','draft','pending','future'),'numberposts'=>100,'orderby'=>'date','order'=>'DESC'));
        $edit_id=absint($_POST['course_id']??($_GET['course_id']??0));$editing=$edit_id?get_post($edit_id):false;if(!$editing||$editing->post_type!==$type)$editing=false;
        ob_start(); ?>
        <section class="mph-section mph-manager-live mph-manager-courses">
            <div class="mph-section-heading">
                <div><small class="mph-eyebrow">مدیریت آموزشی</small><h3>دوره‌های سایت</h3><p>همگام با Tutor LMS و تنظیمات فروش WooCommerce</p></div>
                <div class="mph-section-actions">
                    <button type="button" class="mph-primary mph-new-course-button" data-manager-new-course aria-expanded="false"><span class="dashicons dashicons-plus-alt2"></span> دوره جدید</button>
                </div>
            </div>
            <?php echo $editing?MPH_Courses::manager_editor($editing):self::course_builder(); ?>
            <div class="mph-manager-course-grid">
                <?php if (!$courses) echo self::fallback_card('هنوز دوره‌ای ساخته نشده است.','برای شروع روی دکمه «دوره جدید» بزنید.','dashicons-welcome-learn-more'); ?>
                <?php foreach ($courses as $course) : $count=MPH_Tutor::course_student_count($course->ID);$edit=add_query_arg(array('mph_mode'=>'manager','mph_open'=>'manage_courses','course_id'=>$course->ID),MPH_Helpers::account_page_url());$view=$course->post_status==='publish'?get_permalink($course):get_preview_post_link($course); ?>
                    <article>
                        <?php echo get_the_post_thumbnail($course->ID,'medium')?:'<span class="dashicons dashicons-welcome-learn-more"></span>'; ?>
                        <div><span class="mph-status"><?php $obj=get_post_status_object($course->post_status);echo esc_html($obj?$obj->label:$course->post_status); ?></span><h4><?php echo esc_html($course->post_title); ?></h4><p>مدرس: <?php $custom_name=(string)get_post_meta($course->ID,'_mph_custom_instructor_name',true);if($custom_name!=='')echo esc_html($custom_name);else{$author=get_user_by('id',$course->post_author);echo esc_html($author?MPH_Helpers::display_name($author):'—');} ?></p><small><?php echo absint($count); ?> دانشجو</small><div class="mph-course-actions"><a href="<?php echo esc_url($view); ?>" target="_blank" rel="noopener"><?php echo $course->post_status==='publish'?'مشاهده':'پیش‌نمایش'; ?></a><?php if($edit): ?><a class="mph-course-edit-link" href="<?php echo esc_url($edit); ?>" data-mph-course-edit="<?php echo absint($course->ID); ?>">ویرایش دوره</a><button type="button" class="mph-course-manage-btn" data-mph-course-manage="<?php echo absint($course->ID); ?>" data-course-title="<?php echo esc_attr($course->post_title); ?>"><span class="dashicons dashicons-welcome-learn-more"></span> مدیریت دوره</button><?php endif; ?></div></div>
                    </article>
                <?php endforeach; ?>
            </div>
        </section>
        <?php return ob_get_clean();
    }

    private static function course_builder() {
        $instructors=get_users(array('role__in'=>array('administrator','mph_manager','mph_instructor','tutor_instructor'),'orderby'=>'display_name','order'=>'ASC'));
        $categories=taxonomy_exists('course-category')?get_terms(array('taxonomy'=>'course-category','hide_empty'=>false)):array();
        if(is_wp_error($categories))$categories=array();
        ob_start(); ?>
        <form class="mph-course-create" data-course-create-form data-mph-action="mph_manager_course_save" enctype="multipart/form-data" hidden>
            <div class="mph-course-create-head"><div><small class="mph-eyebrow">دوره‌ساز داخلی</small><h4>ساخت دوره جدید</h4><p>اطلاعات مستقیماً در WordPress و Tutor LMS ذخیره می‌شود.</p></div><button type="button" class="mph-secondary" data-close-course-builder>بستن</button></div>
            <div class="mph-course-builder-grid">
                <label class="is-wide"><?php echo MPH_Helpers::required('عنوان دوره'); ?><input name="course_title" maxlength="180" required placeholder="عنوان روشن و قابل جست‌وجوی دوره"></label>
                <label class="is-wide">توضیح کامل دوره
                    <div class="mph-course-rich-toolbar" data-course-toolbar><button type="button" data-command="bold"><b>B</b></button><button type="button" data-command="italic"><i>I</i></button><button type="button" data-command="insertUnorderedList">• فهرست</button><button type="button" data-command="formatBlock" data-value="h3">عنوان</button><button type="button" data-command="createLink">لینک</button></div>
                    <div class="mph-course-rich-editor" data-course-editor contenteditable="true" role="textbox" aria-multiline="true" data-placeholder="معرفی کامل، برنامه و توضیحات دوره را وارد کنید…"></div><textarea name="course_content" data-course-content hidden></textarea>
                </label>
                <label class="is-wide">خلاصه دوره<textarea name="course_excerpt" rows="3" maxlength="500" placeholder="خلاصه‌ای که در کارت و فهرست دوره‌ها دیده می‌شود"></textarea></label>
                <label>مدرس<select name="course_author" data-mph-instructor-select><?php foreach($instructors as$instructor): ?><option value="<?php echo absint($instructor->ID); ?>" <?php selected($instructor->ID,get_current_user_id()); ?>><?php echo esc_html(MPH_Helpers::display_name($instructor)); ?></option><?php endforeach; ?><option value="custom">نام مدرس ...</option></select></label>
                <label class="mph-custom-instructor-field" data-mph-custom-instructor hidden>نام مدرس (دستی)<input type="text" name="course_instructor_custom" placeholder="نام کامل مدرس را بنویسید"></label>
                <label>وضعیت انتشار<select name="course_status"><option value="publish">انتشار فوری</option><option value="draft">پیش‌نویس</option><option value="pending">در انتظار بررسی</option></select></label>
                <label>تاریخ شروع شمسی در تقویم آموزشی<input type="text" name="course_calendar_date" value="<?php echo esc_attr(MPH_Helpers::gregorian_to_jalali_date(current_time('Y-m-d'))); ?>" inputmode="numeric" maxlength="10" placeholder="۱۴۰۵/۰۶/۰۷" data-mph-jalali-input required><small>نمونه: ۱۴۰۵/۰۶/۰۷</small></label>
                <label>ساعت شروع در تقویم<input type="time" name="course_calendar_time" value="<?php echo esc_attr(current_time('H:i')); ?>"></label>
                <label>سطح دوره<select name="course_level"><option value="all_levels">همه سطوح</option><option value="beginner">مقدماتی</option><option value="intermediate">متوسط</option><option value="expert">پیشرفته</option></select></label>
                <label>حداکثر دانشجو<input type="number" name="maximum_students" min="0" max="100000" value="0"><small>صفر یعنی بدون محدودیت</small></label>
                <label>مدت دوره ـ ساعت<input type="number" name="duration_hours" min="0" max="999" value="0"></label>
                <label>مدت دوره ـ دقیقه<input type="number" name="duration_minutes" min="0" max="59" value="0"></label>
                <label class="is-wide">تصویر شاخص <small>JPG، PNG یا WebP؛ حداکثر ۵ مگابایت</small><div class="mph-course-image-control"><span class="mph-course-image-preview" data-course-image-preview><span class="dashicons dashicons-format-image"></span></span><input type="file" name="course_image" accept="image/jpeg,image/png,image/webp" data-mph-max-file="5242880"></div></label>
                <?php if($categories): ?><div class="is-wide"><b>دسته‌بندی دوره</b><div class="mph-course-taxonomy"><?php foreach($categories as$category): ?><label><input type="checkbox" name="course_categories[]" value="<?php echo absint($category->term_id); ?>"> <?php echo esc_html($category->name); ?></label><?php endforeach; ?></div></div><?php endif; ?>
                <label>دسته جدید <small>(اختیاری)</small><input name="new_course_category" maxlength="100" placeholder="مثلاً مدیریت"></label>
                <label>برچسب‌ها <small>(با ویرگول جدا کنید)</small><input name="course_tags" placeholder="فروش، بازاریابی، مدیریت"></label>
                <label class="is-wide">دستاوردهای دوره<textarea name="course_benefits" rows="3" placeholder="دانشجو پس از پایان دوره چه چیزی یاد می‌گیرد؟"></textarea></label>
                <label class="is-wide">پیش‌نیازها<textarea name="course_requirements" rows="3" placeholder="هر مورد را در یک خط وارد کنید"></textarea></label>
                <label>مخاطبان دوره<textarea name="course_target" rows="3"></textarea></label>
                <label>موارد همراه دوره<textarea name="course_materials" rows="3"></textarea></label>
                <div class="is-wide mph-options"><label><input type="checkbox" name="enable_qa" value="1" checked> پرسش و پاسخ فعال باشد</label><label><input type="checkbox" name="public_course" value="1"> دوره عمومی و بدون الزام ثبت‌نام باشد</label></div>
                <div class="is-wide mph-delivery-builder"><b>روش‌های قابل فروش <small>(اختیاری؛ قیمت در WooCommerce ذخیره می‌شود)</small></b><div class="mph-field-grid"><?php foreach(MPH_Courses::modes()as$mode=>$info): ?><label><span><input type="checkbox" name="modes[<?php echo esc_attr($mode); ?>][enabled]" value="1"> <?php echo esc_html($info['label']); ?></span><input inputmode="decimal" name="modes[<?php echo esc_attr($mode); ?>][price]" placeholder="قیمت"></label><?php endforeach; ?></div><label>لینک کلاس آنلاین<input type="url" name="modes[online][url]" placeholder="https://…" dir="ltr"></label><div class="mph-field-grid"><label>شروع کلاس حضوری<input type="datetime-local" name="modes[inperson][start]"></label><label>ظرفیت کلاس حضوری <small>(صفر یعنی نامحدود)</small><input type="number" name="modes[inperson][capacity]" min="0" max="100000" value="0"></label><label>آدرس کلاس حضوری<textarea name="modes[inperson][address]" rows="2"></textarea></label></div></div>
            </div>
            <div class="mph-form-actions"><button class="mph-primary" type="submit"><span class="dashicons dashicons-saved"></span> ذخیره دوره</button><button class="mph-secondary" type="button" data-close-course-builder>انصراف</button></div><div class="mph-message" aria-live="polite"></div>
        </form>
        <?php return ob_get_clean();
    }

    public static function ajax_course_save() {
        MPH_Helpers::verify_ajax();if(!self::can_manage())wp_send_json_error(array('message'=>'دسترسی ساخت دوره ندارید.'),403);if(!MPH_Tutor::active())wp_send_json_error(array('message'=>'Tutor LMS فعال نیست.'));
        $title=MPH_Helpers::posted('course_title');$content=isset($_POST['course_content'])?wp_kses_post(wp_unslash($_POST['course_content'])):'';$excerpt=MPH_Helpers::posted('course_excerpt','textarea');
        if(isset($_POST['course_calendar_date'])){$raw_date=MPH_Helpers::posted('course_calendar_date');$gregorian=MPH_Helpers::jalali_to_gregorian_date($raw_date);if($gregorian)$_POST['course_calendar_date']=$gregorian;}
        if(!$title)wp_send_json_error(array('message'=>'عنوان دوره الزامی است.'));
        if(!empty($_FILES['course_image']['name'])){$file=$_FILES['course_image'];if(absint($file['size'])>5242880)wp_send_json_error(array('message'=>'حجم تصویر دوره باید حداکثر ۵ مگابایت باشد.'));$check=wp_check_filetype(sanitize_file_name($file['name']),array('jpg|jpeg|jpe'=>'image/jpeg','png'=>'image/png','webp'=>'image/webp'));if(empty($check['type']))wp_send_json_error(array('message'=>'فرمت تصویر دوره مجاز نیست.'));}
        $author_raw=sanitize_text_field(wp_unslash($_POST['course_author']??''));$custom_instructor=sanitize_text_field(wp_unslash($_POST['course_instructor_custom']??''));
        if($author_raw==='custom'){$author=get_current_user_id();}else{$author=absint($author_raw);if(!$author||!get_user_by('id',$author))$author=get_current_user_id();}
        $status=MPH_Helpers::posted('course_status','key');if(!in_array($status,array('draft','pending','publish'),true))$status='draft';if($status==='publish'&&!current_user_can('publish_posts')&&!current_user_can('manage_options'))$status='pending';
        $course_id=wp_insert_post(array('post_type'=>tutor()->course_post_type,'post_status'=>$status,'post_title'=>$title,'post_content'=>$content,'post_excerpt'=>$excerpt,'post_author'=>$author),true);if(is_wp_error($course_id)||!$course_id)wp_send_json_error(array('message'=>is_wp_error($course_id)?$course_id->get_error_message():'ساخت دوره انجام نشد.'));flush_rewrite_rules(false);
        if(!empty($_FILES['course_image']['name'])){require_once ABSPATH.'wp-admin/includes/file.php';require_once ABSPATH.'wp-admin/includes/media.php';require_once ABSPATH.'wp-admin/includes/image.php';$image=media_handle_upload('course_image',$course_id);if(is_wp_error($image)){wp_delete_post($course_id,true);wp_send_json_error(array('message'=>'آپلود تصویر انجام نشد: '.$image->get_error_message()));}set_post_thumbnail($course_id,$image);}
        $level=MPH_Helpers::posted('course_level','key');if(!in_array($level,array('all_levels','beginner','intermediate','expert'),true))$level='all_levels';update_post_meta($course_id,'_tutor_course_level',$level);if($author_raw==='custom'&&$custom_instructor!=='')update_post_meta($course_id,'_mph_custom_instructor_name',$custom_instructor);else delete_post_meta($course_id,'_mph_custom_instructor_name');update_post_meta($course_id,'_course_duration',array('hours'=>min(999,absint($_POST['duration_hours']??0)),'minutes'=>min(59,absint($_POST['duration_minutes']??0))));update_post_meta($course_id,'_tutor_enable_qa',empty($_POST['enable_qa'])?'no':'yes');update_post_meta($course_id,'_tutor_is_public_course',empty($_POST['public_course'])?'no':'yes');update_post_meta($course_id,'_tutor_course_settings',array('maximum_students'=>min(100000,absint($_POST['maximum_students']??0))));update_post_meta($course_id,'_tutor_course_benefits',MPH_Helpers::posted('course_benefits','textarea'));update_post_meta($course_id,'_tutor_course_requirements',MPH_Helpers::posted('course_requirements','textarea'));update_post_meta($course_id,'_tutor_course_target_audience',MPH_Helpers::posted('course_target','textarea'));update_post_meta($course_id,'_tutor_course_material_includes',MPH_Helpers::posted('course_materials','textarea'));$calendar_date=MPH_Helpers::posted('course_calendar_date');if(!preg_match('/^\d{4}-\d{2}-\d{2}$/',$calendar_date))$calendar_date=current_time('Y-m-d');$calendar_time=preg_replace('/[^0-9:]/','',MPH_Helpers::posted('course_calendar_time'));update_post_meta($course_id,'_mph_course_calendar_date',$calendar_date);update_post_meta($course_id,'_mph_course_calendar_time',preg_match('/^\d{2}:\d{2}$/',$calendar_time)?$calendar_time:'');
        if(taxonomy_exists('course-category')){$terms=array_values(array_filter(array_map('absint',(array)($_POST['course_categories']??array()))));$new=MPH_Helpers::posted('new_course_category');if($new){$term=term_exists($new,'course-category');if(!$term)$term=wp_insert_term($new,'course-category');if(!is_wp_error($term))$terms[]=absint(is_array($term)?$term['term_id']:$term);}wp_set_object_terms($course_id,array_values(array_unique($terms)),'course-category');}if(taxonomy_exists('course-tag')){$tags=array_values(array_filter(array_map('trim',preg_split('/[,،]/u',MPH_Helpers::posted('course_tags')))));if($tags)wp_set_object_terms($course_id,$tags,'course-tag');}
        $mode_result=MPH_Courses::configure_modes($course_id,(array)($_POST['modes']??array()));if(class_exists('MPH_Calendar'))MPH_Calendar::sync_course($course_id);$message='دوره «'.$title.'» با موفقیت در WordPress/Tutor ذخیره و با تقویم آموزشی همگام شد.';if(is_wp_error($mode_result))$message.=' دوره ساخته شد، اما تنظیم قیمت: '.$mode_result->get_error_message();wp_send_json_success(array('message'=>$message,'html'=>self::courses()));
    }

    private static function requests(){$roles=get_posts(array('post_type'=>MPH_Roles::POST_TYPE,'post_status'=>'pending','numberposts'=>100,'orderby'=>'date','order'=>'DESC'));$tickets=MPH_Tickets::manager_counts();ob_start(); ?><section class="mph-section mph-manager-live"><div class="mph-section-heading"><div><h3>درخواست‌های تغییر نقش</h3><p>تأیید یا رد؛ نتیجه به‌صورت تیکت برای کاربر ارسال می‌شود.</p></div><span class="dashicons dashicons-yes-alt"></span></div><div class="mph-manager-summary"><div><b><?php echo count($roles); ?></b><span>در انتظار تصمیم</span></div><div><b><?php echo absint($tickets['total']); ?></b><span>کل تیکت‌ها</span></div><div><b><?php echo absint($tickets['open']); ?></b><span>نیازمند رسیدگی</span></div></div><div class="mph-manager-request-list"><h4>درخواست‌ها</h4><?php if(!$roles)echo'<div class="mph-empty">درخواستی وجود ندارد.</div>';foreach($roles as$request):$user=get_user_by('id',$request->post_author);$role=get_post_meta($request->ID,'mph_requested_role',true); ?><div><span><b><?php echo esc_html($user?MPH_Helpers::display_name($user):'کاربر حذف‌شده'); ?></b><small><?php echo esc_html(MPH_Roles::label($role).' · '.($request->post_content?:'بدون توضیح')); ?></small></span><form data-mph-action="mph_manager_role_decision"><input type="hidden" name="request_id" value="<?php echo absint($request->ID); ?>"><button class="mph-primary" name="decision" value="approve">تأیید</button><button class="mph-secondary" name="decision" value="reject">حذف/رد</button><div class="mph-message"></div></form></div><?php endforeach; ?></div></section><?php $html=ob_get_clean();return$html.MPH_Password_Recovery::manager_panel();}

    private static function settings(){$user=wp_get_current_user();ob_start(); ?><section class="mph-section mph-manager-live"><div class="mph-section-heading"><div><h3>تنظیمات مدیر</h3><p>ماژول نمایه مدیر و اطلاعات پرداخت مجموعه</p></div><span class="dashicons dashicons-admin-generic"></span></div><form class="mph-form" data-mph-action="mph_manager_settings"><div class="mph-field-grid"><label><?php echo MPH_Helpers::required('نام'); ?><input name="first_name" value="<?php echo esc_attr($user->first_name); ?>" required></label><label><?php echo MPH_Helpers::required('نام خانوادگی'); ?><input name="last_name" value="<?php echo esc_attr($user->last_name); ?>" required></label></div><div class="mph-field-grid"><label><?php echo MPH_Helpers::required('تحصیلات'); ?><input name="education" value="<?php echo esc_attr(get_user_meta($user->ID,'mph_education',true)); ?>" required></label><label><?php echo MPH_Helpers::required('رشته تحصیلی'); ?><input name="major" value="<?php echo esc_attr(get_user_meta($user->ID,'mph_major',true)); ?>" required></label></div><div class="mph-field-grid"><label>سال تولد <small>(اختیاری)</small><input name="birth_year" value="<?php echo esc_attr(get_user_meta($user->ID,'mph_birth_year',true)); ?>"></label><label>کد پستی <small>(اختیاری)</small><input name="postal_code" value="<?php echo esc_attr(get_user_meta($user->ID,'mph_postal_code',true)); ?>"></label></div><label><?php echo MPH_Helpers::required('آدرس'); ?><textarea name="address" required><?php echo esc_textarea(get_user_meta($user->ID,'mph_address',true)); ?></textarea></label><div class="mph-field-grid"><label>شماره کارت برای پرداخت فیشی<input name="bank_card" value="<?php echo esc_attr(MPH_Security::get_secret_option('mph_bank_card_number','')); ?>" placeholder="6037 0000 0000 0000" dir="ltr"><small>شماره کارت به‌صورت رمزنگاری‌شده نگهداری می‌شود.</small></label><label>نام و نام خانوادگی صاحب کارت<input name="bank_card_owner" value="<?php echo esc_attr(MPH_Security::get_secret_option('mph_bank_card_owner','')); ?>" placeholder="مثلاً علی رضایی"><small>نامی که روی حساب بانکی ثبت شده است.</small></label></div><button class="mph-primary" type="submit">ذخیره تنظیمات</button><div class="mph-message"></div></form></section><?php $html=ob_get_clean();return $html.(class_exists('MPH_Backup')?MPH_Backup::portal_card():'');}

    private static function role_editor() {
        $users=get_users(array('number'=>200,'orderby'=>'display_name','order'=>'ASC'));
        $roles=self::managed_roles();
        $super_id=self::portal_super_admin_id();
        $super_user=$super_id?get_user_by('id',$super_id):false;
        $can_choose=self::can_choose_super_admin();
        ob_start(); ?>
        <section class="mph-section mph-manager-role-editor">
            <div class="mph-section-heading"><div><h3>افزودن یا حذف نقش اعضا</h3><p>فقط چهار نقش پنل نمایش داده می‌شود: کاربر، مدرس، درمانگر و مدیر.</p></div><span class="dashicons dashicons-admin-users"></span></div>
            <div class="mph-super-admin-box <?php echo $super_user?'has-owner':'is-empty'; ?>">
                <div class="mph-super-admin-status"><span class="dashicons dashicons-shield-alt"></span><div><b>سوپرادمین مجموعه</b><small><?php echo esc_html($super_user?'حساب محافظت‌شده: '.MPH_Helpers::display_name($super_user):'هنوز حساب محافظت‌شده انتخاب نشده است.'); ?></small></div></div>
                <?php if($can_choose): ?>
                    <form data-mph-action="mph_manager_super_admin">
                        <label>انتخاب حساب<?php wp_dropdown_users(array('name'=>'super_admin_user_id','selected'=>$super_id,'show_option_none'=>'یک عضو را انتخاب کنید','option_none_value'=>'0')); ?></label>
                        <button class="mph-primary" type="submit"><span class="dashicons dashicons-lock"></span> ذخیره سوپرادمین</button>
                        <div class="mph-message"></div>
                    </form>
                <?php else: ?>
                    <span class="mph-protected-note"><span class="dashicons dashicons-lock"></span> فقط خود سوپرادمین مجموعه می‌تواند این انتخاب را تغییر دهد.</span>
                <?php endif; ?>
            </div>
            <div class="mph-role-editor-list">
                <?php foreach($users as$user):$protected=self::is_portal_super_admin($user->ID);$locked=$protected&&!$can_choose; ?>
                    <form class="mph-role-editor-row <?php echo $protected?'is-super-admin':''; ?>" data-mph-action="mph_manager_user_roles">
                        <input type="hidden" name="user_id" value="<?php echo absint($user->ID); ?>">
                        <div class="mph-member-cell"><?php echo get_avatar($user->ID,40); ?><span><b><?php echo esc_html(MPH_Helpers::display_name($user)); ?></b><small><?php echo esc_html(get_user_meta($user->ID,'mph_phone',true)?:$user->user_email); ?><?php if($protected): ?> · سوپرادمین مجموعه<?php endif; ?></small></span></div>
                        <div class="mph-role-checks"><?php foreach($roles as$key=>$label): ?><label><input type="checkbox" name="user_roles[]" value="<?php echo esc_attr($key); ?>" <?php checked(self::user_has_managed_role($user,$key)); ?> <?php disabled($locked||($key==='manager'&&($protected||$user->ID===get_current_user_id()))); ?>> <?php echo esc_html($label); ?></label><?php endforeach; ?></div>
                        <button class="mph-secondary" type="submit" <?php disabled($locked); ?>>ذخیره نقش‌ها</button>
                        <div class="mph-message"></div>
                    </form>
                <?php endforeach; ?>
            </div>
        </section><?php return ob_get_clean();
    }

    public static function ajax_user_roles() {
        MPH_Helpers::verify_ajax();
        if(!self::can_manage())wp_send_json_error(array('message'=>'دسترسی ندارید.'),403);
        $user_id=absint($_POST['user_id']??0);$user=get_user_by('id',$user_id);
        if(!$user)wp_send_json_error(array('message'=>'حساب کاربری پیدا نشد.'));
        if(self::is_portal_super_admin($user_id)&&!self::can_choose_super_admin())wp_send_json_error(array('message'=>'نقش‌های سوپرادمین مجموعه توسط مدیران دیگر قابل تغییر نیست.'),403);
        $managed=self::managed_roles();
        $wanted=array_values(array_intersect(array_keys($managed),array_map('sanitize_key',(array)($_POST['user_roles']??array()))));
        if($user_id===get_current_user_id()&&!in_array('manager',$wanted,true))$wanted[]='manager';
        if(self::is_portal_super_admin($user_id)&&!in_array('manager',$wanted,true))$wanted[]='manager';
        foreach(array_keys($managed)as$role)self::set_managed_role($user,$role,in_array($role,$wanted,true));
        if(!$user->roles)$user->add_role('subscriber');
        MPH_Helpers::audit('manager_roles_updated','target='.$user_id.';roles='.implode(',',$wanted));
        wp_send_json_success(array('message'=>'نقش‌های عضو به‌روزرسانی شد.','html'=>self::members().self::role_editor()));
    }

    public static function ajax_super_admin() {
        MPH_Helpers::verify_ajax();
        if(!self::can_choose_super_admin())wp_send_json_error(array('message'=>'فقط سوپرادمین مجموعه اجازه تغییر این حساب را دارد.'),403);
        $user_id=absint($_POST['super_admin_user_id']??0);$user=get_user_by('id',$user_id);
        if(!$user)wp_send_json_error(array('message'=>'یک عضو معتبر را انتخاب کنید.'));
        $user->add_role('mph_manager');
        update_option(self::SUPER_ADMIN_OPTION,$user_id,false);
        MPH_Helpers::audit('portal_super_admin_updated','target='.$user_id);
        wp_send_json_success(array('message'=>'سوپرادمین مجموعه انتخاب و در برابر تغییر نقش توسط مدیران دیگر محافظت شد.','html'=>self::members().self::role_editor()));
    }

    public static function portal_super_admin_id() {
        $user_id=absint(get_option(self::SUPER_ADMIN_OPTION,0));
        return$user_id&&get_user_by('id',$user_id)?$user_id:0;
    }

    public static function is_portal_super_admin($user_id=0) {
        $user_id=$user_id?absint($user_id):get_current_user_id();
        return$user_id>0&&$user_id===self::portal_super_admin_id();
    }

    private static function can_choose_super_admin() {
        $super_id=self::portal_super_admin_id();
        if(!$super_id)return current_user_can('manage_options')||(is_multisite()&&is_super_admin());
        return get_current_user_id()===$super_id||(is_multisite()&&is_super_admin());
    }

    public static function managed_roles() {return array('user'=>'کاربر','instructor'=>'مدرس','therapist'=>'درمانگر','manager'=>'مدیر');}

    public static function logical_roles($user) {
        $user=$user instanceof WP_User?$user:get_user_by('id',absint($user));if(!$user)return array();$roles=array();$wp_roles=(array)$user->roles;
        $is_instructor=(bool)array_intersect($wp_roles,array('mph_instructor','tutor_instructor'));
        $is_therapist=in_array('mph_therapist',$wp_roles,true);
        $is_manager=in_array('mph_manager',$wp_roles,true)||self::is_portal_super_admin($user->ID)||user_can($user,'manage_options');
        if((bool)array_intersect($wp_roles,array('subscriber','customer'))||(!$is_instructor&&!$is_therapist&&!$is_manager))$roles[]='user';
        if($is_instructor)$roles[]='instructor';if($is_therapist)$roles[]='therapist';if($is_manager)$roles[]='manager';return$roles;
    }

    public static function logical_users($filter='',$limit=300) {
        $filter=sanitize_key((string)$filter);$args=array('number'=>-1,'orderby'=>'registered','order'=>'DESC');$users=get_users($args);if($filter&&isset(self::managed_roles()[$filter]))$users=array_values(array_filter($users,function($user)use($filter){return in_array($filter,self::logical_roles($user),true);}));return$limit<0?$users:array_slice($users,0,max(0,absint($limit)));
    }

    private static function user_has_managed_role($user,$role) {
        $roles=(array)$user->roles;
        if($role==='user')return(bool)array_intersect($roles,array('subscriber','customer'));
        if($role==='instructor')return(bool)array_intersect($roles,array('mph_instructor','tutor_instructor'));
        if($role==='therapist')return in_array('mph_therapist',$roles,true);
        if($role==='manager')return in_array('mph_manager',$roles,true);
        return false;
    }

    private static function set_managed_role($user,$role,$enabled) {
        if($role==='user'){
            if($enabled&&!self::user_has_managed_role($user,'user'))$user->add_role(get_role('customer')?'customer':'subscriber');
            if(!$enabled){$user->remove_role('subscriber');$user->remove_role('customer');}
        }elseif($role==='instructor'){
            if($enabled){$user->add_role('mph_instructor');if(get_role('tutor_instructor'))$user->add_role('tutor_instructor');}
            else{$user->remove_role('mph_instructor');$user->remove_role('tutor_instructor');}
        }elseif($role==='therapist'){
            $enabled?$user->add_role('mph_therapist'):$user->remove_role('mph_therapist');
        }elseif($role==='manager'){
            $enabled?$user->add_role('mph_manager'):$user->remove_role('mph_manager');
        }
    }

    public static function render_public_profiles($type='instructor') {return self::public_profiles($type);}

    private static function public_profiles($type='instructor') {
        $type=$type==='therapist'?'therapist':'instructor';$role=$type==='therapist'?'mph_therapist':array('mph_instructor','tutor_instructor');$args=array('orderby'=>'display_name','order'=>'ASC');if(is_array($role))$args['role__in']=$role;else$args['role']=$role;$staff=get_users($args);$label=$type==='therapist'?'درمانگر':'مدرس';$meta=$type==='therapist'?'mph_public_therapist_profile_url':'mph_public_instructor_profile_url';$export=wp_nonce_url(admin_url('admin-post.php?action=mph_export_public_profiles&profile_type='.$type),'mph_export_public_profiles_'.$type);ob_start();?><section class="mph-section mph-public-profile-manager is-<?php echo esc_attr($type); ?>"><div class="mph-section-heading"><div><h3>صفحه عمومی <?php echo esc_html($label); ?>ها</h3><p>لینک اختصاصی این نقش را تنظیم کنید؛ لینک نقش دیگر مستقل باقی می‌ماند.</p></div><a class="mph-secondary" href="<?php echo esc_url($export); ?>"><span class="dashicons dashicons-media-spreadsheet"></span> خروجی لیست</a></div><div class="mph-public-profile-list"><?php if(!$staff): ?><div class="mph-empty"><?php echo esc_html($label); ?>ی ثبت نشده است.</div><?php endif;foreach($staff as$user):$custom=(string)get_user_meta($user->ID,$meta,true);$current=MPH_Growth::public_profile_url($user,$type); ?><form data-mph-action="mph_manager_public_profile"><input type="hidden" name="user_id" value="<?php echo absint($user->ID); ?>"><input type="hidden" name="profile_type" value="<?php echo esc_attr($type); ?>"><div class="mph-member-cell"><?php echo get_avatar($user->ID,44); ?><span><b><?php echo esc_html(MPH_Helpers::display_name($user)); ?></b><small><?php echo esc_html($label); ?></small></span></div><label>نشانی صفحه عمومی<input type="url" name="public_profile_url" value="<?php echo esc_attr($custom); ?>" placeholder="<?php echo esc_attr($current); ?>" dir="ltr"></label><div class="mph-public-profile-actions"><a class="mph-secondary" href="<?php echo esc_url($current); ?>" target="_blank" rel="noopener">مشاهده</a><button type="button" class="mph-icon-button" data-mph-copy="<?php echo esc_attr($current); ?>" aria-label="کپی لینک"><span class="dashicons dashicons-admin-page"></span></button><button class="mph-primary" type="submit">ذخیره</button></div><div class="mph-message"></div></form><?php endforeach; ?></div></section><?php return ob_get_clean();
    }

    public static function ajax_public_profile() {
        MPH_Helpers::verify_ajax();if(!self::can_manage())wp_send_json_error(array('message'=>'دسترسی ندارید.'),403);$type=MPH_Helpers::posted('profile_type','key')==='therapist'?'therapist':'instructor';$user_id=absint($_POST['user_id']??0);$user=get_user_by('id',$user_id);$valid=$type==='therapist'?($user&&MPH_Helpers::has_role('mph_therapist',$user)):($user&&MPH_Helpers::has_role('mph_instructor',$user));if(!$valid)wp_send_json_error(array('message'=>$type==='therapist'?'درمانگر معتبر نیست.':'مدرس معتبر نیست.'));$meta=$type==='therapist'?'mph_public_therapist_profile_url':'mph_public_instructor_profile_url';$url=trim(MPH_Helpers::posted('public_profile_url'));if($url){$url=esc_url_raw($url,array('http','https'));$scheme=wp_parse_url($url,PHP_URL_SCHEME);if(!$url||!in_array($scheme,array('http','https'),true))wp_send_json_error(array('message'=>'لینک معتبر http یا https وارد کنید.'));update_user_meta($user_id,$meta,$url);}else delete_user_meta($user_id,$meta);$html=$type==='therapist'?MPH_Appointments::render('manage_therapists').self::public_profiles('therapist'):self::teachers().self::public_profiles('instructor');wp_send_json_success(array('message'=>$url?'لینک صفحه عمومی ذخیره شد.':'صفحه عمومی داخلی افزونه فعال شد.','html'=>$html));
    }

    public static function export_public_profiles(){if(!self::can_manage())wp_die('دسترسی ندارید.','',array('response'=>403));$type=sanitize_key(wp_unslash($_GET['profile_type']??''));if(!in_array($type,array('instructor','therapist'),true)||!wp_verify_nonce(sanitize_text_field(wp_unslash($_GET['_wpnonce']??'')),'mph_export_public_profiles_'.$type))wp_die('لینک معتبر نیست.','',array('response'=>403));$users=$type==='therapist'?get_users(array('role'=>'mph_therapist','orderby'=>'display_name')):get_users(array('role__in'=>array('mph_instructor','tutor_instructor'),'orderby'=>'display_name'));while(ob_get_level())ob_end_clean();nocache_headers();header('Content-Type: text/csv; charset=UTF-8');header('Content-Disposition: attachment; filename="public-'.$type.'s-'.wp_date('Y-m-d').'.csv"');$out=fopen('php://output','w');fwrite($out,"\xEF\xBB\xBF");fputcsv($out,array('نام نمایشی','تلفن','ایمیل','نقش','لینک عمومی'));foreach($users as$user)fputcsv($out,array_map(array(__CLASS__,'csv_safe'),array(MPH_Helpers::display_name($user),get_user_meta($user->ID,'mph_phone',true),$user->user_email,$type==='therapist'?'درمانگر':'مدرس',MPH_Growth::public_profile_url($user,$type))));fclose($out);exit;}

    private static function fallback_card($title,$text,$icon){return'<div class="mph-manager-fallback"><span class="dashicons '.esc_attr($icon).'"></span><div><h4>'.esc_html($title).'</h4><p>'.esc_html($text).'</p></div></div>';}
    public static function role_names($user){$labels=self::managed_roles();$names=array();foreach(self::logical_roles($user)as$role)$names[]=$labels[$role];return implode('، ',$names);}
    private static function can_manage(){return is_user_logged_in()&&(self::is_portal_super_admin()||MPH_Helpers::has_role('mph_manager')||current_user_can('mph_manage_portal')||current_user_can('manage_options'));}
}
