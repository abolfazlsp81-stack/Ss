<?php
defined('ABSPATH') || exit;

final class MPH_Admin {
    const DEFAULTS_VERSION_OPTION = 'mph_defaults_version';

    public static function init() {
        add_action('admin_menu', array(__CLASS__, 'menu'));
        add_action('admin_enqueue_scripts', array(__CLASS__, 'assets'));
        add_action('admin_init', array(__CLASS__, 'save'));
        add_action('admin_post_mph_delete_member', array(__CLASS__, 'delete_member'));
    }

    public static function install_defaults() {
        if (get_option(self::DEFAULTS_VERSION_OPTION) === MPH_VERSION) return;
        MPH_Helpers::repair_numeric_names();
        if(!get_role('mph_therapist'))add_role('mph_therapist','درمانگر',array('read'=>true,'upload_files'=>true,'mph_manage_appointments'=>true));
        $therapist_role=get_role('mph_therapist');if($therapist_role)foreach(array('read','upload_files','mph_manage_appointments')as$capability)$therapist_role->add_cap($capability);
        $manager_role = get_role('mph_manager');
        if ($manager_role) {
            foreach (array('upload_files','manage_tutor','manage_woocommerce','view_woocommerce_reports','edit_posts','edit_others_posts','edit_published_posts','publish_posts','delete_posts','delete_others_posts','edit_shop_coupons','edit_others_shop_coupons','publish_shop_coupons','read_private_shop_coupons','delete_shop_coupons','mph_manage_members','mph_manage_courses','mph_manage_reports','mph_manage_support','mph_manage_appointments') as $capability) $manager_role->add_cap($capability);
            $manager_role->remove_cap('mph_manage_design');
        }
        $administrator_role = get_role('administrator');
        if ($administrator_role) $administrator_role->add_cap('mph_manage_courses');
        $old = get_option(MPH_Helpers::SETTINGS, array());
        $settings = array(
            'account_page_id' => absint($old['account_page_id'] ?? 0),
            'items' => array(
                array('id'=>'dashboard','title'=>'پیشخوان','roles'=>array('user'),'sidebar_icon'=>'dashicons-dashboard','card_icon'=>'dashicons-chart-area','hint'=>'خلاصه وضعیت حساب','enabled'=>1,'show_card'=>1),
                array('id'=>'profile','title'=>'نمایه من','roles'=>array('user'),'sidebar_icon'=>'dashicons-admin-users','card_icon'=>'dashicons-id','hint'=>'اطلاعات شخصی','enabled'=>1,'show_card'=>1),
                array('id'=>'enrolled_courses','title'=>'دوره‌های ثبت‌نام‌شده','roles'=>array('user'),'sidebar_icon'=>'dashicons-welcome-learn-more','card_icon'=>'dashicons-welcome-learn-more','hint'=>'آموزش‌های فعال','enabled'=>1,'show_card'=>1),
                array('id'=>'course_content','title'=>'دوره‌های آفلاین','roles'=>array('user'),'sidebar_icon'=>'dashicons-playlist-video','card_icon'=>'dashicons-video-alt3','hint'=>'ویدئوها و جزوه‌های ضبط‌شده','enabled'=>1,'show_card'=>1),
                array('id'=>'certificates','title'=>'گواهی‌های من','roles'=>array('user'),'sidebar_icon'=>'dashicons-awards','card_icon'=>'dashicons-awards','hint'=>'دانلود گواهی دوره‌ها','enabled'=>1,'show_card'=>1),
                array('id'=>'my_exams','title'=>'آزمون‌های من','roles'=>array('user'),
                array('id'=>'course_forum','title'=>'تالار گفت‌وگو','roles'=>array('user','instructor','manager'),'sidebar_icon'=>'dashicons-format-chat','card_icon'=>'dashicons-format-chat','hint'=>'گفت‌وگوی دوره‌ها با ویس و ریپلای','enabled'=>1,'show_card'=>1),'sidebar_icon'=>'dashicons-clipboard','card_icon'=>'dashicons-editor-help','hint'=>'آزمون‌ها و نتایج','enabled'=>1,'show_card'=>1),
                array('id'=>'wishlist','title'=>'لیست علاقه‌مندی‌ها','roles'=>array('user'),'sidebar_icon'=>'dashicons-heart','card_icon'=>'dashicons-heart','hint'=>'دوره‌های ذخیره‌شده','enabled'=>1,'show_card'=>1),
                array('id'=>'cart','title'=>'سبد خرید','roles'=>array('user'),'sidebar_icon'=>'dashicons-cart','card_icon'=>'dashicons-cart','hint'=>'محصولات آماده پرداخت','enabled'=>1,'show_card'=>1),
                array('id'=>'orders','title'=>'تاریخچه سفارشات','roles'=>array('user'),'sidebar_icon'=>'dashicons-cart','card_icon'=>'dashicons-list-view','hint'=>'خریدها و پرداخت‌ها','enabled'=>1,'show_card'=>1),
                array('id'=>'book_appointment','title'=>'رزرو نوبت','roles'=>array('user'),'sidebar_icon'=>'dashicons-calendar-alt','card_icon'=>'dashicons-calendar-alt','hint'=>'انتخاب درمانگر و زمان','enabled'=>1,'show_card'=>1),
                array('id'=>'my_appointments','title'=>'نوبت‌های من','roles'=>array('user'),'sidebar_icon'=>'dashicons-clock','card_icon'=>'dashicons-clock','hint'=>'پیگیری و دریافت PDF','enabled'=>1,'show_card'=>1),
                array('id'=>'reminders','title'=>'یادآوری‌ها','roles'=>array('user','instructor','therapist','manager'),'sidebar_icon'=>'dashicons-clock','card_icon'=>'dashicons-clock','hint'=>'یادآوری‌های سیستمی و شخصی','enabled'=>1,'show_card'=>1),
                array('id'=>'teacher_dashboard','title'=>'پیشخوان مدرس','roles'=>array('instructor'),'sidebar_icon'=>'dashicons-dashboard','card_icon'=>'dashicons-chart-area','hint'=>'نمای کلی فضای مدرس','enabled'=>1,'show_card'=>0),
                array('id'=>'teacher_courses','title'=>'دوره‌های من','roles'=>array('instructor'),'sidebar_icon'=>'dashicons-welcome-learn-more','card_icon'=>'dashicons-welcome-learn-more','hint'=>'مدیریت دوره‌ها','enabled'=>1,'show_card'=>1),
                array('id'=>'withdrawals','title'=>'برداشت‌ها','roles'=>array('instructor'),'sidebar_icon'=>'dashicons-money-alt','card_icon'=>'dashicons-money-alt','hint'=>'درآمد و تسویه‌ها','enabled'=>1,'show_card'=>1),
                array('id'=>'teacher_exams','title'=>'آزمون‌ها','roles'=>array('instructor'),'sidebar_icon'=>'dashicons-clipboard','card_icon'=>'dashicons-editor-help','hint'=>'مدیریت آزمون‌ها','enabled'=>1,'show_card'=>1),
                array('id'=>'teacher_settings','title'=>'تنظیمات','roles'=>array('instructor'),'sidebar_icon'=>'dashicons-admin-generic','card_icon'=>'dashicons-admin-settings','hint'=>'تنظیمات پنل مدرس','enabled'=>1,'show_card'=>1),
                array('id'=>'my_payouts','title'=>'واریزی‌های من','roles'=>array('instructor','therapist'),'sidebar_icon'=>'dashicons-money-alt','card_icon'=>'dashicons-money-alt','hint'=>'شماره کارت و سوابق تسویه','enabled'=>1,'show_card'=>1),
                array('id'=>'therapist_dashboard','title'=>'پیشخوان درمانگر','roles'=>array('therapist'),'sidebar_icon'=>'dashicons-heart','card_icon'=>'dashicons-chart-area','hint'=>'خلاصه نوبت‌های درمانی','enabled'=>1,'show_card'=>0),
                array('id'=>'therapist_schedule','title'=>'زمان‌های کاری','roles'=>array('therapist'),'sidebar_icon'=>'dashicons-calendar-alt','card_icon'=>'dashicons-calendar-alt','hint'=>'تعریف روز و ساعت پذیرش','enabled'=>1,'show_card'=>1),
                array('id'=>'therapist_appointments','title'=>'مراجعان و نوبت‌ها','roles'=>array('therapist'),'sidebar_icon'=>'dashicons-groups','card_icon'=>'dashicons-groups','hint'=>'مشاهده و مدیریت رزروها','enabled'=>1,'show_card'=>1),
                array('id'=>'therapist_settings','title'=>'پروفایل درمانگر','roles'=>array('therapist'),'sidebar_icon'=>'dashicons-id','card_icon'=>'dashicons-admin-users','hint'=>'اطلاعات حرفه‌ای و حساب','enabled'=>1,'show_card'=>1),
                array('id'=>'manager_dashboard','title'=>'پیشخوان مدیریت','roles'=>array('manager'),'sidebar_icon'=>'dashicons-dashboard','card_icon'=>'dashicons-chart-pie','hint'=>'آمار مجموعه','enabled'=>1,'show_card'=>1),
                array('id'=>'manage_members','title'=>'اعضا','roles'=>array('manager'),'sidebar_icon'=>'dashicons-groups','card_icon'=>'dashicons-groups','hint'=>'مدیریت اعضا','enabled'=>1,'show_card'=>1),
                array('id'=>'manage_teachers','title'=>'مدرسین','roles'=>array('manager'),'sidebar_icon'=>'dashicons-businessperson','card_icon'=>'dashicons-businessperson','hint'=>'مدیریت مدرسین','enabled'=>1,'show_card'=>1),
                array('id'=>'manage_courses','title'=>'دوره‌ها','roles'=>array('manager'),'sidebar_icon'=>'dashicons-welcome-learn-more','card_icon'=>'dashicons-welcome-learn-more','hint'=>'مدیریت دوره‌ها','enabled'=>1,'show_card'=>1),
                array('id'=>'manage_therapists','title'=>'درمانگران','roles'=>array('manager'),'sidebar_icon'=>'dashicons-heart','card_icon'=>'dashicons-heart','hint'=>'درمانگران و وضعیت فعالیت','enabled'=>1,'show_card'=>1),
                array('id'=>'manage_appointment_schedule','title'=>'تقویم نوبت‌دهی','roles'=>array('manager'),'sidebar_icon'=>'dashicons-calendar-alt','card_icon'=>'dashicons-calendar-alt','hint'=>'تنظیم زمان درمانگران','enabled'=>1,'show_card'=>1),
                array('id'=>'manage_appointments','title'=>'مدیریت نوبت‌ها','roles'=>array('manager'),'sidebar_icon'=>'dashicons-clipboard','card_icon'=>'dashicons-clipboard','hint'=>'رزروها و پرداخت‌ها','enabled'=>1,'show_card'=>1),
                array('id'=>'manage_requests','title'=>'درخواست‌ها','roles'=>array('manager'),'sidebar_icon'=>'dashicons-yes-alt','card_icon'=>'dashicons-yes-alt','hint'=>'درخواست‌های جدید','enabled'=>1,'show_card'=>1),
                array('id'=>'payment_receipts','title'=>'تأیید فیش‌ها','roles'=>array('manager'),'sidebar_icon'=>'dashicons-money-alt','card_icon'=>'dashicons-yes-alt','hint'=>'پرداخت‌های در انتظار تأیید','enabled'=>1,'show_card'=>1),
                array('id'=>'staff_payouts','title'=>'واریز مدرس و درمانگر','roles'=>array('manager'),'sidebar_icon'=>'dashicons-money-alt','card_icon'=>'dashicons-money-alt','hint'=>'ثبت و پیگیری تسویه‌ها','enabled'=>1,'show_card'=>1),
                array('id'=>'issue_certificates','title'=>'صدور گواهی‌نامه','roles'=>array('manager'),'sidebar_icon'=>'dashicons-awards','card_icon'=>'dashicons-awards','hint'=>'صدور و مدیریت گواهی‌ها','enabled'=>1,'show_card'=>1),
                array('id'=>'discount_codes','title'=>'کدهای تخفیف','roles'=>array('manager'),'sidebar_icon'=>'dashicons-tickets-alt','card_icon'=>'dashicons-tickets-alt','hint'=>'تخفیف‌های فعال فروشگاه','enabled'=>1,'show_card'=>1),
                array('id'=>'broadcast_messages','title'=>'پیام همگانی','roles'=>array('manager'),'sidebar_icon'=>'dashicons-email-alt','card_icon'=>'dashicons-megaphone','hint'=>'مدیریت پیام‌ها در ربات بله','enabled'=>1,'show_card'=>1),
                array('id'=>'business_reports','title'=>'گزارش فروش','roles'=>array('manager'),'sidebar_icon'=>'dashicons-chart-bar','card_icon'=>'dashicons-chart-bar','hint'=>'قیف خرید، فروش و خروجی Excel','enabled'=>1,'show_card'=>1),
                array('id'=>'manager_settings','title'=>'تنظیمات','roles'=>array('manager'),'sidebar_icon'=>'dashicons-admin-generic','card_icon'=>'dashicons-admin-settings','hint'=>'تنظیمات مدیریت','enabled'=>1,'show_card'=>1),
                array('id'=>'announcements','title'=>'اطلاعیه','roles'=>array('user','instructor','therapist','manager'),'sidebar_icon'=>'dashicons-megaphone','card_icon'=>'dashicons-megaphone','hint'=>'آخرین پیام‌های مدیریت','enabled'=>1,'show_card'=>1),
                array('id'=>'ticket_support','title'=>'تیکت پشتیبانی','roles'=>array('user','instructor','therapist','manager'),'sidebar_icon'=>'dashicons-sos','card_icon'=>'dashicons-sos','hint'=>'پیگیری درخواست‌های پشتیبانی','enabled'=>1,'show_card'=>1),
            )
        );
        if (!empty($old['items']) && is_array($old['items'])) {
            $old_by_id = array();
            foreach ($old['items'] as $old_item) {
                if (!empty($old_item['id'])) $old_by_id[$old_item['id']] = $old_item;
            }
            if (empty($old_by_id['announcements']) && !empty($old_by_id['teacher_notices'])) {
                $old_by_id['announcements'] = $old_by_id['teacher_notices'];
                $old_by_id['announcements']['id'] = 'announcements';
            }
            $default_ids = array();
            foreach ($settings['items'] as $index => $default_item) {
                $default_ids[] = $default_item['id'];
                if (isset($old_by_id[$default_item['id']])) $settings['items'][$index] = array_merge($default_item, $old_by_id[$default_item['id']]);
                if ($default_item['id'] === 'announcements') $settings['items'][$index] = array_merge($settings['items'][$index], array('id'=>'announcements','title'=>'اطلاعیه','roles'=>array('user','instructor','therapist','manager'),'hint'=>'آخرین پیام‌های مدیریت','enabled'=>1,'show_card'=>1));
                if ($default_item['id'] === 'reminders') $settings['items'][$index] = array_merge($settings['items'][$index], array('roles'=>array('user','instructor','therapist','manager'),'enabled'=>1,'show_card'=>1));
                if ($default_item['id'] === 'course_content') $settings['items'][$index] = array_merge($settings['items'][$index], array('title'=>'دوره‌های آفلاین','hint'=>'ویدئوها و جزوه‌های ضبط‌شده','roles'=>array('user'),'enabled'=>1));
                if ($default_item['id'] === 'ticket_support') $settings['items'][$index] = array_merge($settings['items'][$index], array('roles'=>array('user','instructor','therapist','manager'),'enabled'=>1));
                if ($default_item['id'] === 'my_appointments') $settings['items'][$index] = array_merge($settings['items'][$index], array('id'=>'my_appointments','title'=>'نوبت‌های من','roles'=>array('user'),'sidebar_icon'=>'dashicons-clock','card_icon'=>'dashicons-clock','hint'=>'پیگیری، لغو مجاز و دریافت رسید','enabled'=>1,'show_card'=>1));
                if ($default_item['id'] === 'my_payouts') $settings['items'][$index] = array_merge($settings['items'][$index], array('id'=>'my_payouts','title'=>'واریزی‌های من','roles'=>array('instructor','therapist'),'sidebar_icon'=>'dashicons-money-alt','card_icon'=>'dashicons-money-alt','hint'=>'شماره کارت و سوابق تسویه','enabled'=>1,'show_card'=>1));
                if ($default_item['id'] === 'staff_payouts') $settings['items'][$index] = array_merge($settings['items'][$index], array('id'=>'staff_payouts','title'=>'واریز مدرس و درمانگر','roles'=>array('manager'),'sidebar_icon'=>'dashicons-money-alt','card_icon'=>'dashicons-money-alt','hint'=>'ثبت و پیگیری تسویه‌ها','enabled'=>1,'show_card'=>1));
                if ($default_item['id'] === 'broadcast_messages') $settings['items'][$index] = array_merge($settings['items'][$index], array('id'=>'broadcast_messages','title'=>'پیام همگانی','roles'=>array('manager'),'hint'=>'مدیریت پیام‌ها در ربات بله','enabled'=>1,'show_card'=>1));
            }
            foreach ($old['items'] as $old_item) {
                if (!empty($old_item['id']) && !in_array($old_item['id'], array('teacher_notices','notification_settings','portal_design'), true) && !in_array($old_item['id'], $default_ids, true)) $settings['items'][] = $old_item;
            }
        }
        update_option(MPH_Helpers::SETTINGS, $settings);
        
        // Ensure course_forum menu exists for non-therapist roles without wiping custom menus.
        $settings = get_option(MPH_Helpers::SETTINGS, array());
        $items = isset($settings['items']) && is_array($settings['items']) ? $settings['items'] : array();
        $has_forum = false;
        foreach ($items as $it) if (($it['id'] ?? '') === 'course_forum') { $has_forum = true; break; }
        if (!$has_forum) {
            $items[] = array('id'=>'course_forum','title'=>'تالار گفت‌وگو','roles'=>array('user','instructor','manager'),'sidebar_icon'=>'dashicons-format-chat','card_icon'=>'dashicons-format-chat','hint'=>'گفت‌وگوی دوره‌ها','enabled'=>1,'show_card'=>1);
            $settings['items'] = $items;
            update_option(MPH_Helpers::SETTINGS, $settings);
        }

        update_option(self::DEFAULTS_VERSION_OPTION, MPH_VERSION, false);
    }

    public static function menu() {
        add_menu_page('پروفایل مدرن','پروفایل مدرن','manage_options','mph',array(__CLASS__,'settings_page'),'dashicons-id-alt',58);
        add_submenu_page('mph','منوها و آیکون‌ها','منوها و آیکون‌ها','manage_options','mph',array(__CLASS__,'settings_page'));
        add_submenu_page('mph','روش پرداخت آنلاین','روش پرداخت آنلاین','manage_options','mph-payments',array('MPH_Payments','admin_page'));
        add_submenu_page('mph','شیوه و محتوای دوره‌ها','شیوه و محتوای دوره‌ها','mph_manage_courses','mph-courses',array('MPH_Courses','admin_page'));
        add_submenu_page('mph','دوره‌های آنلاین','دوره‌های آنلاین','mph_manage_courses','mph-courses-online',array('MPH_Courses','admin_online_page'));
        add_submenu_page('mph','دوره‌های آفلاین','دوره‌های آفلاین','mph_manage_courses','mph-courses-offline',array('MPH_Courses','admin_offline_page'));
        add_submenu_page('mph','دوره‌های حضوری','دوره‌های حضوری','mph_manage_courses','mph-courses-inperson',array('MPH_Courses','admin_inperson_page'));
        add_submenu_page('mph','کدهای تخفیف','کدهای تخفیف','manage_options','mph-discounts',array('MPH_Discounts','admin_page'));
        add_submenu_page('mph','تقویم آموزشی','تقویم آموزشی','manage_options','mph-calendar',array('MPH_Calendar','admin_page'));
        add_submenu_page('mph','سفیر بله','سفیر بله','manage_options','mph-safir',array('MPH_Safir','admin_page'));
        add_submenu_page('mph','مرکز پیامک و OTP','مرکز پیامک و OTP','manage_options','mph-sms',array('MPH_SMS','admin_page'));
        add_submenu_page('mph','درخواست نقش‌ها','درخواست نقش‌ها','manage_options','mph-role-requests',array(__CLASS__,'role_requests_page'));
        add_submenu_page('mph','اعضای سایت','اعضای سایت','list_users','mph-members',array(__CLASS__,'members_page'));
    }

    public static function assets($hook) {
        if (strpos($hook,'mph')===false) return;
        wp_enqueue_style('mph-yekanbakh', MPH_URL.'assets/css/yekanbakh.css', array(), MPH_VERSION);
        wp_enqueue_style('mph-admin-release', MPH_URL.'assets/css/admin-release.css', array('dashicons','mph-yekanbakh'), MPH_VERSION);
        wp_enqueue_script('mph-admin', MPH_URL.'assets/js/admin.js', array(), MPH_VERSION, true);
        $course_page=strpos($hook,'mph-courses')!==false;
        $design_page=$hook==='toplevel_page_mph';
        if($course_page||$design_page)wp_enqueue_media();
        if($course_page)wp_enqueue_script('mph-course-admin', MPH_URL.'assets/js/course-admin.js', array('mph-admin'), MPH_VERSION, true);
        if($course_page||strpos($hook,'mph-calendar')!==false)wp_enqueue_script('mph-jalali-datetime', MPH_URL.'assets/js/jalali-datetime.js', array(), MPH_VERSION, true);
        foreach(array('mph-admin','mph-course-admin','mph-jalali-datetime')as$handle)wp_script_add_data($handle,'strategy','defer');
        wp_localize_script('mph-admin','MPH_ADMIN',array('ajaxUrl'=>admin_url('admin-ajax.php')));
    }

    public static function save() {
        if(!current_user_can('manage_options')||empty($_POST['mph_admin_nonce'])||!wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['mph_admin_nonce'])),'mph_admin'))return;
        $handled=false;
        if(isset($_POST['mph_save_items'])){self::save_items();$handled=true;}
        if(isset($_POST['mph_approve'])){self::approve();$handled=true;}
        if(isset($_POST['mph_approve_role'])){MPH_Roles::approve(absint($_POST['mph_approve_role']));$handled=true;}
        if(isset($_POST['mph_reject_role'])){MPH_Roles::reject(absint($_POST['mph_reject_role']));$handled=true;}
        if(isset($_POST['mph_make_manager'])){self::make_manager();$handled=true;}
        if(!$handled)return;
        $page=sanitize_key(wp_unslash($_GET['page']??'mph'));
        if(strpos($page,'mph')!==0)$page='mph';
        wp_safe_redirect(add_query_arg(array('page'=>$page,'mph_admin_saved'=>1),admin_url('admin.php')));
        exit;
    }

    private static function save_items() {
        $settings=get_option(MPH_Helpers::SETTINGS,array());
        $settings['account_page_id']=absint($_POST['account_page_id']??0);
        $ids=(array)($_POST['item_id']??array());$titles=(array)($_POST['item_title']??array());$sidebar=(array)($_POST['sidebar_icon']??array());$cards=(array)($_POST['card_icon']??array());$side_images=(array)($_POST['sidebar_image_id']??array());$card_images=(array)($_POST['card_image_id']??array());$hints=(array)($_POST['item_hint']??array());
        $items=array();foreach($ids as $n=>$raw_id){if(isset($_POST['item_delete'][$n]))continue;$id=sanitize_key(wp_unslash($raw_id));$title=sanitize_text_field(wp_unslash($titles[$n]??''));if(!$id||!$title||in_array($id,array('notification_settings','portal_design'),true))continue;$roles=array();foreach(array('user','instructor','therapist','manager') as $role)if(isset($_POST['roles'][$n][$role]))$roles[]=$role;if(!$roles)$roles=array('user');$items[]=array('id'=>$id,'title'=>$title,'roles'=>$roles,'sidebar_icon'=>sanitize_html_class($sidebar[$n]??'dashicons-menu'),'card_icon'=>sanitize_html_class($cards[$n]??'dashicons-star-filled'),'sidebar_image_id'=>absint($side_images[$n]??0),'card_image_id'=>absint($card_images[$n]??0),'hint'=>sanitize_text_field(wp_unslash($hints[$n]??'')),'enabled'=>isset($_POST['enabled'][$n])?1:0,'show_card'=>isset($_POST['show_card'][$n])?1:0);}
        $settings['items']=$items;update_option(MPH_Helpers::SETTINGS,$settings);
    }

    private static function approve() {$id=absint($_POST['mph_approve']);$u=get_user_by('id',$id);if(!$u)return;$u->add_role('mph_instructor');update_user_meta($id,'mph_instructor_status','approved');$alias=MPH_Helpers::posted('instructor_alias');if($alias&&MPH_Helpers::valid_person_name($alias))wp_update_user(array('ID'=>$id,'display_name'=>$alias));$pass=MPH_Helpers::posted('instructor_password','raw');if($pass&&MPH_Helpers::strong_password($pass))wp_set_password($pass,$id);}
    private static function make_manager() {$u=get_user_by('id',absint($_POST['manager_user']??0));if($u)$u->add_role('mph_manager');}
    public static function delete_member() {
        $id=absint($_POST['user_id']??0);
        if(!$id||!wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['_wpnonce']??'')),'mph_delete_member_'.$id))self::members_redirect('درخواست حذف معتبر نیست.','error');
        if(!(current_user_can('delete_users')||current_user_can('manage_options')||(class_exists('MPH_Manager')&&MPH_Manager::is_portal_super_admin())))self::members_redirect('اجازه حذف کاربر را ندارید.','error');
        if($id===get_current_user_id())self::members_redirect('حساب فعلی را نمی‌توانید حذف کنید.','error');
        if(class_exists('MPH_Manager')&&MPH_Manager::is_portal_super_admin($id))self::members_redirect('سوپرادمین محافظت‌شده قابل حذف نیست.','error');
        if(is_multisite()&&is_super_admin($id))self::members_redirect('سوپرادمین شبکه قابل حذف نیست.','error');
        $user=get_user_by('id',$id);if(!$user)self::members_redirect('کاربر پیدا نشد.','error');
        require_once ABSPATH.'wp-admin/includes/user.php';
        if(class_exists('MPH_Courses')&&method_exists('MPH_Courses','on_delete_user_release'))MPH_Courses::on_delete_user_release($id);
        $deleted=wp_delete_user($id,get_current_user_id());
        if(!$deleted)self::members_redirect('وردپرس حذف کاربر را انجام نداد. افزونه امنیتی یا محدودیت پایگاه‌داده را بررسی کنید.','error');
        if(class_exists('MPH_Helpers'))MPH_Helpers::audit('admin_member_deleted','target='.$id.';login='.$user->user_login);
        self::members_redirect('عضو «'.MPH_Helpers::display_name($user).'» حذف شد.','success');
    }

    private static function members_redirect($message,$type){wp_safe_redirect(add_query_arg(array('page'=>'mph-members','mph_member_notice'=>$message,'mph_member_type'=>$type),admin_url('admin.php')));exit;}

    private static function head($title,$text){if(!empty($_GET['mph_admin_saved']))add_settings_error('mph','saved','تغییرات با موفقیت ذخیره شد.','success');settings_errors('mph');?><div class="wrap mph-admin" dir="rtl"><header class="mph-admin-head"><span class="dashicons dashicons-id-alt"></span><div><h1><?php echo esc_html($title); ?></h1><p><?php echo esc_html($text); ?></p></div></header><?php }

    public static function settings_page() {
        self::install_defaults();self::head('منوها و آیکون‌ها','ساخت منوی هر نقش و انتخاب آیکون آماده یا تصویر دلخواه');$settings=get_option(MPH_Helpers::SETTINGS,array());$items=$settings['items']??array();$popup=$settings['account_page_id']?MPH_Helpers::auth_popup_url():''; ?>
        <div class="mph-admin-note"><b>شورت‌کد حساب:</b> <code>[mph_profile]</code><p><b>لینک ثابت آیکون/پاپ‌آپ:</b> <code><?php echo esc_html($popup?:'ابتدا برگه حساب کاربری را انتخاب کنید.'); ?></code></p><p>این لینک را بدون تغییر روی آیکون حساب سایت قرار دهید؛ برای مهمان پاپ‌آپ باز می‌شود و در صورت غیرفعال بودن جاوااسکریپت به صفحه سفید ورود می‌رود.</p></div>
        <form method="post" class="mph-admin-box" id="mph-menu-builder"><?php wp_nonce_field('mph_admin','mph_admin_nonce'); ?><div class="mph-admin-grid"><label>برگه حساب کاربری<?php wp_dropdown_pages(array('name'=>'account_page_id','selected'=>$settings['account_page_id']??0,'show_option_none'=>'انتخاب برگه')); ?></label><div><b>راهنمای آیکون</b><p><a href="https://developer.wordpress.org/resource/dashicons/" target="_blank" rel="noopener">مشاهده نام آیکون‌های Dashicons</a></p></div></div><div class="mph-builder-head"><div><h2>موارد منو</h2><p>عنوان، نقش، آیکون ستون راست و تصویر کارت را مدیریت کنید.</p></div><button type="button" class="button" data-add-menu>＋ افزودن مورد</button></div>
        <div class="mph-menu-rows"><?php foreach($items as $n=>$item)self::menu_row($n,$item); ?></div><button class="button button-primary" name="mph_save_items" value="1">ذخیره منوها</button></form>
        <form method="post" class="mph-admin-box"><?php wp_nonce_field('mph_admin','mph_admin_nonce'); ?><h2>تعریف مدیر مجموعه</h2><p>بعد از انتخاب کاربر، گزینه پنل مدیر در تغییر نقش او فعال می‌شود.</p><?php wp_dropdown_users(array('name'=>'manager_user','show_option_none'=>'انتخاب کاربر')); ?> <button class="button button-primary" name="mph_make_manager" value="1">فعال‌سازی نقش مدیر</button></form></div><?php
    }

    private static function menu_row($n,$item) { ?>
        <div class="mph-menu-row" data-menu-row><div class="mph-row-top"><b>مورد منو</b><label class="mph-mini-check"><input type="checkbox" name="enabled[<?php echo $n; ?>]" <?php checked(!empty($item['enabled'])); ?>> فعال</label><label class="mph-mini-check"><input type="checkbox" name="show_card[<?php echo $n; ?>]" <?php checked(!empty($item['show_card'])); ?>> کارت پیشخوان</label><label class="mph-delete-check"><input type="checkbox" name="item_delete[<?php echo $n; ?>]"> حذف</label></div><div class="mph-menu-grid">
        <label>شناسه<input name="item_id[<?php echo $n; ?>]" value="<?php echo esc_attr($item['id']??''); ?>" placeholder="custom_item"></label><label>عنوان<input name="item_title[<?php echo $n; ?>]" value="<?php echo esc_attr($item['title']??''); ?>"></label><label>آیکون آماده ستون راست<input name="sidebar_icon[<?php echo $n; ?>]" value="<?php echo esc_attr($item['sidebar_icon']??'dashicons-menu'); ?>"></label><label>آیکون آماده کارت<input name="card_icon[<?php echo $n; ?>]" value="<?php echo esc_attr($item['card_icon']??'dashicons-star-filled'); ?>"></label><label>تصویر ستون راست<?php echo self::media_field('sidebar_image_id',$n,$item['sidebar_image_id']??0); ?></label><label>تصویر کارت<?php echo self::media_field('card_image_id',$n,$item['card_image_id']??0); ?></label><label>توضیح کارت<input name="item_hint[<?php echo $n; ?>]" value="<?php echo esc_attr($item['hint']??''); ?>"></label></div><div class="mph-role-checks"><span>نمایش برای:</span><?php foreach(array('user'=>'کاربر','instructor'=>'مدرس','therapist'=>'درمانگر','manager'=>'مدیر') as $role=>$label): ?><label><input type="checkbox" name="roles[<?php echo $n; ?>][<?php echo $role; ?>]" <?php checked(in_array($role,$item['roles']??array(),true)); ?>> <?php echo $label; ?></label><?php endforeach; ?></div></div><?php
    }

    private static function media_field($name,$n,$id){$url=$id?wp_get_attachment_image_url($id,'thumbnail'):'';return '<div class="mph-media-field"><input type="hidden" name="'.esc_attr($name).'['.$n.']" value="'.absint($id).'" data-media-id><span class="mph-media-preview">'.($url?'<img src="'.esc_url($url).'" alt="">':'بدون تصویر').'</span><button type="button" class="button" data-media-upload>انتخاب تصویر</button><button type="button" class="button-link-delete" data-media-remove>حذف</button></div>';}

    public static function instructors_page() {
        self::head('درخواست مدرسین','تأیید مدرس و فعال‌کردن تغییر نقش');$users=get_users(array('meta_key'=>'mph_instructor_status','meta_value'=>'pending')); ?><div class="mph-admin-box"><div class="mph-table-wrap"><table class="widefat striped"><thead><tr><th>نام</th><th>تلفن</th><th>رشته</th><th>تأیید</th></tr></thead><tbody><?php if(!$users): ?><tr><td colspan="4">درخواستی وجود ندارد.</td></tr><?php endif;foreach($users as $u): ?><tr><td><?php echo esc_html(MPH_Helpers::display_name($u)); ?></td><td><?php echo esc_html(get_user_meta($u->ID,'mph_phone',true)); ?></td><td><?php echo esc_html(get_user_meta($u->ID,'mph_major',true)); ?></td><td><form method="post" class="mph-inline-form"><?php wp_nonce_field('mph_admin','mph_admin_nonce'); ?><input name="instructor_alias" placeholder="نام نمایشی"><input type="password" name="instructor_password" minlength="10" placeholder="رمز جدید اختیاری"><button class="button button-primary" name="mph_approve" value="<?php echo $u->ID; ?>">تأیید</button></form></td></tr><?php endforeach; ?></tbody></table></div></div></div><?php
    }

    public static function role_requests_page() {
        self::head('درخواست نقش‌ها','تأیید نقش بدون تغییر نام کاربری یا رمز عبور');
        $requests=get_posts(array('post_type'=>MPH_Roles::POST_TYPE,'post_status'=>'pending','numberposts'=>100,'orderby'=>'date','order'=>'DESC')); ?>
        <section class="mph-admin-box"><div class="mph-table-wrap"><table class="widefat striped"><thead><tr><th>کاربر</th><th>نقش درخواستی</th><th>توضیحات</th><th>تاریخ</th><th>عملیات</th></tr></thead><tbody><?php if(!$requests): ?><tr><td colspan="5">درخواست در انتظاری وجود ندارد.</td></tr><?php endif;foreach($requests as $request):$user=get_user_by('id',$request->post_author);$role=get_post_meta($request->ID,'mph_requested_role',true); ?><tr><td><?php echo esc_html($user?MPH_Helpers::display_name($user):'کاربر حذف‌شده'); ?></td><td><?php echo esc_html(MPH_Roles::label($role)); ?></td><td><?php echo esc_html($request->post_content?:'—'); ?></td><td><?php echo esc_html(get_the_date('Y/m/d',$request)); ?></td><td><form method="post" class="mph-inline-form"><?php wp_nonce_field('mph_admin','mph_admin_nonce'); ?><button class="button button-primary" name="mph_approve_role" value="<?php echo $request->ID; ?>">تأیید</button><button class="button" name="mph_reject_role" value="<?php echo $request->ID; ?>">رد</button></form></td></tr><?php endforeach; ?></tbody></table></div></section></div><?php
    }

    public static function members_page() {
        self::head('اعضای سایت','فهرست اعضا با تفکیک نقش و امکان حذف');
        $notice=sanitize_text_field(wp_unslash($_GET['mph_member_notice']??''));$notice_type=sanitize_key(wp_unslash($_GET['mph_member_type']??''));if($notice): ?><div class="notice notice-<?php echo $notice_type==='error'?'error':'success'; ?> is-dismissible"><p><?php echo esc_html($notice); ?></p></div><?php endif;
        $roles=array('user'=>'کاربر','instructor'=>'مدرس','therapist'=>'درمانگر','manager'=>'مدیر');
        foreach($roles as $role=>$label){$users=class_exists('MPH_Manager')?MPH_Manager::logical_users($role,-1):array(); ?><section class="mph-admin-box"><div class="mph-builder-head"><h2><?php echo esc_html($label); ?></h2><span class="mph-count"><?php echo count($users); ?> نفر</span></div><div class="mph-table-wrap"><table class="widefat striped"><thead><tr><th>تصویر</th><th>نام</th><th>تلفن</th><th>ایمیل</th><th>نقش پنل</th><th>عضویت</th><th>عملیات</th></tr></thead><tbody><?php if(!$users): ?><tr><td colspan="7">عضوی در این گروه نیست.</td></tr><?php endif;foreach($users as $u):$protected=$u->ID===get_current_user_id()||(class_exists('MPH_Manager')&&MPH_Manager::is_portal_super_admin($u->ID))||(is_multisite()&&is_super_admin($u->ID)); ?><tr><td><?php echo get_avatar($u->ID,40); ?></td><td><a href="<?php echo esc_url(get_edit_user_link($u->ID)); ?>"><?php echo esc_html(MPH_Helpers::display_name($u)); ?></a></td><td><?php echo esc_html(get_user_meta($u->ID,'mph_phone',true)?:'—'); ?></td><td><?php echo esc_html($u->user_email?:'—'); ?></td><td><?php echo esc_html(MPH_Manager::role_names($u)); ?></td><td><?php echo esc_html(date_i18n('Y/m/d',strtotime($u->user_registered))); ?></td><td><?php if(!$protected): ?><form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" onsubmit="return confirm('این عضو و اطلاعات وابسته او حذف شود؟')"><input type="hidden" name="action" value="mph_delete_member"><input type="hidden" name="user_id" value="<?php echo absint($u->ID); ?>"><?php wp_nonce_field('mph_delete_member_'.$u->ID); ?><button class="button-link-delete" type="submit">حذف عضو</button></form><?php else: ?><span class="dashicons dashicons-lock" title="حساب محافظت‌شده"></span><?php endif; ?></td></tr><?php endforeach; ?></tbody></table></div></section><?php } ?></div><?php
    }
}
