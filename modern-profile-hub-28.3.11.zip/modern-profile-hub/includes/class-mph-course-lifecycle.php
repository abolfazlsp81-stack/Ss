<?php
defined('ABSPATH') || exit;

final class MPH_Course_Lifecycle {
    public static function init() {
        add_action('wp_ajax_mph_course_delete',array(__CLASS__,'delete'));
        add_filter('woocommerce_is_purchasable',array(__CLASS__,'purchasable'),30,2);
        add_action('pre_get_posts',array(__CLASS__,'catalog'));
    }
    public static function archived($id) {return (bool)get_post_meta(absint($id),'_mph_archived',true);}
    public static function purchasable($allowed,$product) {return $allowed && !self::archived((int)$product->get_meta(MPH_Courses::COURSE_META));}
    public static function catalog($query) {
        if(is_admin() || !$query->is_main_query() || $query->is_singular())return;
        $type=MPH_Tutor::active()?tutor()->course_post_type:'courses';
        if($query->get('post_type')!==$type && !$query->is_post_type_archive($type))return;
        $query->set('meta_query',array('relation'=>'AND',(array)$query->get('meta_query'),array('key'=>'_mph_archived','compare'=>'NOT EXISTS')));
    }
    public static function has_history($id) {
        if(MPH_Tutor::course_student_ids($id))return true;
        global $wpdb;$products=array_values(array_filter(array_map('absint',MPH_Courses::product_map($id))));
        $found=$wpdb->get_var($wpdb->prepare("SELECT meta_id FROM {$wpdb->prefix}woocommerce_order_itemmeta WHERE meta_key=%s AND meta_value=%s LIMIT 1",MPH_Courses::COURSE_META,(string)$id));
        if($found)return true;
        foreach($products as $product)if($wpdb->get_var($wpdb->prepare("SELECT meta_id FROM {$wpdb->prefix}woocommerce_order_itemmeta WHERE meta_key='_product_id' AND meta_value=%s LIMIT 1",(string)$product)))return true;
        return false;
    }
    public static function controls($course) {
        $archived=self::archived($course->ID);$history=self::has_history($course->ID);
        $message=$archived?'دوره دوباره برای خرید جدید فعال شود؟':($history?'این دوره سابقه خرید یا دانشجو دارد. فروش جدید متوقف و دوره بایگانی شود؟ دسترسی خریداران و سوابق حفظ می‌شود.':'دوره به زباله‌دان منتقل شود؟');
        return '<section class="mph-course-delete-box"><h4>'.($archived?'دوره بایگانی شده':'حذف دوره').'</h4><p>'.esc_html($message).'</p><form data-mph-action="mph_course_delete" data-confirm="'.esc_attr($message).'"><input type="hidden" name="course_id" value="'.absint($course->ID).'"><input type="hidden" name="restore" value="'.($archived?'1':'0').'"><button class="mph-secondary" type="submit">'.($archived?'بازگرداندن دوره':($history?'بایگانی امن دوره':'حذف دوره')).'</button><div class="mph-message"></div></form></section>';
    }
    public static function apply($id,$restore=false) {
        $course=get_post($id);$type=MPH_Tutor::active()?tutor()->course_post_type:'courses';
        if(!$course || $course->post_type!==$type)return new WP_Error('mph_course','دوره معتبر نیست.');
        if($restore){delete_post_meta($id,'_mph_archived');$message='دوره از بایگانی بازگردانده شد.';}
        elseif(self::has_history($id)){update_post_meta($id,'_mph_archived',time());$message='دوره بایگانی شد؛ دسترسی خریداران و سوابق محفوظ است.';}
        else {foreach(MPH_Courses::product_map($id) as $product)wp_trash_post(absint($product));if(!wp_trash_post($id))return new WP_Error('mph_delete','حذف دوره انجام نشد.');$message='دوره به زباله‌دان منتقل شد.';}
        MPH_Helpers::audit('course_lifecycle','course='.$id.';operation='.($restore?'restore':'remove'));
        return $message;
    }
    public static function delete() {
        MPH_Helpers::verify_ajax();if(!current_user_can('mph_manage_courses')&&!current_user_can('manage_options'))wp_send_json_error(array('message'=>'اجازه مدیریت دوره را ندارید.'),403);
        $result=self::apply(absint($_POST['course_id']??0),!empty($_POST['restore']));
        if(is_wp_error($result))wp_send_json_error(array('message'=>$result->get_error_message()),400);
        unset($_POST['course_id'],$_GET['course_id']);wp_send_json_success(array('message'=>$result,'html'=>MPH_Dashboard::panel('manage_courses','manager')));
    }
}
