<?php
defined('ABSPATH') || exit;

/** Native browser + in-page notifications for active portal sessions. */
final class MPH_Web_Notifications {
    private static $prompt_rendered = false;

    public static function init() {
        add_action('wp_ajax_mph_web_notifications', array(__CLASS__, 'ajax_feed'));
        add_action('wp_footer', array(__CLASS__, 'footer_prompt'), 98);
    }

    public static function enqueue_assets() {
        if(!is_user_logged_in())return;
        if(!wp_script_is('mph-web-notifications','registered'))wp_register_script('mph-web-notifications', MPH_URL.'assets/js/web-notifications.js', array('mph-frontend'), MPH_VERSION, true);
        wp_enqueue_script('mph-web-notifications');
        wp_enqueue_style('mph-web-notifications', MPH_URL.'assets/css/web-notifications.css', array('dashicons','mph-yekanbakh'), MPH_VERSION);
        static$localized=false;
        if(!$localized){
            wp_localize_script('mph-web-notifications', 'MPH_WEB_NOTIFY', array(
                'ajaxUrl'=>admin_url('admin-ajax.php'),
                'nonce'=>wp_create_nonce('mph_nonce'),
                'icon'=>defined('MPH_LOGO_URL')?esc_url_raw(MPH_LOGO_URL):'',
                'site'=>wp_specialchars_decode(get_bloginfo('name'), ENT_QUOTES),
                'pollInterval'=>45000,
                'mode'=>MPH_Helpers::current_mode(),
            ));
            $localized=true;
        }
        wp_script_add_data('mph-web-notifications', 'strategy', 'defer');
    }

    public static function permission_prompt() {
        if(!is_user_logged_in()||self::$prompt_rendered)return'';
        self::$prompt_rendered=true;
        return '<aside class="mph-web-notification-consent" data-mph-notification-consent hidden>'
            .'<span class="dashicons dashicons-bell"></span>'
            .'<div><b>اعلان‌های سایت را فعال کنید</b><small>پاسخ تیکت، اطلاعیه و یادآوری را همراه صدای اعلان دریافت کنید.</small></div>'
            .'<button type="button" class="mph-primary" data-mph-notification-enable>اجازه می‌دهم</button>'
            .'<button type="button" class="mph-icon-button" data-mph-notification-dismiss aria-label="فعلاً نه">×</button>'
            .'</aside><div class="mph-web-notification-stack" data-mph-notification-stack aria-live="polite"></div>';
    }

    public static function footer_prompt() {
        if(is_admin()||!is_user_logged_in())return;
        echo self::permission_prompt(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    }

    public static function ajax_feed() {
        MPH_Helpers::verify_ajax();
        if(!is_user_logged_in())wp_send_json_error(array('message'=>'نشست کاربری معتبر نیست.'),401);
        $mode=MPH_Helpers::allowed_mode(MPH_Helpers::posted('notification_mode','key')?:MPH_Helpers::current_mode());$user_id=get_current_user_id();$items=array();
        if(class_exists('MPH_Tickets')){$item=MPH_Tickets::notification_payload($mode,$user_id);if($item)$items[]=$item;}
        if(class_exists('MPH_Notices')){$item=MPH_Notices::notification_payload($mode,$user_id);if($item)$items[]=$item;}
        if(class_exists('MPH_Growth')){$item=MPH_Growth::notification_payload($user_id);if($item)$items[]=$item;}
        usort($items,function($a,$b){return absint($b['timestamp']??0)<=>absint($a['timestamp']??0);});
        wp_send_json_success(array('items'=>array_slice($items,0,6),'serverTime'=>time()));
    }
}
