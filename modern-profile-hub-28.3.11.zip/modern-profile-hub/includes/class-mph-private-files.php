<?php
defined('ABSPATH') || exit;

/** Private attachments have no public plaintext copy, including generated thumbnails. */
final class MPH_Private_Files {
    const META='_mph_private_file_v28';
    private static $temporary=array();
    public static function init() {
        add_filter('get_attached_file',array(__CLASS__,'local_path'),20,2);
        add_filter('wp_get_attachment_url',array(__CLASS__,'url'),20,2);
        add_filter('wp_get_attachment_image_src',array(__CLASS__,'image'),20,4);
        add_filter('wp_calculate_image_srcset',array(__CLASS__,'srcset'),20,5);
        add_action('admin_post_mph_private_file',array(__CLASS__,'download'));
        add_action('admin_post_nopriv_mph_private_file',array(__CLASS__,'download'));
        add_action('delete_attachment',array(__CLASS__,'delete'));
        add_action('wp_ajax_mph_private_upload',array(__CLASS__,'upload'));
        add_action('mph_private_file_migrate',array(__CLASS__,'migrate'));
        add_action('init',function(){if(!wp_next_scheduled('mph_private_file_migrate'))wp_schedule_event(time()+30,'hourly','mph_private_file_migrate');});
    }
    public static function directory() {return WP_CONTENT_DIR.'/mph-private';}
    private static function cleanup_public($id,$path='') {
        $path=$path?:get_attached_file($id,true);if(!$path)return true;
        $image=wp_get_attachment_metadata($id);$paths=array($path);
        foreach((array)($image['sizes']??array()) as $size)if(!empty($size['file']))$paths[]=dirname($path).'/'.basename($size['file']);
        if(!empty($image['original_image']))$paths[]=dirname($path).'/'.basename($image['original_image']);
        foreach((array)get_post_meta($id,'_wp_attachment_backup_sizes',true) as $size)if(!empty($size['file']))$paths[]=dirname($path).'/'.basename($size['file']);
        foreach(array_unique($paths) as $old){
            if(!is_file($old))continue;
            if(@unlink($old))continue;
            $wiped=@file_put_contents($old,'',LOCK_EX);@chmod($old,0600);
            if($wiped===false || (is_file($old) && filesize($old)>0)){update_post_meta($id,'_mph_private_cleanup_required',1);return false;}
            @unlink($old);
        }
        if(is_array($image)){$image['sizes']=array();unset($image['original_image']);wp_update_attachment_metadata($id,$image);}
        delete_post_meta($id,'_wp_attachment_backup_sizes');delete_post_meta($id,'_mph_private_cleanup_required');return true;
    }
    public static function protect($id,$type,$object,$owner) {
        $id=absint($id);$meta=get_post_meta($id,self::META,true);
        if ($meta) {self::bind($id,$type,$object,$owner);return self::cleanup_public($id)?$id:new WP_Error('mph_cleanup','پاک‌سازی نسخه عمومی فایل انجام نشد؛ مدیر باید دسترسی فایل را بررسی کند.');}
        $path=get_attached_file($id,true);
        if (!$path || !is_readable($path)) return new WP_Error('mph_file_missing','فایل پیوست در دسترس نیست.');
        $plain=file_get_contents($path);
        if ($plain===false) return new WP_Error('mph_file_read','خواندن پیوست انجام نشد.');
        $payload=wp_json_encode(array('content'=>base64_encode($plain)));
        $cipher=MPH_Security::encrypt($payload);
        if ($cipher===$payload || !preg_match('/^mph:(v1|a1):/',$cipher)) return new WP_Error('mph_crypto','نگهداری امن فایل روی این میزبان آماده نیست؛ مدیر تنظیمات رمزنگاری را بررسی کند.');
        $dir=self::directory();
        if (!wp_mkdir_p($dir)) return new WP_Error('mph_storage','فضای نگهداری امن فایل قابل نوشتن نیست.');
        if (!file_exists($dir.'/.htaccess')) file_put_contents($dir.'/.htaccess',"Require all denied\nDeny from all\n");
        if (!file_exists($dir.'/index.php')) file_put_contents($dir.'/index.php',"<?php http_response_code(404); exit;");
        $name=bin2hex(random_bytes(24)).'.bin';
        if (file_put_contents($dir.'/'.$name,$cipher,LOCK_EX)!==strlen($cipher)) return new WP_Error('mph_storage','ذخیره امن فایل کامل نشد.');
        @chmod($dir.'/'.$name,0600);
        $meta=array('storage'=>$name,'name'=>basename($path),'type'=>sanitize_key($type),'object'=>absint($object),'owner'=>absint($owner),'created'=>time());
        update_post_meta($id,self::META,$meta);
        if (get_post_meta($id,self::META,true)!==$meta) {unlink($dir.'/'.$name);return new WP_Error('mph_file_meta','ثبت اطلاعات پیوست انجام نشد.');}
        if(!self::cleanup_public($id,$path))return new WP_Error('mph_cleanup','پاک‌سازی نسخه عمومی فایل انجام نشد؛ مدیر باید دسترسی فایل را بررسی کند.');
        return $id;
    }
    public static function bind($id,$type,$object,$owner) {
        $meta=get_post_meta($id,self::META,true);if(!is_array($meta))return false;
        $meta['type']=sanitize_key($type);$meta['object']=absint($object);$meta['owner']=absint($owner);update_post_meta($id,self::META,$meta);return true;
    }
    public static function local_path($path,$id) {
        $meta=get_post_meta($id,self::META,true);if(!$meta)return $path;
        if(isset(self::$temporary[$id]) && is_file(self::$temporary[$id]))return self::$temporary[$id];
        $encrypted=self::directory().'/'.basename($meta['storage']);
        if(!is_readable($encrypted))return '';
        $data=json_decode(MPH_Security::decrypt(file_get_contents($encrypted)),true);
        $plain=is_array($data)?base64_decode($data['content']??'',true):false;
        if($plain===false)return '';
        $tmp=tempnam(get_temp_dir(),'mph-file-');if(!$tmp)return '';
        $ext=strtolower(pathinfo((string)($meta['name']??''),PATHINFO_EXTENSION));
        if($ext && preg_match('/^[a-z0-9]{1,8}$/',$ext)){if(@rename($tmp,$tmp.'.'.$ext))$tmp.='.'.$ext;}
        if(file_put_contents($tmp,$plain,LOCK_EX)!==strlen($plain)){unlink($tmp);return '';}
        @chmod($tmp,0600);self::$temporary[$id]=$tmp;
        register_shutdown_function(function()use($tmp){if(is_file($tmp))unlink($tmp);});return $tmp;
    }
    public static function can_read($id,$user_id=0) {
        $uid=$user_id?:get_current_user_id();if(!$uid)return false;
        $meta=get_post_meta($id,self::META,true);if(!is_array($meta))return false;
        if($meta['type']==='ticket')return MPH_Tickets::file_access($meta['object'],$id,$uid);
        if($meta['type']==='receipt'){$order=function_exists('wc_get_order')?wc_get_order($meta['object']):false;return $order && (int)$order->get_meta(MPH_Commerce::RECEIPT_FILE)===(int)$id && ((int)$order->get_customer_id()===$uid || user_can($uid,'mph_manage_portal') || user_can($uid,'manage_options'));}
        return $meta['type']==='draft' && (int)$meta['owner']===$uid;
    }
    public static function url($url,$id) {return get_post_meta($id,self::META,true)?add_query_arg(array('action'=>'mph_private_file','file_id'=>absint($id)),admin_url('admin-post.php')):$url;}
    public static function image($image,$id,$size,$icon) {if($image&&get_post_meta($id,self::META,true)){$image[0]=self::url('',$id);$image[3]=false;}return $image;}
    public static function srcset($sources,$size,$src,$meta,$id) {return get_post_meta($id,self::META,true)?false:$sources;}
    public static function download() {
        $id=absint($_GET['file_id']??0);
        if(!self::can_read($id))wp_die('اجازه مشاهده این پیوست را ندارید.','',array('response'=>403));
        $path=get_attached_file($id);if(!$path || !is_readable($path))wp_die('فایل قابل دریافت نیست.','',array('response'=>404));
        $meta=get_post_meta($id,self::META,true);$mime=get_post_mime_type($id);
        while(ob_get_level())ob_end_clean();nocache_headers();header('X-Content-Type-Options: nosniff');header("Content-Security-Policy: sandbox; default-src 'none'");header('Referrer-Policy: no-referrer');
        header('Content-Type: '.($mime?:'application/octet-stream'));header('Content-Length: '.filesize($path));
        $inline=in_array($mime,array('image/jpeg','image/png','image/gif','image/webp','application/pdf'),true);
        header('Content-Disposition: '.($inline?'inline':'attachment').'; filename="'.sanitize_file_name($meta['name']).'"');readfile($path);exit;
    }
    public static function delete($id) {$meta=get_post_meta($id,self::META,true);if($meta){$path=self::directory().'/'.basename($meta['storage']);if(is_file($path))unlink($path);}}
    public static function staged($id,$purpose) {
        $meta=get_post_meta(absint($id),self::META,true);
        if(!$meta || $meta['type']!=='draft' || (int)$meta['owner']!==get_current_user_id() || get_post_meta($id,'_mph_upload_purpose',true)!==$purpose)return new WP_Error('mph_attachment','پیوست برای این فرم معتبر نیست؛ دوباره فایل را انتخاب کنید.');
        return absint($id);
    }
    public static function upload() {
        MPH_Helpers::verify_ajax();if(!is_user_logged_in())wp_send_json_error(array('message'=>'ابتدا وارد شوید.'),401);
        if(!MPH_Security::allow('private_upload',30,HOUR_IN_SECONDS,'u:'.get_current_user_id()))wp_send_json_error(array('message'=>'تعداد پیوست‌ها زیاد است؛ کمی بعد دوباره تلاش کنید.'),429);
        $purpose=sanitize_key($_POST['purpose']??'');if(!in_array($purpose,array('ticket','receipt'),true))wp_send_json_error(array('message'=>'نوع فرم معتبر نیست.'),400);
        $file=$_FILES['file']??array();if(empty($file['tmp_name'])||!empty($file['error'])||(int)$file['size']>2097152)wp_send_json_error(array('message'=>'فایل را تا حجم ۲ مگابایت انتخاب کنید.'),400);
        require_once ABSPATH.'wp-admin/includes/file.php';require_once ABSPATH.'wp-admin/includes/media.php';require_once ABSPATH.'wp-admin/includes/image.php';
        $mimes=array('jpg|jpeg|jpe'=>'image/jpeg','png'=>'image/png','webp'=>'image/webp','pdf'=>'application/pdf');
        if($purpose==='ticket')$mimes+=array('gif'=>'image/gif','txt'=>'text/plain','doc'=>'application/msword','docx'=>'application/vnd.openxmlformats-officedocument.wordprocessingml.document','xls'=>'application/vnd.ms-excel','xlsx'=>'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        $id=media_handle_upload('file',0,array('post_author'=>get_current_user_id()),array('test_form'=>false,'mimes'=>$mimes));
        if(!is_wp_error($id)){$secured=self::protect($id,'draft',0,get_current_user_id());if(is_wp_error($secured)){wp_delete_attachment($id,true);$id=$secured;}else update_post_meta($id,'_mph_upload_purpose',$purpose);}
        if(is_wp_error($id))wp_send_json_error(array('message'=>$id->get_error_message()),400);
        wp_send_json_success(array('file_id'=>$id,'message'=>'پیوست آماده ارسال است.'));
    }
    public static function migrate() {
        global $wpdb;
        if(!MPH_Tickets::tables_ready())return;
        $ids=$wpdb->get_results("SELECT t.id AS object_id,t.user_id AS owner,t.attachment_id AS file_id FROM {$wpdb->prefix}mph_tickets t LEFT JOIN {$wpdb->postmeta} m ON m.post_id=t.attachment_id AND m.meta_key='_mph_private_file_v28' WHERE t.attachment_id>0 AND m.meta_id IS NULL LIMIT 10");
        foreach((array)$ids as $r)self::protect($r->file_id,'ticket',$r->object_id,$r->owner);
        $rows=$wpdb->get_results("SELECT t.id AS object_id,t.user_id AS owner,r.attachment_id AS file_id FROM {$wpdb->prefix}mph_ticket_messages r INNER JOIN {$wpdb->prefix}mph_tickets t ON t.id=r.ticket_id LEFT JOIN {$wpdb->postmeta} m ON m.post_id=r.attachment_id AND m.meta_key='_mph_private_file_v28' WHERE r.attachment_id>0 AND m.meta_id IS NULL LIMIT 10");
        foreach((array)$rows as $r)self::protect($r->file_id,'ticket',$r->object_id,$r->owner);
        if(function_exists('wc_get_orders'))foreach(wc_get_orders(array('limit'=>20,'meta_key'=>MPH_Commerce::RECEIPT_META,'meta_value'=>'yes','orderby'=>'ID','order'=>'ASC','page'=>max(1,(int)get_option('mph_private_receipt_page',1)))) as $order){$id=(int)$order->get_meta(MPH_Commerce::RECEIPT_FILE);if($id)self::protect($id,'receipt',$order->get_id(),$order->get_customer_id());$processed=true;}
        update_option('mph_private_receipt_page',empty($processed)?1:((int)get_option('mph_private_receipt_page',1)+1),false);
        $drafts=get_posts(array('post_type'=>'attachment','post_status'=>'inherit','numberposts'=>20,'date_query'=>array(array('before'=>'2 days ago')),'meta_query'=>array(array('key'=>'_mph_upload_purpose','compare'=>'EXISTS'))));
        foreach($drafts as $draft){$meta=get_post_meta($draft->ID,self::META,true);if(($meta['type']??'')==='draft')wp_delete_attachment($draft->ID,true);}
        update_option('mph_private_migration_checked',time(),false);
    }
}
