<?php
defined('ABSPATH') || exit;

/** A database lease shared by browser requests, cron and the Bale bridge. */
final class MPH_Operation_Lock {
    public static function acquire($resource, $ttl = 90) {
        global $wpdb;
        $name = '_mph_lease_' . hash('sha256', (string)$resource);
        $current = $wpdb->get_var($wpdb->prepare("SELECT option_value FROM {$wpdb->options} WHERE option_name=%s", $name));
        if ($current !== null) {
            $row = json_decode($current, true);
            if (!is_array($row) || (int)($row['until'] ?? 0) >= time()) return false;
            $wpdb->query($wpdb->prepare("DELETE FROM {$wpdb->options} WHERE option_name=%s AND option_value=%s", $name, $current));
        }
        $value = wp_json_encode(array('token'=>bin2hex(random_bytes(24)), 'until'=>time()+max(15,(int)$ttl)));
        $inserted = $wpdb->query($wpdb->prepare("INSERT IGNORE INTO {$wpdb->options} (option_name,option_value,autoload) VALUES (%s,%s,'no')", $name, $value));
        return $inserted === 1 ? array('name'=>$name,'value'=>$value) : false;
    }

    public static function release($lease) {
        if (!$lease) return;
        global $wpdb;
        $wpdb->query($wpdb->prepare("DELETE FROM {$wpdb->options} WHERE option_name=%s AND option_value=%s", $lease['name'], $lease['value']));
        wp_cache_delete($lease['name'], 'options');
    }

    public static function run($resource, $callback, $ttl = 90) {
        $lease = self::acquire($resource, $ttl);
        if (!$lease) return new WP_Error('mph_busy', 'درخواست قبلی در حال پردازش است؛ چند لحظه بعد دوباره بررسی کنید.', array('status'=>409));
        try { return call_user_func($callback); }
        finally { self::release($lease); }
    }
}
