<?php
defined('ABSPATH') || exit;

final class MPH_Courses {
    const PRODUCTS_META = '_mph_delivery_products';
    const COURSE_META = '_mph_course_id';
    const MODE_META = '_mph_delivery_type';

    public static function init() {
        add_action('admin_init', array(__CLASS__, 'save_admin'));
        add_action('admin_init', array(__CLASS__, 'maybe_repair_rewrites'), 50);
        add_action('wp_ajax_mph_course_admin_save', array(__CLASS__, 'ajax_save_admin'));
        add_action('wp_ajax_mph_offline_lesson_progress', array(__CLASS__, 'ajax_offline_lesson_progress'));
        add_action('wp_ajax_mph_course_progress_save', array(__CLASS__, 'ajax_manual_progress_save'));
        add_action('wp_ajax_mph_course_progress_delete', array(__CLASS__, 'ajax_manual_progress_delete'));
        add_action('wp_ajax_mph_course_manage_panel', array(__CLASS__, 'ajax_manage_panel'));
        add_action('wp_ajax_mph_course_manage_save', array(__CLASS__, 'ajax_manage_save'));
        add_action('admin_post_mph_course_students_xlsx', array(__CLASS__, 'export_students_xlsx'));
        add_action('delete_user', array(__CLASS__, 'on_delete_user_release'), 5, 1);
        add_filter('the_author', array(__CLASS__, 'filter_course_author_name'), 20);
        add_filter('get_the_author_meta', array(__CLASS__, 'filter_author_meta'), 20, 3);
        add_filter('get_the_author_display_name', array(__CLASS__, 'filter_author_display_name'), 20, 2);
        add_filter('tutor_course_instructor', array(__CLASS__, 'filter_tutor_course_instructor'), 20);
        add_filter('tutor_instructor_name', array(__CLASS__, 'filter_tutor_instructor_name'), 20, 2);
        add_filter('tutor_course_instructors_html', array(__CLASS__, 'filter_tutor_course_instructor'), 20);
        add_action('wp_footer', array(__CLASS__, 'inject_instructor_name_script'), 99);

        add_action('wp_enqueue_scripts', array(__CLASS__, 'purchase_assets'), 100);
        add_action('wp_loaded', array(__CLASS__, 'intercept_direct_purchase'), 5);
        add_filter('woocommerce_product_add_to_cart_url', array(__CLASS__, 'product_purchase_url'), 20, 2);
        add_filter('woocommerce_add_to_cart_redirect', array(__CLASS__, 'purchase_redirect'), 99, 2);
        add_action('woocommerce_checkout_create_order_line_item', array(__CLASS__, 'copy_order_item_meta'), 10, 4);
        add_action('woocommerce_payment_complete', array(__CLASS__, 'grant_order_access'));
        add_action('woocommerce_order_status_processing', array(__CLASS__, 'grant_order_access'));
        add_action('woocommerce_order_status_completed', array(__CLASS__, 'grant_order_access'));
        add_action('woocommerce_order_status_changed', array(__CLASS__, 'grant_after_status_change'), 20, 4);
        add_action('admin_post_mph_course_video', array(__CLASS__, 'stream_video'));
        add_action('admin_post_mph_course_note', array(__CLASS__, 'stream_note'));
        add_action('admin_post_mph_print_course_invoice', array(__CLASS__, 'print_invoice'));
    }

    public static function modes() {
        return array(
            'offline' => array('label'=>'آفلاین','icon'=>'dashicons-video-alt3','description'=>'ویدئوها و فصل‌های ضبط‌شده داخل سایت'),
            'online' => array('label'=>'آنلاین','icon'=>'dashicons-laptop','description'=>'ورود به کلاس زنده از طریق لینک اختصاصی'),
            'inperson' => array('label'=>'حضوری','icon'=>'dashicons-location-alt','description'=>'ثبت‌نام کلاس حضوری با صورت‌حساب چاپی'),
        );
    }

    public static function admin_page() {
        self::render_admin('');
    }

    public static function admin_online_page() { self::render_admin('online'); }
    public static function admin_offline_page() { self::render_admin('offline'); }
    public static function admin_inperson_page() { self::render_admin('inperson'); }

    /** همان ویرایشگر کامل دوره، بدون خروج مدیر مجموعه از پنل افزونه. */
    public static function manager_editor($course) {
        if(!$course instanceof WP_Post||!MPH_Tutor::active()||$course->post_type!==tutor()->course_post_type)return'<div class="mph-empty">دوره معتبر نیست.</div>';
        ob_start();self::editor($course);$html=ob_get_clean();$back=add_query_arg(array('mph_mode'=>'manager','mph_open'=>'manage_courses'),MPH_Helpers::account_page_url());
        $html=preg_replace('/<a class="button mph-admin-back" href="[^"]*">.*?<\/a>/u','<a class="button mph-admin-back" data-mph-no-spa href="'.esc_url($back).'">→ بازگشت به دوره‌ها</a>',$html,1);
        return'<div class="mph-manager-course-editor">'.MPH_Helpers::secure_form_markup($html.MPH_Course_Lifecycle::controls($course)).'</div>';
    }

    private static function render_admin($forced_mode='') {
        if (!current_user_can('manage_options') && !current_user_can('mph_manage_courses')) wp_die('دسترسی ندارید.');
        settings_errors('mph-courses');
        $mode=isset(self::modes()[$forced_mode])?$forced_mode:'';
        $course_id=absint($_GET['course_id']??0);$course=$course_id?get_post($course_id):false;$is_new=!empty($_GET['new_course']); ?>
        <div class="wrap mph-admin mph-course-admin" dir="rtl"><header class="mph-admin-head"><span class="dashicons dashicons-welcome-learn-more"></span><div><h1>شیوه و محتوای دوره‌ها</h1><p>قیمت آفلاین، آنلاین و حضوری مستقیماً به‌صورت محصول در WooCommerce ذخیره می‌شود.</p></div></header>
        <?php if(!function_exists('wc_get_product')||!MPH_Tutor::active()): ?><div class="notice notice-error"><p>برای این بخش WooCommerce و Tutor LMS باید فعال باشند.</p></div></div><?php return;endif;
        self::admin_tabs($mode);
        if($course&&$course->post_type===tutor()->course_post_type)self::editor($course,$mode);elseif($is_new)self::new_editor($mode?:'offline');else self::course_list($mode); ?>
        </div><?php
    }

    private static function admin_tabs($active) {
        $tabs=array(''=>'همه دوره‌ها','online'=>'دوره‌های آنلاین','offline'=>'دوره‌های آفلاین','inperson'=>'دوره‌های حضوری'); ?>
        <nav class="nav-tab-wrapper mph-course-tabs"><?php foreach($tabs as$mode=>$label): ?><a class="nav-tab <?php echo $active===$mode?'nav-tab-active':''; ?>" href="<?php echo esc_url(admin_url('admin.php?page='.self::page_slug($mode))); ?>"><?php echo esc_html($label); ?></a><?php endforeach; ?></nav><?php
    }

    private static function course_list($mode='') {
        $courses=get_posts(array('post_type'=>tutor()->course_post_type,'post_status'=>array('publish','draft','pending','future'),'numberposts'=>-1,'orderby'=>'modified','order'=>'DESC'));
        if($mode)$courses=array_values(array_filter($courses,function($course)use($mode){$map=self::product_map($course->ID);return!empty($map[$mode])&&self::product($map[$mode]);}));
        $new_url=add_query_arg(array('page'=>self::page_slug($mode),'new_course'=>1),admin_url('admin.php')); ?>
        <div class="mph-admin-box"><div class="mph-builder-head"><div><h2><?php echo esc_html($mode?'دوره‌های '.self::modes()[$mode]['label']:'همه دوره‌ها'); ?></h2><p>دوره‌ها بر اساس آخرین ویرایش مرتب شده‌اند و اطلاعات فروش روی WooCommerce ذخیره می‌شود.</p></div><div class="mph-course-list-actions"><span class="mph-count"><?php echo count($courses); ?> دوره</span><a class="button button-primary" href="<?php echo esc_url($new_url); ?>">＋ دوره جدید</a></div></div><div class="mph-admin-course-grid"><?php if(!$courses): ?><div class="mph-admin-empty"><span class="dashicons dashicons-welcome-learn-more"></span><p>هنوز دوره‌ای در این بخش تعریف نشده است.</p></div><?php endif;foreach($courses as$course):$active=self::active_product_count($course->ID); ?><a href="<?php echo esc_url(add_query_arg(array('page'=>self::page_slug($mode),'course_id'=>$course->ID),admin_url('admin.php'))); ?>"><span><?php echo get_the_post_thumbnail($course->ID,'medium')?:'<i class="dashicons dashicons-welcome-learn-more"></i>'; ?></span><div><h3><?php echo esc_html($course->post_title); ?></h3><p><?php echo $active?absint($active).' شیوه فروش فعال':'هنوز قیمت‌گذاری نشده'; ?> · <?php echo esc_html(self::status_label($course->post_status)); ?></p><b>مدیریت دوره ←</b></div></a><?php endforeach; ?></div></div><?php
    }

    private static function new_editor($mode) {
        $info=self::modes()[$mode]; ?>
        <a class="button mph-admin-back" href="<?php echo esc_url(admin_url('admin.php?page='.self::page_slug($mode))); ?>">→ بازگشت به دوره‌ها</a>
        <form method="post" class="mph-admin-box mph-course-builder" id="mph-course-builder" data-mph-course-admin-save><?php wp_nonce_field('mph_course_admin','mph_course_nonce'); ?><input type="hidden" name="course_id" value="0"><input type="hidden" name="return_mode" value="<?php echo esc_attr($mode); ?>">
            <div class="mph-course-editor-head"><span><i class="dashicons <?php echo esc_attr($info['icon']); ?>"></i></span><div><small>ساخت مستقیم در Tutor و WooCommerce</small><h2>دوره <?php echo esc_html($info['label']); ?> جدید</h2><p>پس از ذخیره، دوره در همین بخش قابل مدیریت است.</p></div></div>
            <?php self::course_identity_fields(false); ?>
            <div class="mph-delivery-admin-grid"><?php foreach(self::modes() as $mkey=>$minfo): $enabled=($mkey===$mode); ?>
                <section class="mph-delivery-admin-card is-<?php echo esc_attr($mkey); ?> <?php echo $enabled?'is-enabled':''; ?>"><header><span class="dashicons <?php echo esc_attr($minfo['icon']); ?>"></span><div><h3><?php echo esc_html($minfo['label']); ?></h3><p><?php echo esc_html($minfo['description']); ?></p></div><label class="mph-mode-toggle"><input type="checkbox" name="modes[<?php echo esc_attr($mkey); ?>][enabled]" value="1" <?php checked($enabled); ?>><i></i></label></header>
                <label>قیمت به واحد فروشگاه<input type="text" inputmode="decimal" name="modes[<?php echo esc_attr($mkey); ?>][price]" placeholder="مثلاً 2500000" dir="ltr" <?php echo $enabled?'required':''; ?>></label>
                <?php if($mkey==='online'): ?><label>لینک ورود به کلاس آنلاین<input type="url" name="modes[online][url]" placeholder="https://..." dir="ltr"></label><?php endif; ?>
                <?php if($mkey==='inperson'): ?><label>تاریخ و ساعت شروع<input type="datetime-local" name="modes[inperson][start]"></label><label>ظرفیت کلاس <small>(صفر یعنی نامحدود)</small><input type="number" name="modes[inperson][capacity]" min="0" max="100000" value="0"></label><label>آدرس محل برگزاری<textarea name="modes[inperson][address]" rows="2"></textarea></label><?php endif; ?>
                </section>
            <?php endforeach; ?></div>
            <?php self::curriculum_builder(array()); ?>
            <div class="mph-course-savebar"><button class="button button-primary button-hero" name="mph_save_course_modes" value="1">ساخت و ذخیره دوره</button><span class="mph-course-save-status" data-course-save-status></span></div>
        </form><?php
    }

    private static function editor($course,$return_mode='') {
        $products=self::product_map($course->ID);$offline=self::product($products['offline']??0);$curriculum=$offline?$offline->get_meta('_mph_offline_curriculum'):array();if(!is_array($curriculum))$curriculum=array(); ?>
        <a class="button mph-admin-back" href="<?php echo esc_url(admin_url('admin.php?page='.self::page_slug($return_mode))); ?>">→ بازگشت به دوره‌ها</a>
        <form method="post" class="mph-admin-box mph-course-builder" id="mph-course-builder" data-mph-course-admin-save><?php wp_nonce_field('mph_course_admin','mph_course_nonce'); ?><input type="hidden" name="course_id" value="<?php echo absint($course->ID); ?>"><input type="hidden" name="return_mode" value="<?php echo esc_attr($return_mode); ?>">
            <div class="mph-course-editor-head"><span><?php echo get_the_post_thumbnail($course->ID,'thumbnail')?:'<i class="dashicons dashicons-welcome-learn-more"></i>'; ?></span><div><small>تنظیمات فروش و دسترسی</small><h2><?php echo esc_html($course->post_title); ?></h2><a href="<?php echo esc_url(self::course_view_url($course)); ?>" target="_blank" rel="noopener"><?php echo $course->post_status==='publish'?'مشاهده صفحه دوره ↗':'پیش‌نمایش دوره ↗'; ?></a></div></div>
            <?php self::course_identity_fields($course); ?>
            <div class="mph-delivery-admin-grid"><?php foreach(self::modes()as$mode=>$info):$product=self::product($products[$mode]??0);$enabled=$product&&$product->get_status()==='publish'; ?>
                <section class="mph-delivery-admin-card is-<?php echo esc_attr($mode); ?>"><header><span class="dashicons <?php echo esc_attr($info['icon']); ?>"></span><div><h3><?php echo esc_html($info['label']); ?></h3><p><?php echo esc_html($info['description']); ?></p></div><label class="mph-mode-toggle"><input type="checkbox" name="modes[<?php echo esc_attr($mode); ?>][enabled]" value="1" <?php checked($enabled); ?>><i></i></label></header><label>قیمت به واحد فروشگاه<input type="text" inputmode="decimal" name="modes[<?php echo esc_attr($mode); ?>][price]" value="<?php echo esc_attr($product?$product->get_regular_price():''); ?>" placeholder="مثلاً 2500000" dir="ltr"></label>
                <?php if($mode==='online'): ?><label>لینک ورود به کلاس آنلاین<input type="url" name="modes[online][url]" value="<?php echo esc_attr($product?$product->get_meta('_mph_online_url'):''); ?>" placeholder="https://..." dir="ltr"></label><small>این لینک فقط برای خریدار تأییدشده نمایش داده می‌شود.</small><?php endif; ?>
                <?php if($mode==='inperson'): ?><label>تاریخ و ساعت شروع کلاس<input type="datetime-local" name="modes[inperson][start]" value="<?php echo esc_attr(self::datetime_input($product?$product->get_meta('_mph_inperson_start'):'')); ?>"></label><label>ظرفیت کلاس <small>(صفر یعنی نامحدود)</small><input type="number" name="modes[inperson][capacity]" min="0" max="100000" value="<?php echo absint($product?$product->get_meta('_mph_inperson_capacity'):0); ?>"></label><label>آدرس محل برگزاری<textarea name="modes[inperson][address]" rows="2"><?php echo esc_textarea($product?$product->get_meta('_mph_inperson_address'):''); ?></textarea></label><?php endif; ?>
                <?php if($product): ?><small>محصول WooCommerce: #<?php echo absint($product->get_id()); ?></small><?php endif; ?></section>
            <?php endforeach; ?></div>
            <?php self::curriculum_builder($curriculum); ?>
            <div class="mph-course-savebar mph-course-savebar-split"><button class="button button-primary button-hero" name="mph_save_course_modes" value="1">ذخیره دوره و محصولات</button><button type="button" class="button button-hero mph-course-manage-btn" data-mph-course-manage="<?php echo absint($course->ID); ?>" data-course-title="<?php echo esc_attr($course->post_title); ?>"><span class="dashicons dashicons-welcome-learn-more"></span> مدیریت دوره</button><span class="mph-course-save-status" data-course-save-status></span></div>
        </form><?php
    }

    private static function course_identity_fields($course=false) {
        $thumb=$course?get_post_thumbnail_id($course->ID):0;$thumb_url=$thumb?wp_get_attachment_image_url($thumb,'medium'):'';$calendar_date=$course?get_post_meta($course->ID,'_mph_course_calendar_date',true):current_time('Y-m-d');$calendar_time=$course?get_post_meta($course->ID,'_mph_course_calendar_time',true):current_time('H:i');
        $instructor_id=$course?absint($course->post_author):0;$custom_instructor=$course?(string)get_post_meta($course->ID,'_mph_custom_instructor_name',true):'';$instructors=get_users(array('role__in'=>array('mph_instructor','tutor_instructor','mph_manager','administrator'),'orderby'=>'display_name','order'=>'ASC','number'=>200));
        ?><section class="mph-course-identity"><div class="mph-admin-grid"><label>عنوان دوره<input name="course_title" required value="<?php echo esc_attr($course?$course->post_title:''); ?>" placeholder="عنوان کامل دوره"></label><label>وضعیت انتشار<select name="course_status"><option value="draft" <?php selected($course?$course->post_status:'publish','draft'); ?>>پیش‌نویس</option><option value="publish" <?php selected($course?$course->post_status:'publish','publish'); ?>>منتشرشده</option><option value="pending" <?php selected($course?$course->post_status:'publish','pending'); ?>>در انتظار بررسی</option></select></label><label>تاریخ شروع در تقویم آموزشی<input type="date" name="course_calendar_date" value="<?php echo esc_attr($calendar_date?:current_time('Y-m-d')); ?>" required></label><label>ساعت شروع در تقویم<input type="time" name="course_calendar_time" value="<?php echo esc_attr($calendar_time?:current_time('H:i')); ?>"></label></div><label>توضیحات دوره<textarea name="course_content" rows="5" placeholder="معرفی، مخاطبان و توضیحات دوره"><?php echo esc_textarea($course?$course->post_content:''); ?></textarea></label><label>خلاصه دوره<textarea name="course_excerpt" rows="2"><?php echo esc_textarea($course?$course->post_excerpt:''); ?></textarea></label><div class="mph-course-cover"><input type="hidden" name="course_thumbnail_id" value="<?php echo absint($thumb); ?>" data-course-cover-id><span data-course-cover-preview><?php echo $thumb_url?'<img src="'.esc_url($thumb_url).'" alt="">':'بدون تصویر شاخص'; ?></span><button type="button" class="button" data-course-cover>انتخاب تصویر دوره</button><button type="button" class="button-link-delete" data-course-cover-remove>حذف تصویر</button></div>
        <div class="mph-admin-grid mph-instructor-picker" data-mph-instructor-picker>
            <label>مدرس
                <select name="course_instructor_id" data-mph-instructor-select>
                    <option value="0">— انتخاب مدرس —</option>
                    <?php foreach($instructors as $ins): ?>
                        <option value="<?php echo absint($ins->ID); ?>" <?php selected($custom_instructor==='' && $instructor_id===$ins->ID); ?>><?php echo esc_html(MPH_Helpers::display_name($ins)); ?></option>
                    <?php endforeach; ?>
                    <option value="custom" <?php selected($custom_instructor!==''); ?>>نام مدرس ...</option>
                </select>
            </label>
            <label class="mph-custom-instructor-field" data-mph-custom-instructor <?php echo $custom_instructor===''?'hidden':''; ?>>نام مدرس (دستی)
                <input type="text" name="course_instructor_custom" value="<?php echo esc_attr($custom_instructor); ?>" placeholder="نام کامل مدرس را بنویسید">
            </label>
        </div>
        <?php
        $level=$course?(string)get_post_meta($course->ID,'_tutor_course_level',true):'all_levels';if(!in_array($level,array('all_levels','beginner','intermediate','expert'),true))$level='all_levels';
        $duration=$course?get_post_meta($course->ID,'_course_duration',true):array();if(!is_array($duration))$duration=array();
        $settings=$course?get_post_meta($course->ID,'_tutor_course_settings',true):array();if(!is_array($settings))$settings=array();
        $max_students=absint($settings['maximum_students']??0);
        $benefits=$course?(string)get_post_meta($course->ID,'_tutor_course_benefits',true):'';
        $requirements=$course?(string)get_post_meta($course->ID,'_tutor_course_requirements',true):'';
        $target=$course?(string)get_post_meta($course->ID,'_tutor_course_target_audience',true):'';
        $materials=$course?(string)get_post_meta($course->ID,'_tutor_course_material_includes',true):'';
        $enable_qa=$course?get_post_meta($course->ID,'_tutor_enable_qa',true):'yes';
        $public_course=$course?get_post_meta($course->ID,'_tutor_is_public_course',true):'no';
        ?>
        <div class="mph-admin-grid mph-course-extra-fields">
            <label>سطح دوره<select name="course_level"><option value="all_levels" <?php selected($level,'all_levels'); ?>>همه سطوح</option><option value="beginner" <?php selected($level,'beginner'); ?>>مقدماتی</option><option value="intermediate" <?php selected($level,'intermediate'); ?>>متوسط</option><option value="expert" <?php selected($level,'expert'); ?>>پیشرفته</option></select></label>
            <label>حداکثر دانشجو<input type="number" name="maximum_students" min="0" max="100000" value="<?php echo absint($max_students); ?>"><small>صفر یعنی بدون محدودیت</small></label>
            <label>مدت دوره ـ ساعت<input type="number" name="duration_hours" min="0" max="999" value="<?php echo absint($duration['hours']??0); ?>"></label>
            <label>مدت دوره ـ دقیقه<input type="number" name="duration_minutes" min="0" max="59" value="<?php echo absint($duration['minutes']??0); ?>"></label>
        </div>
        <div class="mph-admin-grid">
            <label>دستاوردهای دوره<textarea name="course_benefits" rows="2"><?php echo esc_textarea($benefits); ?></textarea></label>
            <label>پیش‌نیازها<textarea name="course_requirements" rows="2"><?php echo esc_textarea($requirements); ?></textarea></label>
            <label>مخاطبان دوره<textarea name="course_target" rows="2"><?php echo esc_textarea($target); ?></textarea></label>
            <label>موارد همراه دوره<textarea name="course_materials" rows="2"><?php echo esc_textarea($materials); ?></textarea></label>
        </div>
        <div class="mph-options mph-course-toggles"><label><input type="checkbox" name="enable_qa" value="1" <?php checked($enable_qa!=='no'); ?>> پرسش و پاسخ فعال</label><label><input type="checkbox" name="public_course" value="1" <?php checked($public_course==='yes'); ?>> دوره عمومی</label></div>
        </section><?php
    }

    private static function curriculum_builder($curriculum) { ?>
        <input type="hidden" name="mph_curriculum_present" value="1"><section class="mph-curriculum-builder"><div class="mph-builder-head"><div><h2>سرفصل و محتوای دوره آفلاین</h2><p>هر فصل شامل درس‌های مرتب‌شده است؛ برای هر درس ویدئو و جزوه جداگانه انتخاب کنید.</p></div><button type="button" class="button" data-add-course-section>＋ فصل جدید</button></div><div class="mph-curriculum-sections" data-course-sections><?php foreach($curriculum as$s=>$section)self::section_row($s,$section); ?></div><div class="mph-curriculum-empty" data-curriculum-empty <?php if($curriculum)echo'hidden'; ?>><span class="dashicons dashicons-playlist-video"></span><p>هنوز فصلی ساخته نشده است.</p></div></section><?php
    }

    private static function section_row($s,$section) { ?>
        <article class="mph-curriculum-section" data-course-section draggable="true"><header><span class="dashicons dashicons-menu mph-course-drag"></span><b>فصل <?php echo $s+1; ?></b><input name="section_title[<?php echo $s; ?>]" value="<?php echo esc_attr($section['title']??''); ?>" placeholder="عنوان فصل" required><button type="button" class="button" data-add-course-lesson>＋ درس</button><button type="button" class="button-link-delete" data-remove-course-section>حذف فصل</button></header><div class="mph-course-lessons" data-course-lessons><?php foreach($section['lessons']??array()as$l=>$lesson)self::lesson_row($s,$l,$lesson); ?></div></article><?php
    }

    private static function lesson_row($s,$l,$lesson) {$video=absint($lesson['video_id']??0);$video_url=$video?wp_get_attachment_url($video):'';$note=absint($lesson['note_id']??0);$note_url=$note?wp_get_attachment_url($note):''; ?>
        <div class="mph-course-lesson" data-course-lesson draggable="true"><span class="dashicons dashicons-move mph-lesson-drag"></span><b>درس <?php echo $l+1; ?></b><input name="lesson_title[<?php echo $s; ?>][<?php echo $l; ?>]" value="<?php echo esc_attr($lesson['title']??''); ?>" placeholder="عنوان درس" required><div class="mph-lesson-media"><input type="hidden" name="lesson_video[<?php echo $s; ?>][<?php echo $l; ?>]" value="<?php echo $video; ?>" data-course-video-id><span data-course-video-name><?php echo esc_html($video_url?wp_basename($video_url):'بدون ویدئو'); ?></span><button type="button" class="button" data-course-video>ویدئو</button></div><div class="mph-lesson-media"><input type="hidden" name="lesson_note[<?php echo $s; ?>][<?php echo $l; ?>]" value="<?php echo $note; ?>" data-course-note-id><span data-course-note-name><?php echo esc_html($note_url?wp_basename($note_url):'بدون جزوه'); ?></span><button type="button" class="button" data-course-note>جزوه</button></div><button type="button" class="button-link-delete" data-remove-course-lesson>حذف</button></div><?php
    }

    public static function save_admin() {
        if(!isset($_POST['mph_save_course_modes']))return;
        $result=self::save_request();
        if(is_wp_error($result))add_settings_error('mph-courses','save_error',$result->get_error_message(),'error');else add_settings_error('mph-courses','saved','دوره، قیمت‌ها، لینک‌ها و سرفصل‌ها با موفقیت ذخیره شدند.','success');
    }

    public static function ajax_save_admin() {
        $result=self::save_request();
        if(is_wp_error($result))wp_send_json_error(array('message'=>$result->get_error_message()),400);
        $mode=sanitize_key(wp_unslash($_POST['return_mode']??''));if(!isset(self::modes()[$mode]))$mode='';
        wp_send_json_success(array('message'=>'همه تغییرات دوره ذخیره شد.','courseId'=>absint($result),'redirect'=>add_query_arg(array('mph_mode'=>'manager','mph_open'=>'manage_courses','course_id'=>absint($result)),MPH_Helpers::account_page_url())));
    }

    private static function save_request() {
        if(!current_user_can('manage_options')&&!current_user_can('mph_manage_courses'))return new WP_Error('forbidden','دسترسی ذخیره دوره را ندارید.');
        if(empty($_POST['mph_course_nonce'])||!wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['mph_course_nonce'])),'mph_course_admin'))return new WP_Error('nonce','نشست شما منقضی شده است؛ صفحه را تازه کنید.');
        if(isset($_POST['course_calendar_date'])){$raw_date=sanitize_text_field(wp_unslash($_POST['course_calendar_date']));$gregorian=MPH_Helpers::jalali_to_gregorian_date($raw_date);if($gregorian)$_POST['course_calendar_date']=$gregorian;}
        if(!function_exists('wc_get_product')||!MPH_Tutor::active())return new WP_Error('missing','WooCommerce یا Tutor LMS فعال نیست.');
        $course_id=absint($_POST['course_id']??0);$title=sanitize_text_field(wp_unslash($_POST['course_title']??''));$status=sanitize_key(wp_unslash($_POST['course_status']??'draft'));if(!in_array($status,array('draft','publish','pending'),true))$status='draft';
        $posted=(array)($_POST['modes']??array());if(!$posted)return new WP_Error('mode','حداقل یک شیوه برگزاری را تنظیم کنید.');
        $submitted_curriculum=isset($_POST['mph_curriculum_present'])?self::sanitize_curriculum():null;
        if($status==='publish'&&!empty($posted['offline']['enabled'])){$curriculum=$submitted_curriculum;if($curriculum===null&&$course_id){$existing_map=self::product_map($course_id);$existing=self::product($existing_map['offline']??0);$curriculum=$existing?(array)$existing->get_meta('_mph_offline_curriculum'):array();}if(!self::curriculum_is_complete($curriculum))return new WP_Error('offline_content','برای انتشار دوره آفلاین، حداقل یک فصل و یک درس دارای ویدئوی معتبر ثبت کنید.');}
        if(!$course_id){if(!$title)return new WP_Error('title','عنوان دوره را وارد کنید.');$course_id=wp_insert_post(array('post_type'=>tutor()->course_post_type,'post_status'=>$status,'post_title'=>$title,'post_content'=>wp_kses_post(wp_unslash($_POST['course_content']??'')),'post_excerpt'=>sanitize_textarea_field(wp_unslash($_POST['course_excerpt']??'')),'post_author'=>get_current_user_id()),true);if(is_wp_error($course_id))return$course_id;}
        $course=get_post($course_id);if(!$course||$course->post_type!==tutor()->course_post_type)return new WP_Error('invalid','دوره معتبر نیست.');
        if($title){$updated=wp_update_post(array('ID'=>$course_id,'post_title'=>$title,'post_status'=>$status,'post_content'=>wp_kses_post(wp_unslash($_POST['course_content']??$course->post_content)),'post_excerpt'=>sanitize_textarea_field(wp_unslash($_POST['course_excerpt']??$course->post_excerpt))),true);if(is_wp_error($updated))return$updated;$course=get_post($course_id);}
        $thumb=absint($_POST['course_thumbnail_id']??0);if($thumb&&wp_attachment_is_image($thumb))set_post_thumbnail($course_id,$thumb);elseif(array_key_exists('course_thumbnail_id',$_POST))delete_post_thumbnail($course_id);
        $calendar_date=sanitize_text_field(wp_unslash($_POST['course_calendar_date']??''));if(!preg_match('/^\d{4}-\d{2}-\d{2}$/',$calendar_date))$calendar_date=current_time('Y-m-d');$calendar_time=preg_replace('/[^0-9:]/','',sanitize_text_field(wp_unslash($_POST['course_calendar_time']??'')));update_post_meta($course_id,'_mph_course_calendar_date',$calendar_date);update_post_meta($course_id,'_mph_course_calendar_time',preg_match('/^\d{2}:\d{2}$/',$calendar_time)?$calendar_time:'');
        self::persist_instructor_and_extras($course_id);
        $map=self::product_map($course_id);$errors=array();
        foreach(self::modes()as$mode=>$info){if(!array_key_exists($mode,$posted))continue;$data=(array)$posted[$mode];$enabled=!empty($data['enabled']);$price=self::decimal($data['price']??'');if($enabled&&$price===''){$errors[]='قیمت حالت '.$info['label'].' وارد نشده است.';continue;}$current=self::product($map[$mode]??0);$curriculum=$mode==='offline'&&$submitted_curriculum!==null?$submitted_curriculum:($current?(array)$current->get_meta('_mph_offline_curriculum'):array());if($mode==='offline'&&$enabled&&!self::curriculum_is_complete($curriculum))$enabled=false;$result=self::sync_product($course,$mode,$map[$mode]??0,array('enabled'=>$enabled,'price'=>$price,'url'=>esc_url_raw(wp_unslash($data['url']??'')),'start'=>self::sanitize_datetime($data['start']??''),'address'=>sanitize_textarea_field(wp_unslash($data['address']??'')),'capacity'=>min(100000,absint($data['capacity']??0)),'curriculum'=>$curriculum));if(is_wp_error($result))$errors[]=$result->get_error_message();elseif($result)$map[$mode]=$result;}
        update_post_meta($course_id,self::PRODUCTS_META,$map);$active=array();foreach($map as$product_id){$product=self::product($product_id);if($product&&$product->get_status()==='publish')$active[]=$product->get_id();}if($active){update_post_meta($course_id,'_tutor_course_product_id',absint($active[0]));update_post_meta($course_id,'_tutor_course_price_type','paid');}else{delete_post_meta($course_id,'_tutor_course_product_id');update_post_meta($course_id,'_tutor_course_price_type','free');}clean_post_cache($course_id);
        if(class_exists('MPH_Calendar'))MPH_Calendar::sync_course($course_id);
        return$errors?new WP_Error('partial',implode(' ',$errors)):absint($course_id);
    }

    private static function sync_product($course,$mode,$product_id,$data) {
        $product=self::product($product_id);$labels=self::modes();$label=$labels[$mode]['label'];$has_content=$data['price']!==''||($mode==='online'&&!empty($data['url']))||($mode==='inperson'&&(!empty($data['start'])||!empty($data['address'])))||($mode==='offline'&&!empty($data['curriculum']));if(!$product&&!$data['enabled']&&!$has_content)return 0;if(!$product)$product=new WC_Product_Simple();
        $product->set_name($course->post_title.' — '.$label);$product->set_status($data['enabled']?'publish':'draft');$product->set_catalog_visibility('hidden');$product->set_virtual(true);$product->set_sold_individually(false);$product->set_regular_price($data['price']);$product->set_price($data['price']);$product->set_description('ثبت‌نام '.$label.' دوره «'.$course->post_title.'»');$product->set_short_description($labels[$mode]['description']);if(has_post_thumbnail($course->ID))$product->set_image_id(get_post_thumbnail_id($course->ID));
        $product->update_meta_data(self::COURSE_META,$course->ID);$product->update_meta_data(self::MODE_META,$mode);$product->update_meta_data('_mph_delivery_label',$label);$product->update_meta_data('_mph_online_url',$mode==='online'?$data['url']:'');$product->update_meta_data('_mph_inperson_start',$mode==='inperson'?$data['start']:'');$product->update_meta_data('_mph_inperson_address',$mode==='inperson'?$data['address']:'');$product->update_meta_data('_mph_inperson_capacity',$mode==='inperson'?absint($data['capacity']??0):0);if($mode==='offline')$product->update_meta_data('_mph_offline_curriculum',$data['curriculum']);
        try{$id=$product->save();if(function_exists('wc_delete_product_transients'))wc_delete_product_transients($id);return absint($id);}catch(Throwable$e){return new WP_Error('mph_product',$label.': '.$e->getMessage());}
    }

    public static function configure_modes($course_id,$posted) {
        $has_choice=false;foreach((array)$posted as$data)if(!empty($data['enabled'])){$has_choice=true;break;}if(!$has_choice)return true;
        if(!function_exists('wc_get_product'))return new WP_Error('mph_woocommerce','WooCommerce فعال نیست.');$course=get_post(absint($course_id));if(!$course)return new WP_Error('mph_course','دوره پیدا نشد.');$map=self::product_map($course->ID);$errors=array();
        foreach(self::modes()as$mode=>$info){$data=(array)($posted[$mode]??array());$enabled=!empty($data['enabled']);$price=self::decimal($data['price']??'');if($enabled&&$price===''){$errors[]='قیمت '.$info['label'].' وارد نشده است.';continue;}$existing=self::product($map[$mode]??0);$curriculum=$mode==='offline'&&$existing?(array)$existing->get_meta('_mph_offline_curriculum'):array();if($mode==='offline'&&$enabled&&!self::curriculum_is_complete($curriculum)){$errors[]='حالت آفلاین تا زمان ثبت حداقل یک درس دارای ویدئو فعال نمی‌شود.';continue;}$result=self::sync_product($course,$mode,$map[$mode]??0,array('enabled'=>$enabled,'price'=>$price,'url'=>esc_url_raw(wp_unslash($data['url']??'')),'start'=>self::sanitize_datetime($data['start']??''),'address'=>sanitize_textarea_field(wp_unslash($data['address']??'')),'capacity'=>min(100000,absint($data['capacity']??0)),'curriculum'=>$curriculum));if(is_wp_error($result))$errors[]=$result->get_error_message();elseif($result)$map[$mode]=$result;}
        update_post_meta($course->ID,self::PRODUCTS_META,$map);$active=array();foreach($map as$product_id){$product=self::product($product_id);if($product&&$product->get_status()==='publish')$active[]=$product->get_id();}if($active){update_post_meta($course->ID,'_tutor_course_product_id',absint($active[0]));update_post_meta($course->ID,'_tutor_course_price_type','paid');}else update_post_meta($course->ID,'_tutor_course_price_type','free');return$errors?new WP_Error('mph_modes',implode(' ',$errors)):true;
    }

    private static function sanitize_curriculum() {
        $titles=(array)($_POST['section_title']??array());$lesson_titles=(array)($_POST['lesson_title']??array());$lesson_videos=(array)($_POST['lesson_video']??array());$lesson_notes=(array)($_POST['lesson_note']??array());$result=array();
        foreach($titles as$s=>$raw){$title=sanitize_text_field(wp_unslash($raw));if(!$title)continue;$lessons=array();foreach((array)($lesson_titles[$s]??array())as$l=>$raw_lesson){$lesson=sanitize_text_field(wp_unslash($raw_lesson));$video=absint($lesson_videos[$s][$l]??0);$note=absint($lesson_notes[$s][$l]??0);if(!$lesson)continue;if($video&&strpos((string)get_post_mime_type($video),'video/')!==0)$video=0;if($note&&get_post_type($note)!=='attachment')$note=0;$lessons[]=array('title'=>$lesson,'video_id'=>$video,'note_id'=>$note);}$result[]=array('title'=>$title,'lessons'=>$lessons);}
        return$result;
    }

    private static function curriculum_is_complete($curriculum) {
        foreach((array)$curriculum as$section)foreach((array)($section['lessons']??array())as$lesson){$video=absint($lesson['video_id']??0);if($video&&get_post_type($video)==='attachment'&&strpos((string)get_post_mime_type($video),'video/')===0)return true;}return false;
    }

    private static function page_slug($mode='') {$map=array('online'=>'mph-courses-online','offline'=>'mph-courses-offline','inperson'=>'mph-courses-inperson');return$map[$mode]??'mph-courses';}
    private static function status_label($status){$object=get_post_status_object($status);return$object&&!empty($object->label)?$object->label:$status;}
    private static function course_view_url($course){if(!$course instanceof WP_Post)return home_url('/');if($course->post_status==='publish')return get_permalink($course);$preview=get_preview_post_link($course);return$preview?:get_permalink($course);}

    public static function maybe_repair_rewrites() {
        if(!MPH_Tutor::active())return;
        $version=(string)get_option('mph_course_rewrite_version','');
        if($version===MPH_VERSION)return;
        flush_rewrite_rules(false);
        update_option('mph_course_rewrite_version',MPH_VERSION,false);
    }

    public static function append_purchase_options($content) {
        return $content;
    }

    public static function purchase_assets() {
        if (is_admin() || !MPH_Tutor::active() || !is_singular(tutor()->course_post_type)) return;
        $course_id=get_queried_object_id();$map=self::product_map($course_id);$ids=array_values(array_filter(array_map('absint',$map)));
        wp_enqueue_script('mph-course-purchase',MPH_URL.'assets/js/course-purchase.js',array(),MPH_VERSION,true);
        wp_localize_script('mph-course-purchase','MPH_COURSE_PURCHASE',array('courseId'=>$course_id,'productIds'=>$ids,'target'=>self::selection_url($course_id)));
    }

    public static function intercept_direct_purchase() {
        if(is_admin()||wp_doing_ajax()||!function_exists('wc_get_product'))return;
        $product_id=absint($_REQUEST['add-to-cart']??0);if(!$product_id)return;
        $product=wc_get_product($product_id);if(!$product)return;
        $course_id=absint($product->get_meta(self::COURSE_META));$mode=sanitize_key($product->get_meta(self::MODE_META));
        if(!$course_id){$course_id=self::legacy_course_by_product($product_id);if($course_id){$map=self::product_map($course_id);$mode=array_search($product_id,array_map('absint',$map),true)?:'offline';}}
        if(!$course_id||!isset(self::modes()[$mode]))return;
        wp_safe_redirect(self::selection_url($course_id));exit;
    }

    public static function product_purchase_url($url,$product) {
        if(!is_object($product)||!is_singular()||!MPH_Tutor::active()||!is_singular(tutor()->course_post_type))return$url;
        $course_id=absint($product->get_meta(self::COURSE_META))?:get_queried_object_id();
        return $course_id?self::selection_url($course_id):$url;
    }

    public static function purchase_redirect($url,$product=null) {
        if(!is_object($product)||!method_exists($product,'get_meta'))return$url;
        $course_id=absint($product->get_meta(self::COURSE_META));
        return $course_id?self::selection_url($course_id):$url;
    }

    public static function selection_url($course_id) {
        return add_query_arg(array('mph_open'=>'cart','mph_choose_course'=>absint($course_id)),MPH_Helpers::account_page_url());
    }

    public static function courses_archive_url() {
        if(MPH_Tutor::active()){$url=get_post_type_archive_link(tutor()->course_post_type);if($url)return$url;}
        $shop=function_exists('wc_get_page_permalink')?wc_get_page_permalink('shop'):'';return$shop?:home_url('/');
    }

    public static function browse_courses_link() {return'<a class="mph-browse-courses" href="'.esc_url(self::courses_archive_url()).'"><span class="dashicons dashicons-arrow-right-alt"></span> مشاهده دوره‌های دیگر</a>';}

    public static function content_url($course_id) {
        $course_id=absint($course_id);
        return add_query_arg(array('mph_mode'=>'user','mph_open'=>'course_content','course_id'=>$course_id),MPH_Helpers::account_page_url()).'#mph-course-content-'.$course_id;
    }

    /** دکمه‌های دسترسی ثبت‌نام‌شده دقیقاً بر اساس شیوه خرید نمایش داده می‌شوند. */
    public static function enrolled_actions($course_id,$user_id) {
        $course_id=absint($course_id);$user_id=absint($user_id);if(!$course_id||!$user_id)return'';$access=self::access_modes($user_id,$course_id);$actions=array();
        if(isset($access['offline']))$actions[]='<a class="mph-native-link is-offline" href="'.esc_url(self::content_url($course_id)).'">رفتن به محتوای دوره</a>';
        if(isset($access['online'])){$map=self::product_map($course_id);$product=self::product($map['online']??0);$url=$product?$product->get_meta('_mph_online_url'):'';if($url)$actions[]='<a class="mph-native-link is-online" target="_blank" rel="noopener" href="'.esc_url($url).'">ورود به کلاس آنلاین</a>';}
        // برای ثبت‌نام صرفاً حضوری عمداً هیچ دکمه‌ای نمایش داده نمی‌شود.
        return $actions?'<div class="mph-enrolled-actions">'.implode('',$actions).'</div>':'';
    }

    public static function purchase_options($course_id) {
        if(!function_exists('wc_get_product'))return'';$map=self::product_map($course_id);$cards='';$user_id=get_current_user_id();
        foreach(self::modes()as$mode=>$info){$product=self::product($map[$mode]??0);if(!$product||$product->get_status()!=='publish')continue;$access=$user_id&&self::has_access($user_id,$course_id,$mode);$action='';if($access){if($mode==='online'&&$product->get_meta('_mph_online_url'))$action='<a class="mph-primary" target="_blank" rel="noopener" href="'.esc_url($product->get_meta('_mph_online_url')).'">ورود به کلاس آنلاین</a>';elseif($mode==='offline')$action='<a class="mph-primary" href="'.esc_url(self::content_url($course_id)).'">مشاهده محتوای دوره</a>';}else{$action='<a class="mph-primary" href="'.esc_url($product->add_to_cart_url()).'">انتخاب و افزودن به سبد خرید</a>';}
            $extra='';if($mode==='inperson'){$extra=$product->get_meta('_mph_inperson_start')?'<small>شروع: '.esc_html(date_i18n('Y/m/d H:i',strtotime($product->get_meta('_mph_inperson_start')))).'</small>':'';if(class_exists('MPH_Growth')){$status=MPH_Growth::capacity_status($product->get_id());$extra.='<small class="mph-capacity '.($status['full']?'is-full':'').'">'.esc_html(MPH_Growth::capacity_text($product->get_id())).'</small>';if(!$access&&$status['full'])$action=MPH_Growth::waitlist_form($product->get_id());}}$cards.='<article class="mph-delivery-card is-'.esc_attr($mode).'"><span class="dashicons '.esc_attr($info['icon']).'"></span><h3>'.esc_html($info['label']).'</h3><p>'.esc_html($info['description']).'</p>'.$extra.'<strong>'.wp_kses_post($product->get_price_html()).'</strong>'.$action.'</article>';
        }
        if(!$cards)return'';return'<section class="mph-course-delivery" dir="rtl"><div class="mph-section-heading"><div><small>شیوه شرکت در دوره</small><h2>روش مناسب خود را انتخاب کنید</h2><p>هر شیوه قیمت و دسترسی مستقل دارد.</p></div><span class="dashicons dashicons-cart"></span></div><div class="mph-delivery-grid">'.$cards.'</div></section>';
    }

    public static function mode_selector($course_id) {
        if(!function_exists('wc_get_product'))return'<div class="mph-empty">WooCommerce فعال نیست.</div>';
        $course=get_post(absint($course_id));
        if(!$course||!MPH_Tutor::active()||$course->post_type!==tutor()->course_post_type)return'';
        $map=self::product_map($course->ID);$cards='';$selected=self::selected_modes_in_cart($course->ID);
        foreach(self::modes()as$mode=>$info){$product=self::product($map[$mode]??0);if(!$product||$product->get_status()!=='publish')continue;$is_selected=in_array($mode,$selected,true);$extra='';$action='<form data-mph-action="mph_select_course_mode"><input type="hidden" name="course_id" value="'.absint($course->ID).'"><input type="hidden" name="delivery_mode" value="'.esc_attr($mode).'"><button type="button" data-mph-course-choice class="mph-primary">'.($is_selected?'در سبد خرید است':'انتخاب این روش').'</button><div class="mph-message"></div></form>';if($mode==='inperson'){$extra=$product->get_meta('_mph_inperson_start')?'<small>شروع: '.esc_html(date_i18n('Y/m/d H:i',strtotime($product->get_meta('_mph_inperson_start')))).'</small>':'';if(class_exists('MPH_Growth')){$status=MPH_Growth::capacity_status($product->get_id());$extra.='<small class="mph-capacity '.($status['full']?'is-full':'').'">'.esc_html(MPH_Growth::capacity_text($product->get_id())).'</small>';if($status['full'])$action=MPH_Growth::waitlist_form($product->get_id());}}$cards.='<article class="mph-delivery-card is-'.esc_attr($mode).' '.($is_selected?'is-selected':'').'"><span class="dashicons '.esc_attr($info['icon']).'"></span><h3>'.esc_html($info['label']).'</h3><p>'.esc_html($info['description']).'</p>'.$extra.'<strong>'.wp_kses_post($product->get_price_html()).'</strong>'.$action.'</article>';}
        if(!$cards)return'<div class="mph-empty"><p>هنوز روش فروشی برای این دوره فعال نشده است.</p></div>';
        return'<section class="mph-course-mode-selector"><div class="mph-section-heading"><div><small>مرحله اول خرید</small><h3>'.esc_html($course->post_title).'</h3><p>ابتدا شیوه شرکت را انتخاب کنید؛ سپس برای بررسی سبد به مرحله دوم می‌روید.</p></div>'.(get_the_post_thumbnail($course->ID,'thumbnail')?:'<span class="dashicons dashicons-welcome-learn-more"></span>').'</div><div class="mph-delivery-grid">'.$cards.'</div>'.self::browse_courses_link().'</section>';
    }

    public static function product_for_mode($course_id,$mode) {
        if(!isset(self::modes()[$mode]))return false;$map=self::product_map(absint($course_id));$product=self::product($map[$mode]??0);if($product&&$product->is_sold_individually()){try{$product->set_sold_individually(false);$product->save();}catch(Throwable$e){}}return$product&&$product->get_status()==='publish'?$product:false;
    }

    private static function selected_modes_in_cart($course_id){$modes=array();if(!function_exists('WC')||!WC()->cart)return$modes;foreach(WC()->cart->get_cart()as$item){$product=$item['data']??false;if($product&&absint($product->get_meta(self::COURSE_META))===absint($course_id)){$mode=sanitize_key($product->get_meta(self::MODE_META));if(isset(self::modes()[$mode]))$modes[]=$mode;}}return array_values(array_unique($modes));}

    public static function render_library($selected_course_id=0) {
        if(!is_user_logged_in())return'<div class="mph-empty">ابتدا وارد حساب شوید.</div>';if(!MPH_Tutor::active()||!function_exists('wc_get_orders'))return'<div class="mph-empty">Tutor LMS و WooCommerce باید فعال باشند.</div>';$user_id=get_current_user_id();$selected=absint($selected_course_id?:($_GET['course_id']??0));$courses=get_posts(array('post_type'=>tutor()->course_post_type,'post_status'=>'publish','numberposts'=>-1,'orderby'=>'title','order'=>'ASC'));$available=array();foreach($courses as$course){$modes=self::access_modes($user_id,$course->ID);if(isset($modes['offline']))$available[$course->ID]=array($course,array('offline'=>$modes['offline']));}ob_start(); ?>
        <section class="mph-section mph-course-library"><div class="mph-section-heading"><div><h3>دوره‌های آفلاین</h3><p>فصل‌ها، ویدئوها و جزوه‌های دوره‌های ضبط‌شده شما</p></div><span class="dashicons dashicons-playlist-video"></span></div><?php if(!$available): ?><div class="mph-empty"><p>هنوز دوره آفلاینی برای شما فعال نشده است.</p></div><?php endif; ?><div class="mph-library-course-list"><?php foreach($available as$course_id=>$row):list($course,$modes)=$row;$open=$selected===$course_id||(!$selected&&count($available)===1); ?><article class="mph-library-course <?php echo $open?'is-open':''; ?>"><header><span><?php echo get_the_post_thumbnail($course_id,'thumbnail')?:'<i class="dashicons dashicons-welcome-learn-more"></i>'; ?></span><div><h4><?php echo esc_html($course->post_title); ?></h4><small>دوره آفلاین</small></div><a class="mph-secondary" href="<?php echo esc_url(self::content_url($course_id)); ?>"><?php echo $open?'رفتن به ابتدای محتوا':'مشاهده محتوا'; ?></a></header><?php if($open)echo self::course_access_content($course_id,$modes); ?></article><?php endforeach; ?></div></section><?php return ob_get_clean();
    }

    private static function course_access_content($course_id,$modes) {
        $map=self::product_map($course_id);$progress=self::offline_progress_data($course_id,get_current_user_id());ob_start(); ?>
        <div class="mph-library-content" id="mph-course-content-<?php echo absint($course_id); ?>" tabindex="-1">
            <?php if(isset($modes['offline'])):$product=self::product($map['offline']??0);$curriculum=$product?$product->get_meta('_mph_offline_curriculum'):array();$last_video=absint(get_user_meta(get_current_user_id(),'_mph_last_video_'.absint($course_id),true));$last_section=-1;foreach((array)$curriculum as$section_index=>$section)foreach((array)($section['lessons']??array())as$lesson)if($last_video&&absint($lesson['video_id']??0)===$last_video)$last_section=(int)$section_index; ?>
                <div class="mph-offline-progress" aria-label="<?php echo esc_attr($progress['percent']); ?> درصد پیشرفت دوره">
                    <div><span style="width:<?php echo esc_attr($progress['percent']); ?>%"></span></div>
                    <p><b><?php echo esc_html($progress['percent']); ?>٪</b> پیشرفت · <?php echo absint($progress['completed']); ?> از <?php echo absint($progress['total']); ?> درس تکمیل شده</p>
                </div>
                <?php if($last_section>=0): ?><p><a class="mph-secondary" href="#mph-video-<?php echo absint($last_video); ?>"><span class="dashicons dashicons-controls-play"></span> ادامه از آخرین درس دیده‌شده</a></p><?php endif; ?>
                <?php if(!is_array($curriculum)||!$curriculum): ?><div class="mph-empty">محتوای ضبط‌شده این دوره هنوز بارگذاری نشده است.</div>
                <?php else: ?><div class="mph-offline-curriculum"><?php foreach($curriculum as$s=>$section): ?>
                    <details <?php echo ($last_section>=0?(int)$s===$last_section:$s===0)?'open':''; ?>><summary><span><?php echo $s+1; ?></span><div><b><?php echo esc_html($section['title']??'فصل'); ?></b><small><?php echo count($section['lessons']??array()); ?> درس</small></div></summary><div>
                    <?php foreach($section['lessons']??array()as$l=>$lesson):$video=absint($lesson['video_id']??0);$note=absint($lesson['note_id']??0);$done=$video&&in_array($video,$progress['ids'],true); ?>
                        <article <?php if($video&&$video===$last_video): ?>id="mph-video-<?php echo absint($video); ?>"<?php endif; ?> class="<?php echo trim(($done?'is-complete ':'').($video&&$video===$last_video?'is-last-watched':'')); ?>"><header><span class="dashicons <?php echo $done?'dashicons-yes-alt':'dashicons-controls-play'; ?>"></span><div><b><?php echo esc_html($lesson['title']??'درس'); ?></b><small>درس <?php echo $l+1; ?><?php echo $done?' · تکمیل‌شده':''; ?><?php echo $video&&$video===$last_video?' · آخرین مشاهده':''; ?></small></div>
                        <?php if($note): ?><a class="mph-lesson-note" href="<?php echo esc_url(self::note_url($course_id,$note)); ?>"><span class="dashicons dashicons-media-document"></span> دانلود جزوه</a><?php endif; ?>
                        <?php if($video): ?><form class="mph-lesson-progress-form" data-mph-action="mph_offline_lesson_progress"><input type="hidden" name="course_id" value="<?php echo absint($course_id); ?>"><input type="hidden" name="video_id" value="<?php echo absint($video); ?>"><input type="hidden" name="completed" value="<?php echo $done?'0':'1'; ?>"><button type="submit" class="<?php echo $done?'mph-secondary':'mph-primary'; ?>"><span class="dashicons <?php echo $done?'dashicons-undo':'dashicons-yes'; ?>"></span><?php echo $done?'لغو تکمیل':'تکمیل شد'; ?></button><div class="mph-message"></div></form><?php endif; ?></header>
                        <?php if($video): ?><video data-mph-course="<?php echo absint($course_id); ?>" data-mph-video="<?php echo absint($video); ?>" controls preload="metadata" controlsList="nodownload" disablePictureInPicture playsinline draggable="false" oncontextmenu="return false" src="<?php echo esc_url(self::video_url($course_id,$video)); ?>"></video><?php else: ?><p>ویدئوی این درس هنوز بارگذاری نشده است.</p><?php endif; ?></article>
                    <?php endforeach; ?></div></details><?php endforeach; ?></div><?php endif; ?>
            <?php endif; ?>
        </div><?php return ob_get_clean();
    }

    public static function ajax_offline_lesson_progress(){MPH_Helpers::verify_ajax();if(!is_user_logged_in())wp_send_json_error(array('message'=>'ابتدا وارد شوید.'),403);$course_id=absint($_POST['course_id']??0);$video_id=absint($_POST['video_id']??0);if(!$course_id||!$video_id||!self::has_access(get_current_user_id(),$course_id,'offline')||!self::video_in_course($course_id,$video_id))wp_send_json_error(array('message'=>'دسترسی ثبت پیشرفت این درس را ندارید.'),403);$all=self::offline_video_ids($course_id);$key='_mph_offline_progress_'.$course_id;$ids=array_values(array_intersect($all,array_unique(array_map('absint',(array)get_user_meta(get_current_user_id(),$key,true)))));if(!empty($_POST['completed']))$ids[]=$video_id;else$ids=array_values(array_diff($ids,array($video_id)));$ids=array_values(array_unique(array_intersect($all,$ids)));update_user_meta(get_current_user_id(),$key,$ids);wp_send_json_success(array('message'=>!empty($_POST['completed'])?'درس تکمیل شد.':'وضعیت تکمیل درس لغو شد.','html'=>self::render_library($course_id)));}

    private static function offline_video_ids($course_id){$map=self::product_map($course_id);$product=self::product($map['offline']??0);$curriculum=$product?$product->get_meta('_mph_offline_curriculum'):array();$ids=array();foreach((array)$curriculum as$section)foreach((array)($section['lessons']??array())as$lesson){$video=absint($lesson['video_id']??0);if($video&&strpos((string)get_post_mime_type($video),'video/')===0)$ids[]=$video;}return array_values(array_unique($ids));}
    private static function offline_progress_data($course_id,$user_id){$all=self::offline_video_ids($course_id);$saved=array_unique(array_map('absint',(array)get_user_meta(absint($user_id),'_mph_offline_progress_'.absint($course_id),true)));$ids=array_values(array_intersect($all,$saved));$total=count($all);$completed=count($ids);return array('total'=>$total,'completed'=>$completed,'percent'=>$total?(int)round(100*$completed/$total):0,'ids'=>$ids);}
    public static function offline_progress_percent($course_id,$user_id){$data=self::offline_progress_data(absint($course_id),absint($user_id));return absint($data['percent']);}
    public static function manual_progress_percent($course_id,$user_id,$mode=''){$rows=get_post_meta(absint($course_id),'_mph_manual_progress_v26',true);$user_rows=is_array($rows)&&isset($rows[absint($user_id)])&&is_array($rows[absint($user_id)])?$rows[absint($user_id)]:array();if($mode)return min(100,absint($user_rows[sanitize_key($mode)]??0));return max(min(100,absint($user_rows['online']??0)),min(100,absint($user_rows['inperson']??0)));}

    public static function ajax_manual_progress_save(){MPH_Helpers::verify_ajax();if(!self::can_manage_progress())wp_send_json_error(array('message'=>'فقط مدیر مجموعه اجازه تغییر پیشرفت را دارد.'),403);$course_id=absint($_POST['course_id']??0);$user_id=absint($_POST['user_id']??0);$mode=MPH_Helpers::posted('progress_mode','key');$percent=max(0,min(100,absint(MPH_Helpers::normalize_digits($_POST['progress_percent']??0))));$course=get_post($course_id);$students=array_flip(MPH_Tutor::course_student_ids($course_id));if(!$course||!isset($students[$user_id])||!in_array($mode,array('online','inperson'),true))wp_send_json_error(array('message'=>'دوره، هنرجو یا نوع پیشرفت معتبر نیست.'));$rows=get_post_meta($course_id,'_mph_manual_progress_v26',true);if(!is_array($rows))$rows=array();if(!isset($rows[$user_id])||!is_array($rows[$user_id]))$rows[$user_id]=array();$rows[$user_id][$mode]=$percent;$rows[$user_id][$mode.'_updated']=current_time('mysql');update_post_meta($course_id,'_mph_manual_progress_v26',$rows);MPH_Helpers::audit('course_progress_saved','course='.$course_id.';user='.$user_id.';mode='.$mode.';percent='.$percent);wp_send_json_success(array('message'=>'درصد پیشرفت هنرجو ذخیره شد.','html'=>self::render_progress_manager().MPH_Certificates::render_manager()));}

    public static function ajax_manual_progress_delete(){MPH_Helpers::verify_ajax();if(!self::can_manage_progress())wp_send_json_error(array('message'=>'دسترسی ندارید.'),403);$course_id=absint($_POST['course_id']??0);$user_id=absint($_POST['user_id']??0);$mode=MPH_Helpers::posted('progress_mode','key');if(!in_array($mode,array('online','inperson'),true))wp_send_json_error(array('message'=>'نوع پیشرفت معتبر نیست.'));$rows=get_post_meta($course_id,'_mph_manual_progress_v26',true);if(is_array($rows)&&isset($rows[$user_id])){unset($rows[$user_id][$mode],$rows[$user_id][$mode.'_updated']);if(!$rows[$user_id])unset($rows[$user_id]);update_post_meta($course_id,'_mph_manual_progress_v26',$rows);}MPH_Helpers::audit('course_progress_deleted','course='.$course_id.';user='.$user_id.';mode='.$mode);wp_send_json_success(array('message'=>'درصد دستی حذف شد.','html'=>self::render_progress_manager().MPH_Certificates::render_manager()));}

    public static function render_progress_manager(){if(!self::can_manage_progress())return'';$type=MPH_Tutor::active()?tutor()->course_post_type:'courses';$courses=get_posts(array('post_type'=>$type,'post_status'=>array('publish','draft','pending'),'numberposts'=>-1,'orderby'=>'title','order'=>'ASC'));ob_start();?><section class="mph-section mph-manual-progress-manager"><div class="mph-section-heading"><div><h3>پیشرفت هنرجویان دوره‌های آنلاین و حضوری</h3><p>پیشرفت آفلاین خودکار است؛ برای آنلاین و حضوری می‌توانید درصد را اضافه، تغییر یا حذف کنید.</p></div><span class="dashicons dashicons-chart-line"></span></div><?php foreach($courses as$course):$students=MPH_Tutor::course_student_ids($course->ID); ?><details class="mph-progress-course"><summary><b><?php echo esc_html($course->post_title); ?></b><span><?php echo count($students); ?> هنرجو</span></summary><div class="mph-tutor-table"><table><thead><tr><th>هنرجو</th><th>نوع دوره</th><th>درصد ثبت‌شده</th><th>عملیات</th></tr></thead><tbody><?php if(!$students): ?><tr><td colspan="4">هنرجویی ثبت نشده است.</td></tr><?php endif;foreach($students as$user_id):$user=get_user_by('id',$user_id);if(!$user)continue;$access=self::access_modes($user_id,$course->ID);$modes=array_intersect(array_keys($access),array('online','inperson'));if(!$modes&&isset($access['offline'])): ?><tr><td><div class="mph-member-cell"><?php echo get_avatar($user_id,34); ?><b><?php echo esc_html(MPH_Helpers::display_name($user)); ?></b></div></td><td>آفلاین</td><td><?php echo self::offline_progress_percent($course->ID,$user_id); ?>٪ خودکار</td><td>بدون ویرایش دستی</td></tr><?php endif;foreach($modes as$mode):$percent=self::manual_progress_percent($course->ID,$user_id,$mode); ?><tr><td><div class="mph-member-cell"><?php echo get_avatar($user_id,34); ?><b><?php echo esc_html(MPH_Helpers::display_name($user)); ?></b></div></td><td><?php echo esc_html(self::modes()[$mode]['label']); ?></td><td><b><?php echo absint($percent); ?>٪</b></td><td><form class="mph-progress-inline" data-mph-action="mph_course_progress_save"><input type="hidden" name="course_id" value="<?php echo absint($course->ID); ?>"><input type="hidden" name="user_id" value="<?php echo absint($user_id); ?>"><input type="hidden" name="progress_mode" value="<?php echo esc_attr($mode); ?>"><input type="number" name="progress_percent" min="0" max="100" value="<?php echo absint($percent); ?>" required><button class="mph-primary" type="submit">ذخیره</button><button class="mph-secondary" type="submit" formmethod="post" data-mph-progress-delete>حذف</button><div class="mph-message"></div></form></td></tr><?php endforeach;endforeach; ?></tbody></table></div></details><?php endforeach; ?></section><?php return ob_get_clean();}

    private static function can_manage_progress(){return is_user_logged_in()&&(MPH_Helpers::has_role('mph_manager')||current_user_can('manage_options')||current_user_can('mph_manage_portal'));}
    public static function progress_percent($course_id,$user_id){return MPH_Tutor::progress_percent(absint($course_id),absint($user_id));}

    public static function copy_order_item_meta($item,$cart_item_key,$values,$order) {
        $product=$values['data']??false;if($product)self::sync_order_item_meta($item,$product);
    }

    public static function sync_order_item_meta($item,$product) {
        if(!is_object($item)||!is_object($product)||!method_exists($product,'get_meta'))return false;
        $course_id=absint($product->get_meta(self::COURSE_META));$mode=sanitize_key($product->get_meta(self::MODE_META));
        if(!$course_id||!isset(self::modes()[$mode]))return false;
        $item->update_meta_data(self::COURSE_META,$course_id);$item->update_meta_data(self::MODE_META,$mode);
        if($mode==='inperson'){$item->update_meta_data('_mph_class_start',$product->get_meta('_mph_inperson_start'));$item->update_meta_data('_mph_class_address',$product->get_meta('_mph_inperson_address'));}
        return true;
    }

    public static function grant_after_status_change($order_id,$from,$to,$order) {
        if(in_array($to,(array)wc_get_is_paid_statuses(),true))self::grant_order_access($order_id);
    }

    public static function grant_order_access($order_id,$force=false) {
        if(!function_exists('wc_get_order'))return new WP_Error('mph_no_wc','WooCommerce فعال نیست.');
        $order=wc_get_order(absint($order_id));
        if(!$order)return new WP_Error('mph_no_order','سفارش پیدا نشد.');
        $receipt_approved=$order->get_meta('_mph_receipt_payment')==='yes'&&$order->get_meta('_mph_receipt_status')==='approved';
        if(!$force&&!$order->is_paid()&&!$receipt_approved)return new WP_Error('mph_unpaid','سفارش هنوز پرداخت یا تأیید نشده است.');
        $user_id=absint($order->get_customer_id());if(!$user_id)return new WP_Error('mph_no_user','کاربر سفارش مشخص نیست.');
        $granted=array();$errors=array();
        foreach($order->get_items()as$item){
            $product=$item->get_product();$product_id=absint($item->get_product_id());
            $course_id=absint($item->get_meta(self::COURSE_META));$mode=sanitize_key($item->get_meta(self::MODE_META));
            if(!$course_id)$course_id=absint($product?$product->get_meta(self::COURSE_META):get_post_meta($product_id,self::COURSE_META,true));
            if(!$mode)$mode=sanitize_key($product?$product->get_meta(self::MODE_META):get_post_meta($product_id,self::MODE_META,true));
            if(!$course_id||!isset(self::modes()[$mode]))continue;
            $item->update_meta_data(self::COURSE_META,$course_id);$item->update_meta_data(self::MODE_META,$mode);
            if($mode==='inperson'){
                if(!$item->get_meta('_mph_class_start'))$item->update_meta_data('_mph_class_start',$product?$product->get_meta('_mph_inperson_start'):'');
                if(!$item->get_meta('_mph_class_address'))$item->update_meta_data('_mph_class_address',$product?$product->get_meta('_mph_inperson_address'):'');
                if(!$item->get_meta('_mph_attendance_tracking'))$item->update_meta_data('_mph_attendance_tracking',strtoupper(wp_generate_password(10,false,false)));
            }
            $item->save();$result=self::ensure_tutor_enrollment($course_id,$user_id,$order->get_id());
            if(is_wp_error($result))$errors[]=$result->get_error_message();else$granted[]=$course_id;
        }
        $granted=array_values(array_unique(array_map('absint',$granted)));
        if($granted){$previous=(array)$order->get_meta('_mph_access_granted_courses');$order->update_meta_data('_mph_access_granted_courses',array_values(array_unique(array_merge(array_map('absint',$previous),$granted))));$order->delete_meta_data('_mph_access_grant_error');}
        if($errors){$message=implode(' ',$errors);$order->update_meta_data('_mph_access_grant_error',$message);$order->add_order_note('خطای فعال‌سازی دوره: '.$message);}
        $order->save();
        if($granted && !$errors)MPH_Payment_Attempts::event($order,'course_access_enabled','دسترسی دوره‌های خریداری‌شده فعال شد.');
        if($errors)MPH_Payment_Attempts::event($order,'course_access_review','پرداخت ثبت شده است؛ فعال‌سازی برخی دوره‌ها نیازمند بررسی مدیر است.');
        if($errors)return new WP_Error('mph_enroll_failed',implode(' ',$errors));
        return count($granted);
    }

    public static function repair_user_access($user_id,$force=false) {
        $user_id=absint($user_id);if(!$user_id||!function_exists('wc_get_orders'))return;
        $last=absint(get_user_meta($user_id,'_mph_access_repair_at',true));if(!$force&&$last&&time()-$last<300)return;
        $statuses=array_values(array_unique(array_merge((array)wc_get_is_paid_statuses(),array('processing','completed'))));
        $orders=wc_get_orders(array('customer_id'=>$user_id,'status'=>$statuses,'limit'=>-1,'return'=>'objects','orderby'=>'date','order'=>'DESC'));
        foreach($orders as$order)self::grant_order_access($order->get_id());
        update_user_meta($user_id,'_mph_access_repair_at',time());
    }

    private static function ensure_tutor_enrollment($course_id,$user_id,$order_id) {
        if(!MPH_Tutor::active())return true;
        $course=get_post(absint($course_id));$user=get_user_by('id',absint($user_id));
        if(!$course||!$user)return new WP_Error('mph_invalid_enrollment','دوره یا کاربر برای ثبت‌نام معتبر نیست.');
        $utils=tutor_utils();
        try{if(is_callable(array($utils,'is_enrolled'))&&$utils->is_enrolled($course_id,$user_id))return true;}catch(Throwable$e){}
        if(is_callable(array($utils,'do_enroll'))){
            try{$utils->do_enroll($course_id,$order_id,$user_id);}catch(Throwable$e){$api_error=$e->getMessage();}
            try{if(is_callable(array($utils,'is_enrolled'))&&$utils->is_enrolled($course_id,$user_id))return true;}catch(Throwable$e){}
        }
        $existing=get_posts(array('post_type'=>'tutor_enrolled','post_status'=>'any','author'=>$user_id,'post_parent'=>$course_id,'numberposts'=>1,'fields'=>'ids','orderby'=>'ID','order'=>'DESC'));
        if($existing){$enrollment_id=absint($existing[0]);if(get_post_status($enrollment_id)!=='completed')wp_update_post(array('ID'=>$enrollment_id,'post_status'=>'completed'));}
        else{$enrollment_id=wp_insert_post(array('post_type'=>'tutor_enrolled','post_status'=>'completed','post_author'=>$user_id,'post_parent'=>$course_id,'post_title'=>$course->post_title));}
        if(is_wp_error($enrollment_id)||!$enrollment_id)return new WP_Error('mph_tutor_enroll','ثبت دوره در Tutor انجام نشد.'.(!empty($api_error)?' '.$api_error:''));
        update_post_meta($enrollment_id,'_mph_wc_order_id',absint($order_id));clean_post_cache($enrollment_id);
        return true;
    }

    public static function access_modes($user_id,$course_id) {
        static$cache=array();$key=absint($user_id).':'.absint($course_id);if(isset($cache[$key]))return$cache[$key];$result=array();if(user_can($user_id,'manage_options')||user_can($user_id,'mph_manage_portal')||absint(get_post_field('post_author',$course_id))===$user_id){foreach(self::product_map($course_id)as$mode=>$product_id){$product=self::product($product_id);if(isset(self::modes()[$mode])&&$product&&$product->get_status()==='publish')$result[$mode]=array('admin'=>true);}return$cache[$key]=$result;}
        $statuses=array_map(function($status){return'wc-'.$status;},wc_get_is_paid_statuses());$orders=wc_get_orders(array('customer_id'=>$user_id,'status'=>$statuses,'limit'=>-1,'return'=>'objects','orderby'=>'date','order'=>'DESC'));foreach($orders as$order)foreach($order->get_items()as$item){$product=$item->get_product();$item_course=absint($item->get_meta(self::COURSE_META)?:($product?$product->get_meta(self::COURSE_META):0));$mode=sanitize_key($item->get_meta(self::MODE_META)?:($product?$product->get_meta(self::MODE_META):''));if($item_course===$course_id&&isset(self::modes()[$mode]))$result[$mode]=array('order_id'=>$order->get_id());}
        if(!$result&&MPH_Tutor::active()&&is_callable(array(tutor_utils(),'is_enrolled'))&&tutor_utils()->is_enrolled($course_id,$user_id)){$map=self::product_map($course_id);$offline=self::product($map['offline']??0);if(!$map||($offline&&$offline->get_status()==='publish'))$result['offline']=array('legacy'=>true);}return$cache[$key]=$result;
    }

    public static function has_access($user_id,$course_id,$mode){$modes=self::access_modes(absint($user_id),absint($course_id));return isset($modes[$mode]);}

    public static function stream_video() {
        if(!is_user_logged_in())auth_redirect();$course_id=absint($_GET['course_id']??0);$attachment_id=absint($_GET['video_id']??0);$nonce=sanitize_text_field(wp_unslash($_GET['_wpnonce']??''));if(!$course_id||!$attachment_id||!wp_verify_nonce($nonce,'mph_course_video_'.$course_id.'_'.$attachment_id)||!self::has_access(get_current_user_id(),$course_id,'offline')||!self::video_in_course($course_id,$attachment_id))wp_die('دسترسی به ویدئو ندارید.','',array('response'=>403));$path=get_attached_file($attachment_id);if(!$path||!is_readable($path))wp_die('فایل ویدئو پیدا نشد.','',array('response'=>404));self::send_file_range($path,get_post_mime_type($attachment_id)?:'video/mp4');
    }

    public static function stream_note() {
        if(!is_user_logged_in())auth_redirect();$course_id=absint($_GET['course_id']??0);$attachment_id=absint($_GET['note_id']??0);$nonce=sanitize_text_field(wp_unslash($_GET['_wpnonce']??''));if(!$course_id||!$attachment_id||!wp_verify_nonce($nonce,'mph_course_note_'.$course_id.'_'.$attachment_id)||!self::has_access(get_current_user_id(),$course_id,'offline')||!self::note_in_course($course_id,$attachment_id))wp_die('دسترسی به جزوه ندارید.','',array('response'=>403));$path=get_attached_file($attachment_id);if(!$path||!is_readable($path))wp_die('فایل جزوه پیدا نشد.','',array('response'=>404));while(ob_get_level())ob_end_clean();nocache_headers();header('Content-Type: '.(get_post_mime_type($attachment_id)?:'application/octet-stream'));header('Content-Disposition: attachment; filename="'.sanitize_file_name(wp_basename($path)).'"');header('Content-Length: '.filesize($path));readfile($path);exit;
    }

    private static function send_file_range($path,$mime) {
        while(ob_get_level())ob_end_clean();nocache_headers();$size=filesize($path);$start=0;$end=$size-1;$status=200;if(!empty($_SERVER['HTTP_RANGE'])&&preg_match('/bytes=(\d*)-(\d*)/',sanitize_text_field(wp_unslash($_SERVER['HTTP_RANGE'])),$match)){$start=$match[1]!==''?min(absint($match[1]),$end):0;$end=$match[2]!==''?min(absint($match[2]),$end):$end;if($start>$end){status_header(416);header("Content-Range: bytes */{$size}");exit;}$status=206;}status_header($status);header('Content-Type: '.$mime);header('Accept-Ranges: bytes');header('Content-Length: '.($end-$start+1));if($status===206)header("Content-Range: bytes {$start}-{$end}/{$size}");$handle=fopen($path,'rb');fseek($handle,$start);$remaining=$end-$start+1;while($remaining>0&&!feof($handle)){$chunk=fread($handle,min(1048576,$remaining));if($chunk===false||$chunk==='')break;echo$chunk;$remaining-=strlen($chunk);flush();}fclose($handle);exit;
    }

    public static function order_has_inperson($order){if(!$order)return false;foreach($order->get_items()as$item){$product=$item->get_product();$mode=sanitize_key($item->get_meta(self::MODE_META)?:($product?$product->get_meta(self::MODE_META):''));if($mode==='inperson')return true;}return false;}
    public static function invoice_url($order_id,$format=''){return wp_nonce_url(add_query_arg(array_filter(array('action'=>'mph_print_course_invoice','order_id'=>absint($order_id),'format'=>$format)),admin_url('admin-post.php')),'mph_invoice_'.absint($order_id));}
    private static function invoice_links($user_id,$course_id){$links='';$statuses=array_map(function($status){return'wc-'.$status;},wc_get_is_paid_statuses());$orders=wc_get_orders(array('customer_id'=>$user_id,'status'=>$statuses,'limit'=>-1,'orderby'=>'date','order'=>'DESC'));foreach($orders as$order)foreach($order->get_items()as$item){$product=$item->get_product();$item_course=absint($item->get_meta(self::COURSE_META)?:($product?$product->get_meta(self::COURSE_META):0));$mode=sanitize_key($item->get_meta(self::MODE_META)?:($product?$product->get_meta(self::MODE_META):''));if($item_course===$course_id&&$mode==='inperson'){$links='<div class="mph-invoice-actions"><a class="mph-primary" target="_blank" href="'.esc_url(self::invoice_url($order->get_id())).'">چاپ صورت‌حساب</a><a class="mph-secondary" target="_blank" href="'.esc_url(self::invoice_url($order->get_id(),'pdf')).'">ذخیره PDF فارسی</a></div>';break 2;}}return$links?:'<small>صورت‌حساب پرداخت‌شده پیدا نشد.</small>';}
    public static function invoice_card($order_id){$order=wc_get_order(absint($order_id));if(!$order||!self::can_view_order($order)||!$order->is_paid()||!self::order_has_inperson($order))return'';self::grant_order_access($order->get_id());return'<div class="mph-paid-invoice-notice"><span class="dashicons dashicons-yes-alt"></span><div><b>ثبت‌نام حضوری شما قطعی شد</b><p>صورت‌حساب شامل مشخصات کلاس و کد پیگیری آماده است.</p></div><div class="mph-invoice-actions"><a class="mph-primary" target="_blank" href="'.esc_url(self::invoice_url($order->get_id())).'">چاپ</a><a class="mph-secondary" target="_blank" href="'.esc_url(self::invoice_url($order->get_id(),'pdf')).'">PDF فارسی</a></div></div>';}

    public static function print_invoice(){if(!is_user_logged_in())auth_redirect();$order_id=absint($_GET['order_id']??0);$nonce=sanitize_text_field(wp_unslash($_GET['_wpnonce']??''));$order=wc_get_order($order_id);if(!$order||!wp_verify_nonce($nonce,'mph_invoice_'.$order_id)||!self::can_view_order($order)||(!$order->is_paid()&&$order->get_meta(MPH_Commerce::RECEIPT_STATUS)!=='approved'))wp_die('صورت‌حساب معتبر نیست.','',array('response'=>403));self::grant_order_access($order_id);$order=wc_get_order($order_id);$pdf=sanitize_key(wp_unslash($_GET['format']??''))==='pdf';nocache_headers();if($pdf){header('Content-Type: text/html; charset=UTF-8');header('Content-Disposition: inline; filename="invoice-'.$order_id.'.pdf"');header('X-MPH-Invoice: pdf');}self::invoice_document($order,$pdf);exit;}
    private static function invoice_document($order,$pdf_mode=false){$logo=defined('MPH_LOGO_URL')?MPH_LOGO_URL:'';$user=$order->get_user();?><!doctype html><html lang="fa" dir="rtl"><head><meta charset="<?php bloginfo('charset'); ?>"><meta name="viewport" content="width=device-width,initial-scale=1"><title>صورت‌حساب کلاس حضوری #<?php echo esc_html($order->get_order_number()); ?></title><style>body{margin:0;background:#eef1f6;color:#223047;font-family:YekanBakh,Tahoma,Arial,sans-serif;font-size:14px;line-height:1.8}.page{width:800px;max-width:calc(100% - 30px);margin:30px auto;padding:34px;box-sizing:border-box;border-radius:20px;background:#fff;box-shadow:0 20px 60px #18243b18}.head{display:flex;align-items:center;justify-content:space-between;padding-bottom:22px;border-bottom:2px solid #202e4b}.brand{display:flex;align-items:center;gap:14px}.brand img{max-width:100px;max-height:70px}.brand h1{margin:0;font-size:22px;line-height:1.6}.head b{color:#5261ca}.grid{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin:24px 0}.grid div,.course{padding:13px;border:1px solid #e2e6ed;border-radius:12px}.grid small,.course small{display:block;margin-bottom:6px;color:#7c8799;font-size:12px}.course{margin:10px 0;border-right:4px solid #5361d5}.course h3{margin:0 0 12px;font-size:18px}.course-grid{display:grid;grid-template-columns:1fr 1fr;gap:10px}.tracking{font-size:18px;letter-spacing:2px;color:#4050c2}.foot{display:flex;justify-content:space-between;margin-top:25px;padding-top:18px;border-top:1px solid #e1e5ec;color:#7c8798;font-size:11px}.print{position:fixed;left:20px;bottom:20px;padding:12px 20px;border:0;border-radius:12px;background:#223254;color:#fff;font:inherit;cursor:pointer}@media(max-width:650px){.page{padding:18px}.head,.foot{align-items:flex-start;flex-direction:column;gap:10px}.grid,.course-grid{grid-template-columns:1fr}}@media print{body{background:#fff}.page{width:100%;max-width:none;margin:0;box-shadow:none}.print{display:none}}</style></head><body<?php echo $pdf_mode?' onload="setTimeout(function(){window.print()},200)"':''; ?>><main class="page"><header class="head"><div class="brand"><?php if($logo): ?><img src="<?php echo esc_url($logo); ?>" alt=""><?php endif; ?><div><h1><?php echo esc_html(get_bloginfo('name')); ?></h1><small>صورت‌حساب ثبت‌نام کلاس حضوری</small></div></div><b>سفارش #<?php echo esc_html($order->get_order_number()); ?></b></header><section class="grid"><div><small>نام شرکت‌کننده</small><b><?php echo esc_html($order->get_formatted_billing_full_name()?:($user?MPH_Helpers::display_name($user):'—')); ?></b></div><div><small>شماره تلفن</small><b><?php echo esc_html($order->get_billing_phone()?:'—'); ?></b></div><div><small>تاریخ پرداخت</small><b><?php echo esc_html($order->get_date_paid()?wc_format_datetime($order->get_date_paid()):'—'); ?></b></div><div><small>مبلغ پرداخت‌شده</small><b><?php echo wp_kses_post($order->get_formatted_order_total()); ?></b></div></section><?php foreach($order->get_items()as$item):$product=$item->get_product();$mode=sanitize_key($item->get_meta(self::MODE_META)?:($product?$product->get_meta(self::MODE_META):''));if($mode!=='inperson')continue;$course_id=absint($item->get_meta(self::COURSE_META)?:($product?$product->get_meta(self::COURSE_META):0));$start=$item->get_meta('_mph_class_start')?:($product?$product->get_meta('_mph_inperson_start'):'');$address=$item->get_meta('_mph_class_address')?:($product?$product->get_meta('_mph_inperson_address'):'');$tracking=$item->get_meta('_mph_attendance_tracking'); ?><article class="course"><small>دوره حضوری</small><h3><?php echo esc_html(get_the_title($course_id)?:$item->get_name()); ?></h3><div class="course-grid"><div><small>شروع کلاس</small><b><?php echo esc_html($start?date_i18n('Y/m/d H:i',strtotime($start)):'اعلام می‌شود'); ?></b></div><div><small>محل برگزاری</small><b><?php echo esc_html($address?:'اعلام می‌شود'); ?></b></div><div><small>کد پیگیری حضور</small><b class="tracking" dir="ltr"><?php echo esc_html($tracking?:'—'); ?></b></div><div><small>وضعیت ثبت‌نام</small><b>قطعی و پرداخت‌شده</b></div></div></article><?php endforeach; ?><footer class="foot"><span>این صورت‌حساب به‌صورت خودکار توسط <?php echo esc_html(get_bloginfo('name')); ?> صادر شده است.</span><span><?php echo esc_html(wp_date('Y/m/d H:i')); ?></span></footer></main><button class="print" onclick="window.print()"><?php echo $pdf_mode?'ذخیره / دانلود PDF':'چاپ صورت‌حساب'; ?></button></body></html><?php }

    public static function product_map($course_id){$course_id=absint($course_id);$map=get_post_meta($course_id,self::PRODUCTS_META,true);$map=is_array($map)?array_filter(array_map('absint',$map)):array();if(!$map){$legacy=absint(get_post_meta($course_id,'_tutor_course_product_id',true));$product=self::product($legacy);if($product){$map=array('offline'=>$legacy);$product->update_meta_data(self::COURSE_META,$course_id);$product->update_meta_data(self::MODE_META,'offline');try{$product->save();update_post_meta($course_id,self::PRODUCTS_META,$map);}catch(Throwable$e){}}}return$map;}
    private static function product($id){return$id&&function_exists('wc_get_product')?wc_get_product(absint($id)):false;}
    private static function active_product_count($course_id){$count=0;foreach(self::product_map($course_id)as$id){$product=self::product($id);if($product&&$product->get_status()==='publish')$count++;}return$count;}
    private static function decimal($value){$value=strtr((string)$value,array('۰'=>'0','۱'=>'1','۲'=>'2','۳'=>'3','۴'=>'4','۵'=>'5','۶'=>'6','۷'=>'7','۸'=>'8','۹'=>'9','٬'=>'',','=>''));$value=preg_replace('/[^0-9.]/','',$value);return$value===''?'':wc_format_decimal($value);}
    private static function sanitize_datetime($value){$value=sanitize_text_field(wp_unslash($value));$stamp=strtotime($value);return$stamp?wp_date('Y-m-d H:i:s',$stamp):'';}
    private static function datetime_input($value){$stamp=strtotime((string)$value);return$stamp?wp_date('Y-m-d\TH:i',$stamp):'';}
    private static function video_url($course_id,$video_id){return wp_nonce_url(admin_url('admin-post.php?action=mph_course_video&course_id='.absint($course_id).'&video_id='.absint($video_id)),'mph_course_video_'.absint($course_id).'_'.absint($video_id));}
    private static function note_url($course_id,$note_id){return wp_nonce_url(admin_url('admin-post.php?action=mph_course_note&course_id='.absint($course_id).'&note_id='.absint($note_id)),'mph_course_note_'.absint($course_id).'_'.absint($note_id));}
    public static function video_in_course($course_id,$attachment_id){$map=self::product_map($course_id);$product=self::product($map['offline']??0);$curriculum=$product?$product->get_meta('_mph_offline_curriculum'):array();foreach((array)$curriculum as$section)foreach((array)($section['lessons']??array())as$lesson)if(absint($lesson['video_id']??0)===$attachment_id)return true;return false;}
    private static function note_in_course($course_id,$attachment_id){$map=self::product_map($course_id);$product=self::product($map['offline']??0);$curriculum=$product?$product->get_meta('_mph_offline_curriculum'):array();foreach((array)$curriculum as$section)foreach((array)($section['lessons']??array())as$lesson)if(absint($lesson['note_id']??0)===$attachment_id)return true;return false;}
    private static function legacy_course_by_product($product_id){if(!MPH_Tutor::active())return 0;if(method_exists(tutor_utils(),'get_course_id_by_product')){$id=absint(tutor_utils()->get_course_id_by_product(absint($product_id)));if($id)return$id;}$ids=get_posts(array('post_type'=>tutor()->course_post_type,'post_status'=>'any','numberposts'=>1,'fields'=>'ids','meta_key'=>'_tutor_course_product_id','meta_value'=>absint($product_id)));return absint($ids[0]??0);}
    private static function can_view_order($order){return$order&&(absint($order->get_customer_id())===get_current_user_id()||current_user_can('manage_options')||MPH_Helpers::has_role('mph_manager'));}

    /** B2/B3: پارامترهای ساخت روی ویرایش + مدرس دستی/انتخابی. */
    private static function persist_instructor_and_extras($course_id) {
        $course_id=absint($course_id);if(!$course_id)return;
        $instructor_raw=sanitize_text_field(wp_unslash($_POST['course_instructor_id']??''));
        $custom=sanitize_text_field(wp_unslash($_POST['course_instructor_custom']??''));
        // Manual instructor name always wins display when option "custom" is chosen.
        if($instructor_raw==='custom'){
            if($custom==='')return; // keep previous if empty submit
            update_post_meta($course_id,'_mph_custom_instructor_name',$custom);
            // Themes/Tutor often read author display name — also store for loops
            update_post_meta($course_id,'_tutor_instructor_name',$custom);
            update_post_meta($course_id,'mph_instructor_label',$custom);
            // keep post_author for Tutor ownership; display uses custom meta everywhere
        }elseif(array_key_exists('course_instructor_id',$_POST)){
            $ins_id=absint($instructor_raw);
            if($ins_id&&get_user_by('id',$ins_id)){
                wp_update_post(array('ID'=>$course_id,'post_author'=>$ins_id));
            }
            delete_post_meta($course_id,'_mph_custom_instructor_name');delete_post_meta($course_id,'_tutor_instructor_name');delete_post_meta($course_id,'mph_instructor_label');
        }
        if(array_key_exists('course_level',$_POST)){
            $level=sanitize_key(wp_unslash($_POST['course_level']??'all_levels'));
            if(!in_array($level,array('all_levels','beginner','intermediate','expert'),true))$level='all_levels';
            update_post_meta($course_id,'_tutor_course_level',$level);
        }
        if(array_key_exists('duration_hours',$_POST)||array_key_exists('duration_minutes',$_POST)){
            update_post_meta($course_id,'_course_duration',array(
                'hours'=>min(999,absint($_POST['duration_hours']??0)),
                'minutes'=>min(59,absint($_POST['duration_minutes']??0)),
            ));
        }
        if(array_key_exists('maximum_students',$_POST)){
            $settings=get_post_meta($course_id,'_tutor_course_settings',true);if(!is_array($settings))$settings=array();
            $settings['maximum_students']=min(100000,absint($_POST['maximum_students']??0));
            update_post_meta($course_id,'_tutor_course_settings',$settings);
        }
        if(array_key_exists('course_benefits',$_POST))update_post_meta($course_id,'_tutor_course_benefits',sanitize_textarea_field(wp_unslash($_POST['course_benefits'])));
        if(array_key_exists('course_requirements',$_POST))update_post_meta($course_id,'_tutor_course_requirements',sanitize_textarea_field(wp_unslash($_POST['course_requirements'])));
        if(array_key_exists('course_target',$_POST))update_post_meta($course_id,'_tutor_course_target_audience',sanitize_textarea_field(wp_unslash($_POST['course_target'])));
        if(array_key_exists('course_materials',$_POST))update_post_meta($course_id,'_tutor_course_material_includes',sanitize_textarea_field(wp_unslash($_POST['course_materials'])));
        if(array_key_exists('enable_qa',$_POST)||array_key_exists('course_title',$_POST))update_post_meta($course_id,'_tutor_enable_qa',empty($_POST['enable_qa'])?'no':'yes');
        if(array_key_exists('public_course',$_POST)||array_key_exists('course_title',$_POST))update_post_meta($course_id,'_tutor_is_public_course',empty($_POST['public_course'])?'no':'yes');
    }

    /** آیا کاربر فعلی می‌تواند «مدیریت دوره» را برای این course_id باز کند؟ مدیر یا مدرس همان دوره. */
    
    
    public static function filter_author_meta($value, $field, $user_id) {
        if (!in_array($field, array('display_name','nickname','first_name'), true)) return $value;
        $post = get_post();
        if (!$post) return $value;
        $type = (class_exists('MPH_Tutor') && MPH_Tutor::active() && !empty(tutor()->course_post_type)) ? tutor()->course_post_type : 'courses';
        if ($post->post_type !== $type) return $value;
        if ($user_id && absint($post->post_author) !== absint($user_id)) return $value;
        $custom = (string) get_post_meta($post->ID, '_mph_custom_instructor_name', true);
        return $custom !== '' ? $custom : $value;
    }

public static function filter_course_author_name($name) {
        if (!is_singular() && !in_the_loop()) return $name;
        $post = get_post();
        if (!$post) return $name;
        $type = (class_exists('MPH_Tutor') && MPH_Tutor::active() && !empty(tutor()->course_post_type)) ? tutor()->course_post_type : 'courses';
        if ($post->post_type !== $type) return $name;
        $custom = (string) get_post_meta($post->ID, '_mph_custom_instructor_name', true);
        return $custom !== '' ? $custom : $name;
    }

    public static function filter_author_display_name($display_name, $user_id = 0) {
        $post = get_post();
        if (!$post) return $display_name;
        $type = (class_exists('MPH_Tutor') && MPH_Tutor::active() && !empty(tutor()->course_post_type)) ? tutor()->course_post_type : 'courses';
        if ($post->post_type !== $type) return $display_name;
        if ($user_id && absint($post->post_author) !== absint($user_id)) return $display_name;
        $custom = (string) get_post_meta($post->ID, '_mph_custom_instructor_name', true);
        return $custom !== '' ? $custom : $display_name;
    }

    public static function filter_tutor_course_instructor($html) {
        $course_id = get_the_ID();
        if (!$course_id) return $html;
        $custom = (string) get_post_meta($course_id, '_mph_custom_instructor_name', true);
        if ($custom === '') return $html;
        // Replace visible author-like text carefully: inject name into common wrappers
        $safe = esc_html($custom);
        if (is_string($html) && $html !== '') {
            // Prefer replacing content of common instructor name nodes
            $replaced = preg_replace('/(instructor-name[^>]*>)(.*?)(<)/is', '$1'.$safe.'$3', $html, 1);
            if ($replaced && $replaced !== $html) return $replaced;
            $replaced = preg_replace('/(class="[^"]*instructor[^"]*"[^>]*>)([^<]*)/i', '$1'.$safe, $html, 1);
            if ($replaced && $replaced !== $html) return $replaced;
        }
        return '<span class="mph-custom-instructor-name">'.$safe.'</span>';
    }

    public static function filter_tutor_instructor_name($name, $instructor = null) {
        $course_id = get_the_ID();
        if (!$course_id) return $name;
        $custom = (string) get_post_meta($course_id, '_mph_custom_instructor_name', true);
        return $custom !== '' ? $custom : $name;
    }

public static function inject_instructor_name_script() {
        if (is_admin()) return;
        global $wpdb;
        $rows = $wpdb->get_results("SELECT post_id, meta_value FROM {$wpdb->postmeta} WHERE meta_key='_mph_custom_instructor_name' AND meta_value<>'' LIMIT 500");
        if (!$rows) return;
        $map = array();
        foreach ($rows as $row) {
            $id = absint($row->post_id);
            $name = (string) $row->meta_value;
            if (!$id || $name === '') continue;
            $map[(string) $id] = $name;
            $link = get_permalink($id);
            if ($link) $map['url:' . untrailingslashit($link)] = $name;
        }
        if (!$map) return;
        $json = wp_json_encode($map, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT);
        echo '<script id="mph-custom-instructors">(function(){try{'
            .'var map='.$json.';'
            .'function pick(node){if(!node)return"";var a=node.closest&&node.closest("a[href]");var href=(a&&a.href)||(node.getAttribute&&node.getAttribute("href"))||"";if(href){var c=href.split("?")[0].replace(/\\/$/,"");if(map["url:"+c])return map["url:"+c];for(var k in map){if(k.indexOf("url:")===0&&c.indexOf(k.slice(4))!==-1)return map[k];}}var card=node.closest&&node.closest("article,li,.course-card,.tutor-card,.elementor-post,[class*=course]");if(card){var link=card.querySelector("a[href]");if(link&&link.href){var u=link.href.split("?")[0].replace(/\\/$/,"");if(map["url:"+u])return map["url:"+u];for(var key in map){if(key.indexOf("url:")===0&&u.indexOf(key.slice(4))!==-1)return map[key];}}}return"";}'
            .'function apply(){document.querySelectorAll("small,span,p,a,div,h4,h5").forEach(function(n){if(!n||n.dataset.mphIns)return;if(n.closest("script,style,nav,form"))return;if(n.children&&n.children.length>2)return;var t=(n.textContent||"").trim();if(!t||t.length>48)return;if(/تومان|مشاهده|دانشجو|ساعت|٪|%|\\d{3,}/.test(t))return;var onImg=!!(n.closest(".tutor-course-thumbnail,figure,[class*=thumb],[class*=image],[class*=cover]"));var looks=/instructor|teacher|author|مدرس/i.test(n.className||"")||onImg;if(!looks&&t.split(" ").length>4)return;if(!looks&&!onImg)return;var nm=pick(n);if(!nm||nm===t){if(nm===t)n.dataset.mphIns="1";return;}n.textContent=nm;n.dataset.mphIns="1";});}'
            .'apply();document.addEventListener("DOMContentLoaded",apply);setTimeout(apply,500);setTimeout(apply,1500);'
            .'if(window.jQuery){jQuery(document).on("ajaxComplete",function(){setTimeout(apply,250);});}'
            .'}catch(e){}})();</script>';
    }

public static function instructor_display_name($course) {
        $course = $course instanceof WP_Post ? $course : get_post(absint($course));
        if (!$course) return '—';
        $custom = (string) get_post_meta($course->ID, '_mph_custom_instructor_name', true);
        if ($custom !== '') return $custom;
        $author = get_user_by('id', $course->post_author);
        return $author ? MPH_Helpers::display_name($author) : '—';
    }

    public static function can_manage_course($course_id) {
        $course_id=absint($course_id);$course=get_post($course_id);
        if(!$course||!MPH_Tutor::active()||$course->post_type!==tutor()->course_post_type)return false;
        if(current_user_can('manage_options')||current_user_can('mph_manage_courses'))return true;
        $uid=get_current_user_id();
        if($uid&&absint($course->post_author)===$uid)return true;
        return false;
    }

    public static function ajax_manage_panel() {
        MPH_Helpers::verify_ajax();
        $course_id=absint($_POST['course_id']??0);
        if(!self::can_manage_course($course_id))wp_send_json_error(array('message'=>'اجازه مدیریت این دوره را ندارید.'),403);
        wp_send_json_success(array('html'=>self::manage_panel_html($course_id)));
    }

    public static function ajax_manage_save() {
        MPH_Helpers::verify_ajax();
        $course_id=absint($_POST['course_id']??0);
        if(!self::can_manage_course($course_id))wp_send_json_error(array('message'=>'اجازه مدیریت این دوره را ندارید.'),403);
        $section=sanitize_key(wp_unslash($_POST['manage_section']??''));
        if($section==='attendance'){
            $session_key=sanitize_key(wp_unslash($_POST['session_key']??''));
            if($session_key==='')wp_send_json_error(array('message'=>'جلسه معتبر نیست.'));
            $raw=(array)($_POST['attendance']??array());
            $clean=array();
            foreach($raw as $uid=>$status){
                $uid=absint($uid);$status=sanitize_key($status);
                if(!$uid||!in_array($status,array('present','absent','late','excused'),true))continue;
                $clean[(string)$uid]=$status;
            }
            $all=get_post_meta($course_id,'_mph_course_attendance',true);if(!is_array($all))$all=array();
            $all[$session_key]=array('updated_at'=>current_time('mysql'),'by'=>get_current_user_id(),'rows'=>$clean);
            update_post_meta($course_id,'_mph_course_attendance',$all);
            wp_send_json_success(array('message'=>'حضور و غیاب ذخیره شد.','html'=>self::manage_panel_html($course_id,'attendance')));
        }
        if($section==='sessions'){
            $starts=(array)($_POST['session_start']??array());
            $ends=(array)($_POST['session_end']??array());
            $titles=(array)($_POST['session_title']??array());
            $sessions=array();
            $n=max(count($starts),count($ends),count($titles));
            for($i=0;$i<$n;$i++){
                $title=sanitize_text_field(wp_unslash($titles[$i]??''));
                $start=self::sanitize_datetime(wp_unslash($starts[$i]??''));
                $end=self::sanitize_datetime(wp_unslash($ends[$i]??''));
                if($title===''&&$start===''&&$end==='')continue;
                $key='s'.($i+1).'_'.substr(md5($title.'|'.$start.'|'.$end),0,8);
                $sessions[]=array('key'=>$key,'title'=>$title?:('جلسه '.($i+1)),'start'=>$start,'end'=>$end);
            }
            update_post_meta($course_id,'_mph_course_sessions',$sessions);
            wp_send_json_success(array('message'=>'جلسات ذخیره شد.','html'=>self::manage_panel_html($course_id,'sessions')));
        }
        if($section==='exams'){
            $title=sanitize_text_field(wp_unslash($_POST['exam_title']??''));
            $date=sanitize_text_field(wp_unslash($_POST['exam_date']??''));
            $note=sanitize_textarea_field(wp_unslash($_POST['exam_note']??''));
            if($title==='')wp_send_json_error(array('message'=>'عنوان آزمون را وارد کنید.'));
            $exams=get_post_meta($course_id,'_mph_course_exams',true);if(!is_array($exams))$exams=array();
            $exams[]=array(
                'id'=>'ex_'.strtolower(wp_generate_password(8,false,false)),
                'title'=>$title,
                'date'=>preg_match('/^\d{4}-\d{2}-\d{2}$/',$date)?$date:current_time('Y-m-d'),
                'note'=>$note,
                'created_at'=>current_time('mysql'),
                'by'=>get_current_user_id(),
            );
            update_post_meta($course_id,'_mph_course_exams',$exams);
            wp_send_json_success(array('message'=>'آزمون ثبت شد.','html'=>self::manage_panel_html($course_id,'exams')));
        }
        if($section==='course_end'){
            $is_manager=current_user_can('manage_options')||current_user_can('mph_manage_courses')||MPH_Helpers::has_role('mph_manager');
            $prev=get_post_meta($course_id,'_mph_course_end',true);if(!is_array($prev))$prev=array();
            if(!empty($prev['locked'])&&!$is_manager)wp_send_json_error(array('message'=>'این بخش توسط مدیر قفل شده است.'),403);
            $status=sanitize_key(wp_unslash($_POST['end_status']??'draft'));
            if(!in_array($status,array('draft','completed','cancelled'),true))$status='draft';
            $date=sanitize_text_field(wp_unslash($_POST['end_date']??''));
            if($date&&!preg_match('/^\d{4}-\d{2}-\d{2}$/',$date))$date='';
            $note=sanitize_textarea_field(wp_unslash($_POST['end_note']??''));
            $locked=$is_manager?(!empty($_POST['end_lock_instructor'])):!empty($prev['locked']);
            $data=array(
                'status'=>$status,
                'date'=>$date,
                'note'=>$note,
                'locked'=>$locked?1:0,
                'by'=>get_current_user_id(),
                'updated_at'=>current_time('mysql'),
                'instructor_by'=>absint($prev['instructor_by']??0),
                'manager_by'=>absint($prev['manager_by']??0),
            );
            if($is_manager)$data['manager_by']=get_current_user_id();
            else $data['instructor_by']=get_current_user_id();
            // Manager can fully overwrite instructor fields (already using posted values).
            update_post_meta($course_id,'_mph_course_end',$data);
            if($status==='completed')update_post_meta($course_id,'_mph_course_ended','yes');
            else delete_post_meta($course_id,'_mph_course_ended');
            do_action('mph_course_end_saved',$course_id,get_current_user_id());
            wp_send_json_success(array('message'=>'پایان دوره ذخیره شد.','html'=>self::manage_panel_html($course_id,'course_end')));
        }
        wp_send_json_error(array('message'=>'بخش مدیریت نامعتبر است.'));
    }

    private static function manage_panel_html($course_id,$focus='') {
        $course=get_post(absint($course_id));
        if(!$course)return '<div class="mph-empty">دوره پیدا نشد.</div>';
        $sessions=get_post_meta($course_id,'_mph_course_sessions',true);if(!is_array($sessions))$sessions=array();
        $attendance=get_post_meta($course_id,'_mph_course_attendance',true);if(!is_array($attendance))$attendance=array();
        $exams=get_post_meta($course_id,'_mph_course_exams',true);if(!is_array($exams))$exams=array();
        $students=array();
        foreach(MPH_Tutor::course_student_ids($course_id) as $sid){
            $u=get_user_by('id',$sid);if($u)$students[]=$u;
        }
        if(!$sessions)$sessions=array(array('key'=>'default','title'=>'جلسه ۱','start'=>'','end'=>''));
        $active_session=sanitize_key(wp_unslash($_POST['session_key']??($sessions[0]['key']??'default')));
        $found=false;foreach($sessions as $s)if(($s['key']??'')===$active_session){$found=true;break;}
        if(!$found)$active_session=$sessions[0]['key']??'default';
        $rows=$attendance[$active_session]['rows']??array();
        $xlsx=wp_nonce_url(admin_url('admin-post.php?action=mph_course_students_xlsx&course_id='.$course_id),'mph_course_students_'.$course_id);
        if($focus==='')$focus='sessions';
        $end=get_post_meta($course_id,'_mph_course_end',true);if(!is_array($end))$end=array();
        $is_manager=current_user_can('manage_options')||current_user_can('mph_manage_courses')||MPH_Helpers::has_role('mph_manager');
        $can_edit_end=$is_manager||self::can_manage_course($course_id);
        $end_locked=!empty($end['locked'])&&!$is_manager;
        $end_user=!empty($end['by'])?get_user_by('id',absint($end['by'])):null;
        ob_start(); ?>
        <div class="mph-course-manage-panel" data-mph-course-manage-panel data-course-id="<?php echo absint($course_id); ?>">
            <header class="mph-course-manage-head">
                <div><small>مدیریت دوره</small><h3><?php echo esc_html($course->post_title); ?></h3></div>
                <button type="button" class="mph-secondary" data-mph-manage-close>بستن</button>
            </header>
            <nav class="mph-course-manage-tabs" data-mph-manage-tabs>
                <button type="button" class="<?php echo $focus==='sessions'?'is-active':''; ?>" data-manage-tab="sessions">جلسات</button>
                <button type="button" class="<?php echo $focus==='attendance'?'is-active':''; ?>" data-manage-tab="attendance">حضور و غیاب</button>
                <button type="button" class="<?php echo $focus==='exams'?'is-active':''; ?>" data-manage-tab="exams">آزمون‌ها</button>
                <button type="button" class="<?php echo $focus==='students'?'is-active':''; ?>" data-manage-tab="students">دانشجویان</button>
                <button type="button" class="<?php echo $focus==='course_end'?'is-active':''; ?>" data-manage-tab="course_end">پایان دوره</button>
            </nav>

            <section class="mph-manage-tab-panel <?php echo $focus==='sessions'?'is-active':''; ?>" data-manage-panel="sessions">
                <form data-mph-action="mph_course_manage_save" data-mph-sessions-form>
                    <input type="hidden" name="course_id" value="<?php echo absint($course_id); ?>">
                    <input type="hidden" name="manage_section" value="sessions">
                    <div data-mph-session-rows>
                        <?php foreach($sessions as $i=>$s): ?>
                        <div class="mph-admin-grid mph-session-row">
                            <label>عنوان<input type="text" name="session_title[]" value="<?php echo esc_attr($s['title']??''); ?>"></label>
                            <label>شروع<input type="datetime-local" name="session_start[]" value="<?php echo esc_attr(self::datetime_input($s['start']??'')); ?>"></label>
                            <label>پایان<input type="datetime-local" name="session_end[]" value="<?php echo esc_attr(self::datetime_input($s['end']??'')); ?>"></label>
                        </div>
                        <?php endforeach; ?>
                    </div>
                    <button type="button" class="mph-secondary" data-mph-add-session>＋ جلسه</button>
                    <button class="mph-primary" type="submit">ذخیره جلسات</button>
                    <div class="mph-message"></div>
                </form>
            </section>

            <section class="mph-manage-tab-panel <?php echo $focus==='attendance'?'is-active':''; ?>" data-manage-panel="attendance">
                <form data-mph-action="mph_course_manage_save">
                    <input type="hidden" name="course_id" value="<?php echo absint($course_id); ?>">
                    <input type="hidden" name="manage_section" value="attendance">
                    <label>جلسه
                        <select name="session_key">
                            <?php foreach($sessions as $s): ?>
                                <option value="<?php echo esc_attr($s['key']); ?>" <?php selected($active_session,$s['key']); ?>><?php echo esc_html($s['title']??$s['key']); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </label>
                    <div class="mph-tutor-table mph-table-scroll"><table>
                        <thead><tr><th>دانشجو</th><th>تلفن</th><th>وضعیت</th></tr></thead>
                        <tbody>
                        <?php if(!$students): ?><tr><td colspan="3">هنرجویی ثبت‌نام نشده است.</td></tr><?php endif; ?>
                        <?php foreach($students as $user):
                            $st=sanitize_key($rows[(string)$user->ID]??'present'); ?>
                            <tr>
                                <td><?php echo esc_html(MPH_Helpers::display_name($user)); ?></td>
                                <td dir="ltr"><?php echo esc_html(get_user_meta($user->ID,'mph_phone',true)?:'—'); ?></td>
                                <td class="mph-attendance-radios">
                                    <?php foreach(array('present'=>'حاضر','absent'=>'غایب','late'=>'تأخیر','excused'=>'موجه') as $k=>$lab): ?>
                                        <label><input type="radio" name="attendance[<?php echo absint($user->ID); ?>]" value="<?php echo esc_attr($k); ?>" <?php checked($st,$k); ?>> <?php echo esc_html($lab); ?></label>
                                    <?php endforeach; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table></div>
                    <button class="mph-primary" type="submit">ذخیره حضور و غیاب</button>
                    <div class="mph-message"></div>
                </form>
            </section>

            <section class="mph-manage-tab-panel <?php echo $focus==='exams'?'is-active':''; ?>" data-manage-panel="exams">
                <form data-mph-action="mph_course_manage_save">
                    <input type="hidden" name="course_id" value="<?php echo absint($course_id); ?>">
                    <input type="hidden" name="manage_section" value="exams">
                    <div class="mph-admin-grid">
                        <label>عنوان آزمون<input type="text" name="exam_title" required placeholder="مثلاً میان‌ترم"></label>
                        <label>تاریخ<input type="date" name="exam_date" value="<?php echo esc_attr(current_time('Y-m-d')); ?>"></label>
                    </div>
                    <label>یادداشت<textarea name="exam_note" rows="2"></textarea></label>
                    <button class="mph-primary" type="submit">ثبت آزمون</button>
                    <div class="mph-message"></div>
                </form>
                <div class="mph-exam-history">
                    <h4>تاریخچه آزمون‌ها</h4>
                    <?php if(!$exams): ?><div class="mph-empty">هنوز آزمونی ثبت نشده است.</div><?php endif; ?>
                    <ul><?php foreach(array_reverse($exams) as $ex): ?>
                        <li><b><?php echo esc_html($ex['title']??''); ?></b>
                            <small><?php echo esc_html(($ex['date']??'').' · '.($ex['created_at']??'')); ?></small>
                            <?php if(!empty($ex['note'])): ?><p><?php echo esc_html($ex['note']); ?></p><?php endif; ?>
                        </li>
                    <?php endforeach; ?></ul>
                </div>
            </section>

            <section class="mph-manage-tab-panel <?php echo $focus==='students'?'is-active':''; ?>" data-manage-panel="students">
                <div class="mph-section-actions" style="margin-bottom:12px">
                    <a class="mph-primary" href="<?php echo esc_url($xlsx); ?>" data-mph-no-spa><span class="dashicons dashicons-media-spreadsheet"></span> خروجی اکسل</a>
                </div>
                <div class="mph-tutor-table mph-table-scroll"><table>
                    <thead><tr><th>نام</th><th>ایمیل</th><th>تلفن</th><th>پیشرفت</th></tr></thead>
                    <tbody>
                    <?php if(!$students): ?><tr><td colspan="4">دانشجویی نیست.</td></tr><?php endif; ?>
                    <?php foreach($students as $user): ?>
                        <tr>
                            <td><?php echo esc_html(MPH_Helpers::display_name($user)); ?></td>
                            <td dir="ltr"><?php echo esc_html($user->user_email); ?></td>
                            <td dir="ltr"><?php echo esc_html(get_user_meta($user->ID,'mph_phone',true)?:'—'); ?></td>
                            <td><?php echo esc_html(MPH_Tutor::progress_percent($course_id,$user->ID)); ?>٪</td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table></div>
            </section>

            <section class="mph-manage-tab-panel <?php echo $focus==='course_end'?'is-active':''; ?>" data-manage-panel="course_end">
                <form data-mph-action="mph_course_manage_save">
                    <input type="hidden" name="course_id" value="<?php echo absint($course_id); ?>">
                    <input type="hidden" name="manage_section" value="course_end">
                    <p class="mph-muted">مدرس می‌تواند پایان دوره را ثبت کند؛ مدیر همه فیلدها را ویرایش می‌کند.</p>
                    <div class="mph-admin-grid">
                        <label>وضعیت پایان
                            <select name="end_status" <?php disabled($end_locked); ?>>
                                <option value="draft" <?php selected(($end['status']??'draft'),'draft'); ?>>پیش‌نویس</option>
                                <option value="completed" <?php selected(($end['status']??''),'completed'); ?>>دوره پایان یافت</option>
                                <option value="cancelled" <?php selected(($end['status']??''),'cancelled'); ?>>لغو برگزاری</option>
                            </select>
                        </label>
                        <label>تاریخ پایان<input type="date" name="end_date" value="<?php echo esc_attr($end['date']??''); ?>" <?php disabled($end_locked); ?>></label>
                    </div>
                    <label>توضیحات / جمع‌بندی
                        <textarea name="end_note" rows="4" <?php disabled($end_locked); ?>><?php echo esc_textarea($end['note']??''); ?></textarea>
                    </label>
                    <?php if($is_manager): ?>
                        <label><input type="checkbox" name="end_lock_instructor" value="1" <?php checked(!empty($end['locked'])); ?>> قفل ویرایش برای مدرس (فقط مدیر)</label>
                    <?php endif; ?>
                    <?php if(!empty($end['updated_at'])): ?>
                        <small class="mph-muted">آخرین بروزرسانی: <?php echo esc_html($end['updated_at']); ?><?php echo $end_user?' توسط '.esc_html(MPH_Helpers::display_name($end_user)):''; ?></small>
                    <?php endif; ?>
                    <?php if($can_edit_end && (!$end_locked || $is_manager)): ?>
                        <button class="mph-primary" type="submit">ذخیره پایان دوره</button>
                    <?php elseif($end_locked): ?>
                        <div class="mph-empty">این رکورد توسط مدیر قفل شده است.</div>
                    <?php endif; ?>
                    <div class="mph-message"></div>
                </form>
            </section>
        </div>
        <?php
        return MPH_Helpers::secure_form_markup(ob_get_clean());
    }


    public static function export_students_xlsx() {
        $course_id=absint($_GET['course_id']??0);
        if(!self::can_manage_course($course_id))wp_die('دسترسی ندارید.');
        check_admin_referer('mph_course_students_'.$course_id);
        $course=get_post($course_id);
        $rows=array(array('نام','ایمیل','تلفن','پیشرفت ٪'));
        foreach(MPH_Tutor::course_student_ids($course_id) as $sid){
            $u=get_user_by('id',$sid);if(!$u)continue;
            $rows[]=array(
                MPH_Helpers::display_name($u),
                $u->user_email,
                (string)get_user_meta($u->ID,'mph_phone',true),
                (string)MPH_Tutor::progress_percent($course_id,$u->ID),
            );
        }
        $filename='course-'.$course_id.'-students-'.gmdate('Ymd').'.csv';
        while(ob_get_level())ob_end_clean();
        nocache_headers();
        header('Content-Type: text/csv; charset=UTF-8');
        header('Content-Disposition: attachment; filename="'.$filename.'"');
        $out=fopen('php://output','w');
        fwrite($out,"\xEF\xBB\xBF");
        foreach($rows as $r)fputcsv($out,$r);
        fclose($out);
        exit;
    }

    /** B7: با حذف کاربر، ثبت‌نام دوره‌ها و ظرفیت/نوبت آزاد شود. */
    public static function on_delete_user_release($user_id) {
        $user_id=absint($user_id);if(!$user_id)return;
        // Unenroll from Tutor courses (frees student slots / capacity recounts)
        $enrollments=get_posts(array('post_type'=>'tutor_enrolled','post_status'=>'any','author'=>$user_id,'numberposts'=>-1,'fields'=>'ids'));
        $course_ids=array();
        foreach($enrollments as $eid){
            $en=get_post($eid);if($en)$course_ids[]=absint($en->post_parent);
            wp_delete_post($eid,true);
        }
        $course_ids=array_values(array_unique(array_filter($course_ids)));
        foreach($course_ids as $cid){
            $map=self::product_map($cid);
            foreach($map as $pid){
                if(class_exists('MPH_Growth')){
                    delete_transient('mph_capacity_'.absint($pid));
                    if(method_exists('MPH_Growth','flush_product_capacity_cache'))MPH_Growth::flush_product_capacity_cache(absint($pid));
                }else delete_transient('mph_capacity_'.absint($pid));
            }
        }
        // Release appointment slots for this patient
        if(class_exists('MPH_Appointments')&&class_exists('MPH_Appointment_Repository')){
            $items=MPH_Appointment_Repository::query('user',$user_id,500);
            foreach($items as $item){
                $status=get_post_meta($item->ID,'_mph_appointment_status',true);
                if($status==='cancelled')continue;
                if(method_exists('MPH_Appointments','cancel_appointment_public')){
                    MPH_Appointments::cancel_appointment_public($item->ID,'حذف حساب کاربر');
                }else{
                    // fallback inline release
                    $slot_id=absint(get_post_meta($item->ID,'_mph_appointment_slot',true));
                    if($slot_id)MPH_Appointment_Repository::release_slot($slot_id,$item->ID);
                    update_post_meta($item->ID,'_mph_appointment_status','cancelled');
                    update_post_meta($item->ID,'_mph_appointment_cancel_reason','حذف حساب کاربر');
                }
            }
        }
        if(class_exists('MPH_Helpers'))MPH_Helpers::audit('user_capacity_released','user='.$user_id.';courses='.implode(',',$course_ids));
    }

}
