<?php
defined('ABSPATH') || exit;

/**
 * زیرساخت امنیت، ثبت رخداد، رمزنگاری داده‌های حساس و نگهداری دوره‌ای.
 */
final class MPH_Security {
    const CRON_HOOK = 'mph_security_daily_maintenance';

    public static function init() {
        add_action(self::CRON_HOOK, array(__CLASS__, 'daily_maintenance'));
        add_action('wp_mail_failed', array(__CLASS__, 'mail_failed'));
        add_action('mph_queued_mail', array(__CLASS__, 'send_queued_mail'), 10, 4);
        if (!wp_next_scheduled(self::CRON_HOOK)) wp_schedule_event(time() + HOUR_IN_SECONDS, 'daily', self::CRON_HOOK);
    }

    public static function install() {
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $charset = $wpdb->get_charset_collate();
        $log = $wpdb->prefix . 'mph_security_log';
        $locks = $wpdb->prefix . 'mph_slot_locks';
        dbDelta("CREATE TABLE {$log} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            created_at datetime NOT NULL,
            user_id bigint(20) unsigned NOT NULL DEFAULT 0,
            ip_hash char(64) NOT NULL DEFAULT '',
            event varchar(80) NOT NULL,
            details text NOT NULL,
            previous_hash char(64) NOT NULL DEFAULT '',
            row_hash char(64) NOT NULL,
            PRIMARY KEY  (id),
            KEY event_time (event,created_at),
            KEY user_time (user_id,created_at)
        ) {$charset};");
        dbDelta("CREATE TABLE {$locks} (
            slot_id bigint(20) unsigned NOT NULL,
            owner_token char(64) NOT NULL,
            expires_at datetime NOT NULL,
            created_at datetime NOT NULL,
            PRIMARY KEY  (slot_id),
            KEY expires_at (expires_at)
        ) {$charset};");
        // مهاجرت داده‌های قدیمی عمداً در فعال‌سازی اجرا نمی‌شود؛ نگهداری روزانه
        // آن را دسته‌ای انجام می‌دهد تا سایت روی هاست محدود timeout نشود.
    }

    public static function audit($event, $details = '', $user_id = null) {
        global $wpdb;
        $table = $wpdb->prefix . 'mph_security_log';
        $user_id = $user_id === null ? get_current_user_id() : absint($user_id);
        $event = sanitize_key($event);
        $details = sanitize_text_field((string)$details);
        $lock_name = substr($wpdb->prefix.'mph_security_chain',0,64);
        $locked = (int)$wpdb->get_var($wpdb->prepare('SELECT GET_LOCK(%s, 2)',$lock_name)) === 1;
        $previous = (string)$wpdb->get_var("SELECT row_hash FROM {$table} ORDER BY id DESC LIMIT 1");
        $created = current_time('mysql', true);
        $ip_hash = self::request_fingerprint();
        $hash = hash_hmac('sha256', implode('|', array($created,$user_id,$ip_hash,$event,$details,$previous)), wp_salt('auth'));
        $wpdb->insert($table, array('created_at'=>$created,'user_id'=>$user_id,'ip_hash'=>$ip_hash,'event'=>$event,'details'=>$details,'previous_hash'=>$previous,'row_hash'=>$hash), array('%s','%d','%s','%s','%s','%s','%s'));
        if ($locked) $wpdb->get_var($wpdb->prepare('SELECT RELEASE_LOCK(%s)',$lock_name));
    }

    public static function request_fingerprint($extra = '') {
        $ip = (string)($_SERVER['REMOTE_ADDR'] ?? 'unknown');
        $agent = substr((string)($_SERVER['HTTP_USER_AGENT'] ?? ''), 0, 180);
        return hash_hmac('sha256', $ip.'|'.$agent.'|'.(string)$extra, wp_salt('nonce'));
    }

    public static function allow($scope, $max, $ttl, $identity = '') {
        $identity = $identity !== '' ? (string)$identity : (is_user_logged_in() ? 'u:'.get_current_user_id() : self::request_fingerprint());
        $key = 'mph_limit_' . md5(sanitize_key($scope).'|'.$identity);
        $state = get_transient($key);
        if (!is_array($state)) $state = array('count'=>0,'started'=>time());
        if (absint($state['count'] ?? 0) >= absint($max)) return false;
        $state['count'] = absint($state['count'] ?? 0) + 1;
        set_transient($key, $state, max(30, absint($ttl)));
        return true;
    }

    public static function encrypt($value) {
        $value = (string)$value;
        if ($value === '' || strpos($value, 'mph:v1:') === 0 || strpos($value, 'mph:a1:') === 0) return $value;
        $key = hash('sha256', wp_salt('auth'), true);
        if (function_exists('sodium_crypto_secretbox')) {
            $nonce = random_bytes(SODIUM_CRYPTO_SECRETBOX_NONCEBYTES);
            return 'mph:v1:'.base64_encode($nonce.sodium_crypto_secretbox($value,$nonce,$key));
        }
        if (function_exists('openssl_encrypt')) {
            $iv = random_bytes(12);$tag='';$cipher=openssl_encrypt($value,'aes-256-gcm',$key,OPENSSL_RAW_DATA,$iv,$tag);
            if ($cipher !== false) return 'mph:a1:'.base64_encode($iv.$tag.$cipher);
        }
        return $value;
    }

    public static function decrypt($value) {
        $value = (string)$value;$key = hash('sha256', wp_salt('auth'), true);
        if (strpos($value,'mph:v1:')===0 && function_exists('sodium_crypto_secretbox_open')) {
            $raw=base64_decode(substr($value,7),true);if($raw===false)return'';$nonce=substr($raw,0,SODIUM_CRYPTO_SECRETBOX_NONCEBYTES);$cipher=substr($raw,SODIUM_CRYPTO_SECRETBOX_NONCEBYTES);$plain=sodium_crypto_secretbox_open($cipher,$nonce,$key);return $plain===false?'':$plain;
        }
        if (strpos($value,'mph:a1:')===0 && function_exists('openssl_decrypt')) {
            $raw=base64_decode(substr($value,7),true);if($raw===false||strlen($raw)<29)return'';$iv=substr($raw,0,12);$tag=substr($raw,12,16);$cipher=substr($raw,28);$plain=openssl_decrypt($cipher,'aes-256-gcm',$key,OPENSSL_RAW_DATA,$iv,$tag);return $plain===false?'':$plain;
        }
        return $value;
    }

    public static function get_user_meta($user_id, $key) {
        return self::decrypt(get_user_meta(absint($user_id), sanitize_key($key), true));
    }

    public static function update_user_meta($user_id, $key, $value) {
        return update_user_meta(absint($user_id), sanitize_key($key), self::encrypt($value));
    }

    public static function get_secret_option($key, $default = '') {
        $value=get_option(sanitize_key($key),$default);return is_string($value)?self::decrypt($value):$value;
    }

    public static function update_secret_option($key, $value) {
        return update_option(sanitize_key($key),self::encrypt((string)$value),false);
    }

    public static function queue_mail($to, $subject, $body, $headers = array()) {
        $args = array(sanitize_email($to), sanitize_text_field($subject), (string)$body, array_values((array)$headers));
        if (function_exists('as_enqueue_async_action')) return as_enqueue_async_action('mph_queued_mail', $args, 'modern-profile-hub');
        return wp_schedule_single_event(time()+5, 'mph_queued_mail', $args);
    }

    public static function send_queued_mail($to, $subject, $body, $headers = array()) {
        $sent = wp_mail($to,$subject,$body,$headers);
        self::audit($sent?'mail_sent':'mail_failed','to='.self::mask_email($to).';subject='.$subject,0);
    }

    public static function mail_failed($error) {
        if (is_wp_error($error)) self::audit('wp_mail_failed', implode('; ', $error->get_error_messages()), 0);
    }

    public static function daily_maintenance() {
        global $wpdb;
        $wpdb->query($wpdb->prepare("DELETE FROM {$wpdb->prefix}mph_security_log WHERE created_at < %s", gmdate('Y-m-d H:i:s', time()-365*DAY_IN_SECONDS)));
        $wpdb->query($wpdb->prepare("DELETE FROM {$wpdb->prefix}mph_slot_locks WHERE expires_at < %s", current_time('mysql', true)));
        self::cleanup_receipts();
        self::migrate_legacy_secrets(500);
        if (class_exists('MPH_Payments')) MPH_Payments::reconcile_pending_orders(10);
    }

    private static function cleanup_receipts() {
        if (!function_exists('wc_get_orders')) return;
        $days=max(30,absint(get_option('mph_receipt_retention_days',180)));$before=gmdate('Y-m-d',time()-$days*DAY_IN_SECONDS);
        $orders=wc_get_orders(array('limit'=>20,'status'=>array('completed','cancelled','refunded','failed'),'date_created'=>'<'.$before,'meta_key'=>MPH_Commerce::RECEIPT_META,'meta_value'=>'yes','return'=>'objects'));
        foreach((array)$orders as$order){$file=absint($order->get_meta(MPH_Commerce::RECEIPT_FILE));if($file&&get_post($file))wp_delete_attachment($file,true);$order->delete_meta_data(MPH_Commerce::RECEIPT_FILE);$order->update_meta_data('_mph_receipt_purged_at',current_time('mysql'));$order->save();}
    }

    public static function mask_email($email) {
        $email=sanitize_email($email);if(!$email||strpos($email,'@')===false)return'—';list($name,$domain)=explode('@',$email,2);return substr($name,0,2).'***@'.$domain;
    }

    /** مهاجرت تدریجی داده‌های نسخه‌های قبلی از متن ساده به رمزنگاری authenticated. */
    public static function migrate_legacy_secrets($limit = 500) {
        global $wpdb;$limit=max(10,min(2000,absint($limit)));
        foreach(array('mph_bank_card_number','mph_bank_card_owner')as$key){$raw=get_option($key,'');if(is_string($raw)&&$raw!==''&&strpos($raw,'mph:')!==0)self::update_secret_option($key,$raw);}
        $payment=get_option('mph_online_payment_settings',array());if(is_array($payment)){$changed=false;foreach(array('zarinpal_merchant','idpay_api_key')as$key){if(!empty($payment[$key])&&is_string($payment[$key])&&strpos($payment[$key],'mph:')!==0){$payment[$key]=self::encrypt($payment[$key]);$changed=true;}}if($changed)update_option('mph_online_payment_settings',$payment,false);}
        $user_keys=array('mph_payout_card','mph_payout_card_owner','mph_payout_bank');$placeholders=implode(',',array_fill(0,count($user_keys),'%s'));$query=$wpdb->prepare("SELECT umeta_id,meta_value FROM {$wpdb->usermeta} WHERE meta_key IN ({$placeholders}) AND meta_value<>'' AND LEFT(meta_value,4)<>'mph:' LIMIT %d",array_merge($user_keys,array($limit)));$rows=$wpdb->get_results($query);foreach((array)$rows as$row){$raw=(string)$row->meta_value;if($raw!==''&&strpos($raw,'mph:')!==0)$wpdb->update($wpdb->usermeta,array('meta_value'=>self::encrypt($raw)),array('umeta_id'=>absint($row->umeta_id)),array('%s'),array('%d'));}
        $post_keys=array('_mph_payout_card','_mph_payout_card_owner','_mph_payout_bank');$placeholders=implode(',',array_fill(0,count($post_keys),'%s'));$query=$wpdb->prepare("SELECT meta_id,meta_value FROM {$wpdb->postmeta} WHERE meta_key IN ({$placeholders}) AND meta_value<>'' AND LEFT(meta_value,4)<>'mph:' LIMIT %d",array_merge($post_keys,array($limit)));$rows=$wpdb->get_results($query);foreach((array)$rows as$row){$raw=(string)$row->meta_value;if($raw!==''&&strpos($raw,'mph:')!==0)$wpdb->update($wpdb->postmeta,array('meta_value'=>self::encrypt($raw)),array('meta_id'=>absint($row->meta_id)),array('%s'),array('%d'));}
    }
}
