<?php
defined('ABSPATH') || exit;

final class MPH_Helpers {
    const SETTINGS = 'mph_settings';
    const DB_VERSION = 'mph_db_version';

    public static function init() {
        add_action('admin_init', array(__CLASS__, 'keep_portal_manager_in_portal'), 1);
        add_action('user_profile_update_errors', array(__CLASS__, 'validate_wp_profile_names'), 10, 3);
    }

    public static function verify_ajax() {
        if (!check_ajax_referer('mph_nonce', 'nonce', false)) {
            wp_send_json_error(array('message' => 'درخواست نامعتبر است. صفحه را تازه‌سازی کنید.'), 403);
        }
    }

    public static function posted($key, $type = 'text') {
        if (!isset($_POST[$key])) return '';
        $value = wp_unslash($_POST[$key]);
        if ($type === 'raw') return (string) $value;
        if ($type === 'textarea') return sanitize_textarea_field($value);
        if ($type === 'key') return sanitize_key($value);
        return sanitize_text_field($value);
    }

    public static function phone($value) {
        $value = strtr((string) $value, array(
            '۰'=>'0','۱'=>'1','۲'=>'2','۳'=>'3','۴'=>'4','۵'=>'5','۶'=>'6','۷'=>'7','۸'=>'8','۹'=>'9',
            '٠'=>'0','١'=>'1','٢'=>'2','٣'=>'3','٤'=>'4','٥'=>'5','٦'=>'6','٧'=>'7','٨'=>'8','٩'=>'9'
        ));
        $value = preg_replace('/\D+/', '', $value);
        if (strpos($value, '0098') === 0) $value = '0' . substr($value, 4);
        elseif (strpos($value, '98') === 0) $value = '0' . substr($value, 2);
        return preg_match('/^09\d{9}$/', $value) ? $value : '';
    }

    public static function jalali_birth_date($value) {
        $value = strtr((string) $value, array(
            '۰'=>'0','۱'=>'1','۲'=>'2','۳'=>'3','۴'=>'4','۵'=>'5','۶'=>'6','۷'=>'7','۸'=>'8','۹'=>'9',
            '٠'=>'0','١'=>'1','٢'=>'2','٣'=>'3','٤'=>'4','٥'=>'5','٦'=>'6','٧'=>'7','٨'=>'8','٩'=>'9',
            '-'=>'/','–'=>'/','—'=>'/','.'=>'/','\\'=>'/'
        ));
        // برخی قالب‌های فارسی علامت‌های نامرئی جهت متن یا فاصله را همراه مقدار می‌فرستند.
        $value = preg_replace('/[\x{200c}-\x{200f}\x{202a}-\x{202e}\x{2066}-\x{2069}\s]+/u', '', $value);
        if ($value === '') return '';
        if (!preg_match('/^(1[23]\d{2}|14\d{2})\/(\d{1,2})\/(\d{1,2})$/', $value, $m)) return false;
        $year=absint($m[1]);$month=absint($m[2]);$day=absint($m[3]);
        // gmdate عمداً استفاده می‌شود تا فیلتر تبدیل اعداد وردپرس، سال را به صفر تبدیل نکند.
        $current=max(1300,absint(gmdate('Y'))-621);
        if($year<1300||$year>$current||$month<1||$month>12)return false;
        // ورودی فقط از تقویم داخلی و روزهای قابل انتخاب می‌آید؛ پذیرش روز ۳۰ اسفند
        // از رد اشتباه تاریخ در چرخه‌های کبیسه متفاوت جلوگیری می‌کند.
        $max=$month<=6?31:30;
        if($day<1||$day>$max)return false;
        return sprintf('%04d/%02d/%02d',$year,$month,$day);
    }

    public static function normalize_digits($value) {
        return strtr((string)$value, array(
            '۰'=>'0','۱'=>'1','۲'=>'2','۳'=>'3','۴'=>'4','۵'=>'5','۶'=>'6','۷'=>'7','۸'=>'8','۹'=>'9',
            '٠'=>'0','١'=>'1','٢'=>'2','٣'=>'3','٤'=>'4','٥'=>'5','٦'=>'6','٧'=>'7','٨'=>'8','٩'=>'9'
        ));
    }

    public static function jalali_date($value, $min_year = 1300, $max_year = 1500) {
        $value = self::normalize_digits($value);
        $value = strtr($value, array(
            '-'=>'/','–'=>'/','—'=>'/','−'=>'/','.'=>'/','\\'=>'/','_'=>'/',
            '／'=>'/','⁄'=>'/','∕'=>'/'
        ));
        $value = preg_replace('/[\x{200c}-\x{200f}\x{202a}-\x{202e}\x{2066}-\x{2069}\s]+/u', '', $value);
        if ($value === '') return '';
        // در موبایل ممکن است صفحه‌کلید عددی علامت ممیز نداشته باشد؛ ۸ رقم پیوسته هم پذیرفته می‌شود.
        if (preg_match('/^\d{8}$/', $value)) $value = substr($value,0,4).'/'.substr($value,4,2).'/'.substr($value,6,2);
        if (!preg_match('/^(\d{4})\/(\d{1,2})\/(\d{1,2})$/', $value, $match)) return false;
        $year=absint($match[1]);$month=absint($match[2]);$day=absint($match[3]);
        if ($year < absint($min_year) || $year > absint($max_year) || $month < 1 || $month > 12) return false;
        $max = $month <= 6 ? 31 : ($month <= 11 ? 30 : (self::is_jalali_leap($year) ? 30 : 29));
        if ($day < 1 || $day > $max) return false;
        return sprintf('%04d/%02d/%02d', $year, $month, $day);
    }

    public static function jalali_to_gregorian_date($value) {
        $value = self::jalali_date($value);
        if (!$value) return $value;
        list($year,$month,$day)=array_map('absint',explode('/',$value));
        $parts=self::jalali_to_gregorian_parts($year,$month,$day);
        return sprintf('%04d-%02d-%02d',$parts[0],$parts[1],$parts[2]);
    }

    public static function gregorian_to_jalali_date($value) {
        if (!preg_match('/^(\d{4})-(\d{1,2})-(\d{1,2})$/',(string)$value,$match) || !checkdate(absint($match[2]),absint($match[3]),absint($match[1]))) return '';
        $parts=self::gregorian_to_jalali_parts(absint($match[1]),absint($match[2]),absint($match[3]));
        return sprintf('%04d/%02d/%02d',$parts[0],$parts[1],$parts[2]);
    }

    private static function is_jalali_leap($year) {
        $first=self::jalali_to_gregorian_parts($year,1,1);$next=self::jalali_to_gregorian_parts($year+1,1,1);
        return (gmmktime(0,0,0,$next[1],$next[2],$next[0])-gmmktime(0,0,0,$first[1],$first[2],$first[0]))/DAY_IN_SECONDS===366.0;
    }

    private static function jalali_to_gregorian_parts($jy,$jm,$jd) {
        $jy+=1595;$days=-355668+(365*$jy)+(int)floor($jy/33)*8+(int)floor((($jy%33)+3)/4)+$jd;$days+=$jm<7?($jm-1)*31:(($jm-7)*30)+186;
        $gy=400*(int)floor($days/146097);$days%=146097;if($days>36524){$gy+=100*(int)floor(--$days/36524);$days%=36524;if($days>=365)$days++;}$gy+=4*(int)floor($days/1461);$days%=1461;if($days>365){$gy+=(int)floor(($days-1)/365);$days=($days-1)%365;}
        $gd=$days+1;$sal=array(0,31,(($gy%4===0&&$gy%100!==0)||$gy%400===0)?29:28,31,30,31,30,31,31,30,31,30,31);$gm=1;while($gm<=12&&$gd>$sal[$gm]){$gd-=$sal[$gm];$gm++;}return array($gy,$gm,$gd);
    }

    private static function gregorian_to_jalali_parts($gy,$gm,$gd) {
        $gdm=array(0,31,59,90,120,151,181,212,243,273,304,334);$gy2=$gm>2?$gy+1:$gy;$days=355666+(365*$gy)+(int)floor(($gy2+3)/4)-(int)floor(($gy2+99)/100)+(int)floor(($gy2+399)/400)+$gd+$gdm[$gm-1];
        $jy=-1595+33*(int)floor($days/12053);$days%=12053;$jy+=4*(int)floor($days/1461);$days%=1461;if($days>365){$jy+=(int)floor(($days-1)/365);$days=($days-1)%365;}if($days<186){$jm=1+(int)floor($days/31);$jd=1+($days%31);}else{$jm=7+(int)floor(($days-186)/30);$jd=1+(($days-186)%30);}return array($jy,$jm,$jd);
    }

    public static function birth_date_picker($value = '') {
        $value = self::jalali_birth_date($value);
        if ($value === false) $value = '';
        return '<div class="mph-date-picker" data-mph-date-picker><input type="text" name="birth_date" value="'.esc_attr($value).'" inputmode="none" autocomplete="off" readonly placeholder="انتخاب از تقویم شمسی" aria-label="تاریخ تولد"><button type="button" data-mph-date-toggle aria-label="باز کردن تقویم"><span class="dashicons dashicons-calendar-alt"></span></button></div>';
    }

    public static function user_by_phone($phone) {
        $users = get_users(array('meta_key'=>'mph_phone','meta_value'=>$phone,'number'=>1,'count_total'=>false));
        return $users ? $users[0] : false;
    }

    public static function strong_password($password) {
        return strlen($password) >= 10
            && preg_match('/[a-z]/', $password)
            && preg_match('/[A-Z]/', $password)
            && preg_match('/\d/', $password)
            && preg_match('/[^a-zA-Z\d]/', $password);
    }

    public static function valid_person_name($value) {
        $value = trim((string) $value);
        // A real name must contain at least one Unicode letter; numeric-only
        // values (including Persian/Arabic digits) are never accepted.
        return $value !== '' && (bool) preg_match('/\p{L}/u', $value);
    }

    /**
     * نامی که در رابط افزونه چاپ می‌شود همیشه باید دست‌کم یک حرف داشته باشد.
     * این نگهبان داده‌های قدیمیِ عددی را نیز بدون تغییر مخرب حساب، امن نمایش می‌دهد.
     */
    public static function display_name($user = null, $fallback = 'کاربر سایت') {
        $user = $user instanceof WP_User ? $user : ($user ? get_user_by('id', absint($user)) : wp_get_current_user());
        if (!$user instanceof WP_User) return $fallback;
        $full = trim((string) $user->first_name . ' ' . (string) $user->last_name);
        if (self::valid_person_name($full)) return $full;
        $display = trim((string) $user->display_name);
        if (self::valid_person_name($display)) return $display;
        $nickname = trim((string) get_user_meta($user->ID, 'nickname', true));
        if (self::valid_person_name($nickname)) return $nickname;
        return $fallback;
    }

    public static function valid_public_username($value) {
        $value = trim((string) $value);
        return $value !== ''
            && preg_match('/^[\p{L}\p{N}._-]{3,30}$/u', $value)
            && preg_match('/\p{L}/u', $value);
    }

    public static function validate_wp_profile_names($errors, $update, $user) {
        foreach (array('first_name' => 'نام', 'last_name' => 'نام خانوادگی', 'display_name' => 'نام نمایشی') as $field => $label) {
            if (!isset($user->$field) || trim((string) $user->$field) === '') continue;
            if (!self::valid_person_name($user->$field)) {
                $errors->add('mph_numeric_name', $label . ' باید شامل حروف باشد و نمی‌تواند فقط عدد باشد.');
            }
        }
    }

    public static function repair_numeric_names() {
        foreach(get_users(array('number'=>-1,'fields'=>'all'))as$user){$full=trim((string)$user->first_name.' '.(string)$user->last_name);if(!self::valid_person_name($user->display_name))wp_update_user(array('ID'=>$user->ID,'display_name'=>self::valid_person_name($full)?$full:'کاربر سایت'));$public=trim((string)get_user_meta($user->ID,'mph_public_username',true));if($public!==''&&!self::valid_public_username($public))delete_user_meta($user->ID,'mph_public_username');delete_user_meta($user->ID,'_mph_notification_preferences');}
    }

    /** مدیر مجموعه تمام کارهایش را در پنل افزونه انجام می‌دهد، نه wp-admin. */
    public static function keep_portal_manager_in_portal() {
        if (!is_user_logged_in() || !self::has_role('mph_manager') || current_user_can('manage_options')) return;
        if (wp_doing_ajax() || wp_doing_cron() || (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE)) return;
        global $pagenow;
        if (in_array((string) $pagenow, array('admin-ajax.php', 'admin-post.php', 'async-upload.php'), true)) return;
        wp_safe_redirect(add_query_arg('mph_mode', 'manager', self::account_page_url()));
        exit;
    }

    public static function required($label) {
        return esc_html($label) . '<span class="mph-required" aria-hidden="true">*</span>';
    }

    /**
     * همه فرم‌های افزونه حتی در صورت اجرا نشدن JavaScript با POST ارسال می‌شوند.
     * این نگهبان از قرارگرفتن تلفن، آدرس، رمز یا اطلاعات مالی در نشانی مرورگر جلوگیری می‌کند.
     */
    public static function secure_form_markup($html) {
        if(class_exists('MPH_Edit_Guard'))$html=MPH_Edit_Guard::markup($html);
        return preg_replace_callback('/<form\b([^>]*)>/i', function($match) {
            $attributes = (string) $match[1];
            if (!preg_match('/\bmethod\s*=/i', $attributes)) $attributes = ' method="post"' . $attributes;
            return '<form' . $attributes . '>';
        }, (string) $html);
    }

    public static function has_role($role, $user = null) {
        $user = $user ?: wp_get_current_user();
        if ($role === 'mph_instructor' && $user && in_array('tutor_instructor', (array) $user->roles, true)) return true;
        return $user && in_array($role, (array) $user->roles, true);
    }

    public static function current_mode() {
        $mode = isset($_GET['mph_mode']) ? sanitize_key(wp_unslash($_GET['mph_mode'])) : 'user';
        return self::allowed_mode($mode);
    }

    /**
     * نقش درخواستی را با نقش‌های واقعی حساب تطبیق می‌دهد.
     * این متد مانع جعل نقش از طریق AJAX و برگشت ناخواسته مدیر/مدرس به کاربر می‌شود.
     */
    public static function allowed_mode($mode) {
        $mode = sanitize_key((string) $mode);
        if ($mode === 'instructor' && !self::has_role('mph_instructor')) return 'user';
        if ($mode === 'therapist' && !self::has_role('mph_therapist')) return 'user';
        if ($mode === 'manager' && !self::has_role('mph_manager') && !current_user_can('mph_manage_portal') && !current_user_can('manage_options') && !(class_exists('MPH_Manager') && MPH_Manager::is_portal_super_admin())) return 'user';
        return in_array($mode, array('user','instructor','therapist','manager'), true) ? $mode : 'user';
    }

    public static function requested_mode() {
        $posted = self::posted('mode', 'key');
        return $posted ? self::allowed_mode($posted) : self::current_mode();
    }

    public static function role_label($mode) {
        if ($mode === 'manager') return 'مدیر مجموعه';
        if ($mode === 'instructor') return 'مدرس';
        if ($mode === 'therapist') return 'درمانگر';
        return 'کاربر';
    }

    public static function account_page_url() {
        $settings = get_option(self::SETTINGS, array());
        $page_id = absint($settings['account_page_id'] ?? 0);
        if ($page_id && get_post_status($page_id) && get_permalink($page_id)) return get_permalink($page_id);

        // اگر تنظیم صفحه در یک ارتقا پاک شده باشد، برگه دارای شورت‌کد را خودکار پیدا می‌کند.
        global $wpdb;
        $like = '%' . $wpdb->esc_like('[mph_profile') . '%';
        $found = absint($wpdb->get_var($wpdb->prepare(
            "SELECT ID FROM {$wpdb->posts} WHERE post_type='page' AND post_status='publish' AND post_content LIKE %s ORDER BY post_modified_gmt DESC, ID DESC LIMIT 1",
            $like
        )));
        if(!$found){$found=absint($wpdb->get_var($wpdb->prepare(
            "SELECT p.ID FROM {$wpdb->posts} p INNER JOIN {$wpdb->postmeta} pm ON pm.post_id=p.ID WHERE p.post_type='page' AND p.post_status='publish' AND pm.meta_key='_elementor_data' AND pm.meta_value LIKE %s ORDER BY p.post_modified_gmt DESC,p.ID DESC LIMIT 1",
            $like
        )));}
        if ($found && get_permalink($found)) {
            $settings['account_page_id'] = $found;
            update_option(self::SETTINGS, $settings, false);
            return get_permalink($found);
        }
        return home_url('/');
    }

    public static function auth_popup_url() {
        return add_query_arg('mph_profile_popup', '1', self::account_page_url());
    }

    public static function clean_auth_url($args = array()) {
        $url = add_query_arg('mph_clean_auth', '1', self::account_page_url());
        return $args ? add_query_arg($args, $url) : $url;
    }

    /** شناسه نمایشی هرگز عدد خالص نیست و نام ورود وردپرس را تغییر نمی‌دهد. */
    public static function profile_identifier($user = null) {
        $user = $user instanceof WP_User ? $user : ($user ? get_user_by('id', absint($user)) : wp_get_current_user());
        if (!$user instanceof WP_User) return '';
        $custom = trim((string) get_user_meta($user->ID, 'mph_public_username', true));
        if (self::valid_public_username($custom)) return $custom;
        $login = preg_replace('/^mph_/', '', (string) $user->user_login);
        if (self::valid_public_username($login)) return $login;
        $mail = strstr((string) $user->user_email, '@', true);
        if (self::valid_public_username($mail)) return $mail;
        return 'user-' . absint($user->ID);
    }

    public static function has_all_portal_roles($user = null) {
        $user = $user ?: wp_get_current_user();
        return self::has_role('mph_instructor', $user) && self::has_role('mph_manager', $user);
    }

    public static function audit($action, $details = '') {
        if (class_exists('MPH_Security')) MPH_Security::audit($action,$details);
        if (!is_user_logged_in()) return;
        $rows = get_option('mph_activity_log', array());
        if (!is_array($rows)) $rows = array();
        array_unshift($rows, array('time'=>current_time('mysql'),'user_id'=>get_current_user_id(),'action'=>sanitize_key($action),'details'=>sanitize_text_field($details)));
        update_option('mph_activity_log', array_slice($rows, 0, 250), false);
    }
}
