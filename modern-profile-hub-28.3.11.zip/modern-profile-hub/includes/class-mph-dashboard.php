<?php
defined('ABSPATH') || exit;

final class MPH_Dashboard {
    public static function init() {
        // بارگذاری دیرتر از قالب، تا استایل‌های عمومی قالب چینش پنل را برهم نزنند.
        add_action('wp_enqueue_scripts',array(__CLASS__,'assets'),99);
        add_filter('body_class', array(__CLASS__, 'body_classes'));
        add_shortcode('mph_profile',array(__CLASS__,'shortcode'));
        add_action('wp_ajax_mph_panel',array(__CLASS__,'ajax_panel'));
        add_action('wp_ajax_mph_profile',array(__CLASS__,'ajax_profile'));
        add_action('wp_ajax_mph_avatar',array(__CLASS__,'ajax_avatar'));
        add_action('wp_ajax_mph_session_view',array(__CLASS__,'ajax_session_view'));
        add_action('wp_ajax_nopriv_mph_session_view',array(__CLASS__,'ajax_session_view'));
        add_action('wp_ajax_nopriv_mph_auth_shell',array(__CLASS__,'ajax_auth_shell'));
        add_filter('get_avatar_url',array(__CLASS__,'avatar_url'),10,2);
    }

    /** Mark theme pages that host the plugin so UpStudy breadcrumb can be CSS-hidden. */
    public static function body_classes($classes) {
        if (self::is_profile_shortcode_page() || self::requires_portal_styles() || !empty($_GET['mph_clean_auth']) || !empty($_GET['mph_payment_result'])) {
            $classes[] = 'mph-plugin-page';
            $classes[] = 'mph-hide-upstudy-title';
            $classes[] = 'mph-theme-clay';
        }
        return $classes;
    }

    public static function assets() {
        wp_enqueue_style('dashicons');
        wp_enqueue_style('mph-yekanbakh',MPH_URL.'assets/css/yekanbakh.css',array(),MPH_VERSION);
        wp_enqueue_style('mph-header-account',MPH_URL.'assets/css/header-account.css',array(),MPH_VERSION);
        wp_enqueue_style('mph-interface',MPH_URL.'assets/css/interface.css',array('mph-yekanbakh'),MPH_VERSION);
        wp_enqueue_script('mph-typography',MPH_URL.'assets/js/typography.js',array(),MPH_VERSION,true);
        wp_register_style('mph-frontend-release',MPH_URL.'assets/css/frontend-release.css',array('dashicons','mph-yekanbakh'),MPH_VERSION);
        wp_register_style('mph-claymorphism',MPH_URL.'assets/css/claymorphism.css',array('mph-frontend-release','mph-interface'),MPH_VERSION);
        wp_register_style('mph-admin-release-portal',MPH_URL.'assets/css/admin-release.css',array('dashicons','mph-yekanbakh'),MPH_VERSION);
        if(self::requires_portal_styles())wp_enqueue_style('mph-frontend-release');
        wp_register_script('mph-otp-boxes',MPH_URL.'assets/js/otp-boxes.js',array(),MPH_VERSION,true);
        wp_register_script('mph-frontend',MPH_URL.'assets/js/frontend.js',array('mph-otp-boxes'),MPH_VERSION,true);
        wp_register_script('mph-header-account',MPH_URL.'assets/js/header-account.js',array('mph-frontend'),MPH_VERSION,true);
        wp_register_script('mph-date-picker',MPH_URL.'assets/js/date-picker.js',array(),MPH_VERSION,true);
        wp_register_script('mph-portal-v9',MPH_URL.'assets/js/portal-v9.js',array('mph-frontend'),MPH_VERSION,true);
        wp_register_script('mph-cart-v32',MPH_URL.'assets/js/cart-v32.js',array('mph-frontend'),MPH_VERSION,true);
        wp_register_script('mph-jalali-datetime',MPH_URL.'assets/js/jalali-datetime.js',array(),MPH_VERSION,true);
        wp_register_script('mph-appointments',MPH_URL.'assets/js/appointments.js',array('mph-frontend'),MPH_VERSION,true);
        wp_register_script('mph-quizzes-v11',MPH_URL.'assets/js/quizzes-v11.js',array('mph-frontend'),MPH_VERSION,true);
        wp_register_script('mph-admin-portal',MPH_URL.'assets/js/admin.js',array(),MPH_VERSION,true);
        wp_register_script('mph-course-admin',MPH_URL.'assets/js/course-admin.js',array('mph-admin-portal'),MPH_VERSION,true);
        // Header entry + auth popup scripts on all pages (lightweight).
        wp_enqueue_script('mph-otp-boxes');
        wp_enqueue_script('mph-frontend');
        wp_enqueue_script('mph-header-account');
        // Heavy portal skins MUST NOT load on normal theme pages (homepage layout break).
        $need_portal = self::requires_portal_styles() || self::is_profile_shortcode_page() || !empty($_GET['mph_clean_auth']) || !empty($_GET['mph_payment_result']) || !empty($_GET['mph_profile_popup']) || !empty($_GET['mph_auth']);
        if ($need_portal) {
            wp_enqueue_style('mph-frontend-release');
            wp_enqueue_style('mph-experience', MPH_URL.'assets/css/experience.css', array('mph-frontend-release'), MPH_VERSION);
            if (is_readable(MPH_DIR.'assets/css/claymorphism.css')) {
                wp_enqueue_style('mph-claymorphism');
            }
            wp_enqueue_script('mph-experience', MPH_URL.'assets/js/experience.js', array('mph-frontend'), MPH_VERSION, true);
        }
        if (is_user_logged_in() && $need_portal && class_exists('MPH_Forum')) {
            MPH_Forum::enqueue_assets();
        }
        // Tickets JS only on portal surfaces (not every theme page — layout noise).
        if (!empty($need_portal) && class_exists('MPH_Tickets')) {
            MPH_Tickets::enqueue_assets();
        }
        // Notifications + mic consent banners for logged-in users site-wide.
        if (is_user_logged_in() && class_exists('MPH_Web_Notifications')) {
            MPH_Web_Notifications::enqueue_assets();
        }
        foreach(array('mph-otp-boxes','mph-frontend','mph-header-account','mph-cart-v32','mph-jalali-datetime','mph-appointments','mph-date-picker','mph-portal-v9','mph-quizzes-v11','mph-admin-portal','mph-course-admin') as $handle)wp_script_add_data($handle,'strategy','defer');
        self::localize_frontend();
        if(is_user_logged_in()&&(MPH_Helpers::has_role('mph_instructor')||MPH_Helpers::has_role('mph_manager')||current_user_can('mph_manage_courses')||current_user_can('manage_options'))){wp_enqueue_media();wp_enqueue_style('mph-admin-release-portal');wp_enqueue_script('mph-course-admin');wp_localize_script('mph-admin-portal','MPH_ADMIN',array('ajaxUrl'=>admin_url('admin-ajax.php'),'nonce'=>wp_create_nonce('mph_nonce')));}
    }

    public static function shortcode() {
        self::enqueue_client_assets();
        if(is_user_logged_in()){MPH_Tickets::enqueue_assets();if(class_exists('MPH_Forum'))MPH_Forum::enqueue_assets();return MPH_Helpers::secure_form_markup('<div class="mph-root" dir="rtl">'.self::dashboard().'</div>');}
        // Bare account URL for guests is redirected in MPH_Auth::clean_page; keep popup/auth flags only.
        if(empty($_GET['mph_auth'])&&empty($_GET['mph_profile_popup'])&&empty($_GET['mph_clean_auth'])&&empty($_GET['mph_reset'])){
            return '<div class="mph-root" dir="rtl"><div class="mph-empty"><p>در حال بازگشت به صفحه اصلی…</p><script>window.location.replace('.json_encode(home_url('/')).');</script></div></div>';
        }
        if(empty($_GET['mph_auth'])&&empty($_GET['mph_profile_popup']))return MPH_Helpers::secure_form_markup('<div class="mph-root mph-inline-mode" dir="rtl"><div class="mph-inline-auth">'.MPH_Auth::render().'</div></div>');
        return MPH_Helpers::secure_form_markup('<div class="mph-root" dir="rtl"><div class="mph-auth-modal is-open" aria-hidden="false"><div class="mph-auth-backdrop" data-mph-close-auth></div><div class="mph-auth-dialog"><button type="button" class="mph-auth-close" data-mph-close-auth>×</button>'.MPH_Auth::render().'</div></div></div>');
    }

    public static function enqueue_client_assets() {
        self::enqueue_appointment_assets();
        wp_enqueue_script('mph-date-picker');
        wp_enqueue_script('mph-portal-v9');
        wp_enqueue_script('mph-cart-v32');
        wp_enqueue_script('mph-jalali-datetime');
        wp_enqueue_script('mph-quizzes-v11');
        MPH_Tickets::enqueue_assets();
    }

    public static function enqueue_appointment_assets() {
        self::assets();
        wp_enqueue_style('mph-frontend-release');
        wp_enqueue_script('mph-frontend');
        wp_enqueue_script('mph-appointments');
        self::localize_frontend();
    }

    private static function localize_frontend() {
        static $done=false;
        if($done)return;
        $done=true;
        $page_url=MPH_Helpers::account_page_url();
        $logo_url=defined('MPH_LOGO_URL')?MPH_LOGO_URL:'';
        wp_localize_script('mph-frontend','MPH_DATA',array(
            'userId'=>get_current_user_id(),'ajaxUrl'=>admin_url('admin-ajax.php'),
            'nonce'=>wp_create_nonce('mph_nonce'),
            'pageUrl'=>remove_query_arg(array('mph_mode','mph_open','mph_choose_course','mph_auth','mph_profile_popup','mph_clean_auth','mph_stage','mph_reset','mph_help','mph_backup_notice','mph_backup_type','key','flow','login','phone','management_otp','one_time_code','course_id','order_id'),$page_url),
            'homeUrl'=>home_url('/'),
            'cleanAuthUrl'=>MPH_Helpers::clean_auth_url(),
            'popupUrl'=>MPH_Helpers::auth_popup_url(),
            'headerAccount'=>self::header_account_data(),
            'logoUrl'=>esc_url_raw($logo_url),
            'portalStyleUrl'=>esc_url_raw(add_query_arg('ver',MPH_VERSION,MPH_URL.'assets/css/frontend-release.css')),
            'clayStyleUrl'=>esc_url_raw(add_query_arg('ver',MPH_VERSION,MPH_URL.'assets/css/claymorphism.css')),
            'datePickerScriptUrl'=>esc_url_raw(add_query_arg('ver',MPH_VERSION,MPH_URL.'assets/js/date-picker.js')),
            'working'=>'در حال انجام…','connectionError'=>'ارتباط با سرور برقرار نشد.',
            'requestTimeout'=>max(10000,min(60000,absint(apply_filters('mph_ajax_timeout',30000)))),
            'maxAvatarSize'=>2*MB_IN_BYTES,
        ));
    }

    public static function standalone_content() {
        self::enqueue_client_assets();
        if(is_user_logged_in()){MPH_Tickets::enqueue_assets();return MPH_Helpers::secure_form_markup('<div class="mph-root" dir="rtl">'.self::dashboard().'</div>');}
        return MPH_Helpers::secure_form_markup('<div class="mph-root mph-inline-mode" dir="rtl"><div class="mph-inline-auth">'.MPH_Auth::render().'</div></div>');
    }

    public static function popup_shell() {
        // پوسته کامل ورود عمداً روی همه صفحات تزریق نمی شود. با اولین کلیک روی
        // دکمه ورود، همان پوسته و CSS سنگین به صورت تنبل از AJAX دریافت می شود.
        return;
    }

    private static function popup_markup() {
        return MPH_Helpers::secure_form_markup('<div class="mph-root mph-global-popup-root" dir="rtl"><div class="mph-auth-modal" data-mph-global-auth aria-hidden="true"><div class="mph-auth-backdrop" data-mph-close-auth></div><div class="mph-auth-dialog" role="dialog" aria-modal="true" aria-label="ورود به حساب کاربری"><button type="button" class="mph-auth-close" data-mph-close-auth aria-label="بستن">×</button>'.MPH_Auth::render().'</div></div></div>');
    }

    public static function header_account_data() {
        $user=wp_get_current_user();$logged=$user instanceof WP_User&&$user->exists();$public_name='';$tokens=array('mph_');
        if($logged){
            $public_name=trim((string)get_user_meta($user->ID,'mph_public_username',true));
            if(!MPH_Helpers::valid_person_name($public_name))$public_name=MPH_Helpers::display_name($user);
            foreach(array($user->user_login,$user->display_name,MPH_Helpers::profile_identifier($user),get_user_meta($user->ID,'mph_phone',true))as$token){$token=trim((string)$token);if($token!=='')$tokens[]=$token;}
        }
        return array(
            'loggedIn'=>$logged,
            'url'=>$logged?MPH_Helpers::account_page_url():MPH_Helpers::auth_popup_url(),
            'greeting'=>$logged?'سلام، '.$public_name:'',
            'cartCount'=>$logged&&function_exists('WC')&&WC()->cart?absint(WC()->cart->get_cart_contents_count()):0,
            'cartUrl'=>$logged?add_query_arg('mph_open','cart',MPH_Helpers::account_page_url()):'',
            'label'=>$logged?'رفتن به حساب کاربری':'ورود یا ثبت‌نام',
            'accountTokens'=>array_values(array_unique($tokens)),
            'themeAccountSelectors'=>array_values(array_filter(array_map('sanitize_text_field',(array)apply_filters('mph_theme_account_selectors',array())))),
        );
    }

    public static function ajax_auth_shell() {
        // Auth popup on homepage needs portal skin without loading it site-wide earlier.
        wp_enqueue_style('mph-frontend-release');
        if (is_readable(MPH_DIR.'assets/css/claymorphism.css')) wp_enqueue_style('mph-claymorphism');

        nocache_headers();
        if(is_user_logged_in())wp_send_json_success(array('loggedIn'=>true,'headerAccount'=>self::header_account_data(),'nonce'=>wp_create_nonce('mph_nonce')));
        wp_send_json_success(array('loggedIn'=>false,'html'=>self::popup_markup(),'headerAccount'=>self::header_account_data(),'nonce'=>wp_create_nonce('mph_nonce')));
    }

    public static function ajax_session_view() {
        nocache_headers();
        $mode=MPH_Helpers::posted('session_mode','key');
        if($mode)$mode=MPH_Helpers::allowed_mode($mode);
        if(is_user_logged_in()){
            $old_mode=$_GET['mph_mode']??null;$old_open=$_GET['mph_open']??null;
            $old_course=$_GET['mph_choose_course']??null;
            $_GET['mph_mode']=$mode?:MPH_Helpers::current_mode();
            $open=MPH_Helpers::posted('session_panel','key');if($open)$_GET['mph_open']=$open;else unset($_GET['mph_open']);
            $course_id=absint($_POST['session_course']??0);if($course_id)$_GET['mph_choose_course']=$course_id;else unset($_GET['mph_choose_course']);
            $html='<div class="mph-root" dir="rtl">'.self::dashboard().'</div>';
            if($old_mode===null)unset($_GET['mph_mode']);else$_GET['mph_mode']=$old_mode;
            if($old_open===null)unset($_GET['mph_open']);else$_GET['mph_open']=$old_open;
            if($old_course===null)unset($_GET['mph_choose_course']);else$_GET['mph_choose_course']=$old_course;
            wp_send_json_success(array('userId'=>get_current_user_id(),'loggedIn'=>true,'html'=>$html,'mode'=>$mode?:MPH_Helpers::current_mode(),'nonce'=>wp_create_nonce('mph_nonce'),'ticketData'=>MPH_Tickets::client_data($mode?:MPH_Helpers::current_mode()),'headerAccount'=>self::header_account_data()));
        }
        $html='<div class="mph-root mph-inline-mode" dir="rtl"><div class="mph-inline-auth">'.MPH_Auth::render().'</div></div>';
        wp_send_json_success(array('userId'=>0,'loggedIn'=>false,'html'=>$html,'nonce'=>wp_create_nonce('mph_nonce'),'ticketData'=>MPH_Tickets::client_data('user'),'headerAccount'=>self::header_account_data()));
    }

    public static function is_profile_shortcode_page() {
        if(!is_singular())return false;
        $post=get_queried_object();
        return $post instanceof WP_Post && has_shortcode((string)$post->post_content,'mph_profile');
    }

    private static function requires_portal_styles() {
        if(!empty($_GET['mph_clean_auth'])||!empty($_GET['mph_profile_popup'])||!empty($_GET['mph_auth']))return true;
        if(!is_singular())return false;
        $post=get_queried_object();if(!($post instanceof WP_Post))return false;
        $content=(string)$post->post_content;
        return has_shortcode($content,'mph_profile')||has_shortcode($content,'mph_appointment_booking');
    }

    private static function dashboard() {
        $user=wp_get_current_user();$mode=MPH_Helpers::current_mode();$items=self::items($mode);$defaults=array('user'=>'dashboard','instructor'=>'teacher_dashboard','therapist'=>'therapist_dashboard','manager'=>'manager_dashboard');$preferred=$defaults[$mode]??'';$first=$preferred&&self::item($preferred,$mode)?$preferred:($items?$items[0]['id']:$preferred);$requested=isset($_GET['mph_open'])?sanitize_key(wp_unslash($_GET['mph_open'])):'';if($requested&&self::item($requested,$mode))$first=$requested;$menu_alerts=class_exists('MPH_Menu_Alerts')?MPH_Menu_Alerts::flags_for_items($items,$mode,$user->ID):array();$ticket_alert=!empty($menu_alerts['ticket_support']);$announcement_alert=!empty($menu_alerts['announcements'])||!empty($menu_alerts['teacher_notices']);
        $cards_visible=in_array($first,array('dashboard','teacher_dashboard','therapist_dashboard','manager_dashboard'),true);
        ob_start(); ?><section class="mph-dashboard <?php echo $cards_visible?'mph-cards-visible':''; ?>" data-mode="<?php echo esc_attr($mode); ?>" data-initial-panel="<?php echo esc_attr($first); ?>">
        <aside class="mph-user-sidebar">
            <div class="mph-avatar-block">
            <div class="mph-avatar">
                <span class="mph-avatar-ring"><?php echo self::avatar_html($user); ?></span>
                <i class="mph-avatar-status" title="حساب فعال"></i>
            </div>
            <label class="mph-avatar-upload" title="تغییر تصویر پروفایل">
                <span class="dashicons dashicons-camera"></span>
                <span class="mph-avatar-upload-text">آپلود عکس پروفایل</span>
                <input type="file" accept="image/jpeg,image/png,image/webp" hidden>
            </label>
            </div>
            <strong class="mph-display-name"><?php echo esc_html(MPH_Helpers::display_name($user)); ?></strong><small class="mph-phone mph-user-identifier"><span>شناسه کاربری</span><b data-mph-user-id><?php echo esc_html(MPH_Helpers::profile_identifier($user)); ?></b></small><?php echo self::public_profile_controls($user,$mode); ?>
            <div class="mph-role-switch"><span>تغییر نقش کاربری</span><select data-mph-role-switch aria-label="تغییر نقش کاربری"><option value="<?php echo esc_url(add_query_arg('mph_mode','user')); ?>" <?php selected($mode,'user'); ?>>کاربر</option><?php if(MPH_Helpers::has_role('mph_instructor',$user)): ?><option value="<?php echo esc_url(add_query_arg('mph_mode','instructor')); ?>" <?php selected($mode,'instructor'); ?>>مدرس</option><?php endif; ?><?php if(MPH_Helpers::has_role('mph_therapist',$user)): ?><option value="<?php echo esc_url(add_query_arg('mph_mode','therapist')); ?>" <?php selected($mode,'therapist'); ?>>درمانگر</option><?php endif; ?><?php if(MPH_Helpers::has_role('mph_manager',$user)||current_user_can('manage_options')||MPH_Manager::is_portal_super_admin($user->ID)): ?><option value="<?php echo esc_url(add_query_arg('mph_mode','manager')); ?>" <?php selected($mode,'manager'); ?>>مدیر مجموعه</option><?php endif; ?></select><?php if(MPH_Roles::available($user)): ?><button type="button" class="mph-request-role" data-role-request><span class="dashicons dashicons-plus-alt2"></span><span>درخواست نقش</span><?php $pending=MPH_Roles::pending_count($user->ID);if($pending): ?><b><?php echo absint($pending); ?></b><?php endif; ?></button><?php endif; ?></div>
            <nav class="mph-side-menu"><?php foreach($items as $n=>$item):
                $__aid=sanitize_key($item['id']??'');
                $has_alert=class_exists('MPH_Menu_Alerts')?MPH_Menu_Alerts::flag_on($menu_alerts,$__aid):!empty($menu_alerts[$__aid]);
                $__acount=class_exists('MPH_Menu_Alerts')?MPH_Menu_Alerts::flag_count($menu_alerts,$__aid):($has_alert?1:0);
                if($__aid==='course_forum' && $__acount<=0)$has_alert=false;
            ?><button type="button" class="mph-menu-item <?php echo $item['id']===$first?'is-active':''; ?> <?php echo $has_alert?'mph-menu-alert':''; ?>" data-panel="<?php echo esc_attr($item['id']); ?>" data-has-alert="<?php echo $has_alert?'1':'0'; ?>" data-alert-count="<?php echo absint($__acount); ?>"><?php echo self::icon($item,'sidebar'); ?><span><?php echo esc_html($item['title']); ?></span><?php if($has_alert): ?><?php if($__aid==='course_forum' && $__acount>0): ?><b class="mph-alert-count" aria-label="<?php echo absint($__acount); ?> پیام تازه"><?php echo absint($__acount); ?></b><?php else: ?><i class="mph-alert-dot" aria-label="اعلان جدید"></i><?php endif; ?><?php endif; ?></button><?php endforeach; ?><button type="button" class="mph-menu-item mph-logout"><span class="dashicons dashicons-exit"></span><span>خروج</span></button></nav>
        </aside>
        <main class="mph-main"><header class="mph-welcome" data-mph-smart-welcome><div class="mph-welcome-copy"><small><?php echo esc_html(MPH_Helpers::role_label($mode)); ?></small><h2>سلام، <?php echo esc_html(MPH_Helpers::display_name($user)); ?></h2><p><?php echo esc_html(self::welcome($mode)); ?></p></div><?php echo self::welcome_image($user); ?></header><?php echo self::cards($items,$menu_alerts); ?><div class="mph-panel-content"><?php echo self::panel($first,$mode); ?></div></main>
        </section><?php return MPH_Helpers::secure_form_markup(ob_get_clean()).MPH_Growth::reminder_popup();
    }

    private static function welcome($mode){if($mode==='instructor')return 'دوره‌ها، اطلاعیه‌ها، آزمون‌ها و برداشت‌های خود را مدیریت کنید.';if($mode==='therapist')return 'برنامه کاری، زمان‌های آزاد و نوبت‌های مراجعان را مدیریت کنید.';if($mode==='manager')return 'اعضا، مدرسین، درمانگران و بخش‌های مدیریتی مجموعه را مدیریت کنید.';return 'دوره‌ها، نوبت‌های درمانی، آزمون‌ها و سفارش‌های خود را مشاهده کنید.';}

    private static function items($mode) {
        $settings=get_option(MPH_Helpers::SETTINGS,array());
        $removed=array('notification_settings','portal_design');
        $items=array_values(array_filter($settings['items']??array(),function($item)use($mode,$removed){return !in_array($item['id']??'',$removed,true)&&!empty($item['enabled'])&&in_array($mode,$item['roles']??array('user'),true);}));
        $dashboards=array('user'=>'dashboard','instructor'=>'teacher_dashboard','therapist'=>'therapist_dashboard','manager'=>'manager_dashboard');$top=$dashboards[$mode]??'dashboard';
        usort($items,function($a,$b)use($top){$ar=($a['id']??'')===$top?0:1;$br=($b['id']??'')===$top?0:1;return$ar<=>$br;});
        return $items;
    }

    private static function public_profile_controls($user,$mode='user') {
        if(!in_array($mode,array('instructor','therapist'),true))return'';
        if($mode==='instructor'&&!MPH_Helpers::has_role('mph_instructor',$user))return'';
        if($mode==='therapist'&&!MPH_Helpers::has_role('mph_therapist',$user))return'';
        $url=MPH_Growth::public_profile_url($user,$mode);if(!$url)return'';
        return '<div class="mph-public-profile-controls"><a class="mph-profile-link" href="'.esc_url($url).'" target="_blank" rel="noopener"><span class="dashicons dashicons-admin-links"></span><span>صفحه عمومی من</span></a><button type="button" class="mph-profile-copy" data-mph-copy="'.esc_attr($url).'" aria-label="کپی لینک صفحه عمومی"><span class="dashicons dashicons-admin-page"></span></button></div>';
    }

    private static function cards($items,$menu_alerts=array()) {
        $cards=array_values(array_filter($items,function($i){return !empty($i['show_card'])&&!in_array($i['id']??'',array('dashboard','teacher_dashboard','therapist_dashboard','manager_dashboard'),true);}));if(!$cards)return '';
        ob_start(); ?><div class="mph-action-grid"><?php foreach($cards as $item):
            $__aid=sanitize_key($item['id']??'');
            $has_alert=class_exists('MPH_Menu_Alerts')?MPH_Menu_Alerts::flag_on($menu_alerts,$__aid):!empty($menu_alerts[$__aid]);
            $__acount=class_exists('MPH_Menu_Alerts')?MPH_Menu_Alerts::flag_count($menu_alerts,$__aid):($has_alert?1:0);
            if($__aid==='course_forum' && $__acount<=0)$has_alert=false;
        ?><button type="button" class="mph-action <?php echo $has_alert?'mph-menu-alert':''; ?>" data-panel="<?php echo esc_attr($item['id']); ?>" data-alert-count="<?php echo absint($__acount); ?>"><?php echo self::icon($item,'card'); ?><b><?php echo esc_html($item['title']); ?></b><?php if($has_alert): ?><?php if($__aid==='course_forum' && $__acount>0): ?><b class="mph-alert-count"><?php echo absint($__acount); ?></b><?php else: ?><i class="mph-alert-dot" aria-label="اعلان جدید"></i><?php endif; ?><?php endif; ?></button><?php endforeach; ?></div><?php return ob_get_clean();
    }

    private static function icon($item,$place){$image_id=absint($item[$place.'_image_id']??0);if($image_id){$url=wp_get_attachment_image_url($image_id,'thumbnail');if($url)return '<img class="mph-menu-image" src="'.esc_url($url).'" alt="">';}$class=$item[$place.'_icon']??'dashicons-star-filled';return '<span class="dashicons '.esc_attr($class).'"></span>';}

    private static function avatar_html($user) {
        $id=absint(get_user_meta($user->ID,'mph_avatar_id',true));
        if(!$id)$id=absint(get_user_meta($user->ID,'_tutor_profile_photo',true));
        if($id){$image=wp_get_attachment_image($id,'thumbnail',false,array('alt'=>'تصویر پروفایل'));if($image)return $image;}
        return '<span class="mph-avatar-placeholder" role="img" aria-label="تصویر پیش‌فرض کاربر"><span class="dashicons dashicons-admin-users"></span></span>';
    }

    private static function welcome_image($user) {
        $id=absint(get_user_meta($user->ID,'mph_avatar_id',true));
        if(!$id)$id=absint(get_user_meta($user->ID,'_tutor_profile_photo',true));
        if($id){$url=wp_get_attachment_image_url($id,'medium_large');if($url)return '<figure class="mph-welcome-photo"><img src="'.esc_url($url).'" alt="تصویر پروفایل '.esc_attr(MPH_Helpers::display_name($user)).'" data-mph-welcome-image loading="eager" decoding="async"></figure>';}
        return '<figure class="mph-welcome-photo is-placeholder"><span class="dashicons dashicons-admin-users"></span></figure>';
    }

    private static function item($id,$mode) {foreach(self::items($mode) as $item)if($item['id']===$id)return $item;return false;}

    public static function panel($id,$mode='user') {
        $id=sanitize_key((string)$id);
        $mode=in_array($mode,array('user','instructor','therapist','manager'),true)?$mode:'user';
        $html=self::panel_content($id,$mode);
        if(trim((string)$html)!==''||in_array($id,array('dashboard','teacher_dashboard','therapist_dashboard','manager_dashboard'),true))return MPH_Helpers::secure_form_markup((string)$html);
        $item=self::item($id,$mode);
        return MPH_Helpers::secure_form_markup(self::default_panel($id,$mode,$item['title']??self::title($id),$item['card_icon']??'dashicons-clipboard'));
    }

    private static function panel_content($id,$mode='user') {
        $user=wp_get_current_user();
        $item=self::item($id,$mode);
        if($id==='role_request')return MPH_Roles::render_form();
        if(!$item)return self::default_panel($id,$mode,self::title($id),'dashicons-layout');
        if(in_array($id,array('dashboard','teacher_dashboard'),true))return '';
        if($id==='manager_dashboard')return MPH_Backup::portal_card().MPH_Portal_Health::render();
        if($id==='manage_therapists')return MPH_Appointments::render($id).MPH_Manager::render_public_profiles('therapist');
        if(in_array($id,array('book_appointment','my_appointments','therapist_dashboard','therapist_schedule','therapist_appointments','therapist_settings','manage_appointment_schedule','manage_appointments'),true))return MPH_Appointments::render($id);
        if($id==='profile')return self::profile_form($user);
        if($id==='enrolled_courses')return '<section class="mph-section"><h3>دوره‌های ثبت‌نام‌شده</h3>'.MPH_Commerce::pending_courses($user->ID).MPH_Tutor::enrolled_courses($user->ID).'</section>';
        if($id==='course_content')return MPH_Courses::render_library();
        if($id==='certificates')return '<section class="mph-section"><div class="mph-section-heading"><div><h3>گواهی‌های من</h3><p>گواهی دوره‌های تکمیل‌شده را دانلود کنید.</p></div><span class="dashicons dashicons-awards"></span></div>'.MPH_Certificates::render_user($user->ID).'</section>';
        if($id==='my_exams')return '<section class="mph-section"><h3>آزمون‌های من</h3>'.MPH_Tutor::quiz_attempts($user->ID).'</section>';
        if($id==='wishlist')return '<section class="mph-section"><h3>لیست علاقه‌مندی‌ها</h3>'.MPH_Tutor::wishlist($user->ID).'</section>';
        if($id==='cart')return MPH_Commerce::section();
        if($id==='orders'){$order_id=absint($_GET['order_id']??0);return '<section class="mph-section"><h3>تاریخچه سفارشات</h3>'.($order_id?MPH_Courses::invoice_card($order_id).MPH_Payment_Result::timeline(wc_get_order($order_id)):'').MPH_Tutor::orders($user->ID).'</section>';}
        if($id==='teacher_courses')return '<section class="mph-section"><h3>دوره‌های من</h3>'.MPH_Tutor::instructor_courses($user->ID).'</section>';
        if(in_array($id,array('announcements','teacher_notices'),true))return MPH_Notices::render($mode);
        if($id==='withdrawals')return '<section class="mph-section"><h3>برداشت‌ها</h3>'.MPH_Tutor::native_section('withdraw','درآمد و درخواست‌های برداشت در Tutor LMS نگهداری می‌شوند.').'</section>';
        if($id==='my_payouts')return MPH_Payouts::render_user($user->ID);
        if($id==='teacher_exams')return MPH_Quizzes::render();
        if($id==='teacher_settings')return self::profile_form($user);
        if($id==='issue_certificates')return MPH_Courses::render_progress_manager().MPH_Certificates::render_manager();
        if($id==='broadcast_messages')return MPH_Safir::render_manager();
        if($id==='reminders')return MPH_Growth::render_reminders();
        if($id==='business_reports')return MPH_Growth::render_reports();
        if($id==='course_forum')return class_exists('MPH_Forum')?MPH_Forum::render():'<div class="mph-empty">تالار گفت‌وگو در دسترس نیست.</div>';
        if($id==='ticket_support')return MPH_Tickets::render($mode);
        if(in_array($id,array('manage_members','manage_teachers','manage_courses','manage_requests','payment_receipts','staff_payouts','manager_settings','discount_codes'),true))return MPH_Manager::render($id);
        return self::default_panel($id,$mode,$item['title']??self::title($id),$item['card_icon']??'dashicons-clipboard');
    }

    private static function default_panel($id,$mode,$title,$icon) {
        $content=array(
            'user'=>array(
                array('dashicons-yes-alt','حساب شما فعال است','اطلاعات این بخش به حساب کاربری شما متصل و آماده نمایش داده‌های جدید است.'),
                array('dashicons-admin-users','مدیریت از نمایه من','اطلاعات شخصی و راه‌های ارتباطی را از بخش «نمایه من» تکمیل یا ویرایش کنید.'),
                array('dashicons-update','به‌روزرسانی خودکار','پس از ثبت فعالیت مرتبط، محتوا بدون نیاز به ساخت دوباره این صفحه نمایش داده می‌شود.'),
            ),
            'instructor'=>array(
                array('dashicons-welcome-learn-more','فضای مدرس فعال است','این بخش برای مدیریت فعالیت‌های آموزشی حساب مدرس آماده شده است.'),
                array('dashicons-admin-links','هماهنگ با دوره‌ها','اطلاعات دوره و هنرجو در صورت نصب Tutor LMS از همان منبع خوانده می‌شود.'),
                array('dashicons-sos','پشتیبانی ارجاعی','تیکت‌هایی که مدیر به شما ارجاع دهد فقط در بخش تیکت مدرس نمایش داده می‌شوند.'),
            ),
            'therapist'=>array(
                array('dashicons-heart','کارتابل درمانگر فعال است','زمان‌های پذیرش و نوبت‌های مراجعان از این فضای مستقل مدیریت می‌شوند.'),
                array('dashicons-calendar-alt','برنامه‌ریزی دقیق','برای هر روز و ساعت، نوع جلسه و قیمت جداگانه تعریف کنید.'),
                array('dashicons-shield-alt','حریم خصوصی مراجع','اطلاعات رزرو فقط برای درمانگر منتخب و مدیر مجاز قابل مشاهده است.'),
            ),
            'manager'=>array(
                array('dashicons-admin-site-alt3','هماهنگ با سایت','این پنل داده‌های موجود وردپرس، Tutor LMS و ووکامرس را در اولویت قرار می‌دهد.'),
                array('dashicons-shield','دسترسی مدیریت','ابزارهای این بخش فقط برای مدیر مجموعه یا مدیر اصلی سایت قابل استفاده‌اند.'),
                array('dashicons-chart-bar','آماده گزارش‌گیری','با ایجاد داده در سایت، خلاصه‌ها و عملیات مرتبط همین‌جا قابل نمایش خواهند بود.'),
            ),
        );
        $rows=$content[$mode]??$content['user'];
        $cards='';foreach($rows as $row)$cards.='<article><span class="dashicons '.esc_attr($row[0]).'"></span><h4>'.esc_html($row[1]).'</h4><p>'.esc_html($row[2]).'</p></article>';
        return '<section class="mph-section mph-default-content" data-default-panel="'.esc_attr($id).'"><div class="mph-default-hero"><div><h3>'.esc_html($title).'</h3><p>نمای کلی و اطلاعات آماده این بخش</p></div><span class="dashicons '.esc_attr($icon).'"></span></div><div class="mph-default-grid">'.$cards.'</div><div class="mph-default-note"><span class="dashicons dashicons-info-outline"></span><span>این بخش آماده نمایش اطلاعات جدید حساب شماست.</span></div></section>';
    }

    private static function profile_form($user){
        $birth=get_user_meta($user->ID,'mph_birth_date',true);if(!$birth&&get_user_meta($user->ID,'mph_birth_year',true))$birth=get_user_meta($user->ID,'mph_birth_year',true).'/01/01';
        $email=substr((string)$user->user_email,-8)==='.invalid'?'':$user->user_email;
        if(!MPH_Helpers::valid_person_name(trim($user->first_name.' '.$user->last_name))){$user->first_name='';$user->last_name='';}$user->display_name=MPH_Helpers::display_name($user);
        ob_start(); ?><section class="mph-section mph-profile-section"><div class="mph-profile-identity"><div class="mph-avatar mph-avatar-profile"><span class="mph-avatar-ring"><?php echo self::avatar_html($user); ?></span><label title="انتخاب تصویر جدید"><span class="dashicons dashicons-camera"></span><input type="file" accept="image/jpeg,image/png,image/webp" hidden></label><i class="mph-avatar-status"></i></div><div><small>حساب کاربری شما</small><h3><?php echo esc_html(trim($user->first_name.' '.$user->last_name)?:MPH_Helpers::display_name($user)); ?></h3><p>تصویر واضح و مربعی انتخاب کنید؛ JPG، PNG یا WebP تا ۲ مگابایت.</p><label class="mph-avatar-button">تغییر تصویر پروفایل<input type="file" accept="image/jpeg,image/png,image/webp" hidden></label></div></div><form class="mph-form mph-profile-form" data-mph-action="mph_profile"><div class="mph-field-grid"><label><?php echo MPH_Helpers::required('نام'); ?><input name="first_name" value="<?php echo esc_attr($user->first_name); ?>" required></label><label><?php echo MPH_Helpers::required('نام خانوادگی'); ?><input name="last_name" value="<?php echo esc_attr($user->last_name); ?>" required></label></div><label>شناسه کاربری نمایشی <small>(اختیاری)</small><input name="public_username" value="<?php echo esc_attr(get_user_meta($user->ID,'mph_public_username',true)); ?>" minlength="3" maxlength="30" autocomplete="username" placeholder="مثلاً alireza1405"><small>اگر خالی باشد، یک شناسه امن و غیرعددی از حساب شما نمایش داده می‌شود. این گزینه نام ورود وردپرس را تغییر نمی‌دهد.</small></label><label>ایمیل بازیابی <small>(اختیاری)</small><input type="email" name="email" value="<?php echo esc_attr($email); ?>" autocomplete="email"><small>برای دریافت لینک بازیابی رمز عبور استفاده می‌شود.</small></label><div class="mph-field-grid"><label><?php echo MPH_Helpers::required('تحصیلات'); ?><input name="education" value="<?php echo esc_attr(get_user_meta($user->ID,'mph_education',true)); ?>" required></label><label><?php echo MPH_Helpers::required('رشته تحصیلی'); ?><input name="major" value="<?php echo esc_attr(get_user_meta($user->ID,'mph_major',true)); ?>" required></label></div><div class="mph-field-grid"><label>تاریخ تولد <small>(اختیاری)</small><?php echo MPH_Helpers::birth_date_picker($birth); ?></label><label>کد پستی <small>(اختیاری)</small><input name="postal_code" value="<?php echo esc_attr(get_user_meta($user->ID,'mph_postal_code',true)); ?>"></label></div><label><?php echo MPH_Helpers::required('آدرس'); ?><textarea name="address" required><?php echo esc_textarea(get_user_meta($user->ID,'mph_address',true)); ?></textarea></label><?php echo MPH_Payouts::profile_fields($user); ?><button class="mph-primary" type="submit">ذخیره تغییرات</button><div class="mph-message"></div></form><?php if(MPH_Payouts::is_staff($user))echo MPH_Payouts::render_user($user->ID,true); ?></section><?php return ob_get_clean();
    }

    private static function title($id){$map=array('teacher_dashboard'=>'پیشخوان مدرس','enrolled_courses'=>'دوره‌های ثبت‌نام‌شده','course_content'=>'دوره‌های آفلاین','certificates'=>'گواهی‌های من','cart'=>'سبد خرید','course_forum'=>'تالار گفت‌وگو','ticket_support'=>'تیکت پشتیبانی','issue_certificates'=>'صدور گواهی‌نامه','discount_codes'=>'کدهای تخفیف','broadcast_messages'=>'پیام همگانی','my_exams'=>'آزمون‌های من','wishlist'=>'لیست علاقه‌مندی‌ها','orders'=>'تاریخچه سفارشات','teacher_courses'=>'دوره‌های من','announcements'=>'اطلاعیه','teacher_notices'=>'اطلاعیه','withdrawals'=>'برداشت‌ها','my_payouts'=>'واریزی‌های من','staff_payouts'=>'واریز مدرس و درمانگر','teacher_exams'=>'آزمون‌ها','teacher_settings'=>'تنظیمات','manage_members'=>'اعضا','manage_teachers'=>'مدرسین','manage_courses'=>'دوره‌ها','manage_requests'=>'درخواست‌ها','payment_receipts'=>'تأیید فیش‌ها','manager_settings'=>'تنظیمات','reminders'=>'یادآوری‌ها','business_reports'=>'گزارش فروش');return $map[$id]??'جزئیات';}
    private static function count_query($query){return $query instanceof WP_Query?absint($query->found_posts):0;}
    private static function empty_text($id){$map=array('enrolled_courses'=>'هنوز در دوره‌ای ثبت‌نام نکرده‌اید.','my_exams'=>'آزمونی برای شما ثبت نشده است.','wishlist'=>'لیست علاقه‌مندی‌های شما خالی است.','orders'=>'سفارشی ثبت نشده است.','teacher_courses'=>'هنوز دوره‌ای برای تدریس ثبت نشده است.','teacher_notices'=>'اطلاعیه‌ای ثبت نشده است.','withdrawals'=>'درخواست برداشتی ثبت نشده است.','teacher_exams'=>'آزمونی ساخته نشده است.');return $map[$id]??'اطلاعات این بخش پس از اتصال به سیستم مربوطه نمایش داده می‌شود.';}

    public static function ajax_panel(){MPH_Helpers::verify_ajax();if(!is_user_logged_in())wp_send_json_error(array('message'=>'ابتدا وارد شوید.'),401);$id=MPH_Helpers::posted('panel','key');$mode=MPH_Helpers::requested_mode();if(!$id)wp_send_json_error(array('message'=>'بخش درخواستی معتبر نیست.'),400);if($id!=='role_request'&&!self::item($id,$mode))wp_send_json_error(array('message'=>'این بخش برای نقش فعلی شما فعال نیست.'),403);if($id==='broadcast_messages'&&MPH_Safir::bot_admin_url())wp_send_json_success(array('redirect'=>MPH_Safir::bot_admin_url()));$html=self::panel($id,$mode);if(trim($html)===''&&!in_array($id,array('dashboard','teacher_dashboard','manager_dashboard'),true))wp_send_json_error(array('message'=>'خروجی این بخش در دسترس نیست.'),500);wp_send_json_success(array('html'=>$html,'mode'=>$mode));}
    public static function ajax_profile(){
        MPH_Helpers::verify_ajax();if(!is_user_logged_in())wp_send_json_error(array('message'=>'دسترسی ندارید.'),403);
        $first=MPH_Helpers::posted('first_name');$last=MPH_Helpers::posted('last_name');$education=MPH_Helpers::posted('education');$major=MPH_Helpers::posted('major');$address=MPH_Helpers::posted('address','textarea');$email=sanitize_email(MPH_Helpers::posted('email'));$birth=MPH_Helpers::jalali_birth_date(MPH_Helpers::posted('birth_date'));$public_username=trim(MPH_Helpers::posted('public_username'));
        if($birth===false)wp_send_json_error(array('message'=>'تاریخ تولد معتبر نیست.'));if(!$first||!$last||!$education||!$major||!$address)wp_send_json_error(array('message'=>'فیلدهای ستاره‌دار را کامل کنید.'));if(!MPH_Helpers::valid_person_name($first)||!MPH_Helpers::valid_person_name($last))wp_send_json_error(array('message'=>'نام و نام خانوادگی باید شامل حروف باشند و نمی‌توانند فقط عدد باشند.'));
        $id=get_current_user_id();if($email&&(!is_email($email)||(($owner=email_exists($email))&&absint($owner)!==$id)))wp_send_json_error(array('message'=>'ایمیل واردشده نامعتبر یا متعلق به حساب دیگری است.'));$card_saved=MPH_Payouts::save_profile_card($id);if(is_wp_error($card_saved))wp_send_json_error(array('message'=>$card_saved->get_error_message()));
        if($public_username!==''&&!MPH_Helpers::valid_public_username($public_username))wp_send_json_error(array('message'=>'شناسه کاربری باید ۳ تا ۳۰ کاراکتر، شامل حداقل یک حرف و فقط شامل حروف، عدد، نقطه، خط تیره یا زیرخط باشد.'));
        if($public_username!==''){$owners=get_users(array('meta_key'=>'mph_public_username','meta_value'=>$public_username,'exclude'=>array($id),'number'=>1,'fields'=>'ids','count_total'=>false));if($owners)wp_send_json_error(array('message'=>'این شناسه کاربری قبلاً انتخاب شده است.'));}
        $update=array('ID'=>$id,'first_name'=>$first,'last_name'=>$last,'display_name'=>trim($first.' '.$last));if($email)$update['user_email']=$email;$saved=wp_update_user($update);if(is_wp_error($saved))wp_send_json_error(array('message'=>$saved->get_error_message()));
        foreach(array('education'=>$education,'major'=>$major,'birth_date'=>$birth,'birth_year'=>$birth?substr($birth,0,4):'','postal_code'=>MPH_Helpers::posted('postal_code'),'address'=>$address) as $k=>$v)update_user_meta($id,'mph_'.$k,$v);if($public_username==='')delete_user_meta($id,'mph_public_username');else update_user_meta($id,'mph_public_username',$public_username);MPH_Tutor::sync_profile($id,get_user_meta($id,'mph_phone',true),$major,$address);wp_send_json_success(array('message'=>'تغییرات ذخیره شد.','identifier'=>MPH_Helpers::profile_identifier($id)));
    }
    public static function ajax_avatar(){
        MPH_Helpers::verify_ajax();
        if(!is_user_logged_in()||empty($_FILES['avatar'])||!is_array($_FILES['avatar']))wp_send_json_error(array('message'=>'تصویر معتبر نیست.'));
        $file=$_FILES['avatar'];
        if(!empty($file['error'])||empty($file['tmp_name'])||!is_uploaded_file($file['tmp_name']))wp_send_json_error(array('message'=>'آپلود تصویر کامل نشد.'));
        if(absint($file['size']??0)>2*MB_IN_BYTES)wp_send_json_error(array('message'=>'حجم تصویر پروفایل باید حداکثر ۲ مگابایت باشد.'));
        $allowed=array('jpg|jpeg|jpe'=>'image/jpeg','png'=>'image/png','webp'=>'image/webp');
        $check=wp_check_filetype_and_ext($file['tmp_name'],sanitize_file_name($file['name']??''),$allowed);
        if(empty($check['type'])||!in_array($check['type'],array_values($allowed),true))wp_send_json_error(array('message'=>'فقط تصویر JPG، PNG یا WebP مجاز است.'));
        $dimensions=@getimagesize($file['tmp_name']);
        if(!$dimensions||empty($dimensions[0])||empty($dimensions[1])||($dimensions[0]*$dimensions[1])>16000000)wp_send_json_error(array('message'=>'ابعاد تصویر معتبر نیست یا بیش از حد بزرگ است.'));
        require_once ABSPATH.'wp-admin/includes/file.php';require_once ABSPATH.'wp-admin/includes/media.php';require_once ABSPATH.'wp-admin/includes/image.php';
        $id=media_handle_upload('avatar',0,array(),array('test_form'=>false,'mimes'=>$allowed));
        if(is_wp_error($id))wp_send_json_error(array('message'=>$id->get_error_message()));
        if(strpos((string)get_post_mime_type($id),'image/')!==0){wp_delete_attachment($id,true);wp_send_json_error(array('message'=>'فقط فایل تصویری مجاز است.'));}
        $user_id=get_current_user_id();$old_id=absint(get_user_meta($user_id,'mph_avatar_id',true));
        update_user_meta($user_id,'mph_avatar_id',$id);MPH_Tutor::sync_avatar($user_id,$id);$url=wp_get_attachment_image_url($id,'thumbnail');$welcome_url=wp_get_attachment_image_url($id,'medium_large')?:$url;
        if($old_id&&$old_id!==$id&&absint(get_post_meta($old_id,'_mph_profile_avatar_owner',true))===$user_id)wp_delete_attachment($old_id,true);
        update_post_meta($id,'_mph_profile_avatar_owner',$user_id);
        wp_send_json_success(array('message'=>'تصویر پروفایل به‌روزرسانی شد.','url'=>$url,'welcomeUrl'=>$welcome_url,'image'=>'<img src="'.esc_url($url).'" alt="تصویر پروفایل">'));
    }
    public static function avatar_url($url,$id_or_email){$user=is_numeric($id_or_email)?get_user_by('id',absint($id_or_email)):($id_or_email instanceof WP_User?$id_or_email:false);if($user){$id=absint(get_user_meta($user->ID,'mph_avatar_id',true));if(!$id)$id=absint(get_user_meta($user->ID,'_tutor_profile_photo',true));if($id)return wp_get_attachment_image_url($id,'thumbnail')?:$url;}return $url;}
}
