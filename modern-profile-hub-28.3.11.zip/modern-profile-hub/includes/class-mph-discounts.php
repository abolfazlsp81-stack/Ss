<?php
defined('ABSPATH') || exit;

final class MPH_Discounts {
    const CASE_META = '_mph_coupon_original_case';
    public static function init() {
        add_action('admin_init', array(__CLASS__, 'save_admin'));
        add_action('wp_ajax_mph_cart_coupon', array(__CLASS__, 'ajax_apply'));
        add_action('wp_ajax_mph_cart_coupon_remove', array(__CLASS__, 'ajax_remove'));
        add_action('wp_ajax_mph_manager_coupon_save', array(__CLASS__, 'ajax_manager_save'));
        add_action('wp_ajax_mph_manager_coupon_delete', array(__CLASS__, 'ajax_manager_delete'));
    }

    public static function admin_page() {
        if (!current_user_can('manage_options')) return;
        $available = class_exists('WC_Coupon') && function_exists('wc_get_coupon_id_by_code');
        $edit_id = absint($_GET['edit_coupon'] ?? 0);
        $coupon = $available && $edit_id && get_post_type($edit_id) === 'shop_coupon' ? new WC_Coupon($edit_id) : false;
        $coupons = $available ? get_posts(array('post_type' => 'shop_coupon', 'post_status' => array('publish', 'draft'), 'numberposts' => 100, 'orderby' => 'date', 'order' => 'DESC')) : array();
        settings_errors('mph-discounts'); ?>
        <div class="wrap mph-admin" dir="rtl">
            <header class="mph-admin-head"><span class="dashicons dashicons-tickets-alt"></span><div><h1>کدهای تخفیف</h1><p>ساخت کد درصدی و استفاده مستقیم در سبد خرید اختصاصی</p></div></header>
            <?php if (!$available) : ?><div class="notice notice-warning inline"><p>برای ساخت کد تخفیف، افزونه WooCommerce باید فعال باشد.</p></div></div><?php return; endif; ?>
            <div class="mph-admin-split">
                <form method="post" class="mph-admin-box">
                    <?php wp_nonce_field('mph_discount_admin', 'mph_discount_nonce'); ?>
                    <input type="hidden" name="coupon_id" value="<?php echo $coupon ? absint($coupon->get_id()) : 0; ?>">
                    <div class="mph-builder-head"><div><h2><?php echo $coupon ? 'ویرایش کد تخفیف' : 'کد تخفیف جدید'; ?></h2><p>درصد بین ۱ تا ۱۰۰ وارد کنید.</p></div></div>
                    <div class="mph-admin-grid">
                        <label>کد تخفیف<input name="coupon_code" value="<?php echo esc_attr($coupon ? (get_post_meta($coupon->get_id(),self::CASE_META,true)?:$coupon->get_code()) : ''); ?>" required placeholder="مثلاً SUMMER25" dir="ltr"></label>
                        <label>درصد تخفیف<input type="number" name="coupon_percent" value="<?php echo esc_attr($coupon ? $coupon->get_amount() : ''); ?>" min="1" max="100" step="0.01" required></label>
                        <label>حداقل مبلغ خرید <small>(اختیاری)</small><input type="number" name="coupon_minimum" value="<?php echo esc_attr($coupon ? $coupon->get_minimum_amount() : ''); ?>" min="0" step="1000"></label>
                        <label>تعداد دفعات استفاده <small>(اختیاری)</small><input type="number" name="coupon_limit" value="<?php echo esc_attr($coupon ? $coupon->get_usage_limit() : ''); ?>" min="0"></label>
                        <label>تاریخ انقضا <small>(اختیاری)</small><input type="date" name="coupon_expiry" value="<?php echo esc_attr($coupon && $coupon->get_date_expires() ? $coupon->get_date_expires()->date('Y-m-d') : ''); ?>"></label>
                        <label class="mph-admin-checkbox"><input type="checkbox" name="coupon_individual" value="1" <?php checked($coupon ? $coupon->get_individual_use() : true); ?>> با کد دیگری هم‌زمان استفاده نشود</label>
                    </div>
                    <label>توضیحات<input name="coupon_description" value="<?php echo esc_attr($coupon ? $coupon->get_description() : ''); ?>" placeholder="توضیح داخلی برای مدیر"></label>
                    <button class="button button-primary" name="mph_save_coupon" value="1">ذخیره کد تخفیف</button>
                    <?php if ($coupon) : ?><a class="button" href="<?php echo esc_url(admin_url('admin.php?page=mph-discounts')); ?>">انصراف</a><?php endif; ?>
                </form>

                <section class="mph-admin-box">
                    <div class="mph-builder-head"><div><h2>کدهای ساخته‌شده</h2><p><?php echo count($coupons); ?> کد موجود</p></div></div>
                    <div class="mph-table-wrap"><table class="widefat striped"><thead><tr><th>کد</th><th>درصد</th><th>مصرف</th><th>انقضا</th><th>عملیات</th></tr></thead><tbody>
                    <?php if (!$coupons) : ?><tr><td colspan="5">هنوز کد تخفیفی ساخته نشده است.</td></tr><?php endif; ?>
                    <?php foreach ($coupons as $post) : $item = new WC_Coupon($post->ID); ?>
                        <tr><td><code><?php echo esc_html(get_post_meta($item->get_id(),self::CASE_META,true)?:$item->get_code()); ?></code></td><td><?php echo esc_html($item->get_amount()); ?>٪</td><td><?php echo absint($item->get_usage_count()); ?><?php echo $item->get_usage_limit() ? ' از ' . absint($item->get_usage_limit()) : ''; ?></td><td><?php echo esc_html($item->get_date_expires() ? date_i18n('Y/m/d', $item->get_date_expires()->getTimestamp()) : 'بدون انقضا'); ?></td><td><a class="button" href="<?php echo esc_url(add_query_arg(array('page' => 'mph-discounts', 'edit_coupon' => $post->ID), admin_url('admin.php'))); ?>">ویرایش</a> <form method="post" class="mph-inline-form" onsubmit="return confirm('این کد تخفیف حذف شود؟')"><?php wp_nonce_field('mph_discount_admin', 'mph_discount_nonce'); ?><button class="button-link-delete" name="mph_delete_coupon" value="<?php echo absint($post->ID); ?>">حذف</button></form></td></tr>
                    <?php endforeach; ?></tbody></table></div>
                </section>
            </div>
        </div><?php
    }

    public static function save_admin() {
        if (!current_user_can('manage_options') || empty($_POST['mph_discount_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['mph_discount_nonce'])), 'mph_discount_admin')) return;
        if (!class_exists('WC_Coupon')) return;
        if (isset($_POST['mph_delete_coupon'])) {
            $delete_id = absint($_POST['mph_delete_coupon']);
            if (get_post_type($delete_id) === 'shop_coupon') {
                $coupon = new WC_Coupon($delete_id);
                if ($coupon->get_id()) $coupon->delete(true);
            }
            add_settings_error('mph-discounts', 'deleted', 'کد تخفیف حذف شد.', 'success');
            return;
        }
        if (!isset($_POST['mph_save_coupon'])) return;
        $id = absint($_POST['coupon_id'] ?? 0);
        if ($id && get_post_type($id) !== 'shop_coupon') $id = 0;
        $code = function_exists('wc_format_coupon_code') ? wc_format_coupon_code(MPH_Helpers::posted('coupon_code')) : sanitize_key(MPH_Helpers::posted('coupon_code'));
        $percent = (float) ($_POST['coupon_percent'] ?? 0);
        if (!$code || $percent <= 0 || $percent > 100) {add_settings_error('mph-discounts', 'invalid', 'کد و درصد تخفیف معتبر نیست.', 'error');return;}
        $existing = wc_get_coupon_id_by_code($code);
        if ($existing && absint($existing) !== $id) {add_settings_error('mph-discounts', 'exists', 'این کد قبلاً ساخته شده است.', 'error');return;}
        try {
            $coupon = $id ? new WC_Coupon($id) : new WC_Coupon();
            $coupon->set_code($code);
            $coupon->set_discount_type('percent');
            $coupon->set_amount($percent);
            $coupon->set_minimum_amount(max(0, (float) ($_POST['coupon_minimum'] ?? 0)));
            $coupon->set_usage_limit(absint($_POST['coupon_limit'] ?? 0));
            $coupon->set_individual_use(!empty($_POST['coupon_individual']));
            $coupon->set_description(MPH_Helpers::posted('coupon_description'));
            $expiry = MPH_Helpers::posted('coupon_expiry');
            $coupon->set_date_expires($expiry && preg_match('/^\d{4}-\d{2}-\d{2}$/', $expiry) ? strtotime($expiry . ' 23:59:59') : null);
            $saved_id=$coupon->save();update_post_meta($saved_id,self::CASE_META,trim(MPH_Helpers::posted('coupon_code')));
            add_settings_error('mph-discounts', 'saved', 'کد تخفیف ذخیره شد.', 'success');
        } catch (Exception $error) {add_settings_error('mph-discounts', 'failed', $error->getMessage(), 'error');}
    }

    public static function cart_form() {
        if (!function_exists('WC') || !WC()->cart) return '';
        $applied = WC()->cart->get_applied_coupons();
        ob_start(); ?>
        <div class="mph-coupon-box">
            <h5><span class="dashicons dashicons-tickets-alt"></span> کد تخفیف دارید؟</h5>
            <form data-mph-action="mph_cart_coupon"><input name="coupon_code" required placeholder="کد تخفیف" dir="ltr"><button type="submit">اعمال</button><div class="mph-message"></div></form>
            <?php foreach ($applied as $code) : ?><form class="mph-applied-coupon" data-mph-action="mph_cart_coupon_remove"><input type="hidden" name="coupon_code" value="<?php echo esc_attr($code); ?>"><span><?php echo esc_html($code); ?></span><button type="submit" aria-label="حذف کد">×</button><div class="mph-message"></div></form><?php endforeach; ?>
        </div>
        <?php return ob_get_clean();
    }

    public static function ajax_apply() {
        MPH_Helpers::verify_ajax();
        if (!is_user_logged_in() || !function_exists('WC')) wp_send_json_error(array('message' => 'سبد خرید در دسترس نیست.'), 403);
        if (!WC()->cart && function_exists('wc_load_cart')) wc_load_cart();
        if (!WC()->cart) wp_send_json_error(array('message' => 'سبد خرید بارگذاری نشد.'));
        $raw=trim(MPH_Helpers::posted('coupon_code'));$coupon_id=$raw&&function_exists('wc_get_coupon_id_by_code')?absint(wc_get_coupon_id_by_code($raw)):0;if(!$coupon_id)wp_send_json_error(array('message'=>'کد تخفیف معتبر نیست.'));$coupon=new WC_Coupon($coupon_id);$expected=(string)get_post_meta($coupon_id,self::CASE_META,true);if($expected==='')$expected=$coupon->get_code();if(!hash_equals($expected,$raw))wp_send_json_error(array('message'=>'حروف بزرگ و کوچک کد تخفیف را دقیق وارد کنید.'));$code=$coupon->get_code();
        if (!$code || !WC()->cart->apply_coupon($code)) wp_send_json_error(array('message' => 'شرایط استفاده از این کد تخفیف برقرار نیست.'));
        MPH_Commerce::persist_cart();
        wp_send_json_success(array('message' => 'کد تخفیف اعمال شد.', 'html' => MPH_Commerce::section(), 'cartStage' => 'checkout'));
    }

    public static function ajax_remove() {
        MPH_Helpers::verify_ajax();
        if (!is_user_logged_in() || !function_exists('WC')) wp_send_json_error(array('message' => 'سبد خرید در دسترس نیست.'), 403);
        if (!WC()->cart && function_exists('wc_load_cart')) wc_load_cart();
        if (!WC()->cart) wp_send_json_error(array('message' => 'سبد خرید بارگذاری نشد.'));
        $code = function_exists('wc_format_coupon_code') ? wc_format_coupon_code(MPH_Helpers::posted('coupon_code')) : sanitize_key(MPH_Helpers::posted('coupon_code'));
        WC()->cart->remove_coupon($code);
        MPH_Commerce::persist_cart();
        wp_send_json_success(array('message' => 'کد تخفیف حذف شد.', 'html' => MPH_Commerce::section(), 'cartStage' => 'checkout'));
    }

    public static function render_manager() {
        if (!self::can_manage()) return '<div class="mph-empty">دسترسی ندارید.</div>';
        if (!class_exists('WC_Coupon')) return '<section class="mph-section"><div class="mph-empty"><p>برای مدیریت کدهای تخفیف، WooCommerce را فعال کنید.</p></div></section>';
        $posts=get_posts(array('post_type'=>'shop_coupon','post_status'=>array('publish','draft'),'numberposts'=>100,'orderby'=>'date','order'=>'DESC'));
        ob_start(); ?><section class="mph-section mph-manager-coupons"><div class="mph-section-heading"><div><h3>کدهای تخفیف</h3><p>کدها به بزرگی و کوچکی حروف حساس هستند.</p></div><span class="dashicons dashicons-tickets-alt"></span></div><form class="mph-form mph-coupon-create" data-mph-action="mph_manager_coupon_save"><div class="mph-field-grid"><label><?php echo MPH_Helpers::required('کد انگلیسی'); ?><input name="coupon_code" pattern="[A-Za-z0-9_-]+" dir="ltr" placeholder="SUMMER25" required></label><label><?php echo MPH_Helpers::required('درصد تخفیف'); ?><input type="number" name="coupon_percent" min="1" max="100" required></label></div><div class="mph-field-grid"><label>تاریخ انقضا <small>(اختیاری)</small><input type="date" name="coupon_expiry"></label><label>حداقل خرید <small>(اختیاری)</small><input type="number" name="coupon_minimum" min="0"></label></div><button class="mph-primary" type="submit">صدور کد تخفیف</button><div class="mph-message"></div></form><div class="mph-tutor-table"><table><thead><tr><th>کد</th><th>درصد</th><th>انقضا</th><th>مصرف</th><th>وضعیت</th><th>عملیات</th></tr></thead><tbody><?php if(!$posts): ?><tr><td colspan="6">کد تخفیفی ساخته نشده است.</td></tr><?php endif;foreach($posts as$post):$coupon=new WC_Coupon($post->ID);$expiry=$coupon->get_date_expires();$expired=$expiry&&$expiry->getTimestamp()<time();$shown=get_post_meta($coupon->get_id(),self::CASE_META,true)?:$coupon->get_code(); ?><tr><td><code dir="ltr"><?php echo esc_html($shown); ?></code></td><td><?php echo esc_html($coupon->get_amount()); ?>٪</td><td><?php echo esc_html($expiry?date_i18n('Y/m/d',$expiry->getTimestamp()):'بدون انقضا'); ?></td><td><?php echo absint($coupon->get_usage_count()); ?></td><td><span class="mph-status <?php echo $expired?'is-danger':''; ?>"><?php echo $expired?'منقضی':'فعال'; ?></span></td><td><form data-mph-action="mph_manager_coupon_delete" onsubmit="return confirm('کد حذف شود؟')"><input type="hidden" name="coupon_id" value="<?php echo absint($coupon->get_id()); ?>"><button class="mph-icon-danger" type="submit"><span class="dashicons dashicons-trash"></span></button><div class="mph-message"></div></form></td></tr><?php endforeach; ?></tbody></table></div></section><?php return ob_get_clean();
    }

    public static function ajax_manager_save(){
        MPH_Helpers::verify_ajax();if(!self::can_manage()||!class_exists('WC_Coupon'))wp_send_json_error(array('message'=>'دسترسی یا WooCommerce موجود نیست.'),403);$raw=trim(MPH_Helpers::posted('coupon_code'));if(!preg_match('/^[A-Za-z0-9_-]+$/',$raw))wp_send_json_error(array('message'=>'کد فقط باید شامل حروف انگلیسی، عدد، خط تیره یا زیرخط باشد.'));$code=function_exists('wc_format_coupon_code')?wc_format_coupon_code($raw):sanitize_key($raw);$percent=(float)($_POST['coupon_percent']??0);$expiry=MPH_Helpers::posted('coupon_expiry');if($percent<=0||$percent>100)wp_send_json_error(array('message'=>'درصد باید بین ۱ تا ۱۰۰ باشد.'));if(wc_get_coupon_id_by_code($code))wp_send_json_error(array('message'=>'این کد قبلاً ساخته شده است.'));
        try{$coupon=new WC_Coupon();$coupon->set_code($code);$coupon->set_discount_type('percent');$coupon->set_amount($percent);$coupon->set_minimum_amount(max(0,(float)($_POST['coupon_minimum']??0)));$coupon->set_individual_use(true);if($expiry&&preg_match('/^\d{4}-\d{2}-\d{2}$/',$expiry))$coupon->set_date_expires(strtotime($expiry.' 23:59:59'));$id=$coupon->save();update_post_meta($id,self::CASE_META,$raw);wp_send_json_success(array('message'=>'کد تخفیف با حساسیت کامل به حروف بزرگ و کوچک صادر شد.','html'=>self::render_manager()));}catch(Exception$e){wp_send_json_error(array('message'=>$e->getMessage()));}
    }

    public static function ajax_manager_delete(){MPH_Helpers::verify_ajax();if(!self::can_manage()||!class_exists('WC_Coupon'))wp_send_json_error(array('message'=>'دسترسی ندارید.'),403);$id=absint($_POST['coupon_id']??0);if(!$id||get_post_type($id)!=='shop_coupon')wp_send_json_error(array('message'=>'کد پیدا نشد.'));$coupon=new WC_Coupon($id);$coupon->delete(true);wp_send_json_success(array('message'=>'کد تخفیف حذف شد.','html'=>self::render_manager()));}

    private static function can_manage(){return is_user_logged_in()&&(MPH_Helpers::has_role('mph_manager')||current_user_can('mph_manage_portal')||current_user_can('manage_options'));}
}
