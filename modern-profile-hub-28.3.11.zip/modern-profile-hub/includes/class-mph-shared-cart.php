<?php
defined('ABSPATH') || exit;

/** User-owned cart. WooCommerce sessions are a projection, never the source of deletion. */
final class MPH_Shared_Cart {
    const META = '_mph_shared_cart_v28';
    private static $syncing = false;

    public static function init() {
        add_action('woocommerce_add_to_cart',array(__CLASS__,'added'),30,6);
        add_action('woocommerce_remove_cart_item',array(__CLASS__,'removed'),5,2);
        add_action('woocommerce_applied_coupon',array(__CLASS__,'coupon_added'));
        add_action('woocommerce_removed_coupon',array(__CLASS__,'coupon_removed'));
        add_action('woocommerce_payment_complete',array(__CLASS__,'consume_order'),30);
        add_action('woocommerce_order_status_processing',array(__CLASS__,'consume_order'),30);
        add_action('woocommerce_order_status_completed',array(__CLASS__,'consume_order'),30);
        add_action('woocommerce_before_calculate_totals',array(__CLASS__,'prices'),5);
        add_filter('woocommerce_get_item_data',array(__CLASS__,'item_data'),30,2);
        add_filter('woocommerce_cart_item_name',array(__CLASS__,'item_name'),30,2);
        add_action('woocommerce_checkout_create_order_line_item',array(__CLASS__,'copy_line'),20,4);
    }

    public static function read($user_id) {
        wp_cache_delete(absint($user_id),'user_meta');
        $saved=get_user_meta(absint($user_id),self::META,true);
        return is_array($saved) ? wp_parse_args($saved,array('revision'=>0,'items'=>array(),'coupons'=>array())) : array('revision'=>0,'items'=>array(),'coupons'=>array());
    }

    private static function mutate($user_id,$callback) {
        if (!$user_id || !get_user_by('id',absint($user_id))) return new WP_Error('mph_user','حساب معتبر نیست.');
        return MPH_Operation_Lock::run('cart:'.absint($user_id),function() use ($user_id,$callback) {
            $data=self::read($user_id);$next=call_user_func($callback,$data);
            if (is_wp_error($next)) return $next;
            if ($next!==$data) {
                $next['revision']=(int)$data['revision']+1;
                update_user_meta($user_id,self::META,$next);
                $stored=self::read($user_id);
                if ($stored!==$next) return new WP_Error('mph_cart_save','ذخیره سبد انجام نشد؛ دوباره تلاش کنید.');
            }
            return $next;
        });
    }

    public static function key($entry) {
        return hash('sha256',wp_json_encode(array($entry['kind']??'product',absint($entry['product_id']??0),absint($entry['variation_id']??0),(array)($entry['variation']??array()),absint($entry['course_id']??0),$entry['mode']??'',absint($entry['slot_id']??0),$entry['appointment_mode']??'')));
    }

    public static function add($user_id,$entry) {
        $entry=self::normalise($entry);
        if (is_wp_error($entry)) return $entry;
        return self::mutate($user_id,function($data) use ($entry) {
            $key=self::key($entry);
            if (!isset($data['items'][$key])) {$entry['instance']=bin2hex(random_bytes(16));$data['items'][$key]=$entry;}
            return $data;
        });
    }

    public static function remove($user_id,$key,$instance='') {
        return self::mutate($user_id,function($data) use ($key,$instance) {
            if (isset($data['items'][$key]) && (!$instance || hash_equals((string)$data['items'][$key]['instance'],(string)$instance))) unset($data['items'][$key]);
            return $data;
        });
    }

    private static function normalise($entry) {
        $kind=($entry['kind']??'')==='appointment'?'appointment':'product';
        if ($kind==='appointment') {
            $valid=MPH_Appointment_Cart::validate(absint($entry['slot_id']??0),sanitize_key($entry['appointment_mode']??''));
            if (is_wp_error($valid)) return $valid;
            return array('kind'=>'appointment','product_id'=>MPH_Appointments::service_product_id(),'slot_id'=>$valid['slot_id'],'therapist_id'=>$valid['therapist_id'],'appointment_mode'=>$valid['mode'],'price'=>$valid['price'],'label'=>$valid['label'],'note'=>MPH_Security::encrypt(mb_substr((string)($entry['note']??''),0,500)));
        }
        $product_id=absint($entry['product_id']??0);$variation_id=absint($entry['variation_id']??0);
        $product=wc_get_product($variation_id?:$product_id);
        if (!$product || !$product->is_purchasable() || !$product->is_in_stock()) return new WP_Error('mph_product','محصول در حال حاضر قابل خرید نیست.');
        if ($variation_id && (int)$product->get_parent_id()!==$product_id) return new WP_Error('mph_variation','مدل محصول معتبر نیست.');
        if ($product->get_id()===absint(get_option(MPH_Appointments::SERVICE_PRODUCT_OPTION))) return new WP_Error('mph_service','نوبت را از تقویم انتخاب کنید.');
        $course_id=absint($product->get_meta(MPH_Courses::COURSE_META));$mode=sanitize_key($product->get_meta(MPH_Courses::MODE_META));
        if ($course_id && get_post_status($course_id)!=='publish') return new WP_Error('mph_course','این دوره برای خرید جدید در دسترس نیست.');
        return array('kind'=>$course_id?'course':'product','product_id'=>$product_id,'variation_id'=>$variation_id,'variation'=>array_map('sanitize_text_field',(array)($entry['variation']??array())),'course_id'=>$course_id,'mode'=>$mode);
    }

    public static function added($key,$product_id,$quantity,$variation_id,$variation,$data) {
        if (self::$syncing || !is_user_logged_in()) return;
        $entry=array('product_id'=>$product_id,'variation_id'=>$variation_id,'variation'=>$variation);
        if (!empty($data['mph_appointment_slot'])) return;
        $saved=self::add(get_current_user_id(),$entry);
        if (!is_wp_error($saved)) {
            $entry=self::normalise($entry);$shared=self::key($entry);
            WC()->cart->cart_contents[$key]['mph_shared_key']=$shared;
            WC()->cart->cart_contents[$key]['mph_shared_instance']=$saved['items'][$shared]['instance'];
        }
    }

    public static function removed($key,$cart) {
        if (self::$syncing || !is_user_logged_in()) return;
        $row=$cart->get_cart_item($key);
        if (!empty($row['mph_shared_key'])) self::remove(get_current_user_id(),$row['mph_shared_key'],$row['mph_shared_instance']??'');
    }

    public static function coupon_added($code) {self::coupon($code,true);}
    public static function coupon_removed($code) {self::coupon($code,false);}
    private static function coupon($code,$add) {
        if (self::$syncing || !is_user_logged_in()) return;
        self::mutate(get_current_user_id(),function($data) use ($code,$add) {
            $codes=(array)$data['coupons'];
            $data['coupons']=$add?array_values(array_unique(array_merge($codes,array((string)$code)))):array_values(array_diff($codes,array((string)$code)));
            return $data;
        });
    }

    public static function sync() {
        if (self::$syncing || !is_user_logged_in() || !function_exists('WC') || !WC()->cart) return;
        self::$syncing=true;
        try {
            $user_id=get_current_user_id();$data=self::read($user_id);
            if (!$data['revision']) {
                $candidates=array();
                foreach (WC()->cart->get_cart() as $row) $candidates[]=array('product_id'=>$row['product_id'],'variation_id'=>$row['variation_id']??0,'variation'=>$row['variation']??array());
                $legacy=get_user_meta($user_id,MPH_Growth::SAVED_CART,true);
                foreach ((array)($legacy['items']??array()) as $row) $candidates[]=$row;
                foreach ($candidates as $entry) self::add($user_id,$entry);
                // Persist an empty cart too, so stale sessions cannot resurrect removed purchases.
                self::mutate($user_id,function($d){if (!$d['revision']) $d['initialised']=true;return $d;});
                $data=self::read($user_id);
            }
            $cart=WC()->cart;$cart->cart_contents=array();
            foreach ($data['items'] as $key=>$entry) {
                $product=wc_get_product(absint($entry['variation_id']??0)?:absint($entry['product_id']??0));
                if (!$product || !$product->exists()) continue;
                $meta=array('mph_shared_key'=>$key,'mph_shared_instance'=>$entry['instance']);
                if (!empty($entry['course_id'])) $meta+=array('mph_course_id'=>$entry['course_id'],'mph_delivery_selected'=>$entry['mode'],'mph_mode_key'=>$entry['course_id'].':'.$entry['mode']);
                if ($entry['kind']==='appointment') $meta+=array('mph_appointment_slot'=>$entry['slot_id'],'mph_appointment_mode'=>$entry['appointment_mode'],'mph_appointment_label'=>$entry['label'],'mph_appointment_price'=>$entry['price']);
                $wc_key=$cart->add_to_cart($entry['product_id'],1,$entry['variation_id']??0,$entry['variation']??array(),$meta);
                if ($wc_key && $entry['kind']==='appointment') {$cart->cart_contents[$wc_key]['data']=clone $cart->cart_contents[$wc_key]['data'];$cart->cart_contents[$wc_key]['data']->set_name($entry['label']);}
            }
            foreach ($cart->get_applied_coupons() as $code) if (!in_array($code,$data['coupons'],true)) $cart->remove_coupon($code);
            foreach ($data['coupons'] as $code) if (!$cart->has_discount($code)) $cart->apply_coupon($code);
            $cart->calculate_totals();
            if (method_exists($cart,'set_session')) $cart->set_session();
        } finally {self::$syncing=false;}
    }

    public static function snapshot() {
        $result=array();
        foreach (WC()->cart->get_cart() as $row) if (!empty($row['mph_shared_key'])) $result[$row['mph_shared_key']]=(string)$row['mph_shared_instance'];
        ksort($result);return $result;
    }

    public static function consume_order($order_id) {
        $order=wc_get_order($order_id);
        if (!$order || !$order->is_paid() || !$order->get_customer_id()) return;
        $snapshot=(array)$order->get_meta('_mph_cart_snapshot');
        if (!$snapshot) return;
        self::mutate($order->get_customer_id(),function($data) use ($snapshot) {
            foreach ($snapshot as $key=>$instance) if (isset($data['items'][$key]) && hash_equals((string)$data['items'][$key]['instance'],(string)$instance)) unset($data['items'][$key]);
            if (!$data['items']) $data['coupons']=array();
            return $data;
        });
        if (get_current_user_id()===$order->get_customer_id()) self::sync();
    }

    public static function prices($cart) {
        foreach ($cart->get_cart() as $row) if (!empty($row['mph_appointment_slot']) && !empty($row['data'])) $row['data']->set_price((float)$row['mph_appointment_price']);
    }
    public static function item_name($name,$row) {return !empty($row['mph_appointment_label'])?esc_html($row['mph_appointment_label']):$name;}
    public static function item_data($rows,$row) {
        if (!empty($row['mph_appointment_slot'])) $rows[]=array('key'=>'نوع خرید','value'=>'نوبت درمانی');
        elseif (!empty($row['mph_delivery_selected'])) $rows[]=array('key'=>'شیوه دوره','value'=>MPH_Courses::modes()[$row['mph_delivery_selected']]['label']??'');
        return $rows;
    }
    public static function copy_line($item,$key,$values,$order) {
        foreach (array('mph_shared_key','mph_shared_instance') as $field) if (!empty($values[$field])) $item->add_meta_data('_'.$field,$values[$field],true);
    }

    public static function unavailable() {
        $data=self::read(get_current_user_id());$present=self::snapshot();$html='';
        foreach ($data['items'] as $key=>$entry) if (!isset($present[$key])) {
            $label=$entry['label']??get_the_title($entry['course_id']??$entry['product_id']);
            $html.='<article class="mph-cart-item is-unavailable"><div><b>'.esc_html($label?:'انتخاب ذخیره‌شده').'</b><p>این انتخاب اکنون قابل خرید نیست؛ در سبد شما حفظ شده است.</p></div><form data-mph-action="mph_cart_remove"><input type="hidden" name="shared_key" value="'.esc_attr($key).'"><button class="mph-secondary" type="submit">حذف انتخاب</button><div class="mph-message"></div></form></article>';
        }
        return $html;
    }
}
