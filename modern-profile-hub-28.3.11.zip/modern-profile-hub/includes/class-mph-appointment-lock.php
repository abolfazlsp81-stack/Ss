<?php
defined('ABSPATH') || exit;

/** قفل اتمیک رزرو؛ از رزرو هم‌زمان یک بازه در چند پردازش PHP جلوگیری می‌کند. */
final class MPH_Appointment_Lock {
    public static function acquire($slot_id, $ttl = 180) {
        global $wpdb;
        $slot_id=absint($slot_id);if(!$slot_id)return false;
        $table=$wpdb->prefix.'mph_slot_locks';$now=current_time('mysql',true);$expires=gmdate('Y-m-d H:i:s',time()+max(30,absint($ttl)));
        $wpdb->query($wpdb->prepare("DELETE FROM {$table} WHERE slot_id=%d AND expires_at<%s",$slot_id,$now));
        $token=hash_hmac('sha256',$slot_id.'|'.microtime(true).'|'.wp_rand(),wp_salt('nonce'));
        $inserted=$wpdb->query($wpdb->prepare("INSERT IGNORE INTO {$table} (slot_id,owner_token,expires_at,created_at) VALUES (%d,%s,%s,%s)",$slot_id,$token,$expires,$now));
        return $inserted===1?$token:false;
    }

    public static function release($slot_id, $token) {
        global $wpdb;
        if(!$slot_id||!$token)return false;
        return (bool)$wpdb->delete($wpdb->prefix.'mph_slot_locks',array('slot_id'=>absint($slot_id),'owner_token'=>(string)$token),array('%d','%s'));
    }
}
