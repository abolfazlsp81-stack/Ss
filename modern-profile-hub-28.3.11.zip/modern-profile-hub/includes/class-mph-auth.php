<?php
defined('ABSPATH') || exit;

final class MPH_Auth {
    private static $standalone_kind = 'account';

    public static function init() {
        add_action('wp_ajax_nopriv_mph_auth_phone', array(__CLASS__, 'phone_step'));
        add_action('wp_ajax_nopriv_mph_login', array(__CLASS__, 'login'));
        add_action('wp_ajax_nopriv_mph_login_otp_start', array(__CLASS__, 'login_otp_start'));
        add_action('wp_ajax_nopriv_mph_login_otp_verify', array(__CLASS__, 'login_otp_verify'));
        add_action('wp_ajax_nopriv_mph_login_2fa', array(__CLASS__, 'login_2fa'));
        add_action('wp_ajax_nopriv_mph_register', array(__CLASS__, 'register'));
        add_action('wp_ajax_nopriv_mph_recovery_email', array(__CLASS__, 'recovery_email'));
        add_action('wp_ajax_nopriv_mph_recovery_otp', array(__CLASS__, 'recovery_otp'));
        add_action('wp_ajax_nopriv_mph_reset_otp', array(__CLASS__, 'reset_otp'));
        add_action('wp_ajax_nopriv_mph_reset_password', array(__CLASS__, 'reset_password'));
        add_action('wp_ajax_mph_logout', array(__CLASS__, 'logout'));
        add_action('template_redirect', array(__CLASS__, 'clean_page'), 0);
        add_action('send_headers', array(__CLASS__, 'security_headers'), 20);
        add_filter('show_admin_bar', array(__CLASS__, 'admin_bar_visibility'), 99);
    }

    public static function render() {
        // شماره تلفن و مرحله ورود هرگز از Query String خوانده نمی‌شود؛ جریان ورود فقط با POST/AJAX ادامه دارد.
        $phone = '';
        $stage = !empty($_GET['mph_help']) ? 'help_verify' : 'phone';
        if (!empty($_GET['mph_reset'])) return self::reset_form();
        ob_start(); ?>
        <section class="mph-auth-card mph-smart-auth" data-auth-stage="<?php echo esc_attr($stage); ?>">
            <header class="mph-auth-header">
                <?php echo self::logo_markup(); ?>
                <h2 class="mph-auth-title">ورود یا ساخت حساب</h2>
                <p>ابتدا شماره تلفن همراه خود را وارد کنید.</p>
            </header>
            <div class="mph-auth-flow" aria-hidden="true"><i class="is-active"></i><i></i><i></i></div>

            <form class="mph-form mph-auth-panel <?php echo $stage==='phone'?'is-active':''; ?>" data-mph-action="mph_auth_phone" data-auth-panel="phone">
                <label><?php echo MPH_Helpers::required('شماره تلفن'); ?><input type="tel" name="phone" value="<?php echo esc_attr($phone); ?>" inputmode="numeric" autocomplete="tel" maxlength="11" minlength="11" pattern="09[0-9]{9}" data-mph-phone placeholder="09xxxxxxxxx" required><small>شماره باید ۱۱ رقم و با 09 شروع شود.</small></label>
                <button class="mph-primary" type="submit">ادامه</button>
                <div class="mph-message" role="status"></div>
            </form>

            <form class="mph-form mph-auth-panel <?php echo $stage==='password'?'is-active':''; ?>" data-mph-action="mph_login" data-auth-panel="password">
                <div class="mph-auth-phone-chip"><span data-auth-phone-label></span><button type="button" data-auth-back="phone">تغییر شماره</button></div>
                <input type="hidden" name="phone" data-auth-phone-value>
                <label><?php echo MPH_Helpers::required('رمز عبور'); ?><input type="password" name="password" autocomplete="current-password" required autofocus></label>
                <button class="mph-primary" type="submit">ورود به داشبورد</button>
                <div class="mph-login-otp-choice"><span class="dashicons dashicons-smartphone"></span><div><b>ورود با کد یکبار مصرف</b><small>ارسال کد امن به همین شماره تلفن</small></div><button type="button" data-login-otp-start>انتخاب</button></div>
                <button class="mph-auth-link" type="button" data-auth-recovery>رمز عبور را فراموش کرده‌ام</button>
                <div class="mph-message" role="status"></div>
            </form>
            <form class="mph-form mph-auth-panel" data-mph-action="mph_login_otp_verify" data-auth-panel="login_sms_otp"><input type="hidden" name="phone" data-auth-phone-value><input type="hidden" name="flow_token" data-login-otp-flow><button type="button" class="mph-auth-back" data-auth-back="password">← ورود با رمز عبور</button><h3>ورود با کد یکبار مصرف</h3><p>کد شش‌رقمی ارسال‌شده را وارد کنید.</p><label class="mph-otp-label"><?php echo MPH_Helpers::required('کد یکبار مصرف'); ?><div class="mph-otp-boxes" data-mph-otp-boxes data-otp-target="otp"><input type="text" inputmode="numeric" maxlength="1" pattern="[0-9۰-۹٠-٩]" class="mph-otp-digit" data-mph-otp-digit autocomplete="one-time-code" aria-label="رقم 1"><input type="text" inputmode="numeric" maxlength="1" pattern="[0-9۰-۹٠-٩]" class="mph-otp-digit" data-mph-otp-digit autocomplete="one-time-code" aria-label="رقم 2"><input type="text" inputmode="numeric" maxlength="1" pattern="[0-9۰-۹٠-٩]" class="mph-otp-digit" data-mph-otp-digit autocomplete="one-time-code" aria-label="رقم 3"><input type="text" inputmode="numeric" maxlength="1" pattern="[0-9۰-۹٠-٩]" class="mph-otp-digit" data-mph-otp-digit autocomplete="one-time-code" aria-label="رقم 4"><input type="text" inputmode="numeric" maxlength="1" pattern="[0-9۰-۹٠-٩]" class="mph-otp-digit" data-mph-otp-digit autocomplete="one-time-code" aria-label="رقم 5"><input type="text" inputmode="numeric" maxlength="1" pattern="[0-9۰-۹٠-٩]" class="mph-otp-digit" data-mph-otp-digit autocomplete="one-time-code" aria-label="رقم 6"><input type="hidden" name="otp" value="" data-mph-otp-value required></div></label><button class="mph-primary" type="submit">تأیید کد و ورود</button><button type="button" class="mph-auth-link" data-login-otp-start>ارسال دوباره کد</button><div class="mph-message" role="status"></div></form>
            <form class="mph-form mph-auth-panel" data-mph-action="mph_login_2fa" data-auth-panel="login_2fa"><input type="hidden" name="flow_token" data-login-2fa-flow><h3>تأیید ورود امن</h3><p>برای نقش حساس، یک رمز شش‌رقمی به ایمیل حساب ارسال شده است.</p><label class="mph-otp-label"><?php echo MPH_Helpers::required('رمز یک‌بارمصرف ایمیل'); ?><div class="mph-otp-boxes" data-mph-otp-boxes data-otp-target="otp"><input type="text" inputmode="numeric" maxlength="1" pattern="[0-9۰-۹٠-٩]" class="mph-otp-digit" data-mph-otp-digit autocomplete="one-time-code" aria-label="رقم 1"><input type="text" inputmode="numeric" maxlength="1" pattern="[0-9۰-۹٠-٩]" class="mph-otp-digit" data-mph-otp-digit autocomplete="one-time-code" aria-label="رقم 2"><input type="text" inputmode="numeric" maxlength="1" pattern="[0-9۰-۹٠-٩]" class="mph-otp-digit" data-mph-otp-digit autocomplete="one-time-code" aria-label="رقم 3"><input type="text" inputmode="numeric" maxlength="1" pattern="[0-9۰-۹٠-٩]" class="mph-otp-digit" data-mph-otp-digit autocomplete="one-time-code" aria-label="رقم 4"><input type="text" inputmode="numeric" maxlength="1" pattern="[0-9۰-۹٠-٩]" class="mph-otp-digit" data-mph-otp-digit autocomplete="one-time-code" aria-label="رقم 5"><input type="text" inputmode="numeric" maxlength="1" pattern="[0-9۰-۹٠-٩]" class="mph-otp-digit" data-mph-otp-digit autocomplete="one-time-code" aria-label="رقم 6"><input type="hidden" name="otp" value="" data-mph-otp-value required></div></label><button class="mph-primary" type="submit">تأیید و ورود</button><button class="mph-auth-link" type="button" data-auth-back="password">ارسال دوباره / بازگشت</button><div class="mph-message" role="status"></div></form>

            <form class="mph-form mph-auth-panel mph-register-form <?php echo $stage==='register'?'is-active':''; ?>" data-mph-action="mph_register" data-auth-panel="register">
                <input type="hidden" name="phone" value="<?php echo esc_attr($phone); ?>" data-auth-phone-value>
                <div class="mph-auth-phone-chip"><span data-auth-phone-label><?php echo esc_html($phone); ?></span><button type="button" data-auth-back="phone">تغییر شماره</button></div>
                <div class="mph-register-progress"><i class="is-active"></i><i></i></div>
                <div class="mph-register-step is-active" data-register-step="1">
                    <div class="mph-register-heading"><b>آشنایی با شما</b><small>مرحله ۱ از ۲</small></div>
                    <div class="mph-field-grid"><label><?php echo MPH_Helpers::required('نام'); ?><input name="first_name" autocomplete="given-name" required></label><label><?php echo MPH_Helpers::required('نام خانوادگی'); ?><input name="last_name" autocomplete="family-name" required></label></div>
                    <label>ایمیل بازیابی <small>(اختیاری)</small><input type="email" name="email" autocomplete="email" placeholder="name@example.com"><small>برای بازیابی رمز با ایمیل استفاده می‌شود.</small></label>
                    <div class="mph-field-grid"><label><?php echo MPH_Helpers::required('تحصیلات'); ?><select name="education" required><option value="">انتخاب کنید</option><option>دیپلم</option><option>کاردانی</option><option>کارشناسی</option><option>کارشناسی ارشد</option><option>دکتری</option></select></label><label><?php echo MPH_Helpers::required('رشته تحصیلی'); ?><input name="major" placeholder="مثلاً مدیریت بازرگانی" required></label></div>
                    <button class="mph-primary" type="button" data-register-next>مرحله بعد</button>
                </div>
                <div class="mph-register-step" data-register-step="2">
                    <div class="mph-register-heading"><b>تکمیل حساب کاربری</b><small>مرحله ۲ از ۲</small></div>
                    <div class="mph-field-grid"><label>تاریخ تولد <small>(اختیاری)</small><?php echo MPH_Helpers::birth_date_picker(); ?></label><label>کد پستی <small>(اختیاری)</small><input name="postal_code" inputmode="numeric" maxlength="10"></label></div>
                    <label><?php echo MPH_Helpers::required('آدرس'); ?><textarea name="address" required></textarea></label>
                    <div class="mph-field-grid mph-password-grid"><label><?php echo MPH_Helpers::required('رمز عبور'); ?><input type="password" name="password" minlength="10" autocomplete="new-password" required><i class="mph-strength"></i></label>
                    <label><?php echo MPH_Helpers::required('تکرار رمز عبور'); ?><input type="password" name="password2" minlength="10" autocomplete="new-password" required></label></div>
                    <small class="mph-password-hint">حداقل ۱۰ کاراکتر شامل حرف بزرگ، کوچک، عدد و نماد</small>
                    <div class="mph-form-actions"><button class="mph-primary" type="submit">ساخت حساب کاربری</button><button class="mph-secondary" type="button" data-register-back>مرحله قبل</button></div>
                    <div class="mph-message" role="status"></div>
                </div>
            </form>

            <section class="mph-auth-panel mph-recovery-choice <?php echo $stage==='recovery'?'is-active':''; ?>" data-auth-panel="recovery">
                <div class="mph-auth-phone-chip"><span data-auth-phone-label></span><button type="button" data-auth-back="password">بازگشت</button></div>
                <h3>روش بازیابی رمز عبور</h3><p>یکی از روش‌های زیر را انتخاب کنید.</p>
                <button type="button" class="mph-recovery-option" data-recovery-option="email"><span class="dashicons dashicons-email-alt"></span><b>ارسال لینک به ایمیل</b><small>برای حساب‌هایی که ایمیل معتبر دارند</small></button>
                <button type="button" class="mph-recovery-option" data-recovery-option="otp"><span class="dashicons dashicons-format-chat"></span><b>رمز یک‌بارمصرف</b><small>ارسال از طریق سرویس تنظیم‌شده سایت</small></button>
                <button type="button" class="mph-recovery-option" data-recovery-option="management"><span class="dashicons dashicons-sos"></span><b>درخواست بررسی مدیریت</b><small>مدیر یا سوپرادمین رمز و مدت اعتبار را تعیین می‌کند و جزئیات به ایمیل شما می‌رسد</small></button>
            </section>

            <form class="mph-form mph-auth-panel <?php echo $stage==='recovery_email'?'is-active':''; ?>" data-mph-action="mph_recovery_email" data-auth-panel="recovery_email"><input type="hidden" name="phone" value="<?php echo esc_attr($phone); ?>" data-auth-phone-value><button type="button" class="mph-auth-back" data-auth-back="recovery">← انتخاب روش دیگر</button><h3>بازیابی با ایمیل</h3><p>لینک تنظیم رمز جدید به ایمیل ثبت‌شده حساب ارسال می‌شود.</p><button class="mph-primary" type="submit">ارسال لینک بازیابی</button><div class="mph-message" role="status"></div></form>
            <form class="mph-form mph-auth-panel <?php echo $stage==='recovery_otp'?'is-active':''; ?>" data-mph-action="mph_recovery_otp" data-auth-panel="recovery_otp"><input type="hidden" name="phone" value="<?php echo esc_attr($phone); ?>" data-auth-phone-value><button type="button" class="mph-auth-back" data-auth-back="recovery">← انتخاب روش دیگر</button><h3>بازیابی با کد یک‌بارمصرف</h3><p>یک رمز شش‌رقمی از طریق سرویس تنظیم‌شده سایت به شماره حساب شما ارسال می‌شود.</p><button class="mph-primary" type="submit">ارسال رمز یک‌بارمصرف</button><div class="mph-message" role="status"></div></form>
            <form class="mph-form mph-auth-panel" data-mph-action="mph_password_help_request" data-auth-panel="recovery_management"><input type="hidden" name="phone" value="<?php echo esc_attr($phone); ?>" data-auth-phone-value><button type="button" class="mph-auth-back" data-auth-back="recovery">← انتخاب روش دیگر</button><h3>درخواست بررسی مدیریت</h3><p>درخواست در کارتابل ثبت می‌شود و مدیر یا سوپرادمین، رمز شش‌رقمی و مدت اعتبار آن را تعیین می‌کند.</p><div class="mph-auth-security-note"><span class="dashicons dashicons-shield"></span><small>پس از تأیید، متن کامل، رمز و زمان اعتبار به ایمیل ثبت‌شده حساب ارسال می‌شود.</small></div><button class="mph-primary" type="submit">ثبت درخواست امن</button><div class="mph-message" role="status"></div></form>
            <form class="mph-form mph-auth-panel" data-mph-action="mph_reset_otp" data-auth-panel="otp_verify"><input type="hidden" name="phone" data-auth-phone-value><input type="hidden" name="flow_token" data-otp-flow><h3>تنظیم رمز جدید</h3><label class="mph-otp-label"><?php echo MPH_Helpers::required('رمز یک‌بارمصرف'); ?><div class="mph-otp-boxes" data-mph-otp-boxes data-otp-target="otp"><input type="text" inputmode="numeric" maxlength="1" pattern="[0-9۰-۹٠-٩]" class="mph-otp-digit" data-mph-otp-digit autocomplete="one-time-code" aria-label="رقم 1"><input type="text" inputmode="numeric" maxlength="1" pattern="[0-9۰-۹٠-٩]" class="mph-otp-digit" data-mph-otp-digit autocomplete="one-time-code" aria-label="رقم 2"><input type="text" inputmode="numeric" maxlength="1" pattern="[0-9۰-۹٠-٩]" class="mph-otp-digit" data-mph-otp-digit autocomplete="one-time-code" aria-label="رقم 3"><input type="text" inputmode="numeric" maxlength="1" pattern="[0-9۰-۹٠-٩]" class="mph-otp-digit" data-mph-otp-digit autocomplete="one-time-code" aria-label="رقم 4"><input type="text" inputmode="numeric" maxlength="1" pattern="[0-9۰-۹٠-٩]" class="mph-otp-digit" data-mph-otp-digit autocomplete="one-time-code" aria-label="رقم 5"><input type="text" inputmode="numeric" maxlength="1" pattern="[0-9۰-۹٠-٩]" class="mph-otp-digit" data-mph-otp-digit autocomplete="one-time-code" aria-label="رقم 6"><input type="hidden" name="otp" value="" data-mph-otp-value required></div></label><label><?php echo MPH_Helpers::required('رمز عبور جدید'); ?><input type="password" name="password" minlength="10" autocomplete="new-password" required></label><label><?php echo MPH_Helpers::required('تکرار رمز جدید'); ?><input type="password" name="password2" minlength="10" autocomplete="new-password" required></label><button class="mph-primary" type="submit">ثبت رمز جدید و ورود</button><div class="mph-message" role="status"></div></form>
            <section class="mph-auth-panel mph-auth-result" data-auth-panel="email_sent"><span class="dashicons dashicons-yes-alt"></span><h3>ایمیل ارسال شد</h3><p>پوشه ورودی و Spam را بررسی کنید و روی لینک بازیابی کلیک کنید.</p><button type="button" class="mph-secondary" data-auth-back="phone">بازگشت</button></section>
            <section class="mph-auth-panel mph-auth-result" data-auth-panel="help_sent"><span class="dashicons dashicons-yes-alt"></span><h3>درخواست ثبت شد</h3><p>پس از بررسی مدیریت، رمز یک‌بارمصرف و مدت اعتبار آن به ایمیل ثبت‌شده حساب ارسال می‌شود.</p><button type="button" class="mph-primary" data-auth-back="help_verify">رمز ایمیل‌شده را دارم</button><button type="button" class="mph-secondary" data-auth-back="phone">بازگشت</button></section>
            <form class="mph-form mph-auth-panel <?php echo $stage==='help_verify'?'is-active':''; ?>" data-mph-action="mph_password_help_consume" data-auth-panel="help_verify"><button type="button" class="mph-auth-back" data-auth-back="phone">← بازگشت</button><h3>تغییر رمز با تأیید مدیریت</h3><p>شماره حساب و رمز شش‌رقمی تعیین‌شده توسط مدیر یا سوپرادمین را وارد کنید.</p><label><?php echo MPH_Helpers::required('شماره تلفن'); ?><input type="tel" name="phone" inputmode="numeric" autocomplete="tel" maxlength="11" pattern="09[0-9]{9}" data-mph-phone required></label><label class="mph-otp-label"><?php echo MPH_Helpers::required('رمز یک‌بارمصرف مدیریت'); ?><div class="mph-otp-boxes" data-mph-otp-boxes data-otp-target="management_otp"><input type="text" inputmode="numeric" maxlength="1" pattern="[0-9۰-۹٠-٩]" class="mph-otp-digit" data-mph-otp-digit autocomplete="one-time-code" aria-label="رقم 1"><input type="text" inputmode="numeric" maxlength="1" pattern="[0-9۰-۹٠-٩]" class="mph-otp-digit" data-mph-otp-digit autocomplete="one-time-code" aria-label="رقم 2"><input type="text" inputmode="numeric" maxlength="1" pattern="[0-9۰-۹٠-٩]" class="mph-otp-digit" data-mph-otp-digit autocomplete="one-time-code" aria-label="رقم 3"><input type="text" inputmode="numeric" maxlength="1" pattern="[0-9۰-۹٠-٩]" class="mph-otp-digit" data-mph-otp-digit autocomplete="one-time-code" aria-label="رقم 4"><input type="text" inputmode="numeric" maxlength="1" pattern="[0-9۰-۹٠-٩]" class="mph-otp-digit" data-mph-otp-digit autocomplete="one-time-code" aria-label="رقم 5"><input type="text" inputmode="numeric" maxlength="1" pattern="[0-9۰-۹٠-٩]" class="mph-otp-digit" data-mph-otp-digit autocomplete="one-time-code" aria-label="رقم 6"><input type="hidden" name="management_otp" value="" data-mph-otp-value required></div></label><label><?php echo MPH_Helpers::required('رمز عبور جدید'); ?><input type="password" name="password" minlength="10" autocomplete="new-password" required><small>حداقل ۱۰ کاراکتر شامل حرف بزرگ، کوچک، عدد و نماد</small><i class="mph-strength"></i></label><label><?php echo MPH_Helpers::required('تکرار رمز جدید'); ?><input type="password" name="password2" minlength="10" autocomplete="new-password" required></label><button class="mph-primary" type="submit">تأیید رمز و ورود</button><div class="mph-message" role="status"></div></form>
        </section><?php
        return MPH_Helpers::secure_form_markup(ob_get_clean());
    }

    private static function reset_form() {
        $key = sanitize_text_field(wp_unslash($_GET['key'] ?? ''));
        $flow = sanitize_text_field(wp_unslash($_GET['flow'] ?? ''));
        $login = $flow ? MPH_Security::decrypt((string)get_transient('mph_email_reset_'.hash('sha256',$flow))) : sanitize_user(wp_unslash($_GET['login'] ?? ''), true);
        $check = ($key && $login) ? check_password_reset_key($key, $login) : new WP_Error('invalid_key','');
        ob_start(); ?><section class="mph-auth-card mph-smart-auth mph-email-reset"><header class="mph-auth-header"><?php echo self::logo_markup(); ?><h2>تنظیم رمز عبور جدید</h2><p>یک رمز قوی و غیرتکراری انتخاب کنید.</p></header><?php if(is_wp_error($check)): ?><div class="mph-auth-expired"><span class="dashicons dashicons-warning"></span><h3>لینک معتبر نیست</h3><p>لینک بازیابی منقضی یا قبلاً استفاده شده است.</p><a class="mph-primary" href="<?php echo esc_url(MPH_Helpers::clean_auth_url()); ?>">درخواست دوباره</a></div><?php else: ?><form class="mph-form mph-auth-panel is-active" data-mph-action="mph_reset_password"><input type="hidden" name="key" value="<?php echo esc_attr($key); ?>"><input type="hidden" name="login" value="<?php echo esc_attr($login); ?>"><input type="hidden" name="flow" value="<?php echo esc_attr($flow); ?>"><label><?php echo MPH_Helpers::required('رمز عبور جدید'); ?><input type="password" name="password" minlength="10" autocomplete="new-password" required><small>شامل حرف بزرگ، کوچک، عدد و نماد</small><i class="mph-strength"></i></label><label><?php echo MPH_Helpers::required('تکرار رمز جدید'); ?><input type="password" name="password2" minlength="10" autocomplete="new-password" required></label><button class="mph-primary" type="submit">ذخیره رمز جدید و ورود</button><div class="mph-message" role="status"></div></form><?php endif; ?></section><?php return MPH_Helpers::secure_form_markup(ob_get_clean());
    }

    private static function logo_markup() {
        $logo=defined('MPH_LOGO_URL')?MPH_LOGO_URL:'';
        if($logo)return '<span class="mph-auth-brand"><img class="mph-auth-logo" src="'.esc_url($logo).'" alt="'.esc_attr(get_bloginfo('name')).'"></span>';
        return '<span class="mph-auth-brand mph-auth-brand-fallback"><span class="dashicons dashicons-admin-site-alt3"></span></span>';
    }

    public static function clean_page() {
        self::strip_sensitive_query();
        $is_clean = !empty($_GET['mph_clean_auth']);
        $is_profile_page = MPH_Dashboard::is_profile_shortcode_page();
        $is_calendar_page = MPH_Calendar::is_shortcode_page();
        // Guest visiting bare account shortcode URL -> site home (login only via popup/clean auth flags).
        if ($is_profile_page && !is_user_logged_in() && !$is_clean && empty($_GET['mph_auth']) && empty($_GET['mph_profile_popup']) && empty($_GET['mph_reset']) && empty($_GET['mph_help'])) {
            wp_safe_redirect(home_url('/'));
            exit;
        }
        if (!$is_clean && !$is_profile_page && !$is_calendar_page) return;
        self::$standalone_kind = $is_calendar_page ? 'calendar' : 'account';
        add_filter('body_class', array(__CLASS__, 'standalone_body_classes'));
        if ($is_calendar_page) {
            MPH_Calendar::register_assets();
            $post = get_queried_object();
            $content = $post instanceof WP_Post ? do_shortcode((string) $post->post_content) : MPH_Calendar::shortcode();
        } else {
            MPH_Dashboard::enqueue_client_assets();
            $logged_in = is_user_logged_in() && empty($_GET['mph_reset']);
            $content = $logged_in ? MPH_Dashboard::standalone_content() : '<div class="mph-root mph-inline-mode" dir="rtl"><div class="mph-inline-auth">'.self::render().'</div></div>';
        }
        if (!$is_calendar_page) {
            nocache_headers();
            header('X-Robots-Tag: noindex, nofollow', true);
            header('X-Content-Type-Options: nosniff', true);
            header('Referrer-Policy: same-origin', true);
        }
        get_header();
        $logged_in = !$is_calendar_page && is_user_logged_in() && empty($_GET['mph_reset']);
        $shell_class = $is_calendar_page ? 'mph-plugin-page-shell mph-calendar-only-shell' : 'mph-clean-auth-shell'.($logged_in ? ' is-dashboard' : '');
        ?><main id="mph-standalone-content" class="<?php echo esc_attr($shell_class); ?>"><?php echo $content; ?></main><?php
        self::standalone_cleanup_script();
        if ($is_calendar_page) {
            wp_footer();
            ?></body></html><?php
        } else {
            wp_footer();
            ?></body></html><?php
        }
        exit;
    }

    private static function strip_sensitive_query() {
        if (is_admin() || strtoupper((string)($_SERVER['REQUEST_METHOD'] ?? 'GET')) !== 'GET') return;
        $sensitive = array('phone','mobile','address','office_address','billing_address_1','billing_address_2','billing_phone','billing_email','billing_postcode','billing_city','billing_state','first_name','last_name','email','password','password2','management_otp','one_time_code','postal_code','education','major','birth_date','patient_note','appointment_note','payout_card','payout_card_owner','payout_amount','card_number','card_owner','holiday_dates','therapy_phone');
        $found = array_values(array_intersect($sensitive, array_keys($_GET)));
        if (!$found) return;
        $url = remove_query_arg($found);
        wp_safe_redirect($url, 303, 'Modern Profile Hub');
        exit;
    }

    public static function security_headers() {
        if (is_admin() || headers_sent()) return;
        header('X-Content-Type-Options: nosniff', true);
        header('Referrer-Policy: same-origin', true);
        header('X-Frame-Options: SAMEORIGIN', true);
        header('Permissions-Policy: camera=(), microphone=(), geolocation=()', true);
        if (MPH_Dashboard::is_profile_shortcode_page() || !empty($_GET['mph_clean_auth'])) {
            nocache_headers();
            header('Cache-Control: private, no-store, no-cache, must-revalidate, max-age=0', true);
            header('X-Robots-Tag: noindex, nofollow', true);
        }
    }

    public static function standalone_body_classes($classes) {
        $classes[] = 'mph-standalone-page';
        $classes[] = self::$standalone_kind === 'calendar' ? 'mph-calendar-standalone-page' : 'mph-account-standalone-page';
        if (self::$standalone_kind === 'account') $classes[] = is_user_logged_in() && empty($_GET['mph_reset']) ? 'mph-standalone-dashboard' : 'mph-clean-auth-page';
        return array_values(array_unique($classes));
    }

    public static function admin_bar_visibility($show) {
        return is_user_logged_in() && is_super_admin(get_current_user_id());
    }

    private static function standalone_cleanup_script() {
        $selectors = array(
            '.widget-area','.sidebar','.search-modal','.search-overlay','.search-popup','.search-box','.fullscreen-search','.search-panel','.header-search-popup','.mobile-search','.floating-search','.sticky-search','.fixed-search','.search-widget','.elementor-widget-search','.elementor-search-form','.wp-block-search','[role="search"]','#search-modal','#search-popup','[class*="search-popup"]','[id*="search-popup"]','.scroll-to-top','.back-to-top','.go-top','.to-top','.backtop','.scrollup','.scroll-top','.scroll-top-button','.return-to-top','.back-to-top-wrapper','#back-to-top','#scroll-top','#scroll-to-top','#scrollUp','.progress-wrap','.qodef-back-to-top','.ct-back-to-top','#ast-scroll-top','.generate-back-to-top'
        );
        if (self::$standalone_kind === 'calendar') {
            // theme footer stays visible on plugin pages
            $selectors = array_merge($selectors, array('.upstudy-page-title-area','.upstudy-default-breadcrumb','.upstudy-page-title','.upstudy-breadcrumb','div.upstudy-page-title-area.upstudy-default-breadcrumb','.page-title-area','.breadcrumb-area'));
        } else {
            $selectors = array_merge($selectors, array('.page-banner','.page-title','.page-title-area','.page-header','.page-header-banner','.inner-banner','.breadcrumb-area','.breadcrumbs','.breadcrumbs-area','.site-breadcrumbs','.entry-header.page-header','.elementor-page-title','.upstudy-page-title-area','.upstudy-default-breadcrumb','.upstudy-page-title','.upstudy-breadcrumb','div.upstudy-page-title-area.upstudy-default-breadcrumb'));
        }
        ?><script id="mph-standalone-cleanup">(function(){'use strict';var selectors=<?php echo wp_json_encode(array_values(array_unique($selectors))); ?>,keepFooter=true;function header(){var primary=document.querySelector('#masthead,.site-header,.upstudy-header-area,.header-area,.main-header,.site-header-wrap,body>header');if(primary)return primary;return Array.prototype.find.call(document.querySelectorAll('header[role="banner"]'),function(node){return !!node.querySelector('nav,.custom-logo,.site-logo,[class*="menu"]');})||null;}function isStructural(node,siteHeader){if(!node||node.closest('#mph-standalone-content,.mph-root'))return true;if(keepFooter&&node.closest('#colophon,.site-footer,footer'))return true;if(siteHeader&&(node===siteHeader||siteHeader.contains(node)||node.contains(siteHeader)))return true;if(node.matches('header,nav,[role="banner"]')||node.querySelector('nav,.custom-logo,.site-logo,.menu-toggle,[class*="header-actions"],[class*="menu"]'))return true;return false;}function clean(){var siteHeader=header();document.querySelectorAll(selectors.join(',')).forEach(function(node){if(isStructural(node,siteHeader))return;node.setAttribute('data-mph-page-banner-hidden','1');node.hidden=true;node.style.setProperty('display','none','important');});if(siteHeader)document.documentElement.style.setProperty('--mph-site-header-height',Math.ceil(siteHeader.getBoundingClientRect().height)+'px');}clean();if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',clean);window.addEventListener('load',clean,{once:true});window.addEventListener('resize',clean,{passive:true});setTimeout(clean,300);setTimeout(clean,1000);})();</script><?php
    }

    public static function strip_theme_assets() {
        $styles = wp_styles();
        foreach ((array) $styles->queue as $handle) if ($handle !== 'dashicons' && strpos($handle, 'mph-') !== 0) wp_dequeue_style($handle);
        $scripts = wp_scripts();
        foreach ((array) $scripts->queue as $handle) if (strpos($handle, 'mph-') !== 0) wp_dequeue_script($handle);
    }

    public static function phone_step() {
        MPH_Helpers::verify_ajax();
        if (!self::allow_attempt('phone', 30, 5 * MINUTE_IN_SECONDS)) wp_send_json_error(array('message'=>'درخواست‌های زیادی ارسال شده است. چند دقیقه بعد تلاش کنید.'), 429);
        $phone = MPH_Helpers::phone(MPH_Helpers::posted('phone'));
        if (!$phone) wp_send_json_error(array('message'=>'شماره تلفن معتبر نیست.'));
        $user = MPH_Helpers::user_by_phone($phone);
        if ($user) wp_send_json_success(array('next'=>'password','phone'=>$phone,'message'=>'شماره شناسایی شد؛ رمز عبور را وارد کنید.'));
        // فرم ثبت‌نام از قبل داخل همان کارت احراز هویت وجود دارد. تغییر مرحله با JSON
        // مانع بازشدن admin-ajax.php در مرورگر و نمایش پاسخ خام «0» می‌شود.
        wp_send_json_success(array('next'=>'register','phone'=>$phone,'message'=>'این شماره هنوز ثبت نشده است؛ اطلاعات حساب را کامل کنید.'));
    }

    public static function register() {
        MPH_Helpers::verify_ajax();
        if (!self::allow_attempt('register', 6, 15 * MINUTE_IN_SECONDS)) wp_send_json_error(array('message'=>'تعداد تلاش ثبت‌نام بیش از حد مجاز است. کمی بعد دوباره تلاش کنید.'), 429);
        $phone = MPH_Helpers::phone(MPH_Helpers::posted('phone'));
        $password = MPH_Helpers::posted('password', 'raw');
        $repeat = MPH_Helpers::posted('password2', 'raw');
        $first = MPH_Helpers::posted('first_name');
        $last = MPH_Helpers::posted('last_name');
        $education = MPH_Helpers::posted('education');
        $major = MPH_Helpers::posted('major');
        $address = MPH_Helpers::posted('address', 'textarea');
        $email = sanitize_email(MPH_Helpers::posted('email'));
        $birth_date = MPH_Helpers::jalali_birth_date(MPH_Helpers::posted('birth_date'));
        if (!$phone) wp_send_json_error(array('message'=>'شماره تلفن معتبر نیست.'));
        if (MPH_Helpers::user_by_phone($phone)) wp_send_json_error(array('message'=>'این شماره قبلاً ثبت شده است. به صفحه ورود برگردید.'));
        if (!$first || !$last || !$education || !$major || !$address) wp_send_json_error(array('message'=>'تمام فیلدهای ستاره‌دار را کامل کنید.'));
        if (!MPH_Helpers::valid_person_name($first) || !MPH_Helpers::valid_person_name($last)) wp_send_json_error(array('message'=>'نام و نام خانوادگی باید شامل حروف باشند و نمی‌توانند فقط عدد باشند.'));
        if ($email && (!is_email($email) || email_exists($email))) wp_send_json_error(array('message'=>'ایمیل واردشده نامعتبر یا قبلاً استفاده شده است.'));
        if ($birth_date === false) wp_send_json_error(array('message'=>'تاریخ تولد انتخاب‌شده معتبر نیست.'));
        if ($password !== $repeat || !MPH_Helpers::strong_password($password)) wp_send_json_error(array('message'=>'رمز عبور باید حداقل ۱۰ کاراکتر و شامل حرف بزرگ، کوچک، عدد و نماد باشد.'));
        $account_email = $email ?: 'mph_' . $phone . '@users.invalid';
        $id = wp_create_user('mph_' . $phone, $password, $account_email);
        if (is_wp_error($id)) wp_send_json_error(array('message'=>$id->get_error_message()));
        wp_update_user(array('ID'=>$id,'first_name'=>$first,'last_name'=>$last,'display_name'=>trim($first.' '.$last)));
        $values = array('phone'=>$phone,'education'=>$education,'major'=>$major,'birth_date'=>$birth_date,'birth_year'=>$birth_date?substr($birth_date,0,4):'','postal_code'=>MPH_Helpers::posted('postal_code'),'address'=>$address);
        foreach ($values as $name=>$value) update_user_meta($id, 'mph_'.$name, $value);
        MPH_Tutor::sync_profile($id, $phone, $major, $address);
        wp_set_current_user($id); wp_set_auth_cookie($id, true, is_ssl());
        wp_send_json_success(array('sessionChanged'=>true,'message'=>'حساب شما ساخته شد و با موفقیت وارد شدید.'));
    }

    public static function login() {
        MPH_Helpers::verify_ajax();
        if (!self::allow_attempt('login', 12, 10 * MINUTE_IN_SECONDS)) wp_send_json_error(array('message'=>'تعداد تلاش ورود بیش از حد مجاز است. کمی بعد تلاش کنید.'), 429);
        $phone = MPH_Helpers::phone(MPH_Helpers::posted('phone'));
        $user = $phone ? MPH_Helpers::user_by_phone($phone) : false;
        if (!$user) wp_send_json_error(array('message'=>'شماره تلفن یا رمز عبور نادرست است.'));
        $signed = wp_authenticate($user->user_login,MPH_Helpers::posted('password','raw'));
        if (is_wp_error($signed)) wp_send_json_error(array('message'=>'شماره تلفن یا رمز عبور نادرست است.'));
        $requires_two_factor=self::requires_two_factor($signed);
        $has_two_factor_email=is_email($signed->user_email)&&substr((string)$signed->user_email,-8)!=='.invalid';
        if($requires_two_factor&&!$has_two_factor_email)wp_send_json_error(array('message'=>'برای ورود امن این نقش، ابتدا یک ایمیل معتبر برای حساب ثبت کنید.'),403);
        if($requires_two_factor){
            if(!MPH_Security::allow('login_2fa_start',5,15*MINUTE_IN_SECONDS,'u:'.$signed->ID.'|'.MPH_Security::request_fingerprint()))wp_send_json_error(array('message'=>'تعداد درخواست رمز ورود بیش از حد مجاز است. کمی بعد تلاش کنید.'),429);
            $flow=bin2hex(random_bytes(24));$code=(string)wp_rand(100000,999999);$key='mph_login_2fa_'.hash('sha256',$flow);
            set_transient($key,array('user_id'=>$signed->ID,'code_hash'=>wp_hash_password($code),'fingerprint'=>MPH_Security::request_fingerprint(),'attempts'=>0,'expires'=>time()+10*MINUTE_IN_SECONDS),10*MINUTE_IN_SECONDS);
            $subject='رمز تأیید ورود | '.wp_specialchars_decode(get_bloginfo('name'),ENT_QUOTES);$body="رمز یک‌بارمصرف ورود شما: {$code}\n\nاین رمز فقط یک‌بار و تا ۱۰ دقیقه معتبر است. اگر این ورود متعلق به شما نیست، رمز حساب را تغییر دهید.";
            if(!wp_mail($signed->user_email,$subject,$body,MPH_Password_Recovery::management_headers())){delete_transient($key);wp_send_json_error(array('message'=>'ارسال رمز ورود انجام نشد؛ تنظیمات ایمیل مدیریت را بررسی کنید.'));}
            MPH_Security::audit('login_2fa_started','email='.MPH_Security::mask_email($signed->user_email),$signed->ID);wp_send_json_success(array('next'=>'login_2fa','loginFlow'=>$flow,'message'=>'رمز ورود امن از ایمیل مدیریت ارسال شد.'));
        }
        wp_set_current_user($signed->ID);wp_set_auth_cookie($signed->ID,true,is_ssl());MPH_Security::audit('login_completed','2fa=0',$signed->ID);wp_send_json_success(array('sessionChanged'=>true,'message'=>'با موفقیت وارد حساب شدید.'));
    }

    public static function login_otp_start() {
        MPH_Helpers::verify_ajax();
        if(!self::allow_attempt('login_otp_start',5,15*MINUTE_IN_SECONDS))wp_send_json_error(array('message'=>'تعداد درخواست کد بیش از حد مجاز است. کمی بعد تلاش کنید.'),429);
        $phone=MPH_Helpers::phone(MPH_Helpers::posted('phone'));$user=$phone?MPH_Helpers::user_by_phone($phone):false;
        if(!$user)wp_send_json_error(array('message'=>'حسابی با این شماره پیدا نشد.'));
        if(!class_exists('MPH_SMS')||!MPH_SMS::ready_for_otp())wp_send_json_error(array('message'=>'این سرویس در حال حاضر وجود ندارد','serviceUnavailable'=>true));
        $flow=MPH_Safir::start_otp($user,'login');if(is_wp_error($flow))wp_send_json_error(array('message'=>$flow->get_error_message()));
        wp_send_json_success(array('next'=>'login_sms_otp','flowToken'=>$flow,'phone'=>$phone,'message'=>'کد یکبار مصرف ارسال شد.'));
    }

    public static function login_otp_verify() {
        MPH_Helpers::verify_ajax();
        $user=MPH_Safir::consume_otp(MPH_Helpers::posted('flow_token','raw'),MPH_Helpers::posted('phone'),MPH_Helpers::posted('otp'),'login');
        if(is_wp_error($user))wp_send_json_error(array('message'=>$user->get_error_message()));
        wp_set_current_user($user->ID);wp_set_auth_cookie($user->ID,true,is_ssl());MPH_Security::audit('login_completed','sms_otp=1',$user->ID);
        wp_send_json_success(array('sessionChanged'=>true,'message'=>'کد تأیید شد و وارد حساب شدید.'));
    }

    public static function login_2fa() {
        MPH_Helpers::verify_ajax();$flow=MPH_Helpers::posted('flow_token','raw');$code=preg_replace('/\D+/','',MPH_Helpers::normalize_digits(MPH_Helpers::posted('otp')));if(!$flow||strlen($code)!==6)wp_send_json_error(array('message'=>'رمز شش‌رقمی را کامل وارد کنید.'));
        $key='mph_login_2fa_'.hash('sha256',$flow);$state=get_transient($key);if(!is_array($state)||empty($state['user_id'])||absint($state['expires']??0)<time()||!hash_equals((string)($state['fingerprint']??''),MPH_Security::request_fingerprint())){delete_transient($key);wp_send_json_error(array('message'=>'درخواست ورود منقضی یا نامعتبر است. دوباره وارد شوید.'));}
        $state['attempts']=absint($state['attempts']??0)+1;if($state['attempts']>5||empty($state['code_hash'])||!wp_check_password($code,$state['code_hash'])){if($state['attempts']>5)delete_transient($key);else set_transient($key,$state,max(30,absint($state['expires'])-time()));MPH_Security::audit('login_2fa_failed','attempt='.$state['attempts'],absint($state['user_id']));wp_send_json_error(array('message'=>'رمز تأیید نادرست یا منقضی شده است.'));}
        $user=get_user_by('id',absint($state['user_id']));delete_transient($key);if(!$user)wp_send_json_error(array('message'=>'حساب کاربری در دسترس نیست.'));wp_set_current_user($user->ID);wp_set_auth_cookie($user->ID,true,is_ssl());MPH_Security::audit('login_2fa_completed','', $user->ID);wp_send_json_success(array('sessionChanged'=>true,'message'=>'ورود امن تأیید شد.'));
    }

    private static function requires_two_factor($user) {
        $roles=$user instanceof WP_User?(array)$user->roles:array();$required=(bool)array_intersect($roles,array('administrator','mph_manager','mph_therapist'));return(bool)apply_filters('mph_require_login_2fa',$required,$user);
    }

    public static function recovery_email() {
        MPH_Helpers::verify_ajax();
        if (!self::allow_attempt('recovery_email', 5, 15 * MINUTE_IN_SECONDS)) wp_send_json_error(array('message'=>'تعداد درخواست بازیابی بیش از حد مجاز است. کمی بعد دوباره تلاش کنید.'), 429);
        $phone=MPH_Helpers::phone(MPH_Helpers::posted('phone'));$user=$phone?MPH_Helpers::user_by_phone($phone):false;
        if(!$user)wp_send_json_error(array('message'=>'حساب کاربری پیدا نشد.'));
        if(!is_email($user->user_email)||substr($user->user_email,-8)==='.invalid')wp_send_json_error(array('message'=>'برای این حساب ایمیل بازیابی ثبت نشده است. از رمز یک‌بارمصرف بله استفاده کنید.'));
        if(get_transient('mph_mail_reset_'.$user->ID))wp_send_json_error(array('message'=>'ایمیل قبلاً ارسال شده است. یک دقیقه صبر کنید.'));
        $key=get_password_reset_key($user);if(is_wp_error($key))wp_send_json_error(array('message'=>'ساخت لینک بازیابی انجام نشد.'));
        $flow=bin2hex(random_bytes(24));set_transient('mph_email_reset_'.hash('sha256',$flow),MPH_Security::encrypt($user->user_login),DAY_IN_SECONDS);
        $url=MPH_Helpers::clean_auth_url(array('mph_reset'=>1,'key'=>$key,'flow'=>$flow));
        $subject='بازیابی رمز عبور | '.wp_specialchars_decode(get_bloginfo('name'),ENT_QUOTES);
        $body="برای تنظیم رمز عبور جدید روی لینک زیر کلیک کنید:\n\n".$url."\n\nاگر این درخواست را شما ثبت نکرده‌اید، این پیام را نادیده بگیرید.";
        if(!wp_mail($user->user_email,$subject,$body,MPH_Password_Recovery::management_headers())){delete_transient('mph_email_reset_'.hash('sha256',$flow));wp_send_json_error(array('message'=>'ارسال ایمیل انجام نشد. ایمیل مدیریت یا SMTP وردپرس را بررسی کنید.'));}
        MPH_Security::audit('password_reset_email_sent','email='.MPH_Security::mask_email($user->user_email),$user->ID);
        set_transient('mph_mail_reset_'.$user->ID,1,MINUTE_IN_SECONDS);wp_send_json_success(array('next'=>'email_sent','message'=>'لینک بازیابی از ایمیل مدیریت ارسال شد و شما را برای تغییر رمز به همین افزونه برمی‌گرداند.'));
    }

    public static function recovery_otp() {
        MPH_Helpers::verify_ajax();if(!self::allow_attempt('recovery_otp',5,15*MINUTE_IN_SECONDS))wp_send_json_error(array('message'=>'تعداد درخواست بازیابی بیش از حد مجاز است. کمی بعد دوباره تلاش کنید.'),429);$phone=MPH_Helpers::phone(MPH_Helpers::posted('phone'));$user=$phone?MPH_Helpers::user_by_phone($phone):false;if(!$user)wp_send_json_error(array('message'=>'حساب کاربری پیدا نشد.'));
        $flow=MPH_Safir::start_otp($user);if(is_wp_error($flow))wp_send_json_error(array('message'=>$flow->get_error_message()));wp_send_json_success(array('next'=>'otp_verify','flowToken'=>$flow,'phone'=>$phone,'message'=>'رمز شش‌رقمی ارسال شد.'));
    }

    public static function reset_otp() {
        MPH_Helpers::verify_ajax();$password=MPH_Helpers::posted('password','raw');$repeat=MPH_Helpers::posted('password2','raw');if($password!==$repeat||!MPH_Helpers::strong_password($password))wp_send_json_error(array('message'=>'رمز جدید باید حداقل ۱۰ کاراکتر و شامل حرف بزرگ، کوچک، عدد و نماد باشد.'));
        $user=MPH_Safir::consume_otp(MPH_Helpers::posted('flow_token','raw'),MPH_Helpers::posted('phone'),MPH_Helpers::posted('otp'));if(is_wp_error($user))wp_send_json_error(array('message'=>$user->get_error_message()));reset_password($user,$password);wp_set_current_user($user->ID);wp_set_auth_cookie($user->ID,true,is_ssl());wp_send_json_success(array('sessionChanged'=>true,'message'=>'رمز جدید ثبت شد و وارد حساب شدید.'));
    }

    public static function reset_password() {
        MPH_Helpers::verify_ajax();$key=MPH_Helpers::posted('key','raw');$login=sanitize_user(MPH_Helpers::posted('login','raw'),true);$flow=MPH_Helpers::posted('flow','raw');$password=MPH_Helpers::posted('password','raw');$repeat=MPH_Helpers::posted('password2','raw');
        if($password!==$repeat||!MPH_Helpers::strong_password($password))wp_send_json_error(array('message'=>'رمز جدید باید حداقل ۱۰ کاراکتر و شامل حرف بزرگ، کوچک، عدد و نماد باشد.'));
        $user=check_password_reset_key($key,$login);if(is_wp_error($user))wp_send_json_error(array('message'=>'لینک بازیابی منقضی یا نامعتبر است.'));
        reset_password($user,$password);if($flow)delete_transient('mph_email_reset_'.hash('sha256',$flow));MPH_Security::audit('password_reset_completed','email_link=1',$user->ID);wp_set_current_user($user->ID);wp_set_auth_cookie($user->ID,true,is_ssl());wp_send_json_success(array('sessionChanged'=>true,'message'=>'رمز جدید ثبت شد و وارد حساب شدید.'));
    }

    private static function allow_attempt($name,$max,$ttl) {
        return MPH_Security::allow($name,$max,$ttl,MPH_Security::request_fingerprint());
    }

    public static function logout() { MPH_Helpers::verify_ajax();wp_logout();wp_set_current_user(0);wp_send_json_success(array('sessionChanged'=>true,'redirect'=>home_url('/'),'message'=>'از حساب کاربری خارج شدید.')); }
}
