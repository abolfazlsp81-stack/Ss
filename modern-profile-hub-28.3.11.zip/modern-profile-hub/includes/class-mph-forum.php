<?php
defined('ABSPATH') || exit;

/**
 * Course-scoped forum (messenger-like) with text, voice, and reply.
 * Audience: enrolled students, course instructor, managers — not therapists-only mode.
 */
final class MPH_Forum {
    const CPT = 'mph_forum_msg';
    const MAX_VOICE_BYTES = 5242880;
    const MAX_FILE_BYTES = 10485760;
    const MAX_IMAGE_BYTES = 10485760;
    const MAX_TEXT = 4000;

    public static function init() {
        add_action('init', array(__CLASS__, 'register'));
        add_action('wp_ajax_mph_forum_thread', array(__CLASS__, 'ajax_thread'));
        add_action('wp_ajax_mph_forum_send', array(__CLASS__, 'ajax_send'));
        add_action('wp_ajax_mph_forum_voice', array(__CLASS__, 'ajax_voice'));
        add_filter('upload_mimes', array(__CLASS__, 'upload_mimes'));
    }

    public static function upload_mimes($mimes) {
        $mimes = self::audio_mimes($mimes);
        $mimes['jpg|jpeg|jpe'] = 'image/jpeg';
        $mimes['png'] = 'image/png';
        $mimes['gif'] = 'image/gif';
        $mimes['webp'] = 'image/webp';
        $mimes['pdf'] = 'application/pdf';
        $mimes['zip'] = 'application/zip';
        $mimes['rar'] = 'application/x-rar-compressed';
        return $mimes;
    }

    public static function audio_mimes($mimes) {
        $mimes['webm'] = 'audio/webm';
        $mimes['weba'] = 'audio/webm';
        $mimes['ogg'] = 'audio/ogg';
        $mimes['oga'] = 'audio/ogg';
        $mimes['mp3'] = 'audio/mpeg';
        $mimes['m4a'] = 'audio/mp4';
        $mimes['wav'] = 'audio/wav';
        return $mimes;
    }

    public static function register() {
        register_post_type(self::CPT, array(
            'labels' => array('name' => 'پیام تالار'),
            'public' => false,
            'show_ui' => false,
            'supports' => array('title', 'editor', 'author'),
            'capability_type' => 'post',
        ));
    }

    public static function enqueue_assets() {
        $base = defined('MPH_URL') ? MPH_URL : plugin_dir_url(dirname(__FILE__) . '/modern-profile-hub.php');
        $ver = defined('MPH_VERSION') ? MPH_VERSION : '28.3.1';
        // Cross-browser mic helper must load before forum UI.
        wp_register_script('mph-forum', $base . 'assets/js/forum.js', array(), $ver, true);
        wp_enqueue_script('mph-forum');
        wp_localize_script('mph-forum', 'MPH_FORUM', array(
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('mph_nonce'),
        ));
    }

    public static function can_access_course($course_id, $user_id = 0) {
        $course_id = absint($course_id);
        $user_id = absint($user_id ?: get_current_user_id());
        if (!$course_id || !$user_id) return false;
        if (current_user_can('manage_options') || current_user_can('mph_manage_courses')) return true;
        if (class_exists('MPH_Helpers') && MPH_Helpers::has_role('mph_manager')) return true;
        $course = get_post($course_id);
        if (!$course) return false;
        // Accept tutor course types loosely
        $type = (class_exists('MPH_Tutor') && MPH_Tutor::active() && !empty(tutor()->course_post_type)) ? tutor()->course_post_type : $course->post_type;
        if ($course->post_type !== $type && $course->post_type !== 'courses') {
            // still allow if meta marks it
        }
        if (absint($course->post_author) === $user_id) return true;
        if (class_exists('MPH_Tutor')) {
            $ids = MPH_Tutor::course_student_ids($course_id);
            if (in_array($user_id, array_map('absint', (array)$ids), true)) return true;
        }
        // Direct enrollment query fallback
        $enrolled = get_posts(array(
            'post_type' => 'tutor_enrolled',
            'post_status' => 'any',
            'author' => $user_id,
            'post_parent' => $course_id,
            'numberposts' => 1,
            'fields' => 'ids',
        ));
        return !empty($enrolled);
    }

    public static function is_course_ended($course_id) {
        $course_id = absint($course_id);
        if (!$course_id) return false;
        if (get_post_meta($course_id, '_mph_course_ended', true) === 'yes') return true;
        $end = get_post_meta($course_id, '_mph_course_end', true);
        if (is_array($end)) {
            $status = sanitize_key((string)($end['status'] ?? ''));
            if (in_array($status, array('completed', 'ended', 'finished'), true)) return true;
            foreach (array('date', 'end_date', 'ended_at') as $k) {
                $date = (string)($end[$k] ?? '');
                if ($date !== '') {
                    $ts = strtotime($date);
                    if ($ts && $ts < current_time('timestamp')) return true;
                }
            }
        }
        return (bool) apply_filters('mph_forum_course_ended', false, $course_id);
    }

    public static function courses_for_user($user_id = 0) {
        $user_id = absint($user_id ?: get_current_user_id());
        $out = array();
        if (!$user_id) return $out;
        $type = (class_exists('MPH_Tutor') && MPH_Tutor::active() && !empty(tutor()->course_post_type)) ? tutor()->course_post_type : 'courses';

        if (current_user_can('manage_options') || current_user_can('mph_manage_courses') || (class_exists('MPH_Helpers') && MPH_Helpers::has_role('mph_manager'))) {
            return get_posts(array('post_type' => $type, 'post_status' => array('publish', 'private'), 'numberposts' => 100, 'orderby' => 'title', 'order' => 'ASC'));
        }

        $taught = get_posts(array('post_type' => $type, 'author' => $user_id, 'post_status' => array('publish', 'private', 'draft'), 'numberposts' => 50));
        foreach ($taught as $p) $out[$p->ID] = $p;

        if (class_exists('MPH_Tutor') && MPH_Tutor::active() && function_exists('tutor_utils')) {
            try {
                $q = tutor_utils()->get_enrolled_courses_by_user($user_id, array('publish', 'private'));
                if ($q && !empty($q->posts)) foreach ($q->posts as $p) $out[$p->ID] = $p;
            } catch (Throwable $e) {}
        }
        global $wpdb;
        $ids = $wpdb->get_col($wpdb->prepare(
            "SELECT DISTINCT post_parent FROM {$wpdb->posts} WHERE post_type='tutor_enrolled' AND post_author=%d AND post_status NOT IN ('trash','auto-draft')",
            $user_id
        ));
        foreach ((array)$ids as $cid) {
            $p = get_post(absint($cid));
            if ($p) $out[$p->ID] = $p;
        }
        return array_values($out);
    }

    public static function render() {
        if (!is_user_logged_in()) return '<div class="mph-empty">ابتدا وارد شوید.</div>';
        $mode = class_exists('MPH_Helpers') ? MPH_Helpers::requested_mode() : 'user';
        if ($mode === 'therapist') return '<div class="mph-empty">تالار گفت‌وگو برای نقش درمانگر فعال نیست.</div>';
        self::enqueue_assets();
        $courses = self::courses_for_user();
        $first_id = 0;
        if ($courses) {
            foreach ($courses as $c) {
                if (!self::is_course_ended($c->ID)) { $first_id = absint($c->ID); break; }
            }
            if (!$first_id) $first_id = absint($courses[0]->ID);
        }
        $initial = $first_id ? self::thread_html($first_id) : '<div class="mph-empty"><p>دوره‌ای برای گفت‌وگو در دسترس شما نیست.</p></div>';
        ob_start(); ?>
        <section class="mph-section mph-forum" data-mph-forum>
            <div class="mph-section-heading">
                <div><small class="mph-eyebrow">پیام‌رسان دوره</small><h3>تالار گفت‌وگو</h3><p>گفت‌وگو بر اساس دوره؛ متن، فایل و پاسخ</p></div>
                <span class="dashicons dashicons-format-chat"></span>
            </div>
            <?php if (!$courses): ?>
                <div class="mph-empty"><p>دوره‌ای برای گفت‌وگو در دسترس شما نیست.</p></div>
            <?php else: ?>
            <div class="mph-forum-layout">
                <aside class="mph-forum-courses" data-forum-courses>
                    <?php foreach ($courses as $course):
                        $cid = absint($course->ID);
                        $ended = self::is_course_ended($cid);
                        $is_active = ($cid === $first_id);
                    ?>
                        <button type="button"
                            class="mph-forum-course<?php echo $is_active ? ' is-active' : ''; ?><?php echo $ended ? ' is-ended' : ''; ?>"
                            data-forum-course="<?php echo $cid; ?>"
                            <?php echo $ended ? 'disabled aria-disabled="true"' : ''; ?>>
                            <b><?php echo esc_html($course->post_title); ?></b>
                            <?php if ($ended): ?>
                                <span class="mph-forum-ended-label">به پایان رسید</span>
                            <?php else: ?>
                                <small><?php echo esc_html(class_exists('MPH_Courses') ? MPH_Courses::instructor_display_name($course) : ''); ?></small>
                            <?php endif; ?>
                        </button>
                    <?php endforeach; ?>
                </aside>
                <div class="mph-forum-main">
                    <div class="mph-forum-thread" data-forum-thread data-course-id="<?php echo $first_id; ?>">
                        <?php echo $initial; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
                    </div>
                    <form class="mph-forum-composer" data-mph-action="mph_forum_send" data-forum-composer enctype="multipart/form-data">
                        <input type="hidden" name="course_id" value="<?php echo $first_id; ?>" data-forum-course-field>
                        <input type="hidden" name="reply_to" value="0" data-forum-reply-to>
                        <div class="mph-forum-reply-bar" data-forum-reply-bar hidden>
                            <span data-forum-reply-preview></span>
                            <button type="button" data-forum-reply-clear aria-label="لغو پاسخ">×</button>
                        </div>
                        <div class="mph-forum-composer-row">
                            <div class="mph-forum-attach-wrap">
                            <label class="mph-secondary mph-forum-attach" title="پیوست فایل (JPEG، PNG، PDF، ZIP، RAR)">
                                <span class="dashicons dashicons-media-default" aria-hidden="true"></span>
                                <input type="file" name="image" accept=".jpg,.jpeg,.png,.pdf,.zip,.rar,image/jpeg,image/png,application/pdf,application/zip,application/x-rar-compressed" hidden data-forum-file data-forum-image-file>
                            </label>
                            <div class="mph-forum-upload-progress" data-forum-upload-progress hidden>
                                <div class="mph-forum-upload-bar"><i data-forum-upload-bar></i></div>
                                <span class="mph-forum-upload-status" data-forum-upload-status></span>
                            </div>
                            </div>
                            <textarea name="message" rows="1" maxlength="<?php echo (int) self::MAX_TEXT; ?>" placeholder="پیام بنویسید…"></textarea>
                            <div class="mph-forum-tools">
                                <button class="mph-primary" type="submit" title="ارسال"><span class="dashicons dashicons-arrow-up-alt2"></span><span class="mph-forum-send-label">ارسال</span></button>
                            </div>
                        </div>
                        <div class="mph-message" role="status"></div>
                    </form>
                </div>
            </div>
            <?php endif; ?>
        </section>
        <?php
        return class_exists('MPH_Helpers') ? MPH_Helpers::secure_form_markup(ob_get_clean()) : ob_get_clean();
    }

    public static function messages($course_id, $limit = 100) {
        $course_id = absint($course_id);
        return get_posts(array(
            'post_type' => self::CPT,
            'post_status' => 'publish',
            'numberposts' => max(1, min(200, absint($limit))),
            'meta_key' => '_mph_forum_course',
            'meta_value' => (string) $course_id,
            'orderby' => 'date',
            'order' => 'ASC',
            'no_found_rows' => true,
        ));
    }

    public static function thread_html($course_id) {
        $course_id = absint($course_id);
        if (!self::can_access_course($course_id)) {
            return '<div class="mph-empty">به این دوره دسترسی ندارید.</div>';
        }
        $msgs = self::messages($course_id);
        if (!$msgs) {
            return '<div class="mph-empty"><p>هنوز پیامی نیست. اولین نفر باشید.</p></div>';
        }
        ob_start();
        foreach ($msgs as $msg) {
            $uid = absint($msg->post_author);
            $user = get_user_by('id', $uid);
            $voice = absint(get_post_meta($msg->ID, '_mph_forum_voice', true));
            $image = absint(get_post_meta($msg->ID, '_mph_forum_image', true));
            $reply_to = absint(get_post_meta($msg->ID, '_mph_forum_reply_to', true));
            $mine = $uid === get_current_user_id();
            $reply_preview = '';
            if ($reply_to) {
                $parent = get_post($reply_to);
                if ($parent) $reply_preview = wp_trim_words(wp_strip_all_tags($parent->post_content), 16);
            }
            $voice_url = $voice ? wp_get_attachment_url($voice) : '';
            $image_url = '';
            $image_full = '';
            $file_url = '';
            $file_name = '';
            $file_ext = '';
            if ($image) {
                $mime = (string) get_post_mime_type($image);
                $file_url = (string) wp_get_attachment_url($image);
                $file_name = basename((string) (get_attached_file($image) ?: $file_url));
                $file_ext = strtolower((string) (get_post_meta($image, '_mph_forum_file_ext', true) ?: pathinfo($file_name, PATHINFO_EXTENSION)));
                if (strpos($mime, 'image/') === 0 || in_array($file_ext, array('jpg','jpeg','png'), true)) {
                    $image_url = wp_get_attachment_image_url($image, 'medium') ?: $file_url;
                    $image_full = wp_get_attachment_image_url($image, 'large') ?: $file_url;
                }
            }
            ?>
            <article class="mph-forum-msg <?php echo $mine ? 'is-mine' : ''; ?>" data-msg-id="<?php echo absint($msg->ID); ?>" id="mph-forum-msg-<?php echo absint($msg->ID); ?>">
                <header>
                    <?php echo get_avatar($uid, 32); ?>
                    <div>
                        <b><?php echo esc_html($user ? (class_exists('MPH_Helpers') ? MPH_Helpers::display_name($user) : $user->display_name) : 'کاربر'); ?></b>
                        <time datetime="<?php echo esc_attr(get_post_time('c', true, $msg)); ?>"><?php echo esc_html(get_post_time('Y/m/d H:i', false, $msg)); ?></time>
                    </div>
                </header>
                <?php if ($reply_preview !== ''): ?>
                    <a class="mph-forum-quote" href="#mph-forum-msg-<?php echo absint($reply_to); ?>">پاسخ به: <?php echo esc_html($reply_preview); ?></a>
                <?php endif; ?>
                <?php if (trim((string)$msg->post_content) !== ''): ?>
                    <div class="mph-forum-text"><?php echo nl2br(esc_html($msg->post_content)); ?></div>
                <?php endif; ?>
                <?php if (!empty($image_url)): ?><a class="mph-forum-image" href="<?php echo esc_url($image_full ?: $image_url); ?>" target="_blank" rel="noopener"><img src="<?php echo esc_url($image_url); ?>" alt="تصویر" loading="lazy"></a><?php elseif (!empty($file_url)): ?><a class="mph-forum-file" href="<?php echo esc_url($file_url); ?>" target="_blank" rel="noopener" download><span class="dashicons dashicons-media-default"></span><span><?php echo esc_html($file_name ?: ('فایل.'.$file_ext)); ?></span><small><?php echo esc_html(strtoupper($file_ext)); ?></small></a><?php endif; ?><?php if ($voice_url): ?>
                    <audio class="mph-forum-audio" controls preload="metadata" src="<?php echo esc_url($voice_url); ?>"></audio>
                <?php endif; ?>
                <footer><button type="button" class="mph-forum-reply-btn" data-forum-reply="<?php echo absint($msg->ID); ?>" data-reply-excerpt="<?php echo esc_attr(wp_trim_words(wp_strip_all_tags($msg->post_content), 12)); ?>">پاسخ</button></footer>
            </article>
            <?php
        }
        return ob_get_clean();
    }

    public static function ajax_thread() {
        if (class_exists('MPH_Helpers')) MPH_Helpers::verify_ajax();
        if (!is_user_logged_in()) wp_send_json_error(array('message' => 'وارد شوید.'), 401);
        $course_id = absint($_POST['course_id'] ?? 0);
        if (!$course_id) wp_send_json_error(array('message' => 'دوره مشخص نیست.'));
        if (!self::can_access_course($course_id)) wp_send_json_error(array('message' => 'دسترسی ندارید.'), 403);
        wp_send_json_success(array('html' => self::thread_html($course_id), 'course_id' => $course_id));
    }

    public static function ajax_send() {
        if (class_exists('MPH_Helpers')) MPH_Helpers::verify_ajax();
        if (!is_user_logged_in()) wp_send_json_error(array('message' => 'وارد شوید.'), 401);
        $course_id = absint($_POST['course_id'] ?? 0);
        if (!self::can_access_course($course_id)) wp_send_json_error(array('message' => 'دسترسی به این دوره ندارید.'), 403);
        if (self::is_course_ended($course_id)) wp_send_json_error(array('message' => 'این دوره به پایان رسیده است.'), 403);
        $text = sanitize_textarea_field(wp_unslash($_POST['message'] ?? ''));
        $reply_to = absint($_POST['reply_to'] ?? 0);
        $has_image = !empty($_FILES['image']['name']) && (empty($_FILES['image']['error']) || (int)$_FILES['image']['error'] === UPLOAD_ERR_OK);
        if ($text === '' && !$has_image) wp_send_json_error(array('message' => 'متن یا فایل پیوست لازم است.'));
        if (function_exists('mb_strlen') ? mb_strlen($text) > self::MAX_TEXT : strlen($text) > self::MAX_TEXT) {
            wp_send_json_error(array('message' => 'پیام خیلی طولانی است.'));
        }
        if ($reply_to) {
            $parent = get_post($reply_to);
            if (!$parent || $parent->post_type !== self::CPT || absint(get_post_meta($reply_to, '_mph_forum_course', true)) !== $course_id) {
                $reply_to = 0;
            }
        }
        $id = wp_insert_post(array(
            'post_type' => self::CPT,
            'post_status' => 'publish',
            'post_title' => 'forum-' . $course_id . '-' . time(),
            'post_content' => $text,
            'post_author' => get_current_user_id(),
        ), true);
        if (is_wp_error($id) || !$id) wp_send_json_error(array('message' => is_wp_error($id) ? $id->get_error_message() : 'ذخیره پیام ناموفق بود.'));
        update_post_meta($id, '_mph_forum_course', $course_id);
        if ($reply_to) update_post_meta($id, '_mph_forum_reply_to', $reply_to);
        if ($has_image) {
            $image = self::handle_image_upload($id);
            if (is_wp_error($image)) {
                wp_send_json_success(array(
                    'message' => 'پیام متنی ارسال شد؛ فایل: ' . $image->get_error_message(),
                    'html' => self::thread_html($course_id),
                    'course_id' => $course_id,
                ));
            } elseif ($image) {
                update_post_meta($id, '_mph_forum_image', absint($image));
            }
        }
        self::notify_participants($course_id, get_current_user_id());
        wp_send_json_success(array('message' => 'ارسال شد.', 'html' => self::thread_html($course_id), 'course_id' => $course_id));
    }

    public static function ajax_voice() {
        if (!isset($_POST['message'])) $_POST['message'] = '';
        self::ajax_send();
    }

    
    private static function handle_image_upload($post_id) {
        $file = null;
        if (!empty($_FILES['file']['name'])) $file = $_FILES['file'];
        elseif (!empty($_FILES['image']['name'])) $file = $_FILES['image'];
        if (!$file || empty($file['name'])) return 0;
        if (!empty($file['error'])) return new WP_Error('file_err', 'خطای آپلود فایل (' . absint($file['error']) . ').');
        if (!empty($file['size']) && absint($file['size']) > self::MAX_FILE_BYTES) {
            return new WP_Error('file_size', 'حجم فایل حداکثر ۱۰ مگابایت است.');
        }
        $name = (string) $file['name'];
        $ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));
        $allowed_ext = array('jpg', 'jpeg', 'png', 'pdf', 'zip', 'rar');
        if (!in_array($ext, $allowed_ext, true)) {
            return new WP_Error('file_type', 'فرمت مجاز: JPEG، PNG، PDF، ZIP، RAR.');
        }
        $mime_map = array(
            'jpg' => 'image/jpeg', 'jpeg' => 'image/jpeg', 'png' => 'image/png',
            'pdf' => 'application/pdf', 'zip' => 'application/zip', 'rar' => 'application/x-rar-compressed',
        );
        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/media.php';
        require_once ABSPATH . 'wp-admin/includes/image.php';
        $overrides = array(
            'test_form' => false,
            'mimes' => array(
                'jpg|jpeg|jpe' => 'image/jpeg',
                'png' => 'image/png',
                'pdf' => 'application/pdf',
                'zip' => 'application/zip',
                'rar' => 'application/x-rar-compressed',
            ),
        );
        add_filter('upload_mimes', array(__CLASS__, 'upload_mimes'), 99);
        $upload = wp_handle_upload($file, $overrides);
        remove_filter('upload_mimes', array(__CLASS__, 'upload_mimes'), 99);
        if (!empty($upload['error'])) {
            if (in_array($ext, array('rar', 'zip'), true)) {
                $uploads = wp_upload_dir();
                if (!empty($uploads['error'])) return new WP_Error('file_upload', $upload['error']);
                $dest_name = wp_unique_filename($uploads['path'], sanitize_file_name($name));
                $dest = trailingslashit($uploads['path']) . $dest_name;
                if (!@move_uploaded_file($file['tmp_name'], $dest)) {
                    return new WP_Error('file_upload', $upload['error']);
                }
                $upload = array(
                    'file' => $dest,
                    'url' => trailingslashit($uploads['url']) . $dest_name,
                    'type' => $mime_map[$ext],
                );
            } else {
                return new WP_Error('file_upload', $upload['error']);
            }
        }
        $attachment = array(
            'post_mime_type' => !empty($upload['type']) ? $upload['type'] : $mime_map[$ext],
            'post_title' => sanitize_file_name(pathinfo($upload['file'], PATHINFO_FILENAME)),
            'post_content' => '',
            'post_status' => 'inherit',
        );
        $attach_id = wp_insert_attachment($attachment, $upload['file'], absint($post_id));
        if (is_wp_error($attach_id) || !$attach_id) return new WP_Error('file_attach', 'ذخیره فایل ناموفق بود.');
        if (strpos((string) $attachment['post_mime_type'], 'image/') === 0) {
            $meta = wp_generate_attachment_metadata($attach_id, $upload['file']);
            if (!is_wp_error($meta) && $meta) wp_update_attachment_metadata($attach_id, $meta);
        }
        update_post_meta($attach_id, '_mph_forum_file_ext', $ext);
        return absint($attach_id);
    }

    private static function handle_voice_upload($post_id) {
        if (empty($_FILES['voice']) || empty($_FILES['voice']['name'])) return 0;
        $file = $_FILES['voice'];
        if (!empty($file['error'])) return new WP_Error('voice_err', 'خطای آپلود ویس (' . absint($file['error']) . ').');
        if (!empty($file['size']) && absint($file['size']) > self::MAX_VOICE_BYTES) {
            return new WP_Error('voice_size', 'حجم ویس حداکثر ۵ مگابایت است.');
        }
        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/media.php';
        require_once ABSPATH . 'wp-admin/includes/image.php';

        // Prefer sideload-like handle with broad audio mimes
        add_filter('upload_mimes', array(__CLASS__, 'audio_mimes'), 99);
        add_filter('wp_check_filetype_and_ext', array(__CLASS__, 'force_audio_type'), 10, 5);
        $id = media_handle_upload('voice', $post_id, array(), array(
            'test_form' => false,
            'mimes' => array(
                'mp3|m4a|wav|ogg|oga|webm|weba' => 'audio/mpeg',
                'webm' => 'audio/webm',
                'weba' => 'audio/webm',
                'ogg|oga' => 'audio/ogg',
                'wav' => 'audio/wav',
                'm4a' => 'audio/mp4',
                'mp3' => 'audio/mpeg',
            ),
        ));
        remove_filter('upload_mimes', array(__CLASS__, 'audio_mimes'), 99);
        remove_filter('wp_check_filetype_and_ext', array(__CLASS__, 'force_audio_type'), 10);
        if (is_wp_error($id)) return $id;
        $mime = (string) get_post_mime_type($id);
        if ($mime && strpos($mime, 'audio/') !== 0 && strpos($mime, 'video/webm') !== 0) {
            // still allow webm often reported as video/webm from MediaRecorder
            if (strpos($mime, 'webm') === false) {
                wp_delete_attachment($id, true);
                return new WP_Error('voice_type', 'فقط فایل صوتی مجاز است (' . $mime . ').');
            }
        }
        return $id;
    }

    public static function force_audio_type($data, $file, $filename, $mimes, $real = null) {
        $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
        $map = array(
            'webm' => 'audio/webm',
            'weba' => 'audio/webm',
            'ogg' => 'audio/ogg',
            'oga' => 'audio/ogg',
            'mp3' => 'audio/mpeg',
            'm4a' => 'audio/mp4',
            'wav' => 'audio/wav',
        );
        if (isset($map[$ext])) {
            $data['ext'] = $ext;
            $data['type'] = $map[$ext];
            $data['proper_filename'] = $filename;
        }
        return $data;
    }

    private static function notify_participants($course_id, $except_user) {
        $course_id = absint($course_id);
        $except_user = absint($except_user);
        $users = class_exists('MPH_Tutor') ? MPH_Tutor::course_student_ids($course_id) : array();
        $course = get_post($course_id);
        if ($course) $users[] = absint($course->post_author);
        $users = array_values(array_unique(array_filter(array_map('absint', (array)$users))));
        foreach ($users as $uid) {
            if ($uid === $except_user) continue;
            if (class_exists('MPH_Menu_Alerts')) MPH_Menu_Alerts::bump('course_forum', $uid, 'forum:' . $course_id . ':' . time());
            do_action('mph_forum_message', $uid, $course_id);
        }
        if (class_exists('MPH_Menu_Alerts')) MPH_Menu_Alerts::bump('course_forum', 0, 'forum:' . $course_id . ':' . time());
    }

    public static function unread_count_for_user($user_id = 0) {
        $user_id = absint($user_id ?: get_current_user_id());
        if (!$user_id || !class_exists('MPH_Menu_Alerts')) return 0;
        $seen = MPH_Menu_Alerts::seen_map($user_id);
        $seen_ts = absint($seen['course_forum'] ?? 0);
        $courses = self::courses_for_user($user_id);
        if (!$courses) return 0;
        $ids = array_map('absint', wp_list_pluck($courses, 'ID'));
        if (!$ids) return 0;
        $args = array(
            'post_type' => self::CPT,
            'post_status' => 'publish',
            'numberposts' => 100,
            'orderby' => 'date',
            'order' => 'DESC',
            'author__not_in' => array($user_id),
            'meta_query' => array(array('key' => '_mph_forum_course', 'value' => $ids, 'compare' => 'IN')),
        );
        if ($seen_ts > 0) {
            $args['date_query'] = array(array('after' => gmdate('Y-m-d H:i:s', $seen_ts), 'inclusive' => false, 'column' => 'post_date_gmt'));
        }
        $msgs = get_posts($args);
        return is_array($msgs) ? count($msgs) : 0;
    }

    public static function latest_event_for_user($user_id) {
        $user_id = absint($user_id);
        $courses = self::courses_for_user($user_id);
        if (!$courses) return array('ts' => 0, 'fp' => '');
        $ids = array_map('absint', wp_list_pluck($courses, 'ID'));
        if (!$ids) return array('ts' => 0, 'fp' => '');
        $msgs = get_posts(array(
            'post_type' => self::CPT,
            'post_status' => 'publish',
            'numberposts' => 1,
            'orderby' => 'date',
            'order' => 'DESC',
            'meta_query' => array(array(
                'key' => '_mph_forum_course',
                'value' => $ids,
                'compare' => 'IN',
            )),
        ));
        if (!$msgs) return array('ts' => 0, 'fp' => '');
        $ts = strtotime($msgs[0]->post_date_gmt . ' UTC') ?: strtotime($msgs[0]->post_date);
        return array('ts' => absint($ts), 'fp' => 'forummsg:' . $msgs[0]->ID);
    }
}
