<?php
defined('ABSPATH') || exit;

/**
 * Per-menu badge alerts. Opening a panel marks it seen until a newer event arrives.
 * Every menu item can receive a badge; modules push events via bump()/filters.
 */
final class MPH_Menu_Alerts {
    const META = 'mph_menu_seen_v30';
    const EVENTS = 'mph_menu_events_v30';
    const FINGERPRINTS = 'mph_menu_seen_fp_v30';

    public static function init() {
        add_action('wp_ajax_mph_menu_seen', array(__CLASS__, 'ajax_seen'));
        // Ticket / notice bridges
        add_action('mph_ticket_activity', array(__CLASS__, 'on_ticket'), 10, 2);
        add_action('mph_notice_published', array(__CLASS__, 'on_notice'), 10, 2);
        add_action('woocommerce_add_to_cart', array(__CLASS__, 'on_cart_change'), 20);
        add_action('woocommerce_cart_item_removed', array(__CLASS__, 'on_cart_change'), 20);
        add_action('woocommerce_order_status_changed', array(__CLASS__, 'on_order'), 20, 4);
        add_action('mph_receipt_submitted', array(__CLASS__, 'on_receipt'), 10, 1);
        add_action('mph_role_request_created', array(__CLASS__, 'on_role_request'), 10, 1);
        add_action('mph_appointment_booked', array(__CLASS__, 'on_appointment'), 10, 2);
        add_action('mph_forum_message', array(__CLASS__, 'on_forum'), 10, 2);
        add_action('mph_course_end_saved', array(__CLASS__, 'on_course_end'), 10, 2);
    }

    /** Push a menu event timestamp (and optional fingerprint) for a user or role audience. */
    public static function bump($panel, $user_id = 0, $fingerprint = '') {
        $panel = sanitize_key($panel);
        if (!$panel) return;
        $user_id = absint($user_id);
        $now = time();
        if ($user_id) {
            $map = get_user_meta($user_id, self::EVENTS, true);
            if (!is_array($map)) $map = array();
            $map[$panel] = array('ts' => $now, 'fp' => sanitize_text_field((string)$fingerprint));
            update_user_meta($user_id, self::EVENTS, $map);
            return;
        }
        // Global option bucket for manager-wide panels
        $map = get_option(self::EVENTS, array());
        if (!is_array($map)) $map = array();
        $map[$panel] = array('ts' => $now, 'fp' => sanitize_text_field((string)$fingerprint));
        update_option(self::EVENTS, $map, false);
    }

    public static function seen_map($user_id = 0) {
        $user_id = absint($user_id ?: get_current_user_id());
        $map = get_user_meta($user_id, self::META, true);
        return is_array($map) ? $map : array();
    }

    public static function mark_seen($panel, $user_id = 0, $at = 0, $fingerprint = '') {
        $user_id = absint($user_id ?: get_current_user_id());
        $panel = sanitize_key($panel);
        if (!$user_id || !$panel) return;
        $map = self::seen_map($user_id);
        $map[$panel] = max(absint($at ?: time()), absint($map[$panel] ?? 0));
        update_user_meta($user_id, self::META, $map);
        if ($fingerprint !== '') {
            $fp = get_user_meta($user_id, self::FINGERPRINTS, true);
            if (!is_array($fp)) $fp = array();
            $fp[$panel] = sanitize_text_field($fingerprint);
            update_user_meta($user_id, self::FINGERPRINTS, $fp);
        }
    }

    public static function is_unseen($panel, $event_ts, $user_id = 0, $fingerprint = '') {
        $event_ts = absint($event_ts);
        if ($event_ts <= 0) return false;
        $user_id = absint($user_id ?: get_current_user_id());
        $map = self::seen_map($user_id);
        $seen = absint($map[sanitize_key($panel)] ?? 0);
        if ($fingerprint !== '') {
            $fp = get_user_meta($user_id, self::FINGERPRINTS, true);
            if (!is_array($fp)) $fp = array();
            $seen_fp = (string)($fp[sanitize_key($panel)] ?? '');
            if ($seen_fp !== '' && hash_equals($seen_fp, (string)$fingerprint) && $event_ts <= $seen) return false;
            if ($seen_fp !== '' && !hash_equals($seen_fp, (string)$fingerprint)) return true;
        }
        return $event_ts > $seen;
    }

    private static function event_bucket($panel, $user_id) {
        $user_map = get_user_meta($user_id, self::EVENTS, true);
        if (is_array($user_map) && !empty($user_map[$panel]['ts'])) return $user_map[$panel];
        $global = get_option(self::EVENTS, array());
        if (is_array($global) && !empty($global[$panel]['ts'])) return $global[$panel];
        return array('ts' => 0, 'fp' => '');
    }

    public static function latest_event_for_panel($panel, $mode, $user_id) {
        $panel = sanitize_key($panel);
        $mode = MPH_Helpers::allowed_mode($mode);
        $user_id = absint($user_id);
        $ts = 0;
        $fp = '';
        $count = 0;
        $exists = 0;

        $bucket = self::event_bucket($panel, $user_id);
        $ts = max($ts, absint($bucket['ts'] ?? 0));
        $fp = (string)($bucket['fp'] ?? '');

        if ($panel === 'ticket_support' && class_exists('MPH_Tickets') && method_exists('MPH_Tickets', 'has_alert') && MPH_Tickets::has_alert($mode, $user_id)) {
            $payload = method_exists('MPH_Tickets', 'notification_payload') ? MPH_Tickets::notification_payload($mode, $user_id) : array();
            $ts = max($ts, absint($payload['time'] ?? time()));
            $fp = 'ticket:' . absint($payload['count'] ?? 1) . ':' . $ts;
        }
        if (in_array($panel, array('announcements', 'teacher_notices'), true) && class_exists('MPH_Notices') && method_exists('MPH_Notices', 'has_unread') && MPH_Notices::has_unread($mode, $user_id)) {
            $payload = method_exists('MPH_Notices', 'notification_payload') ? MPH_Notices::notification_payload($mode, $user_id) : array();
            $ts = max($ts, absint($payload['time'] ?? time()));
            $fp = 'notice:' . absint($payload['count'] ?? 1) . ':' . $ts;
        }
        if ($panel === 'cart' && function_exists('WC')) {
            if (!WC()->cart && function_exists('wc_load_cart')) wc_load_cart();
            $count = (WC()->cart) ? WC()->cart->get_cart_contents_count() : 0;
            if (class_exists('MPH_Shared_Cart')) {
                $saved = MPH_Shared_Cart::read($user_id);
                if (!empty($saved['items'])) {
                    $ts = max($ts, absint($saved['revision'] ?? time()));
                    $fp = 'cart:' . count((array)$saved['items']) . ':' . absint($saved['revision'] ?? 0);
                }
            } elseif ($count > 0) {
                $ts = max($ts, time() - 1);
                $fp = 'cart:' . $count;
            }
        }
        if ($panel === 'orders' && function_exists('wc_get_orders')) {
            $orders = wc_get_orders(array('customer_id' => $user_id, 'limit' => 1, 'orderby' => 'date', 'order' => 'DESC', 'return' => 'objects'));
            if ($orders) {
                $created = $orders[0]->get_date_created();
                if ($created) {
                    $ts = max($ts, $created->getTimestamp());
                    $fp = 'order:' . $orders[0]->get_id();
                }
            }
        }
        if ($panel === 'payment_receipts' && class_exists('MPH_Commerce') && method_exists('MPH_Commerce', 'manager_pending_count')) {
            $count = (int) MPH_Commerce::manager_pending_count();
            if ($count > 0) {
                $ts = max($ts, absint($bucket['ts'] ?? time()));
                if ($ts <= 0) $ts = time();
                $fp = 'receipts:' . $count;
            }
        }
        if ($panel === 'manage_requests' && class_exists('MPH_Roles') && method_exists('MPH_Roles', 'pending_total')) {
            $n = (int) MPH_Roles::pending_total();
            if ($n > 0) {
                $ts = max($ts, absint($bucket['ts'] ?? time()));
                if ($ts <= 0) $ts = time();
                $fp = 'requests:' . $n;
            }
        }
        if ($panel === 'my_appointments' && class_exists('MPH_Appointment_Repository')) {
            // Defer detailed active-only logic to presence block below (avoids badge on past/cancelled).
        }
        if ($panel === 'course_forum' && class_exists('MPH_Forum')) {
            $latest = MPH_Forum::latest_event_for_user($user_id);
            if (!empty($latest['ts'])) {
                $ts = max($ts, absint($latest['ts']));
                $fp = (string)($latest['fp'] ?? $fp);
            }
        }

        
        // --- presence / count panels (badge only when content exists) ---
        if ($panel === 'wishlist' && class_exists('MPH_Tutor') && method_exists('MPH_Tutor', 'wishlist_count')) {
            $n = (int) MPH_Tutor::wishlist_count($user_id);
            if ($n > 0) { $ts = max($ts, time() - 1); $fp = 'wish:'.$n; $count = $n; $exists = 1; }
        } elseif ($panel === 'wishlist' && class_exists('MPH_Tutor') && method_exists('MPH_Tutor', 'active')) {
            // fallback: try tutor wishlist size without new method via filter later
        }
        if ($panel === 'reminders' && class_exists('MPH_Growth')) {
            $n = 0;
            // merged_reminders is private — count via public/user-meta only (no fatal).
            if (method_exists('MPH_Growth', 'reminder_count')) {
                $n = (int) MPH_Growth::reminder_count($user_id);
            } else {
                $rows = get_user_meta($user_id, '_mph_manual_reminders_v26', true); // primary
                if (!is_array($rows)) $rows = get_user_meta($user_id, '_mph_manual_reminders', true);
                if (is_array($rows)) {
                    foreach ($rows as $row) {
                        if (!is_array($row)) continue;
                        $when = strtotime((string)($row['time'] ?? $row['at'] ?? $row['date'] ?? ''));
                        if ($when && $when < current_time('timestamp') - DAY_IN_SECONDS) continue;
                        $n++;
                    }
                }
                $n = (int) apply_filters('mph_reminder_badge_count', $n, $user_id);
            }
            if ($n > 0) { $ts = max($ts, time() - 1); $fp = 'rem:'.$n; $count = $n; $exists = 1; }
        }
        if ($panel === 'my_exams' && class_exists('MPH_Tutor') && method_exists('MPH_Tutor', 'active_exam_count')) {
            $n = (int) MPH_Tutor::active_exam_count($user_id);
            if ($n > 0) { $ts = max($ts, time() - 1); $fp = 'exam:'.$n; $count = $n; $exists = 1; }
        }
        if ($panel === 'therapist_schedule' && class_exists('MPH_Appointments') && method_exists('MPH_Appointments', 'therapist_has_schedule')) {
            if (MPH_Appointments::therapist_has_schedule($user_id)) {
                $ts = max($ts, time() - 1); $fp = 'sched:1'; $count = 1; $exists = 1;
            }
        }
        if ($panel === 'therapist_appointments' && class_exists('MPH_Appointment_Repository')) {
            $items = MPH_Appointment_Repository::query('therapist', $user_id, 20);
            $n = is_array($items) ? count($items) : 0;
            if ($n > 0) { $ts = max($ts, time() - 1); $fp = 'tappt:'.$n; $count = $n; $exists = 1; }
        }
        if ($panel === 'manage_appointments') {
            $items = get_posts(array(
                'post_type' => 'mph_appointment',
                'post_status' => 'publish',
                'numberposts' => 20,
                'fields' => 'ids',
            ));
            $n = is_array($items) ? count($items) : 0;
            if ($n > 0) { $ts = max($ts, time() - 1); $fp = 'mappt:'.$n; $count = $n; $exists = 1; }
        }
        if ($panel === 'my_appointments' && class_exists('MPH_Appointment_Repository')) {
            // Only NEW upcoming appointments; clear when past/done/cancelled
            $items = MPH_Appointment_Repository::query('user', $user_id, 20);
            $fresh = 0; $latest = 0; $latest_id = 0;
            if (is_array($items)) {
                foreach ($items as $p) {
                    $st = sanitize_key((string) get_post_meta($p->ID, '_mph_appointment_status', true));
                    if ($st === '') $st = sanitize_key((string) get_post_meta($p->ID, 'status', true));
                    if (in_array($st, array('cancelled', 'canceled', 'completed', 'done', 'past', 'expired'), true)) continue;
                    $when = strtotime((string) get_post_meta($p->ID, '_mph_appointment_start', true));
                    if (!$when) $when = strtotime($p->post_date_gmt . ' UTC') ?: strtotime($p->post_date);
                    if ($when && $when < current_time('timestamp') - 3600) continue; // past
                    $fresh++;
                    if ($when >= $latest) { $latest = $when; $latest_id = $p->ID; }
                }
            }
            if ($fresh > 0) {
                $ts = max($ts, $latest ?: (time() - 1));
                $fp = 'apptnew:'.$latest_id.':'.$fresh;
                $count = $fresh;
                $exists = 1;
            } else {
                // force no badge when nothing active
                $ts = 0; $fp = 'appt:none'; $count = 0;
            }
        }
        if ($panel === 'course_forum' && class_exists('MPH_Forum') && method_exists('MPH_Forum', 'unread_count_for_user')) {
            $n = (int) MPH_Forum::unread_count_for_user($user_id);
            $latest = method_exists('MPH_Forum', 'latest_event_for_user') ? MPH_Forum::latest_event_for_user($user_id) : array();
            if ($n > 0) {
                $ts = max($ts, absint($latest['ts'] ?? time() - 1));
                $fp = 'forum:'.$n.':'.absint($latest['ts'] ?? 0);
                $count = $n;
                $exists = 1;
            } else {
                $count = 0;
            }
        }
        if ($panel === 'cart' && function_exists('WC')) {
            if (!WC()->cart && function_exists('wc_load_cart')) wc_load_cart();
            $count_cart = (WC()->cart) ? (int) WC()->cart->get_cart_contents_count() : 0;
            if ($count_cart > 0) { $count = $count_cart; $exists = 1; }
            else { $count = 0; $ts = 0; }
        }
        if ($panel === 'payment_receipts' && class_exists('MPH_Commerce') && method_exists('MPH_Commerce', 'manager_pending_count')) {
            $n = (int) MPH_Commerce::manager_pending_count();
            $count = $n; $exists = $n > 0 ? 1 : 0;
            if ($n <= 0) $ts = 0;
        }
        if ($panel === 'manage_requests') {
            // requests EXCEPT tickets — role/other requests only
            $n = 0;
            if (class_exists('MPH_Roles') && method_exists('MPH_Roles', 'pending_total')) {
                $n = (int) MPH_Roles::pending_total();
            } elseif (class_exists('MPH_Roles') && method_exists('MPH_Roles', 'pending_count')) {
                // manager queue of role requests
                $n = (int) apply_filters('mph_manage_requests_count', 0, $user_id);
                if (!$n && method_exists('MPH_Roles', 'pending_roles_all')) {
                    $n = count((array) MPH_Roles::pending_roles_all());
                }
            }
            // Explicitly exclude ticket counts from this panel
            $count = max(0, $n);
            $exists = $count > 0 ? 1 : 0;
            if ($count > 0) { $ts = max($ts, time() - 1); $fp = 'req:'.$count; }
            else { $ts = 0; }
        }


        $filtered = apply_filters('mph_menu_alert_event', array('ts' => $ts, 'fp' => $fp), $panel, $mode, $user_id);
        if (is_array($filtered)) {
            $ts = absint($filtered['ts'] ?? $ts);
            $fp = (string)($filtered['fp'] ?? $fp);
            if (isset($filtered['count'])) $count = absint($filtered['count']);
            if (isset($filtered['exists'])) $exists = !empty($filtered['exists']) ? 1 : 0;
        } else {
            $ts = absint(apply_filters('mph_menu_alert_timestamp', $ts, $panel, $mode, $user_id));
        }
        return array('ts' => $ts, 'fp' => $fp, 'count' => absint($count ?? 0), 'exists' => !empty($exists) ? 1 : 0);
    }

    public static function flags_for_items($items, $mode, $user_id) {
        $flags = array();
        foreach ((array) $items as $item) {
            $id = sanitize_key($item['id'] ?? '');
            if (!$id) continue;
            try {
                $event = self::latest_event_for_panel($id, $mode, $user_id);
            } catch (Throwable $e) {
                $flags[$id] = false;
                continue;
            }
            if (!is_array($event)) $event = array();
            $ts = absint($event['ts'] ?? 0);
            $fp = (string)($event['fp'] ?? '');
            $count = absint($event['count'] ?? 0);
            $on = self::is_unseen($id, $ts, $user_id, $fp);
            // "only if exists" panels: require count > 0
            if (in_array($id, array('wishlist','cart','reminders','my_exams','therapist_schedule','therapist_appointments','manage_appointments','payment_receipts','manage_requests','my_appointments'), true)) {
                if ($count <= 0 && empty($event['exists'])) $on = false;
            }
            if ($id === 'course_forum') {
                $on = $count > 0;
            }
            $flags[$id] = $on ? array('on' => 1, 'count' => max(1, $count ?: 1), 'fp' => $fp) : false;
        }
        return $flags;
    }

    /** Back-compat bool helper */
    public static function flag_on($flags, $id) {
        if (empty($flags[$id])) return false;
        if (is_array($flags[$id])) return !empty($flags[$id]['on']);
        return !empty($flags[$id]);
    }

    public static function flag_count($flags, $id) {
        if (empty($flags[$id])) return 0;
        if (is_array($flags[$id])) return absint($flags[$id]['count'] ?? 0);
        return !empty($flags[$id]) ? 1 : 0;
    }

    public static function ajax_seen() {
        MPH_Helpers::verify_ajax();
        if (!is_user_logged_in()) wp_send_json_error(array('message' => 'نشست نامعتبر است.'), 401);
        $panel = sanitize_key(MPH_Helpers::posted('panel', 'key'));
        if (!$panel) wp_send_json_error(array('message' => 'منو نامعتبر است.'));
        $user_id = get_current_user_id();
        $mode = MPH_Helpers::requested_mode();
        $event = self::latest_event_for_panel($panel, $mode, $user_id);
        $at = max(time(), absint($event['ts'] ?? 0));
        self::mark_seen($panel, $user_id, $at, (string)($event['fp'] ?? ''));
        wp_send_json_success(array('ok' => 1, 'panel' => $panel, 'seen_at' => $at));
    }

    public static function on_ticket($user_id, $panel = 'ticket_support') {
        self::bump($panel ?: 'ticket_support', absint($user_id), 'ticket:' . time());
    }
    public static function on_notice($mode, $user_id = 0) {
        $panel = ($mode === 'instructor') ? 'teacher_notices' : 'announcements';
        self::bump($panel, absint($user_id), 'notice:' . time());
    }
    public static function on_cart_change() {
        if (is_user_logged_in()) self::bump('cart', get_current_user_id(), 'cart:' . time());
    }
    public static function on_order($order_id, $from, $to, $order) {
        if (!is_object($order) || !method_exists($order, 'get_customer_id')) return;
        $uid = absint($order->get_customer_id());
        if ($uid) self::bump('orders', $uid, 'order:' . absint($order_id) . ':' . $to);
    }
    public static function on_receipt($order_id = 0) {
        self::bump('payment_receipts', 0, 'receipts:' . absint($order_id) . ':' . time());
    }
    public static function on_role_request($request_id = 0) {
        self::bump('manage_requests', 0, 'requests:' . absint($request_id));
    }
    public static function on_appointment($user_id, $appointment_id = 0) {
        self::bump('my_appointments', absint($user_id), 'appt:' . absint($appointment_id));
    }
    public static function on_forum($user_id, $course_id = 0) {
        self::bump('course_forum', absint($user_id), 'forum:' . absint($course_id) . ':' . time());
    }
    public static function on_course_end($course_id, $user_id = 0) {
        self::bump('manage_courses', 0, 'end:' . absint($course_id));
        self::bump('teacher_courses', absint($user_id), 'end:' . absint($course_id));
    }
}
