<?php
defined('ABSPATH') || exit;

/** Minimal dependency-free XLSX writer with embedded receipt images. */
final class MPH_XLSX {
    public static function export_receipts($orders) {
        $tmp=self::temp_dir();if(is_wp_error($tmp))wp_die($tmp->get_error_message());
        try{
            self::mkdirs($tmp);
            $drawing=array();$relationships=array();$media_types=array();$rows=array();$image_number=0;
            $headers=array('شماره سفارش','مشتری','تلفن','مبلغ','تخفیف','روش پرداخت','وضعیت','تاریخ','فیش ۱','فیش ۲','فیش ۳','فیش ۴');
            $rows[]=self::row_xml(1,$headers,true,32);
            $row_number=2;
            foreach((array)$orders as$order){
                if(!is_object($order)||!method_exists($order,'get_id'))continue;
                $frames=self::receipt_frames($order,$tmp,4);$cells=array($order->get_order_number(),$order->get_formatted_billing_full_name(),$order->get_billing_phone(),$order->get_total(),$order->get_discount_total(),$order->get_payment_method_title(),wc_get_order_status_name($order->get_status()),$order->get_date_created()?$order->get_date_created()->date('Y-m-d H:i'):'');
                for($slot=0;$slot<4;$slot++)$cells[]=isset($frames[$slot])?'':($slot===0?'فایلی ثبت نشده':'');
                $rows[]=self::row_xml($row_number,$cells,false,$frames?110:34);
                foreach($frames as$slot=>$frame){
                    $image_number++;$ext=$frame['ext'];$name='image'.$image_number.'.'.$ext;$target=$tmp.'/xl/media/'.$name;if(!copy($frame['path'],$target))continue;
                    $rid='rId'.$image_number;$relationships[]='<Relationship Id="'.$rid.'" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="../media/'.$name.'"/>';$media_types[$ext]=self::mime_for_ext($ext);
                    $col=8+absint($slot);$row=$row_number-1;$drawing[]=self::anchor_xml($image_number,$rid,$col,$row,$frame['label']??('فیش '.$row_number));
                }
                $row_number++;
            }
            self::write($tmp.'/xl/worksheets/sheet1.xml',self::sheet_xml($rows));
            self::write($tmp.'/xl/drawings/drawing1.xml',self::drawing_xml($drawing));
            self::write($tmp.'/xl/drawings/_rels/drawing1.xml.rels',self::rels_xml($relationships));
            self::write($tmp.'/[Content_Types].xml',self::content_types_xml($media_types));
            self::write_base_files($tmp);
            $xlsx=$tmp.'/mph-receipts-'.wp_date('Y-m-d').'.xlsx';$created=self::zip_tree($tmp,$xlsx);if(is_wp_error($created))throw new RuntimeException($created->get_error_message());
            while(ob_get_level())ob_end_clean();nocache_headers();header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');header('Content-Disposition: attachment; filename="'.sanitize_file_name(basename($xlsx)).'"');header('Content-Length: '.filesize($xlsx));readfile($xlsx);self::cleanup($tmp);exit;
        }catch(Throwable$error){self::cleanup($tmp);wp_die('ساخت خروجی Excel انجام نشد: '.esc_html($error->getMessage()));}
    }

    private static function receipt_frames($order,$tmp,$limit) {
        $ids=array();foreach(array(MPH_Commerce::RECEIPT_FILE,'_mph_receipt_file_ids','_mph_receipt_files')as$key){$value=$order->get_meta($key);foreach(self::flatten_ids($value)as$id)$ids[]=$id;}$ids=array_values(array_unique(array_filter(array_map('absint',$ids))));$frames=array();
        foreach($ids as$id){if(count($frames)>=$limit)break;$path=get_attached_file($id);if(!$path||!is_readable($path))continue;$mime=(string)get_post_mime_type($id);$remaining=$limit-count($frames);if($mime==='application/pdf'||strtolower(pathinfo($path,PATHINFO_EXTENSION))==='pdf')$new=self::pdf_frames($path,$tmp,$remaining,$id);else{$image=self::image_frame($path,$tmp,$id);$new=$image?array($image):array();}foreach($new as$frame){$frames[]=$frame;if(count($frames)>=$limit)break;}}
        return$frames;
    }

    private static function flatten_ids($value) {if(is_numeric($value))return array(absint($value));if(is_string($value)&&is_serialized($value))$value=maybe_unserialize($value);if(!is_array($value))return array();$ids=array();array_walk_recursive($value,function($item)use(&$ids){if(is_numeric($item))$ids[]=absint($item);});return$ids;}

    private static function image_frame($path,$tmp,$id) {
        $ext=strtolower(pathinfo($path,PATHINFO_EXTENSION));if(in_array($ext,array('jpg','jpeg','png'),true))return array('path'=>$path,'ext'=>$ext==='jpeg'?'jpg':$ext,'label'=>basename($path));
        require_once ABSPATH.'wp-admin/includes/image.php';$editor=wp_get_image_editor($path);if(is_wp_error($editor))return false;$dest=$tmp.'/converted-image-'.absint($id).'.png';$saved=$editor->save($dest,'image/png');return is_wp_error($saved)?false:array('path'=>$saved['path'],'ext'=>'png','label'=>basename($path));
    }

    private static function pdf_frames($path,$tmp,$limit,$id) {
        $frames=array();
        if(class_exists('Imagick')){
            try{$pdf=new Imagick();$pdf->setResolution(120,120);$pdf->readImage($path);$index=0;foreach($pdf as$page){if($index>=$limit)break;$page->setImageBackgroundColor('white');if(method_exists($page,'mergeImageLayers'))$page=$page->mergeImageLayers(Imagick::LAYERMETHOD_FLATTEN);$page->setImageFormat('png');$page->thumbnailImage(1000,1200,true);$dest=$tmp.'/receipt-'.absint($id).'-page-'.($index+1).'.png';$page->writeImage($dest);if(is_readable($dest))$frames[]=array('path'=>$dest,'ext'=>'png','label'=>basename($path).' — صفحه '.($index+1));$index++;}$pdf->clear();$pdf->destroy();}catch(Throwable$e){$frames=array();}
        }
        if($frames)return$frames;
        $meta=wp_get_attachment_metadata($id);$base=dirname($path);foreach((array)($meta['sizes']??array())as$size){$preview=$base.'/'.sanitize_file_name($size['file']??'');if($preview&&is_readable($preview)){$frame=self::image_frame($preview,$tmp,$id);if($frame){$frame['label']=basename($path).' — پیش‌نمایش صفحه اول';$frames[]=$frame;break;}}}
        return$frames;
    }

    private static function row_xml($row,$values,$header=false,$height=32) {
        $cells='';foreach(array_values($values)as$index=>$value){$ref=self::column($index).$row;$style=$header?1:2;$cells.='<c r="'.$ref.'" t="inlineStr" s="'.$style.'"><is><t xml:space="preserve">'.self::xml((string)$value).'</t></is></c>';}
        return'<row r="'.$row.'" ht="'.absint($height).'" customHeight="1">'.$cells.'</row>';
    }

    private static function anchor_xml($id,$rid,$col,$row,$label) {
        return'<xdr:twoCellAnchor editAs="oneCell"><xdr:from><xdr:col>'.$col.'</xdr:col><xdr:colOff>75000</xdr:colOff><xdr:row>'.$row.'</xdr:row><xdr:rowOff>60000</xdr:rowOff></xdr:from><xdr:to><xdr:col>'.($col+1).'</xdr:col><xdr:colOff>0</xdr:colOff><xdr:row>'.($row+1).'</xdr:row><xdr:rowOff>0</xdr:rowOff></xdr:to><xdr:pic><xdr:nvPicPr><xdr:cNvPr id="'.$id.'" name="Receipt '.$id.'" descr="'.self::xml($label).'"/><xdr:cNvPicPr><a:picLocks noChangeAspect="1"/></xdr:cNvPicPr></xdr:nvPicPr><xdr:blipFill><a:blip r:embed="'.$rid.'"/><a:stretch><a:fillRect/></a:stretch></xdr:blipFill><xdr:spPr><a:xfrm/><a:prstGeom prst="rect"><a:avLst/></a:prstGeom></xdr:spPr></xdr:pic><xdr:clientData/></xdr:twoCellAnchor>';
    }

    private static function sheet_xml($rows) {return'<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheetViews><sheetView workbookViewId="0" rightToLeft="1" showGridLines="1"><pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews><cols><col min="1" max="1" width="15" customWidth="1"/><col min="2" max="3" width="22" customWidth="1"/><col min="4" max="5" width="14" customWidth="1"/><col min="6" max="8" width="20" customWidth="1"/><col min="9" max="12" width="24" customWidth="1"/></cols><sheetData>'.implode('',$rows).'</sheetData><autoFilter ref="A1:L1"/><drawing r:id="rId1"/></worksheet>';}
    private static function drawing_xml($drawing) {return'<?xml version="1.0" encoding="UTF-8" standalone="yes"?><xdr:wsDr xmlns:xdr="http://schemas.openxmlformats.org/drawingml/2006/spreadsheetDrawing" xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'.implode('',$drawing).'</xdr:wsDr>';}
    private static function rels_xml($rels) {return'<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'.implode('',$rels).'</Relationships>';}
    private static function content_types_xml($types) {$defaults='<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/>';foreach($types as$ext=>$mime)$defaults.='<Default Extension="'.self::xml($ext).'" ContentType="'.self::xml($mime).'"/>';return'<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'.$defaults.'<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/><Override PartName="/xl/drawings/drawing1.xml" ContentType="application/vnd.openxmlformats-officedocument.drawing+xml"/><Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/><Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/></Types>';}

    private static function write_base_files($tmp) {
        self::write($tmp.'/_rels/.rels','<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/><Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties" Target="docProps/app.xml"/></Relationships>');
        self::write($tmp.'/xl/workbook.xml','<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><workbookPr/><bookViews><workbookView/></bookViews><sheets><sheet name="فیش‌های فروش" sheetId="1" r:id="rId1"/></sheets><calcPr calcId="191029" fullCalcOnLoad="1"/></workbook>');
        self::write($tmp.'/xl/_rels/workbook.xml.rels','<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>');
        self::write($tmp.'/xl/worksheets/_rels/sheet1.xml.rels','<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/drawing" Target="../drawings/drawing1.xml"/></Relationships>');
        self::write($tmp.'/xl/styles.xml','<?xml version="1.0" encoding="UTF-8" standalone="yes"?><styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><fonts count="2"><font><sz val="11"/><name val="Tahoma"/></font><font><b/><color rgb="FFFFFFFF"/><sz val="11"/><name val="Tahoma"/></font></fonts><fills count="3"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FF334155"/><bgColor indexed="64"/></patternFill></fill></fills><borders count="2"><border><left/><right/><top/><bottom/><diagonal/></border><border><left style="thin"><color rgb="FFDCE3EA"/></left><right style="thin"><color rgb="FFDCE3EA"/></right><top style="thin"><color rgb="FFDCE3EA"/></top><bottom style="thin"><color rgb="FFDCE3EA"/></bottom><diagonal/></border></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="3"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/><xf numFmtId="0" fontId="1" fillId="2" borderId="1" xfId="0" applyAlignment="1"><alignment horizontal="center" vertical="center" readingOrder="2"/></xf><xf numFmtId="0" fontId="0" fillId="0" borderId="1" xfId="0" applyAlignment="1"><alignment horizontal="center" vertical="center" wrapText="1" readingOrder="2"/></xf></cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>');
        $now=gmdate('Y-m-d\TH:i:s\Z');self::write($tmp.'/docProps/core.xml','<?xml version="1.0" encoding="UTF-8" standalone="yes"?><cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"><dc:creator>Modern Profile Hub</dc:creator><cp:lastModifiedBy>Modern Profile Hub</cp:lastModifiedBy><dcterms:created xsi:type="dcterms:W3CDTF">'.$now.'</dcterms:created><dcterms:modified xsi:type="dcterms:W3CDTF">'.$now.'</dcterms:modified></cp:coreProperties>');
        self::write($tmp.'/docProps/app.xml','<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties" xmlns:vt="http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes"><Application>Modern Profile Hub</Application></Properties>');
    }

    private static function mkdirs($tmp) {foreach(array('_rels','docProps','xl','xl/_rels','xl/worksheets','xl/worksheets/_rels','xl/drawings','xl/drawings/_rels','xl/media')as$dir)if(!wp_mkdir_p($tmp.'/'.$dir))throw new RuntimeException('ساخت پوشه‌های Excel ممکن نیست.');}
    private static function write($path,$content) {if(file_put_contents($path,$content,LOCK_EX)===false)throw new RuntimeException('نوشتن فایل Excel ممکن نیست.');}
    private static function column($index) {$name='';for($n=$index+1;$n>0;$n=intdiv($n-1,26))$name=chr(65+(($n-1)%26)).$name;return$name;}
    private static function xml($value) {return htmlspecialchars((string)$value,ENT_XML1|ENT_QUOTES,'UTF-8');}
    private static function mime_for_ext($ext) {return$ext==='png'?'image/png':'image/jpeg';}

    private static function zip_tree($tmp,$path) {
        $files=self::files($tmp,$path);if(class_exists('ZipArchive')){$zip=new ZipArchive();if($zip->open($path,ZipArchive::CREATE|ZipArchive::OVERWRITE)!==true)return new WP_Error('xlsx_zip','ساخت ZIP مربوط به Excel ممکن نیست.');foreach($files as$file)$zip->addFile($file,ltrim(substr($file,strlen($tmp)),'/'));$zip->close();return true;}
        require_once ABSPATH.'wp-admin/includes/class-pclzip.php';$zip=new PclZip($path);$ok=$zip->create($files,PCLZIP_OPT_REMOVE_PATH,$tmp);return$ok?true:new WP_Error('xlsx_zip','کتابخانه ZIP روی سرور در دسترس نیست.');
    }
    private static function files($dir,$exclude='') {$result=array();$iterator=new RecursiveIteratorIterator(new RecursiveDirectoryIterator($dir,FilesystemIterator::SKIP_DOTS));foreach($iterator as$file)if($file->isFile()&&$file->getPathname()!==$exclude)$result[]=$file->getPathname();return$result;}
    private static function temp_dir() {$base=function_exists('get_temp_dir')?get_temp_dir():WP_CONTENT_DIR.'/';$path=trailingslashit($base).'mph-xlsx-'.wp_generate_password(16,false,false);return wp_mkdir_p($path)?$path:new WP_Error('tmp','ساخت پوشه موقت Excel ممکن نیست.');}
    private static function cleanup($dir) {if(!is_string($dir)||strpos(basename($dir),'mph-xlsx-')!==0||!is_dir($dir))return;$iterator=new RecursiveIteratorIterator(new RecursiveDirectoryIterator($dir,FilesystemIterator::SKIP_DOTS),RecursiveIteratorIterator::CHILD_FIRST);foreach($iterator as$file){$file->isDir()?@rmdir($file->getPathname()):@unlink($file->getPathname());}@rmdir($dir);}
}
