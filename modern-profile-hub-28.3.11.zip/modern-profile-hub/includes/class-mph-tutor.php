<?php
defined('ABSPATH') || exit;

final class MPH_Tutor {
    public static function active() { return function_exists('tutor_utils') && function_exists('tutor'); }

    public static function sync_profile($user_id, $phone = '', $major = '', $address = '') {
        update_user_meta($user_id, 'phone_number', $phone);
        update_user_meta($user_id, '_tutor_profile_job_title', $major);
        if ($address) update_user_meta($user_id, '_tutor_profile_bio', $address);
        update_user_meta($user_id, '_is_tutor_student', 1);
    }

    public static function sync_avatar($user_id, $attachment_id) {
        update_user_meta($user_id, '_tutor_profile_photo', $attachment_id);
    }

    public static function approve_instructor($user_id) {
        $user = new WP_User($user_id);
        $role = self::active() && !empty(tutor()->instructor_role) ? tutor()->instructor_role : 'tutor_instructor';
        if (get_role($role)) $user->add_role($role);
        $user->add_role('mph_instructor');
        update_user_meta($user_id, '_is_tutor_instructor', current_time('timestamp'));
        update_user_meta($user_id, '_tutor_instructor_status', 'approved');
        update_user_meta($user_id, '_tutor_instructor_approved', current_time('timestamp'));
        update_user_meta($user_id, 'tutor_instructor_show_approval_message', true);
        if (self::active()) do_action('tutor_after_approved_instructor', $user_id);
    }

    public static function dashboard_url($section = '') {
        if (!self::active()) return '#';
        return tutor_utils()->get_tutor_dashboard_page_permalink($section);
    }

    public static function enrolled_courses($user_id) {
        if (!self::active()) return self::inactive();
        MPH_Courses::repair_user_access($user_id);
        $query = tutor_utils()->get_enrolled_courses_by_user($user_id, array('private','publish'));
        return self::course_query($query, 'هنوز در دوره‌ای ثبت‌نام نکرده‌اید.', false, $user_id);
    }

    public static function instructor_courses($user_id) {
        if (!self::active()) return self::inactive();
        $type = !empty(tutor()->course_post_type) ? tutor()->course_post_type : 'courses';
        $query = new WP_Query(array('post_type'=>$type,'author'=>$user_id,'post_status'=>array('publish','pending','draft','future'),'posts_per_page'=>20));
        return self::course_query($query, 'هنوز دوره‌ای برای تدریس ایجاد نشده است.', true);
    }

    public static function instructor_course_count($user_id){if(!self::active())return 0;$type=!empty(tutor()->course_post_type)?tutor()->course_post_type:'courses';$counts=count_user_posts(absint($user_id),$type,true);return absint($counts);}

    public static function course_student_count($course_id){if(!self::active())return 0;if(method_exists(tutor_utils(),'count_enrolled_users_by_course'))return absint(tutor_utils()->count_enrolled_users_by_course(absint($course_id)));return count(self::course_student_ids($course_id));}

    public static function course_student_ids($course_id){global$wpdb;$ids=$wpdb->get_col($wpdb->prepare("SELECT DISTINCT post_author FROM {$wpdb->posts} WHERE post_type='tutor_enrolled' AND post_parent=%d AND post_status NOT IN ('trash','auto-draft')",absint($course_id)));return array_values(array_filter(array_map('absint',(array)$ids)));}

    public static function wishlist_count($user_id = 0) {
        $user_id = absint($user_id ?: get_current_user_id());
        if (!$user_id || !self::active()) return 0;
        try {
            $w = tutor_utils()->get_wishlist($user_id);
            if (is_array($w)) return count($w);
        } catch (Throwable $e) {}
        global $wpdb;
        $table = $wpdb->prefix . 'tutor_wishlist';
        if ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $table)) === $table) {
            return (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$table} WHERE user_id=%d", $user_id));
        }
        return 0;
    }

    public static function wishlist($user_id) {
        if (!self::active()) return self::inactive();
        $wishlist = array();
        try {$wishlist = tutor_utils()->get_wishlist(absint($user_id));} catch (Throwable $error) {$wishlist=array();}
        if (!$wishlist) {
            global $wpdb;$table=$wpdb->prefix.'tutor_wishlist';
            if($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$table))===$table)$wishlist=$wpdb->get_col($wpdb->prepare("SELECT course_id FROM {$table} WHERE user_id=%d",absint($user_id)));
        }
        if (!$wishlist) return self::empty_box('لیست علاقه‌مندی‌ها خالی است.');
        $ids = array(); foreach ((array) $wishlist as $item) { if (is_object($item) && isset($item->course_id)) $ids[] = absint($item->course_id); elseif (is_object($item) && isset($item->ID)) $ids[] = absint($item->ID); else $ids[] = absint($item); }
        $ids = array_filter(array_unique($ids));
        if (!$ids) return self::empty_box('لیست علاقه‌مندی‌ها خالی است.');
        $query = new WP_Query(array('post_type'=>tutor()->course_post_type,'post__in'=>$ids,'posts_per_page'=>-1,'orderby'=>'post__in'));
        return self::course_query($query, 'لیست علاقه‌مندی‌ها خالی است.');
    }

    public static function active_exam_count($user_id = 0) {
        $user_id = absint($user_id ?: get_current_user_id());
        if (!$user_id || !self::active()) return 0;
        // Prefer quizzes marked available/open for enrolled user; fall back to filter.
        $n = (int) apply_filters('mph_active_exam_count', -1, $user_id);
        if ($n >= 0) return $n;
        global $wpdb;
        $table = $wpdb->prefix . 'tutor_quiz_attempts';
        // Count distinct quizzes with no finished attempt yet that are published — best-effort
        // "active only": quizzes user can still take (no attempt or in-progress)
        if ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $table)) === $table) {
            // unfinished attempts
            $open = (int) $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) FROM {$table} WHERE user_id=%d AND (attempt_status IS NULL OR attempt_status IN ('','started','in_progress','attempt_started'))",
                $user_id
            ));
            if ($open > 0) return $open;
        }
        // If Tutor quiz list API exists, count available
        try {
            if (function_exists('tutor_utils')) {
                // no reliable global list — return 0 unless filter provides
            }
        } catch (Throwable $e) {}
        return 0;
    }

    public static function quiz_attempts($user_id) {
        if (!self::active()) return self::inactive();
        global $wpdb; $table = $wpdb->prefix . 'tutor_quiz_attempts';
        if ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $table)) !== $table) return self::empty_box('اطلاعات آزمون در دسترس نیست.');
        $rows = $wpdb->get_results($wpdb->prepare("SELECT * FROM {$table} WHERE user_id=%d ORDER BY attempt_id DESC LIMIT 30", $user_id));
        if (!$rows) return self::empty_box('آزمونی برای شما ثبت نشده است.');
        ob_start(); ?><div class="mph-tutor-table"><table><thead><tr><th>آزمون</th><th>دوره</th><th>نمره</th><th>وضعیت</th></tr></thead><tbody><?php foreach($rows as $row): ?><tr><td><?php echo esc_html(get_the_title(absint($row->quiz_id??0))); ?></td><td><?php echo esc_html(get_the_title(absint($row->course_id??0))); ?></td><td><?php echo esc_html($row->earned_marks??'—'); ?></td><td><?php echo !empty($row->attempt_ended_at)?'تکمیل‌شده':'در حال انجام'; ?></td></tr><?php endforeach; ?></tbody></table></div><a class="mph-native-link" href="<?php echo esc_url(self::dashboard_url('my-quiz-attempts')); ?>">مشاهده در Tutor LMS</a><?php return ob_get_clean();
    }

    public static function orders($user_id) {
        if (function_exists('wc_get_orders')) {
            $orders = wc_get_orders(array('customer_id'=>$user_id,'limit'=>20,'orderby'=>'date','order'=>'DESC'));
            if (!$orders) return self::empty_box('سفارشی ثبت نشده است.');
            ob_start(); ?><div class="mph-tutor-table mph-order-history mph-order-history-v29"><table><thead><tr><th>شماره</th><th>تاریخ</th><th>شرح محصول</th><th>مبلغ</th><th>وضعیت</th><th>صورت‌حساب</th><th>دانلود فاکتور</th></tr></thead><tbody><?php foreach($orders as $order):
                $names=array();
                foreach($order->get_items() as $item){$n=trim(wp_strip_all_tags($item->get_name()));if($n!=='')$names[]=$n;}
                $names=array_values(array_unique($names));
                $product_label=$names?implode(' + ',$names):'—';
                $can_invoice=$order->is_paid() || $order->get_meta(MPH_Commerce::RECEIPT_STATUS)==='approved';
            ?><tr>
                <td data-label="شماره">#<?php echo esc_html($order->get_order_number()); ?></td>
                <td data-label="تاریخ"><?php echo esc_html(wc_format_datetime($order->get_date_created())); ?></td>
                <td data-label="شرح محصول" class="mph-order-products"><?php echo esc_html($product_label); ?></td>
                <td data-label="مبلغ"><?php echo wp_kses_post($order->get_formatted_order_total()); ?></td>
                <td data-label="وضعیت"><?php echo esc_html(wc_get_order_status_name($order->get_status())); ?></td>
                <td data-label="صورت‌حساب"><?php if($can_invoice && class_exists('MPH_Courses') && method_exists('MPH_Courses','invoice_url')): ?><span class="mph-muted">PDF</span><?php else: ?>—<?php endif; ?></td>
                <td data-label="دانلود فاکتور"><?php if($can_invoice && class_exists('MPH_Courses') && method_exists('MPH_Courses','invoice_url')): ?><a class="mph-primary mph-invoice-download" rel="noopener" download href="<?php echo esc_url(MPH_Courses::invoice_url($order->get_id(),'pdf')); ?>"><span class="dashicons dashicons-pdf"></span> دانلود PDF</a><?php else: ?><span class="mph-muted">پس از تأیید</span><?php endif; ?></td>
            </tr><?php endforeach; ?></tbody></table></div><?php return ob_get_clean();
        }
        if (self::active()) return '<div class="mph-empty"><p>تاریخچه خرید در داشبورد Tutor در دسترس است.</p><a class="mph-native-link" href="'.esc_url(self::dashboard_url('purchase_history')).'">مشاهده تاریخچه خرید</a></div>';
        return self::inactive();
    }

    public static function native_section($section, $message) {
        if (!self::active()) return self::inactive();
        return '<div class="mph-empty"><p>'.esc_html($message).'</p><a class="mph-native-link" href="'.esc_url(self::dashboard_url($section)).'">بازکردن بخش اصلی Tutor LMS</a></div>';
    }

    private static function course_query($query, $empty, $instructor = false, $progress_user_id = 0) {
        if (!$query || !$query->have_posts()) return self::empty_box($empty);
        ob_start(); ?><div class="mph-course-grid mph-plugin-course-grid"><?php while($query->have_posts()):$query->the_post();$id=get_the_ID();$view_url=get_post_status($id)==='publish'?get_permalink($id):(get_preview_post_link($id)?:get_permalink($id));$offline=$progress_user_id&&class_exists('MPH_Courses')&&MPH_Courses::has_access($progress_user_id,$id,'offline');$progress=$offline?MPH_Courses::offline_progress_percent($id,$progress_user_id):0; ?><article class="mph-course-card <?php echo $offline?'has-offline-progress':''; ?>"><a class="mph-course-cover-link" href="<?php echo esc_url($view_url); ?>"><?php if(has_post_thumbnail())the_post_thumbnail('medium');else echo '<span class="mph-course-placeholder dashicons dashicons-welcome-learn-more"></span>'; ?></a><div><h4><a href="<?php echo esc_url($view_url); ?>"><?php the_title(); ?></a></h4><p><?php echo esc_html(wp_trim_words(get_the_excerpt(),12)); ?></p><?php if($offline): ?><div class="mph-course-progress" aria-label="<?php echo esc_attr($progress); ?> درصد پیشرفت"><div><span style="width:<?php echo esc_attr($progress); ?>%"></span></div><small><b><?php echo esc_html($progress); ?>٪</b> پیشرفت دوره آفلاین</small></div><?php endif; ?><?php if($instructor): ?><span class="mph-status"><?php $status=get_post_status_object(get_post_status());echo esc_html($status?$status->label:get_post_status()); ?></span><div class="mph-course-actions" style="margin-top:8px"><button type="button" class="mph-course-manage-btn" data-mph-course-manage="<?php echo absint($id); ?>" data-course-title="<?php echo esc_attr(get_the_title($id)); ?>"><span class="dashicons dashicons-welcome-learn-more"></span> مدیریت دوره</button></div><?php elseif($progress_user_id): ?><?php echo MPH_Courses::enrolled_actions($id,$progress_user_id); ?><?php else: ?><a class="mph-native-link" href="<?php echo esc_url($view_url); ?>">مشاهده جزئیات دوره</a><?php endif; ?></div></article><?php endwhile;wp_reset_postdata(); ?></div><?php return ob_get_clean();
    }

    private static function course_progress($course_id, $user_id) {
        if (!$user_id || !self::active() || !method_exists(tutor_utils(), 'get_course_completed_percent')) return 0;
        $value = tutor_utils()->get_course_completed_percent($course_id, $user_id);
        if (is_array($value)) $value = $value['completed_percent'] ?? 0;
        return max(0, min(100, absint($value)));
    }

    public static function progress_percent($course_id,$user_id){$course_id=absint($course_id);$user_id=absint($user_id);$native=self::course_progress($course_id,$user_id);if(!class_exists('MPH_Courses')||!method_exists('MPH_Courses','access_modes'))return min(100,absint($native));$access=MPH_Courses::access_modes($user_id,$course_id);$values=array();if(isset($access['offline']))$values[]=MPH_Courses::offline_progress_percent($course_id,$user_id);if(isset($access['online']))$values[]=MPH_Courses::manual_progress_percent($course_id,$user_id,'online');if(isset($access['inperson']))$values[]=MPH_Courses::manual_progress_percent($course_id,$user_id,'inperson');return min(100,absint($values?max($values):$native));}

    private static function inactive(){return '<div class="mph-empty mph-tutor-warning"><span class="dashicons dashicons-warning"></span><p>برای نمایش اطلاعات آموزشی، افزونه Tutor LMS باید فعال باشد.</p></div>';}
    private static function empty_box($text){return '<div class="mph-empty"><p>'.esc_html($text).'</p></div>';}
}
