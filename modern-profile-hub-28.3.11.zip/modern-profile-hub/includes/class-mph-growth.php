<?php
defined('ABSPATH') || exit;

/** قابلیت‌های رشد، گزارش، ظرفیت، یادآوری و بازیابی سبد. */
final class MPH_Growth {
    const SAVED_CART = '_mph_saved_cart_v22';
    const FUNNEL = 'mph_funnel_totals_v22';
    const MANUAL_REMINDERS = '_mph_manual_reminders_v26';

    public static function init() {
        add_action('init', array(__CLASS__, 'rewrites'));
        add_filter('query_vars', array(__CLASS__, 'query_vars'));
        add_action('template_redirect', array(__CLASS__, 'instructor_template'), 5);
        add_action('wp_loaded', array(__CLASS__, 'restore_cart'), 30);
        add_action('woocommerce_cart_updated', array(__CLASS__, 'save_cart'));
        add_action('woocommerce_add_to_cart', array(__CLASS__, 'track_cart'), 20);
        add_action('woocommerce_checkout_order_created', array(__CLASS__, 'track_checkout'));
        add_action('woocommerce_payment_complete', array(__CLASS__, 'track_purchase'));
        add_action('woocommerce_order_status_processing', array(__CLASS__, 'track_purchase'));
        add_action('woocommerce_order_status_completed', array(__CLASS__, 'track_purchase'));
        add_action('woocommerce_order_status_changed', array(__CLASS__, 'flush_order_capacity_cache'), 10, 4);
        add_action('woocommerce_update_product', array(__CLASS__, 'flush_product_capacity_cache'));
        add_action('wp', array(__CLASS__, 'track_course_view'));
        add_action('wp_ajax_mph_reminder_save', array(__CLASS__, 'ajax_reminder_save'));
        add_action('wp_ajax_mph_reminder_delete', array(__CLASS__, 'ajax_reminder_delete'));
        add_action('wp_ajax_mph_join_waitlist', array(__CLASS__, 'ajax_waitlist'));
        add_action('admin_post_mph_growth_export', array(__CLASS__, 'export'));
        add_action('mph_growth_reminders', array(__CLASS__, 'send_reminders'));
        if (!wp_next_scheduled('mph_growth_reminders')) wp_schedule_event(time() + 300, 'hourly', 'mph_growth_reminders');
    }

    public static function activate() {
        self::rewrites();
        flush_rewrite_rules(false);
        if (!wp_next_scheduled('mph_growth_reminders')) wp_schedule_event(time() + 300, 'hourly', 'mph_growth_reminders');
    }

    public static function rewrites() {
        add_rewrite_rule('^mph-instructor/([^/]+)/?$', 'index.php?mph_instructor=$matches[1]', 'top');
        add_rewrite_rule('^mph-therapist/([^/]+)/?$', 'index.php?mph_therapist=$matches[1]', 'top');
    }

    public static function query_vars($vars) {$vars[]='mph_instructor';$vars[]='mph_therapist';return $vars;}

    public static function instructor_url($user) {
        $user=$user instanceof WP_User?$user:get_user_by('id',absint($user));
        if(!$user)return home_url('/');$custom=esc_url_raw(get_user_meta($user->ID,'mph_public_instructor_profile_url',true));if(!$custom)$custom=esc_url_raw(get_user_meta($user->ID,'mph_public_profile_url',true));
        return $custom?:home_url('/mph-instructor/'.rawurlencode($user->user_nicename).'/');
    }

    public static function therapist_url($user) {
        $user=$user instanceof WP_User?$user:get_user_by('id',absint($user));
        if(!$user)return home_url('/');$custom=esc_url_raw(get_user_meta($user->ID,'mph_public_therapist_profile_url',true));if(!$custom)$custom=esc_url_raw(get_user_meta($user->ID,'mph_public_profile_url',true));
        return $custom?:home_url('/mph-therapist/'.rawurlencode($user->user_nicename).'/');
    }

    public static function public_profile_url($user,$role='') {
        $user=$user instanceof WP_User?$user:get_user_by('id',absint($user));if(!$user)return'';
        $role=sanitize_key((string)$role);
        $is_instructor=MPH_Helpers::has_role('mph_instructor',$user);
        $is_therapist=MPH_Helpers::has_role('mph_therapist',$user);
        if($role==='instructor')return$is_instructor?self::instructor_url($user):'';
        if($role==='therapist')return$is_therapist?self::therapist_url($user):'';
        if($is_therapist)return self::therapist_url($user);
        if($is_instructor)return self::instructor_url($user);
        return'';
    }

    public static function instructor_template() {
        $therapist_slug=get_query_var('mph_therapist');$slug=$therapist_slug?:get_query_var('mph_instructor');if(!$slug)return;
        $user=get_user_by('slug',sanitize_title($slug));
        $is_therapist=(bool)$therapist_slug;$allowed=$user&&($is_therapist?MPH_Helpers::has_role('mph_therapist',$user):MPH_Helpers::has_role('mph_instructor',$user));
        if(!$user||!$allowed){status_header(404);nocache_headers();return;}
        MPH_Dashboard::enqueue_client_assets();get_header();
        $courses=!$is_therapist&&MPH_Tutor::active()?get_posts(array('post_type'=>tutor()->course_post_type,'post_status'=>'publish','author'=>$user->ID,'numberposts'=>12,'orderby'=>'date','order'=>'DESC')):array();
        $specialty=$is_therapist?get_user_meta($user->ID,'mph_therapist_specialty',true):get_user_meta($user->ID,'mph_major',true);
        ?><main class="mph-public-instructor <?php echo $is_therapist?'is-therapist':''; ?>" dir="rtl"><section class="mph-instructor-hero"><div class="mph-instructor-avatar"><?php echo get_avatar($user->ID,180); ?></div><div><small>پروفایل رسمی <?php echo $is_therapist?'درمانگر':'مدرس'; ?></small><h1><?php echo esc_html(MPH_Helpers::display_name($user)); ?></h1><p><?php echo esc_html($specialty?:($is_therapist?'درمانگر مجموعه':'مدرس مجموعه')); ?></p><div class="mph-instructor-stats"><?php if(!$is_therapist): ?><span><b><?php echo count($courses); ?></b> دوره فعال</span><?php endif; ?><span><b><?php echo esc_html(date_i18n('Y',strtotime($user->user_registered))); ?></b> سال عضویت</span></div></div></section><section class="mph-instructor-about"><h2>درباره <?php echo $is_therapist?'درمانگر':'مدرس'; ?></h2><p><?php echo esc_html($user->description?:'اطلاعات تکمیلی این پروفایل به‌زودی درج می‌شود.'); ?></p></section><?php if(!$is_therapist): ?><section class="mph-instructor-courses"><div class="mph-section-heading"><div><h2>دوره‌های مدرس</h2><p>دوره‌های منتشرشده و قابل ثبت‌نام</p></div></div><div class="mph-public-course-grid"><?php if(!$courses): ?><div class="mph-empty">هنوز دوره منتشرشده‌ای وجود ندارد.</div><?php endif;foreach($courses as$course): ?><article><a href="<?php echo esc_url(get_permalink($course)); ?>"><?php echo get_the_post_thumbnail($course->ID,'medium')?:'<span class="dashicons dashicons-welcome-learn-more"></span>'; ?><h3><?php echo esc_html($course->post_title); ?></h3><span>مشاهده دوره ←</span></a></article><?php endforeach; ?></div></section><?php else: ?><section class="mph-instructor-about"><h2>رزرو نوبت</h2><p>برای مشاهده زمان‌های آزاد و رزرو، وارد پنل کاربری شوید.</p><a class="mph-primary" href="<?php echo esc_url(add_query_arg('mph_open','book_appointment',MPH_Helpers::account_page_url())); ?>">مشاهده نوبت‌های آزاد</a></section><?php endif; ?></main><?php
        get_footer();exit;
    }

    public static function save_cart() {
        // The shared cart records explicit add/remove operations and must not be replaced by an old session snapshot.
        if (class_exists('MPH_Shared_Cart')) return;
        if(!is_user_logged_in()||!function_exists('WC')||!WC()->cart)return;
        $rows=array();foreach(WC()->cart->get_cart()as$item){$product=$item['data']??false;if(!$product||!$product->exists())continue;$rows[]=array('product_id'=>$product->get_id(),'variation_id'=>absint($item['variation_id']??0),'quantity'=>max(1,absint($item['quantity']??1)),'variation'=>(array)($item['variation']??array()),'course_id'=>absint($item['mph_course_id']??0),'delivery_mode'=>sanitize_key($item['mph_delivery_selected']??''));}
        if($rows)update_user_meta(get_current_user_id(),self::SAVED_CART,array('saved_at'=>time(),'items'=>$rows));else delete_user_meta(get_current_user_id(),self::SAVED_CART);
    }

    public static function restore_cart() {
        if (class_exists('MPH_Shared_Cart')) {MPH_Shared_Cart::sync();return;}
        if(is_admin()||wp_doing_ajax()||!is_user_logged_in()||!function_exists('WC')||!WC()->cart||!WC()->cart->is_empty())return;
        $saved=get_user_meta(get_current_user_id(),self::SAVED_CART,true);if(!is_array($saved)||empty($saved['items'])||time()-absint($saved['saved_at']??0)>14*DAY_IN_SECONDS){delete_user_meta(get_current_user_id(),self::SAVED_CART);return;}
        foreach((array)$saved['items']as$item){$product=function_exists('wc_get_product')?wc_get_product(absint($item['variation_id']?:$item['product_id'])):false;if(!$product||!$product->is_purchasable())continue;$course_id=absint($item['course_id']??0);$mode=sanitize_key($item['delivery_mode']??'');$data=$course_id&&$mode?array('mph_course_id'=>$course_id,'mph_delivery_selected'=>$mode,'mph_mode_key'=>$course_id.':'.$mode):array();WC()->cart->add_to_cart(absint($item['product_id']),max(1,absint($item['quantity'])),absint($item['variation_id']),array_map('sanitize_text_field',(array)$item['variation']),$data);}
        if(!WC()->cart->is_empty())WC()->cart->calculate_totals();
    }

    public static function clear_saved_cart($user_id=0){delete_user_meta($user_id?:get_current_user_id(),self::SAVED_CART);}

    public static function capacity_status($product_id) {
        $product_id=absint($product_id);$product=function_exists('wc_get_product')?wc_get_product($product_id):false;$capacity=$product?absint($product->get_meta('_mph_inperson_capacity')):0;$sold=0;
        $cache_key='mph_capacity_'.$product_id;$cached=get_transient($cache_key);if(is_array($cached)&&absint($cached['capacity']??-1)===$capacity)return$cached;
        if($capacity&&function_exists('wc_get_orders')){$orders=wc_get_orders(array('status'=>array('wc-processing','wc-completed','wc-on-hold'),'limit'=>-1,'return'=>'objects'));foreach($orders as$order)foreach($order->get_items()as$item)if(absint($item->get_product_id())===absint($product_id))$sold+=absint($item->get_quantity());}
        $status=array('capacity'=>$capacity,'sold'=>$sold,'remaining'=>$capacity?max(0,$capacity-$sold):PHP_INT_MAX,'full'=>$capacity>0&&$sold>=$capacity);set_transient($cache_key,$status,3*MINUTE_IN_SECONDS);return$status;
    }

    public static function flush_product_capacity_cache($product_id){$product_id=absint($product_id);delete_transient('mph_capacity_'.$product_id);self::notify_waitlist_if_open($product_id);}
    public static function flush_order_capacity_cache($order_id,$from,$to,$order){if(!$order&&function_exists('wc_get_order'))$order=wc_get_order($order_id);if(!$order)return;$counted=array('processing','completed','on-hold');$released=in_array($from,$counted,true)&&!in_array($to,$counted,true);foreach($order->get_items()as$item){$product_id=$item->get_product_id();delete_transient('mph_capacity_'.absint($product_id));$variation_id=$item->get_variation_id();if($variation_id)delete_transient('mph_capacity_'.absint($variation_id));if($released)self::notify_waitlist_if_open($variation_id?:$product_id);}}

    private static function notify_waitlist_if_open($product_id){$product_id=absint($product_id);$product=function_exists('wc_get_product')?wc_get_product($product_id):false;if(!$product||$product->get_meta(MPH_Courses::MODE_META)!=='inperson')return;$users=array_values(array_unique(array_filter(array_map('absint',(array)$product->get_meta('_mph_inperson_waitlist')))));if(!$users)return;$status=self::capacity_status($product_id);if($status['full']||$status['remaining']<1)return;$notify=array_slice($users,0,min(count($users),absint($status['remaining'])));$remaining=array_values(array_diff($users,$notify));$course_id=absint($product->get_meta(MPH_Courses::COURSE_META));$title=get_the_title($course_id)?:$product->get_name();foreach($notify as$user_id){$message='ظرفیت کلاس حضوری «'.$title.'» باز شده است. برای ثبت‌نام وارد صفحه دوره شوید.';MPH_Tickets::create_system_notification($user_id,'بازشدن ظرفیت کلاس',$message,'education');$user=get_user_by('id',$user_id);if($user&&is_email($user->user_email)&&strpos($user->user_email,'.invalid')===false)wp_mail($user->user_email,'بازشدن ظرفیت کلاس | '.get_bloginfo('name'),$message);}update_post_meta($product_id,'_mph_inperson_waitlist',$remaining);}

    public static function capacity_text($product_id) {$s=self::capacity_status($product_id);return !$s['capacity']?'ظرفیت آزاد':($s['full']?'ظرفیت تکمیل':'فقط '.number_format_i18n($s['remaining']).' جای خالی');}

    public static function waitlist_form($product_id) {
        if(!is_user_logged_in())return'<a class="mph-secondary" href="'.esc_url(MPH_Helpers::auth_popup_url()).'">ورود برای لیست انتظار</a>';
        return'<form class="mph-waitlist-form" data-mph-action="mph_join_waitlist"><input type="hidden" name="product_id" value="'.absint($product_id).'"><button type="submit" class="mph-secondary">عضویت در لیست انتظار</button><div class="mph-message"></div></form>';
    }

    public static function ajax_waitlist() {
        MPH_Helpers::verify_ajax();if(!is_user_logged_in())wp_send_json_error(array('message'=>'ابتدا وارد شوید.'),403);$product_id=absint($_POST['product_id']??0);$product=function_exists('wc_get_product')?wc_get_product($product_id):false;if(!$product||$product->get_meta(MPH_Courses::MODE_META)!=='inperson')wp_send_json_error(array('message'=>'کلاس حضوری معتبر نیست.'));$users=array_values(array_unique(array_filter(array_map('absint',(array)$product->get_meta('_mph_inperson_waitlist')))));$users[]=get_current_user_id();$product->update_meta_data('_mph_inperson_waitlist',array_values(array_unique($users)));$product->save();wp_send_json_success(array('message'=>'در لیست انتظار ثبت شدید؛ در صورت بازشدن ظرفیت اطلاع می‌دهیم.'));
    }

    /** تنظیمات اعلان بنا به درخواست حذف شده‌اند؛ کانال‌های سیستمی همیشه فعال‌اند. */
    public static function allows($user_id,$channel){return true;}
    public static function render_reminders() {
        $events=self::merged_reminders(get_current_user_id(),90*DAY_IN_SECONDS);ob_start();?><section class="mph-section mph-reminders"><div class="mph-section-heading"><div><h3>یادآوری‌ها</h3><p>یادآوری خودکار سیستم و مواردی که خودتان ثبت کرده‌اید؛ موارد مشابه یک‌بار نمایش داده می‌شوند.</p></div><span class="dashicons dashicons-clock"></span></div><form class="mph-form mph-reminder-form" data-mph-action="mph_reminder_save"><div class="mph-field-grid"><label><?php echo MPH_Helpers::required('عنوان یادآوری'); ?><input name="reminder_title" maxlength="140" required placeholder="مثلاً کلاس آنلاین یا آزمون پایان فصل"></label><label><?php echo MPH_Helpers::required('تاریخ و ساعت'); ?><input type="datetime-local" name="reminder_datetime" required></label></div><label>لینک مرتبط <small>(اختیاری)</small><input type="url" name="reminder_url" placeholder="https://…"></label><button class="mph-primary" type="submit"><span class="dashicons dashicons-plus-alt2"></span> ثبت یادآوری شخصی</button><div class="mph-message"></div></form><div class="mph-reminder-list"><?php if(!$events):?><div class="mph-empty">یادآوری آینده‌ای ثبت نشده است.</div><?php endif;foreach($events as$event):?><article class="is-<?php echo esc_attr($event['source']); ?>"><span class="dashicons <?php echo esc_attr($event['icon']); ?>"></span><div><small><?php echo esc_html($event['type']); ?><?php if(!empty($event['shared'])): ?> · <b>یادآوری مشترک</b><?php endif; ?></small><h4><?php echo esc_html($event['title']); ?></h4><p><?php echo esc_html($event['detail']); ?></p><?php if(!empty($event['url'])): ?><a href="<?php echo esc_url($event['url']); ?>" target="_blank" rel="noopener">بازکردن پیوند</a><?php endif; ?></div><time><?php echo esc_html(human_time_diff(time(),$event['time']).' دیگر'); ?></time><?php if($event['source']==='manual'): ?><form data-mph-action="mph_reminder_delete" onsubmit="return confirm('این یادآوری حذف شود؟')"><input type="hidden" name="reminder_id" value="<?php echo esc_attr($event['id']); ?>"><button class="mph-icon-danger" type="submit" aria-label="حذف یادآوری"><span class="dashicons dashicons-trash"></span></button><div class="mph-message"></div></form><?php endif; ?></article><?php endforeach;?></div></section><?php return ob_get_clean();
    }

    public static function reminder_popup() {
        if(!is_user_logged_in())return'';$events=array_slice(self::merged_reminders(get_current_user_id(),7*DAY_IN_SECONDS),0,3);if(!$events)return'';
        $hash=md5(implode('|',array_map(function($event){return$event['title'].'@'.$event['time'];},$events)));ob_start();?><aside class="mph-reminder-popup" data-mph-reminder-popup data-reminder-hash="<?php echo esc_attr($hash); ?>" role="status"><button type="button" data-mph-reminder-close aria-label="بستن">×</button><header><span class="dashicons dashicons-clock"></span><div><b>یادآوری‌های نزدیک شما</b><small>تا ۷ روز آینده</small></div></header><?php foreach($events as$event): ?><article><div><b><?php echo esc_html($event['title']); ?></b><small><?php echo esc_html($event['type'].(!empty($event['shared'])?' · یادآوری مشترک':'')); ?></small></div><time><?php echo esc_html(human_time_diff(time(),$event['time']).' دیگر'); ?></time></article><?php endforeach; ?><button type="button" class="mph-reminder-open" data-panel="reminders">مشاهده همه یادآوری‌ها</button></aside><?php return ob_get_clean();
    }

    public static function ajax_reminder_save() {
        MPH_Helpers::verify_ajax();if(!is_user_logged_in())wp_send_json_error(array('message'=>'ابتدا وارد شوید.'),403);$title=MPH_Helpers::posted('reminder_title');$datetime=MPH_Helpers::posted('reminder_datetime');$stamp=strtotime($datetime);$url=esc_url_raw(MPH_Helpers::posted('reminder_url'));
        if(!$title||!MPH_Helpers::valid_person_name($title))wp_send_json_error(array('message'=>'عنوان یادآوری باید شامل حروف باشد.'));if(!$stamp||$stamp<=time())wp_send_json_error(array('message'=>'زمان یادآوری باید در آینده باشد.'));
        $rows=self::manual_reminders(get_current_user_id(),false);$rows[]=array('id'=>function_exists('wp_generate_uuid4')?wp_generate_uuid4():uniqid('rem-',true),'title'=>$title,'time'=>$stamp,'url'=>$url,'created'=>time());usort($rows,function($a,$b){return absint($a['time']??0)<=>absint($b['time']??0);});update_user_meta(get_current_user_id(),self::MANUAL_REMINDERS,array_slice($rows,-100));wp_send_json_success(array('message'=>'یادآوری شخصی ثبت شد.','html'=>self::render_reminders()));
    }

    public static function ajax_reminder_delete() {
        MPH_Helpers::verify_ajax();if(!is_user_logged_in())wp_send_json_error(array('message'=>'ابتدا وارد شوید.'),403);$id=MPH_Helpers::posted('reminder_id');$rows=array_values(array_filter(self::manual_reminders(get_current_user_id(),false),function($row)use($id){return(string)($row['id']??'')!==$id;}));update_user_meta(get_current_user_id(),self::MANUAL_REMINDERS,$rows);wp_send_json_success(array('message'=>'یادآوری حذف شد.','html'=>self::render_reminders()));
    }

    private static function manual_reminders($user_id,$future_only=true) {
        $rows=get_user_meta(absint($user_id),self::MANUAL_REMINDERS,true);if(!is_array($rows))return array();$result=array();foreach($rows as$row){if(!is_array($row))continue;$time=absint($row['time']??0);if(!$time||($future_only&&$time<time()-MINUTE_IN_SECONDS))continue;$result[]=array('id'=>sanitize_text_field($row['id']??''),'title'=>sanitize_text_field($row['title']??''),'time'=>$time,'url'=>esc_url_raw($row['url']??''),'created'=>absint($row['created']??0));}return$result;
    }

    public static function reminder_count($user_id = 0) {
        $user_id = absint($user_id ?: get_current_user_id());
        if (!$user_id) return 0;
        try {
            $events = self::merged_reminders($user_id, 90 * DAY_IN_SECONDS);
            return is_array($events) ? count($events) : 0;
        } catch (Throwable $e) {
            return 0;
        }
    }

    private static function merged_reminders($user_id,$window) {
        $events=array();$seen=array();foreach(self::upcoming_for_user($user_id,$window)as$event){$event['source']='system';$event['id']='';$event['url']='';$event['shared']=false;$key=self::reminder_key($event['title'],$event['time']);if(isset($seen[$key]))continue;$seen[$key]=count($events);$events[]=$event;}foreach(self::manual_reminders($user_id)as$manual){if($manual['time']>time()+$window)continue;$key=self::reminder_key($manual['title'],$manual['time']);if(isset($seen[$key])){$events[$seen[$key]]['shared']=true;continue;}$seen[$key]=count($events);$events[]=array('source'=>'manual','id'=>$manual['id'],'type'=>'یادآوری شخصی','title'=>$manual['title'],'detail'=>date_i18n('Y/m/d H:i',$manual['time']),'time'=>$manual['time'],'icon'=>'dashicons-calendar-alt','url'=>$manual['url'],'shared'=>false);}usort($events,function($a,$b){return$a['time']<=>$b['time'];});return$events;
    }

    public static function notification_payload($user_id=0) {
        $user_id=absint($user_id?:get_current_user_id());if(!$user_id)return array();$events=self::merged_reminders($user_id,24*HOUR_IN_SECONDS);if(!$events)return array();$event=$events[0];$stamp=absint($event['time']??0);if(!$stamp)return array();return array('id'=>'reminder-'.md5($event['title'].'|'.$stamp),'type'=>'reminder','title'=>'یادآوری: '.$event['title'],'body'=>($event['type']??'یادآوری').' · '.human_time_diff(time(),$stamp).' دیگر','panel'=>'reminders','url'=>esc_url_raw($event['url']??''),'timestamp'=>$stamp,'icon'=>'dashicons-clock');
    }

    private static function reminder_key($title,$time) {$title=trim(preg_replace('/\s+/u',' ',(string)$title));$title=function_exists('mb_strtolower')?mb_strtolower($title,'UTF-8'):strtolower($title);$title=remove_accents($title);return md5($title.'|'.wp_date('Y-m-d H:i',absint($time)));}

    private static function upcoming_for_user($user_id,$window) {
        $result=array();$now=time();
        if(function_exists('wc_get_orders')){$statuses=array_map(function($s){return'wc-'.$s;},wc_get_is_paid_statuses());$orders=wc_get_orders(array('customer_id'=>absint($user_id),'status'=>$statuses,'limit'=>-1,'return'=>'objects'));foreach($orders as$order)foreach($order->get_items()as$item){$start=$item->get_meta('_mph_class_start');$stamp=$start?strtotime($start):0;if($stamp>$now&&$stamp<=$now+$window)$result[]=array('type'=>'کلاس حضوری','title'=>$item->get_name(),'detail'=>date_i18n('Y/m/d H:i',$stamp).' · '.($item->get_meta('_mph_class_address')?:'محل برگزاری اعلام می‌شود'),'time'=>$stamp,'icon'=>'dashicons-location-alt','order_id'=>$order->get_id());}}
        if(MPH_Tutor::active()){$types=array_filter(array('tutor_quiz','tutor_assignments','tutor_assignment'),function($type){return post_type_exists($type);});if($types){$posts=get_posts(array('post_type'=>$types,'post_status'=>array('publish','future'),'numberposts'=>-1));foreach($posts as$post){$parent=wp_get_post_parent_id($post);if($parent&&get_post_type($parent)==='topics')$parent=wp_get_post_parent_id($parent);if(!$parent||(!MPH_Courses::has_access($user_id,$parent,'online')&&!MPH_Courses::has_access($user_id,$parent,'offline')&&!MPH_Courses::has_access($user_id,$parent,'inperson')))continue;$is_quiz=strpos($post->post_type,'quiz')!==false;$date=$is_quiz?get_post_meta($post->ID,'_mph_quiz_start',true):'';if(!$date)foreach(array('_mph_assignment_due','_tutor_assignment_deadline','assignment_due_date')as$key){$date=get_post_meta($post->ID,$key,true);if($date)break;}$stamp=$date?strtotime(is_array($date)?'':$date):0;if($stamp>$now&&$stamp<=$now+$window)$result[]=array('type'=>$is_quiz?'آزمون':'تکلیف','title'=>$post->post_title,'detail'=>date_i18n('Y/m/d H:i',$stamp).' · '.get_the_title($parent),'time'=>$stamp,'icon'=>$is_quiz?'dashicons-editor-help':'dashicons-edit-page','order_id'=>0);}}}
        usort($result,function($a,$b){return$a['time']<=>$b['time'];});return$result;
    }

    public static function send_reminders() {
        if(!function_exists('wc_get_orders'))return;$users=get_users(array('fields'=>'ids'));foreach($users as$user_id){if(!self::allows($user_id,'reminders'))continue;foreach(self::upcoming_for_user($user_id,26*HOUR_IN_SECONDS)as$event){if($event['time']-time()<20*HOUR_IN_SECONDS)continue;$key='_mph_reminder_'.md5($user_id.'|'.$event['title'].'|'.$event['time']);if(get_user_meta($user_id,$key,true))continue;$message=$event['title'].' در '.$event['detail'].' برگزار می‌شود.';if(self::allows($user_id,'inapp'))MPH_Tickets::create_system_notification($user_id,'یادآوری کلاس',$message,'reminder');$user=get_user_by('id',$user_id);if($user&&self::allows($user_id,'email')&&is_email($user->user_email))wp_mail($user->user_email,'یادآوری کلاس | '.get_bloginfo('name'),$message);update_user_meta($user_id,$key,time());}}
    }

    public static function track($stage,$amount=0) {$allowed=array('view','cart','checkout','purchase');if(!in_array($stage,$allowed,true))return;$data=get_option(self::FUNNEL,array());foreach($allowed as$key)if(!isset($data[$key]))$data[$key]=0;$data[$stage]++;if($stage==='purchase')$data['revenue']=floatval($data['revenue']??0)+floatval($amount);update_option(self::FUNNEL,$data,false);}
    public static function track_course_view(){if(MPH_Tutor::active()&&is_singular(tutor()->course_post_type))self::track('view');}
    public static function track_cart(){self::track('cart');}
    public static function track_checkout($order){if(!$order||$order->get_meta('_mph_funnel_checkout'))return;$order->update_meta_data('_mph_funnel_checkout',1);$order->save();self::track('checkout');}
    public static function track_purchase($order_id){$order=function_exists('wc_get_order')?wc_get_order($order_id):false;if(!$order||$order->get_meta('_mph_funnel_purchase'))return;$order->update_meta_data('_mph_funnel_purchase',1);$order->save();self::track('purchase',$order->get_total());self::clear_saved_cart($order->get_customer_id());}

    public static function render_reports() {
        $f=wp_parse_args((array)get_option(self::FUNNEL,array()),array('view'=>0,'cart'=>0,'checkout'=>0,'purchase'=>0,'revenue'=>0));$orders=function_exists('wc_get_orders')?wc_get_orders(array('status'=>array_map(function($s){return'wc-'.$s;},wc_get_is_paid_statuses()),'date_created'=>'>'.(time()-90*DAY_IN_SECONDS),'limit'=>-1,'return'=>'objects')):array();$revenue=0;$discount=0;$payments=array();$customers=array();foreach($orders as$order){$revenue+=(float)$order->get_total();$discount+=(float)$order->get_discount_total();$method=$order->get_payment_method_title()?:'نامشخص';$payments[$method]=($payments[$method]??0)+1;$cid=$order->get_customer_id();if($cid)$customers[$cid]=($customers[$cid]??0)+1;}$repeat=count(array_filter($customers,function($n){return$n>1;}));
        ob_start();?><section class="mph-section mph-business-reports"><div class="mph-section-heading"><div><h3>گزارش فروش و قیف خرید</h3><p>نمای زنده ۹۰ روز اخیر و آمار تجمعی قیف</p></div><span class="dashicons dashicons-chart-bar"></span></div><div class="mph-report-kpis"><article><small>فروش ۹۰ روز</small><b><?php echo wp_kses_post(function_exists('wc_price')?wc_price($revenue):number_format_i18n($revenue)); ?></b></article><article><small>سفارش موفق</small><b><?php echo count($orders); ?></b></article><article><small>تخفیف داده‌شده</small><b><?php echo wp_kses_post(function_exists('wc_price')?wc_price($discount):number_format_i18n($discount)); ?></b></article><article><small>مشتری تکراری</small><b><?php echo $repeat; ?></b></article></div><div class="mph-funnel"><div style="--v:100%"><b><?php echo absint($f['view']); ?></b><span>بازدید دوره</span></div><div style="--v:<?php echo esc_attr($f['view']?max(12,round($f['cart']/$f['view']*100)):12); ?>%"><b><?php echo absint($f['cart']); ?></b><span>افزودن به سبد</span></div><div style="--v:<?php echo esc_attr($f['view']?max(12,round($f['checkout']/$f['view']*100)):12); ?>%"><b><?php echo absint($f['checkout']); ?></b><span>صورتحساب</span></div><div style="--v:<?php echo esc_attr($f['view']?max(12,round($f['purchase']/$f['view']*100)):12); ?>%"><b><?php echo absint($f['purchase']); ?></b><span>خرید موفق</span></div></div><div class="mph-report-split"><div><h4>روش‌های پرداخت</h4><?php if(!$payments)echo'<p>هنوز داده‌ای ثبت نشده است.</p>';foreach($payments as$name=>$count)echo'<p><span>'.esc_html($name).'</span><b>'.absint($count).'</b></p>';?></div><div><h4>خروجی استاندارد Excel</h4><div class="mph-export-grid"><?php foreach(array('orders'=>'سفارش‌ها','students'=>'دانشجویان','receipts'=>'فیش‌ها','progress'=>'پیشرفت دوره')as$type=>$label):?><a class="mph-secondary" href="<?php echo esc_url(self::export_url($type)); ?>"><span class="dashicons dashicons-media-spreadsheet"></span><?php echo esc_html($label); ?></a><?php endforeach;?></div></div></div></section><?php return ob_get_clean();
    }

    private static function export_url($type){return wp_nonce_url(admin_url('admin-post.php?action=mph_growth_export&type='.sanitize_key($type)),'mph_growth_export_'.sanitize_key($type));}
    public static function export(){
        if(!self::can_manage())wp_die('دسترسی ندارید.','',array('response'=>403));
        $type=sanitize_key(wp_unslash($_GET['type']??''));
        if(!in_array($type,array('orders','students','receipts','progress'),true)||!wp_verify_nonce(sanitize_text_field(wp_unslash($_GET['_wpnonce']??'')),'mph_growth_export_'.$type))wp_die('لینک معتبر نیست.','',array('response'=>403));
        if($type==='receipts'){$orders=function_exists('wc_get_orders')?wc_get_orders(array('limit'=>-1,'return'=>'objects','orderby'=>'date','order'=>'DESC','meta_key'=>MPH_Commerce::RECEIPT_META,'meta_value'=>'yes')):array();MPH_XLSX::export_receipts($orders);}
        while(ob_get_level())ob_end_clean();nocache_headers();header('Content-Type: text/csv; charset=UTF-8');header('Content-Disposition: attachment; filename="mph-'.$type.'-'.wp_date('Y-m-d').'.csv"');$out=fopen('php://output','w');fwrite($out,"\xEF\xBB\xBF");
        if($type==='orders'||$type==='receipts'){
            $columns=array('شماره سفارش','مشتری','تلفن','مبلغ','تخفیف','روش پرداخت','وضعیت','تاریخ');if($type==='receipts')$columns[]= 'فایل فیش ارسالی';fputcsv($out,$columns);
            $args=array('limit'=>-1,'return'=>'objects','orderby'=>'date','order'=>'DESC');if($type==='receipts'){$args['meta_key']=MPH_Commerce::RECEIPT_META;$args['meta_value']='yes';}
            foreach((array)wc_get_orders($args)as$order){$row=array($order->get_order_number(),$order->get_formatted_billing_full_name(),$order->get_billing_phone(),$order->get_total(),$order->get_discount_total(),$order->get_payment_method_title(),wc_get_order_status_name($order->get_status()),$order->get_date_created()?$order->get_date_created()->date('Y-m-d H:i'):'');if($type==='receipts'){$file_id=absint($order->get_meta(MPH_Commerce::RECEIPT_FILE));$row[]=$file_id?MPH_Commerce::receipt_url($order->get_id(),$file_id):'بدون فایل';}fputcsv($out,$row);}
        }elseif($type==='students'){
            fputcsv($out,array('نام','ایمیل','تلفن','تعداد دوره ثبت‌نامی','تاریخ عضویت'));
            foreach(get_users(array('number'=>-1))as$user){$count=MPH_Tutor::active()?count(get_posts(array('post_type'=>'tutor_enrolled','post_status'=>'completed','author'=>$user->ID,'numberposts'=>-1,'fields'=>'ids'))):0;fputcsv($out,array(MPH_Helpers::display_name($user),$user->user_email,get_user_meta($user->ID,'mph_phone',true),$count,$user->user_registered));}
        }else{
            fputcsv($out,array('هنرجو','ایمیل','دوره','درصد پیشرفت','تاریخ ثبت‌نام'));
            $enrollments=MPH_Tutor::active()?get_posts(array('post_type'=>'tutor_enrolled','post_status'=>'completed','numberposts'=>-1,'orderby'=>'date','order'=>'DESC')):array();foreach($enrollments as$enrollment){$user=get_user_by('id',$enrollment->post_author);$course_id=absint($enrollment->post_parent);fputcsv($out,array($user?MPH_Helpers::display_name($user):'کاربر حذف‌شده',$user?$user->user_email:'',get_the_title($course_id),MPH_Tutor::progress_percent($course_id,$enrollment->post_author),$enrollment->post_date));}
        }
        fclose($out);exit;
    }
    private static function can_manage(){return is_user_logged_in()&&(current_user_can('manage_options')||current_user_can('mph_manage_portal')||MPH_Helpers::has_role('mph_manager'));}
}
