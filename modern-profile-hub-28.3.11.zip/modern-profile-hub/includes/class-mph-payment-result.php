<?php
defined('ABSPATH') || exit;

final class MPH_Payment_Result {
    public static function init() {
        add_action('template_redirect',array(__CLASS__,'route'),2);
        add_action('wp_ajax_mph_payment_recheck',array(__CLASS__,'recheck'));
        add_action('wp_ajax_mph_payment_retry',array(__CLASS__,'retry'));
        add_action('woocommerce_order_status_changed',array(__CLASS__,'status_changed'),40,4);
    }
    public static function url($order) {return add_query_arg(array('mph_payment_result'=>$order->get_id()),MPH_Helpers::account_page_url());}
    public static function can_view($order) {return $order && is_user_logged_in() && ((int)$order->get_customer_id()===get_current_user_id() || current_user_can('manage_options') || current_user_can('mph_manage_portal'));}

    public static function state($order) {
        if ($order->get_meta('_mph_payment_review')) return array('key'=>'review','title'=>'سفارش نیازمند بررسی مدیر است','message'=>'وضعیت این سفارش نیاز به بررسی پشتیبانی دارد. دوباره فیش نفرستید مگر مدیر بخواهد.','icon'=>'warning');
        if ($order->is_paid()) return array('key'=>'success','title'=>'سفارش تأیید شد','message'=>'پرداخت/فیش این سفارش تأیید شده و دسترسی‌ها فعال است.','icon'=>'yes-alt');
        if ($order->get_meta(MPH_Commerce::RECEIPT_STATUS)==='pending') return array('key'=>'pending','title'=>'فیش در انتظار بررسی است','message'=>'فیش ثبت شده است؛ تأیید نهایی پس از بررسی مدیر انجام می‌شود.','icon'=>'clock');
        if ($order->get_meta(MPH_Commerce::RECEIPT_STATUS)==='rejected') return array('key'=>'failed','title'=>'فیش رد شد','message'=>'فیش این سفارش تأیید نشد. در صورت نیاز فیش صحیح را دوباره از سبد ارسال کنید.','icon'=>'dismiss');
        if ($order->has_status(array('failed','cancelled','refunded'))) return array('key'=>'failed','title'=>'این سفارش فعال نیست','message'=>'وضعیت سفارش: '.wc_get_order_status_name($order->get_status()),'icon'=>'dismiss');
        return array('key'=>'pending','title'=>'در انتظار فیش واریزی','message'=>'سفارش هنوز فیش ندارد. از سبد خرید فیش را آپلود کنید.','icon'=>'clock');
    }

    public static function render($order) {
        if (!self::can_view($order)) return '<div class="mph-empty">برای دیدن نتیجه، وارد حساب صاحب سفارش شوید.</div>';
        $state=self::state($order);$ref=(string)$order->get_transaction_id();
        ob_start(); ?>
        <section class="mph-section mph-payment-result is-<?php echo esc_attr($state['key']); ?>">
            <span class="mph-result-icon dashicons dashicons-<?php echo esc_attr($state['icon']); ?>"></span>
            <h2><?php echo esc_html($state['title']); ?></h2><p><?php echo esc_html($state['message']); ?></p>
            <dl class="mph-result-details"><div><dt>شماره سفارش</dt><dd><?php echo esc_html($order->get_order_number()); ?></dd></div><div><dt>مبلغ</dt><dd><?php echo wp_kses_post($order->get_formatted_order_total()); ?></dd></div><div><dt>روش</dt><dd><?php echo esc_html($order->get_meta(MPH_Commerce::RECEIPT_META)==='yes'?'فیش واریزی':($order->get_payment_method_title()?:'—')); ?></dd></div></dl>
            <?php if($order->get_meta('_mph_appointment_conflicts')): ?><p class="mph-message is-error">وضعیت نوبت نیازمند بررسی مدیر است؛ برای تعیین تکلیف با پشتیبانی تماس بگیرید.</p><?php endif; ?>
            <div class="mph-result-actions"><a class="mph-primary" href="<?php echo esc_url(add_query_arg(array('mph_open'=>'orders','order_id'=>$order->get_id()),MPH_Helpers::account_page_url())); ?>">سوابق خرید و صورتحساب</a><a class="mph-secondary" href="<?php echo esc_url(MPH_Commerce::cart_redirect()); ?>">بازگشت به سبد / ارسال فیش</a></div>
            <?php echo self::timeline($order); ?>
        </section><?php return MPH_Helpers::secure_form_markup(ob_get_clean());
    }

    public static function timeline($order) {
        if (!self::can_view($order)) return '';
        $rows=(array)$order->get_meta('_mph_order_events');
        if (!$rows) return '';
        $html='<section class="mph-order-timeline"><h3>مسیر سفارش</h3><ol>';
        foreach ($rows as $row) if (isset($row['time'],$row['message'])) $html.='<li><time>'.esc_html(wp_date('Y/m/d H:i',(int)$row['time'])).'</time><span>'.esc_html($row['message']).'</span></li>';
        return $html.'</ol></section>';
    }

    public static function route() {
        if (empty($_GET['mph_payment_result'])) return;
        nocache_headers();header('X-Robots-Tag: noindex, nofollow',true);header('Referrer-Policy: same-origin',true);
        $order=function_exists('wc_get_order')?wc_get_order(absint($_GET['mph_payment_result'])):false;
        MPH_Dashboard::enqueue_client_assets();get_header();
        echo '<main class="mph-root mph-inline-mode mph-result-page" dir="rtl">';
        if (!is_user_logged_in()) echo '<div class="mph-inline-auth"><p>برای مشاهده نتیجه پرداخت وارد حساب خود شوید.</p>'.MPH_Auth::render().'</div>';
        elseif (!self::can_view($order)) echo '<div class="mph-empty">این سفارش برای حساب شما قابل مشاهده نیست.</div>';
        else echo self::render($order);
        echo '</main>';wp_footer();echo '</body></html>';exit;
    }

    private static function requested_order() {
        MPH_Helpers::verify_ajax();$order=wc_get_order(absint($_POST['order_id']??0));
        if (!self::can_view($order)) wp_send_json_error(array('message'=>'سفارش برای این حساب قابل مشاهده نیست.'),403);
        if (!MPH_Security::allow('payment_check',6,MINUTE_IN_SECONDS,'u:'.get_current_user_id())) wp_send_json_error(array('message'=>'کمی بعد دوباره بررسی کنید.'),429);
        return $order;
    }
    public static function recheck() {
        $order=self::requested_order();
        wp_send_json_success(array('message'=>'وضعیت فعلی سفارش بازخوانی شد. پرداخت آنلاین وجود ندارد.','redirect'=>self::url($order)));
    }
    public static function can_retry($order) {
        return false;
    }
    public static function retry() {
        self::requested_order();
        wp_send_json_error(array('message'=>'پرداخت آنلاین غیرفعال است. از سبد خرید فیش واریزی را آپلود کنید.'),400);
    }
    public static function status_changed($id,$from,$to,$order) {
        if (!$order || !$order->get_meta('_mph_cart_snapshot')) return;
        MPH_Payment_Attempts::event($order,'status_'.$to,'وضعیت سفارش: '.wc_get_order_status_name($to));
    }
}
