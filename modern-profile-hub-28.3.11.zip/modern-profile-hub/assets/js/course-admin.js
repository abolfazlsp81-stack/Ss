(function(){
  'use strict';
  const one=(s,c)=>(c||document).querySelector(s),all=(s,c)=>Array.from((c||document).querySelectorAll(s));
  const pad=v=>String(v).padStart(2,'0'),div=(a,b)=>Math.floor(a/b),mod=(a,b)=>a-Math.floor(a/b)*b;
  function g2j(gy,gm,gd){let gdm=[0,31,59,90,120,151,181,212,243,273,304,334],gy2=gm>2?gy+1:gy,days=355666+365*gy+div(gy2+3,4)-div(gy2+99,100)+div(gy2+399,400)+gd+gdm[gm-1],jy=-1595+33*div(days,12053);days=mod(days,12053);jy+=4*div(days,1461);days=mod(days,1461);if(days>365){jy+=div(days-1,365);days=mod(days-1,365);}return days<186?[jy,1+div(days,31),1+mod(days,31)]:[jy,7+div(days-186,30),1+mod(days-186,30)];}
  function j2g(jy,jm,jd){jy+=1595;let days=-355668+365*jy+div(jy,33)*8+div(mod(jy,33)+3,4)+jd+(jm<7?(jm-1)*31:(jm-7)*30+186),gy=400*div(days,146097);days=mod(days,146097);if(days>36524){gy+=100*div(--days,36524);days=mod(days,36524);if(days>=365)days++;}gy+=4*div(days,1461);days=mod(days,1461);if(days>365){gy+=div(days-1,365);days=mod(days-1,365);}let gd=days+1,sal=[0,31,((gy%4===0&&gy%100!==0)||gy%400===0)?29:28,31,30,31,30,31,31,30,31,30,31],gm=1;while(gm<=12&&gd>sal[gm])gd-=sal[gm++];return[gy,gm,gd];}
  function latin(value){return String(value||'').replace(/[۰-۹]/g,d=>'۰۱۲۳۴۵۶۷۸۹'.indexOf(d)).replace(/[٠-٩]/g,d=>'٠١٢٣٤٥٦٧٨٩'.indexOf(d));}
  function bindJalaliCourseDate(root){const input=one('input[name="course_calendar_date"]',root);if(!input||input.dataset.mphJalaliCourseBound)return;input.dataset.mphJalaliCourseBound='1';const match=latin(input.value).match(/^(\d{4})-(\d{2})-(\d{2})$/),now=new Date(),j=match?g2j(+match[1],+match[2],+match[3]):g2j(now.getFullYear(),now.getMonth()+1,now.getDate());const visible=document.createElement('input');visible.type='text';visible.inputMode='numeric';visible.dir='ltr';visible.placeholder='۱۴۰۵/۰۶/۰۷';visible.value=j[0]+'/'+pad(j[1])+'/'+pad(j[2]);visible.setAttribute('aria-label','تاریخ شروع شمسی');input.hidden=true;input.insertAdjacentElement('afterend',visible);const sync=()=>{const m=latin(visible.value).replace(/[-.]/g,'/').match(/^(1[34]\d{2})\/(\d{1,2})\/(\d{1,2})$/);if(!m){visible.setCustomValidity('تاریخ شمسی را به شکل ۱۴۰۵/۰۶/۰۷ وارد کنید.');return;}const g=j2g(+m[1],+m[2],+m[3]);input.value=g[0]+'-'+pad(g[1])+'-'+pad(g[2]);visible.setCustomValidity('');};visible.addEventListener('input',sync);sync();}
  function lessonRow(s,l){return '<div class="mph-course-lesson" data-course-lesson draggable="true"><span class="dashicons dashicons-move mph-lesson-drag"></span><b>درس '+(l+1)+'</b><input name="lesson_title['+s+']['+l+']" placeholder="عنوان درس" required><div class="mph-lesson-media"><input type="hidden" name="lesson_video['+s+']['+l+']" value="0" data-course-video-id><span data-course-video-name>بدون ویدئو</span><button type="button" class="button" data-course-video>ویدئو</button></div><div class="mph-lesson-media"><input type="hidden" name="lesson_note['+s+']['+l+']" value="0" data-course-note-id><span data-course-note-name>بدون جزوه</span><button type="button" class="button" data-course-note>جزوه</button></div><button type="button" class="button-link-delete" data-remove-course-lesson>حذف</button></div>';}
  function sectionRow(s){return '<article class="mph-curriculum-section" data-course-section draggable="true"><header><span class="dashicons dashicons-menu mph-course-drag"></span><b>فصل '+(s+1)+'</b><input name="section_title['+s+']" placeholder="عنوان فصل" required><button type="button" class="button" data-add-course-lesson>＋ درس</button><button type="button" class="button-link-delete" data-remove-course-section>حذف فصل</button></header><div class="mph-course-lessons" data-course-lessons>'+lessonRow(s,0)+'</div></article>';}
  function reindex(root){all('[data-course-section]',root).forEach((section,s)=>{const chapter=one('header>b',section);if(chapter)chapter.textContent='فصل '+(s+1);const sectionTitle=one('input[name^="section_title["]',section);if(sectionTitle)sectionTitle.name='section_title['+s+']';all('[data-course-lesson]',section).forEach((lesson,l)=>{const label=one('b',lesson);if(label)label.textContent='درس '+(l+1);const title=one('input[name^="lesson_title["]',lesson),video=one('input[name^="lesson_video["]',lesson),note=one('input[name^="lesson_note["]',lesson);if(title)title.name='lesson_title['+s+']['+l+']';if(video)video.name='lesson_video['+s+']['+l+']';if(note)note.name='lesson_note['+s+']['+l+']';});});const empty=one('[data-curriculum-empty]',root);if(empty)empty.hidden=all('[data-course-section]',root).length>0;}
  function sortable(container,itemSelector,root){if(!container)return;let dragged=null;container.addEventListener('dragstart',event=>{const item=event.target.closest(itemSelector);if(!item||item.parentElement!==container)return;dragged=item;item.classList.add('is-dragging');event.dataTransfer.effectAllowed='move';});container.addEventListener('dragover',event=>{if(!dragged)return;event.preventDefault();const target=event.target.closest(itemSelector);if(!target||target===dragged||target.parentElement!==container)return;const rect=target.getBoundingClientRect();container.insertBefore(dragged,event.clientY<rect.top+rect.height/2?target:target.nextSibling);});container.addEventListener('dragend',()=>{if(dragged)dragged.classList.remove('is-dragging');dragged=null;reindex(root);});}
  function bindLessonSorts(root){all('[data-course-lessons]',root).forEach(box=>{if(box.dataset.sortBound)return;box.dataset.sortBound='1';sortable(box,'[data-course-lesson]',root);});}
  function mediaFrame(options,onSelect){if(!window.wp||!wp.media){alert('کتابخانه رسانه وردپرس بارگذاری نشده است.');return;}const frame=wp.media(options);frame.on('select',()=>onSelect(frame.state().get('selection').first().toJSON()));frame.open();}
  function setStatus(root,text,type){const node=one('[data-course-save-status]',root);if(!node)return;node.textContent=text||'';node.className='mph-course-save-status '+(type?'is-'+type:'');}
  function parseResponse(response){return response.text().then(text=>{try{return JSON.parse(text);}catch(e){throw new Error(text==='0'?'درخواست ذخیره توسط وردپرس اجرا نشد. افزونه را یک‌بار غیرفعال و فعال کنید.':'پاسخ نامعتبر از سرور دریافت شد.');}});}

  function bindInstructorPicker(root){
    all('[data-mph-instructor-picker],[data-mph-instructor-select]', root).forEach(node=>{
      const select = node.matches('[data-mph-instructor-select]') ? node : one('[data-mph-instructor-select]', node);
      if(!select || select.dataset.mphInstructorBound) return;
      select.dataset.mphInstructorBound = '1';
      const scope = select.closest('form') || select.closest('[data-mph-instructor-picker]') || root || document;
      const custom = one('[data-mph-custom-instructor]', scope) || one('[data-mph-custom-instructor]', select.parentElement && select.parentElement.parentElement);
      const sync = ()=>{
        const isCustom = select.value === 'custom';
        if(custom){
          custom.hidden = !isCustom;
          const input = one('input', custom);
          if(input){ if(isCustom) input.setAttribute('required','required'); else input.removeAttribute('required'); }
        }
      };
      select.addEventListener('change', sync);
      sync();
    });
  }

  function manageModalShell(){
    let shell = one('[data-mph-course-manage-modal]');
    if(shell) return shell;
    shell = document.createElement('div');
    shell.className = 'mph-course-manage-modal';
    shell.setAttribute('data-mph-course-manage-modal','');
    shell.hidden = true;
    shell.innerHTML = '<div class="mph-course-manage-backdrop" data-mph-manage-close></div><div class="mph-course-manage-dialog" role="dialog" aria-modal="true"><div class="mph-course-manage-body" data-mph-manage-body><div class="mph-empty">در حال بارگذاری…</div></div></div>';
    document.body.appendChild(shell);
    shell.addEventListener('click', ev=>{
      if(ev.target.closest('[data-mph-manage-close]')){ shell.hidden = true; return; }
      const tab = ev.target.closest('[data-manage-tab]');
      if(tab){
        const panel = one('[data-mph-course-manage-panel]', shell);
        if(!panel) return;
        all('[data-manage-tab]', panel).forEach(b=>b.classList.toggle('is-active', b===tab));
        all('[data-manage-panel]', panel).forEach(p=>p.classList.toggle('is-active', p.getAttribute('data-manage-panel')===tab.getAttribute('data-manage-tab')));
        return;
      }
      const add = ev.target.closest('[data-mph-add-session]');
      if(add){
        const box = one('[data-mph-session-rows]', shell);
        if(!box) return;
        const row = document.createElement('div');
        row.className = 'mph-admin-grid mph-session-row';
        row.innerHTML = '<label>عنوان<input type="text" name="session_title[]" value=""></label><label>شروع<input type="datetime-local" name="session_start[]" value=""></label><label>پایان<input type="datetime-local" name="session_end[]" value=""></label>';
        box.appendChild(row);
      }
    });
    return shell;
  }

  function openCourseManage(courseId, title){
    const shell = manageModalShell();
    const body = one('[data-mph-manage-body]', shell);
    shell.hidden = false;
    body.innerHTML = '<div class="mph-empty">در حال بارگذاری مدیریت دوره'+(title?(' «'+title+'»'):'')+'…</div>';
    const data = new FormData();
    data.set('action','mph_course_manage_panel');
    data.set('course_id', String(courseId));
    const nonce = (window.MPH_DATA && MPH_DATA.nonce) || (window.MPH && (MPH.nonce||MPH.ajaxNonce)) || (window.MPH_ADMIN && MPH_ADMIN.nonce) || '';
    if(nonce) data.set('nonce', nonce);
    const ajax = (window.MPH_DATA && MPH_DATA.ajaxUrl) || (window.MPH && MPH.ajaxUrl) || (window.MPH_ADMIN && MPH_ADMIN.ajaxUrl) || window.ajaxurl || '/wp-admin/admin-ajax.php';
    fetch(ajax,{method:'POST',credentials:'same-origin',body:data}).then(r=>r.json()).then(result=>{
      if(!result || !result.success) throw new Error((result && result.data && result.data.message) || 'بارگذاری مدیریت دوره ناموفق بود.');
      body.innerHTML = result.data.html || '';
      // re-bind SPA forms if available
      if(typeof window.MPHBindForms === 'function') window.MPHBindForms(body);
      else if(window.MPH && typeof window.MPH.bindForms === 'function') window.MPH.bindForms(body);
      // manual form bind fallback for manage save inside modal
      body.querySelectorAll('form[data-mph-action]').forEach(form=>{
        if(form.dataset.boundManage) return;
        form.dataset.boundManage = '1';
        form.addEventListener('submit', function(event){
          if(form.dataset.mphBoundByFrontend) return; // frontend.js already handles
          event.preventDefault();
          const fd = new FormData(form);
          fd.set('action', form.dataset.mphAction);
          if(nonce){ fd.set('nonce', nonce); }
          const msg = form.querySelector('.mph-message');
          if(msg) msg.textContent = 'در حال ذخیره…';
          fetch(ajax,{method:'POST',credentials:'same-origin',body:fd}).then(r=>r.json()).then(res=>{
            if(!res.success) throw new Error((res.data && res.data.message) || 'خطا');
            if(res.data && res.data.html){ body.innerHTML = res.data.html; openCourseManage._rebind && openCourseManage._rebind(body); }
            else if(msg) msg.textContent = (res.data && res.data.message) || 'ذخیره شد.';
          }).catch(err=>{ if(msg) msg.textContent = err.message || 'خطا'; });
        });
      });
    }).catch(err=>{ body.innerHTML = '<div class="mph-empty">'+(err.message||'خطا')+'</div>'; });
  }
  openCourseManage._rebind = function(body){
    const shell = manageModalShell();
    // noop - click delegated on shell
  };

  function bindManageButtons(root){
    (root||document).addEventListener('click', function(ev){
      const btn = ev.target.closest('[data-mph-course-manage]');
      if(!btn) return;
      ev.preventDefault();
      openCourseManage(btn.getAttribute('data-mph-course-manage'), btn.getAttribute('data-course-title')||'');
    });
  }

  function start(){bindManageButtons(document);bindInstructorPicker(document);const root=one('#mph-course-builder');if(!root){return;}bindJalaliCourseDate(root);bindInstructorPicker(root);const sections=one('[data-course-sections]',root);reindex(root);sortable(sections,'[data-course-section]',root);bindLessonSorts(root);all('.mph-delivery-admin-card input[type="checkbox"]',root).forEach(input=>{const sync=()=>input.closest('.mph-delivery-admin-card').classList.toggle('is-enabled',input.checked);input.addEventListener('change',sync);sync();});
    root.addEventListener('click',event=>{const addSection=event.target.closest('[data-add-course-section]');if(addSection&&sections){sections.insertAdjacentHTML('beforeend',sectionRow(all('[data-course-section]',sections).length));reindex(root);bindLessonSorts(root);return;}const addLesson=event.target.closest('[data-add-course-lesson]');if(addLesson){const section=addLesson.closest('[data-course-section]'),box=one('[data-course-lessons]',section),s=all('[data-course-section]',sections).indexOf(section),l=all('[data-course-lesson]',box).length;box.insertAdjacentHTML('beforeend',lessonRow(s,l));reindex(root);return;}const removeLesson=event.target.closest('[data-remove-course-lesson]');if(removeLesson){removeLesson.closest('[data-course-lesson]').remove();reindex(root);return;}const removeSection=event.target.closest('[data-remove-course-section]');if(removeSection&&confirm('این فصل و همه درس‌های آن حذف شود؟')){removeSection.closest('[data-course-section]').remove();reindex(root);return;}
      const videoButton=event.target.closest('[data-course-video]');if(videoButton){const lesson=videoButton.closest('[data-course-lesson]');mediaFrame({title:'انتخاب یا بارگذاری ویدئوی درس',button:{text:'استفاده از ویدئو'},library:{type:'video'},multiple:false},file=>{one('[data-course-video-id]',lesson).value=file.id;one('[data-course-video-name]',lesson).textContent=file.filename||file.title||'ویدئو انتخاب شد';});return;}
      const noteButton=event.target.closest('[data-course-note]');if(noteButton){const lesson=noteButton.closest('[data-course-lesson]');mediaFrame({title:'انتخاب یا بارگذاری جزوه درس',button:{text:'استفاده از فایل'},multiple:false},file=>{one('[data-course-note-id]',lesson).value=file.id;one('[data-course-note-name]',lesson).textContent=file.filename||file.title||'جزوه انتخاب شد';});return;}
      const coverButton=event.target.closest('[data-course-cover]');if(coverButton){mediaFrame({title:'انتخاب تصویر دوره',button:{text:'استفاده از تصویر'},library:{type:'image'},multiple:false},file=>{one('[data-course-cover-id]',root).value=file.id;one('[data-course-cover-preview]',root).innerHTML='<img src="'+(file.sizes&&file.sizes.medium?file.sizes.medium.url:file.url)+'" alt="">';});return;}
      const coverRemove=event.target.closest('[data-course-cover-remove]');if(coverRemove){one('[data-course-cover-id]',root).value='0';one('[data-course-cover-preview]',root).textContent='بدون تصویر شاخص';}
    });
    root.addEventListener('submit',event=>{reindex(root);if(!root.matches('[data-mph-course-admin-save]'))return;if(!root.checkValidity()){event.preventDefault();root.reportValidity();return;}event.preventDefault();const button=event.submitter||one('[type="submit"]',root),data=new FormData(root);data.set('action','mph_course_admin_save');if(button)button.classList.add('is-busy');setStatus(root,'در حال ذخیره همه اطلاعات…','loading');fetch((window.MPH_ADMIN&&MPH_ADMIN.ajaxUrl)||window.ajaxurl,{method:'POST',credentials:'same-origin',body:data}).then(parseResponse).then(result=>{if(!result.success)throw new Error(result.data&&result.data.message||'ذخیره دوره انجام نشد.');const id=Number(result.data&&result.data.courseId||0),idInput=one('input[name="course_id"]',root);if(id&&idInput)idInput.value=String(id);if(id&&window.history){const url=new URL(window.location.href);url.searchParams.set('course_id',String(id));url.searchParams.set('mph_saved','1');window.history.replaceState({mphCourse:id},'',url.toString());}setStatus(root,result.data.message,'success');if(button)button.classList.remove('is-busy');}).catch(error=>{if(button)button.classList.remove('is-busy');setStatus(root,error.message||'خطای ناشناخته هنگام ذخیره.','error');});});
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start);else start();
})();
