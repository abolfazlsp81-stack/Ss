(function(){
  'use strict';
  const map={'۰':'0','۱':'1','۲':'2','۳':'3','۴':'4','۵':'5','۶':'6','۷':'7','۸':'8','۹':'9','٠':'0','١':'1','٢':'2','٣':'3','٤':'4','٥':'5','٦':'6','٧':'7','٨':'8','٩':'9'};
  const latin=v=>String(v||'').replace(/[۰-۹٠-٩]/g,d=>map[d]||d).replace(/\D+/g,'');

  function cells(box){
    return Array.prototype.slice.call(box.querySelectorAll('[data-mph-otp-digit], .mph-otp-digit'));
  }
  function hiddenOf(box){
    return box.querySelector('[data-mph-otp-value]') ||
      (box.closest('form') && box.closest('form').querySelector('input[name="otp"]')) || null;
  }
  function sync(box){
    const inputs=cells(box);
    const hidden=hiddenOf(box);
    const code=inputs.map(i=>latin(i.value).slice(-1)).join('').slice(0, inputs.length||6);
    if(hidden){ hidden.value=code; hidden.setAttribute('value', code); if(!hidden.name) hidden.name='otp'; }
    box.dataset.otpCode=code;
    return code;
  }
  function fill(box, code){
    const inputs=cells(box);
    const chars=latin(code).slice(0, inputs.length).split('');
    inputs.forEach((input,i)=>{ input.value=chars[i]||''; });
    sync(box);
    const next=inputs.find(i=>!latin(i.value))||inputs[inputs.length-1];
    if(next){ next.focus(); try{next.select();}catch(e){} }
  }
  function goNext(inputs, index){
    if(inputs[index+1]){ inputs[index+1].focus(); try{inputs[index+1].select();}catch(e){} }
  }
  function submitForm(box){
    const form=box.closest('form');
    if(!form) return;
    sync(box);
    if(typeof form.requestSubmit==='function') form.requestSubmit();
    else {
      const btn=form.querySelector('[type="submit"],button.mph-primary,button[name="mph_submit"]');
      if(btn) btn.click();
      else form.dispatchEvent(new Event('submit',{bubbles:true,cancelable:true}));
    }
  }

  function bind(box){
    if(!box || box.dataset.mphOtpBound==='1') return;
    box.dataset.mphOtpBound='1';
    const inputs=cells(box);
    if(!inputs.length) return;

    let hidden=hiddenOf(box);
    if(!hidden){
      const form=box.closest('form');
      hidden=document.createElement('input');
      hidden.type='hidden';
      hidden.name='otp';
      hidden.setAttribute('data-mph-otp-value','');
      (form||box).appendChild(hidden);
    } else if(!hidden.name){ hidden.name='otp'; }

    inputs.forEach((input, index)=>{
      input.setAttribute('inputmode','numeric');
      input.setAttribute('maxlength','1');
      input.setAttribute('autocomplete', index===0 ? 'one-time-code' : 'off');
      input.setAttribute('enterkeyhint', index===inputs.length-1 ? 'done' : 'next');
      input.setAttribute('autocapitalize','off');
      input.setAttribute('spellcheck','false');
      // Flag: keydown already applied digit — input must not re-apply
      let fromKey = false;

      input.addEventListener('keydown', function(e){
        if(e.key==='Enter'){
          e.preventDefault();
          const code=sync(box);
          if(code.length>=inputs.length) submitForm(box);
          else goNext(inputs, index);
          return;
        }
        if(e.key==='Backspace'){
          if(!latin(input.value) && inputs[index-1]){
            e.preventDefault();
            inputs[index-1].value='';
            inputs[index-1].focus();
            sync(box);
          } else if(latin(input.value)){
            e.preventDefault();
            input.value='';
            sync(box);
          }
          return;
        }
        if(e.key==='ArrowLeft' && inputs[index-1]){ e.preventDefault(); inputs[index-1].focus(); return; }
        if(e.key==='ArrowRight' && inputs[index+1]){ e.preventDefault(); inputs[index+1].focus(); return; }
        // Digit via keydown only once — block default so input event gets empty/no double
        if(/^[0-9]$/.test(e.key) || map[e.key]){
          e.preventDefault();
          const d=latin(e.key).slice(-1);
          if(!d) return;
          fromKey = true;
          input.value = d;
          sync(box);
          goNext(inputs, index);
          // clear flag after input event cycle
          setTimeout(function(){ fromKey = false; }, 0);
        }
      });

      input.addEventListener('beforeinput', function(e){
        // Block insert when we already handled via keydown
        if(fromKey){ e.preventDefault(); return; }
        if(e.inputType === 'insertText' && e.data && latin(e.data).length === 1 && /^[0-9۰-۹٠-٩]$/.test(e.data)){
          // Let mobile path go to input; don't also handle here
        }
      });

      input.addEventListener('input', function(){
        if(fromKey){
          // keydown already set single digit — normalize only
          input.value = latin(input.value).slice(-1);
          sync(box);
          fromKey = false;
          return;
        }
        const raw = latin(input.value);
        if(raw.length > 1){ fill(box, raw); return; }
        if(raw.length === 1){
          input.value = raw;
          sync(box);
          goNext(inputs, index);
          return;
        }
        input.value = '';
        sync(box);
      });

      input.addEventListener('paste', function(e){
        const text=(e.clipboardData||window.clipboardData).getData('text');
        if(!text) return;
        e.preventDefault();
        fill(box, text);
      });

      input.addEventListener('focus', function(){ try{ input.select(); }catch(e){} });
    });

    const form=box.closest('form');
    if(form && !form.dataset.mphOtpSubmitBound){
      form.dataset.mphOtpSubmitBound='1';
      form.addEventListener('submit', function(){ sync(box); }, true);
    }
    sync(box);
  }

  function init(root){
    (root||document).querySelectorAll('[data-mph-otp-boxes], .mph-otp-boxes').forEach(bind);
  }
  window.MPHOtpBoxesInit=init;
  window.MPHOtpSync=function(scope){
    scope=scope||document;
    let code='';
    scope.querySelectorAll('[data-mph-otp-boxes], .mph-otp-boxes').forEach(box=>{ bind(box); code=sync(box)||code; });
    return code;
  };
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded', function(){ init(document); }, {once:true});
  else init(document);
  document.addEventListener('mph:rebind', function(){ init(document); });
  document.addEventListener('mph:panel-loaded', function(e){ init(e.target||document); });
})();
