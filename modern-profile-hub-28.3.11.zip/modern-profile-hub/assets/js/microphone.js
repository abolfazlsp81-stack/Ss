/**
 * MPH Microphone — cross-browser / cross-OS voice capture helper
 * Desktop + mobile (Chrome, Edge, Firefox, Safari, iOS WebKit).
 * Does NOT open the mic by itself; call from a user gesture (click/tap).
 *
 * Public API: window.MPHMicrophone
 */
(function (root) {
  'use strict';

  var fa = {
    insecure: 'ضبط ویس فقط روی HTTPS (یا localhost) کار می‌کند.',
    unsupported: 'این مرورگر از میکروفون پشتیبانی نمی‌کند. فایل صوتی پیوست کنید.',
    noRecorder: 'ضبط زنده در این مرورگر ممکن نیست. فایل ویس انتخاب کنید.',
    denied: 'اجازه میکروفون داده نشد. از قفل/تنظیمات سایت Allow کنید.',
    notFound: 'میکروفونی پیدا نشد. هدست یا میکروفون را وصل کنید.',
    busy: 'میکروفون در دسترس نیست (شاید برنامه دیگری اشغال کرده).',
    empty: 'ویس خالی بود؛ دوباره ضبط کنید.',
    recording: 'در حال ضبط… دوباره میکروفون = توقف',
    ready: 'ویس آماده',
    generic: 'ضبط ممکن نشد'
  };

  var AUDIO_MIME_CANDIDATES = [
    'audio/webm;codecs=opus',
    'audio/webm',
    'audio/mp4;codecs=mp4a.40.2',
    'audio/mp4',
    'audio/ogg;codecs=opus',
    'audio/ogg',
    'audio/wav'
  ];

  function isSecure() {
    try {
      if (typeof window.isSecureContext === 'boolean') return window.isSecureContext;
    } catch (e) {}
    var h = (location && location.hostname) || '';
    return location.protocol === 'https:' || h === 'localhost' || h === '127.0.0.1' || h === '[::1]';
  }

  function hasMediaDevices() {
    return !!(navigator.mediaDevices && typeof navigator.mediaDevices.getUserMedia === 'function');
  }

  function hasMediaRecorder() {
    return typeof root.MediaRecorder !== 'undefined';
  }

  function capabilities() {
    return {
      secure: isSecure(),
      mediaDevices: hasMediaDevices(),
      mediaRecorder: hasMediaRecorder(),
      canLiveRecord: isSecure() && hasMediaDevices() && hasMediaRecorder()
    };
  }

  function pickMimeType() {
    if (!hasMediaRecorder() || typeof MediaRecorder.isTypeSupported !== 'function') {
      return '';
    }
    for (var i = 0; i < AUDIO_MIME_CANDIDATES.length; i++) {
      try {
        if (MediaRecorder.isTypeSupported(AUDIO_MIME_CANDIDATES[i])) {
          return AUDIO_MIME_CANDIDATES[i];
        }
      } catch (e) {}
    }
    return '';
  }

  function extensionFor(mime) {
    var m = String(mime || '').toLowerCase();
    if (m.indexOf('mp4') >= 0 || m.indexOf('m4a') >= 0 || m.indexOf('aac') >= 0) return 'm4a';
    if (m.indexOf('ogg') >= 0 || m.indexOf('opus') >= 0 && m.indexOf('webm') < 0) return 'ogg';
    if (m.indexOf('wav') >= 0) return 'wav';
    if (m.indexOf('mpeg') >= 0 || m.indexOf('mp3') >= 0) return 'mp3';
    return 'webm';
  }

  function errorMessage(err) {
    if (!err) return fa.generic;
    var name = err.name || '';
    if (name === 'NotAllowedError' || name === 'PermissionDeniedError') return fa.denied;
    if (name === 'NotFoundError' || name === 'DevicesNotFoundError') return fa.notFound;
    if (name === 'NotReadableError' || name === 'TrackStartError' || name === 'AbortError') return fa.busy;
    if (name === 'SecurityError') return fa.insecure;
    if (name === 'TypeError' && !hasMediaDevices()) return fa.unsupported;
    return err.message || fa.generic;
  }

  function stopStream(stream) {
    if (!stream) return;
    try {
      var tracks = stream.getTracks ? stream.getTracks() : [];
      for (var i = 0; i < tracks.length; i++) {
        try { tracks[i].stop(); } catch (e) {}
      }
    } catch (e2) {}
  }

  function blobToFile(blob, filename) {
    var name = filename || ('voice-' + Date.now() + '.' + extensionFor(blob && blob.type));
    var type = (blob && blob.type) || 'application/octet-stream';
    try {
      return new File([blob], name, { type: type, lastModified: Date.now() });
    } catch (e) {
      try {
        blob.name = name;
      } catch (e2) {}
      return blob;
    }
  }

  /**
   * Put a Blob/File into an <input type="file"> when the browser allows DataTransfer.
   * Always also sets input._mphBlob / _mphBlobName as fallback for FormData builders.
   */
  function assignToInput(input, blob, filename) {
    if (!input || !blob) return false;
    var file = blobToFile(blob, filename);
    var name = file.name || filename || ('voice-' + Date.now() + '.webm');
    input._mphBlob = blob;
    input._mphBlobName = name;
    input._mphBlobType = blob.type || '';
    try {
      var dt = new DataTransfer();
      if (file instanceof File) dt.items.add(file);
      else dt.items.add(new File([blob], name, { type: blob.type || 'audio/webm' }));
      input.files = dt.files;
      return !!(input.files && input.files.length);
    } catch (e) {
      return true; // blob fallback still usable
    }
  }

  /** Append voice field onto FormData from input or raw blob. */
  function appendToFormData(fd, fieldName, inputOrBlob, filename) {
    if (!fd) return false;
    var key = fieldName || 'voice';
    if (inputOrBlob && inputOrBlob.tagName === 'INPUT') {
      var input = inputOrBlob;
      if (input.files && input.files[0]) {
        fd.set(key, input.files[0], input.files[0].name || 'voice.webm');
        return true;
      }
      if (input._mphBlob) {
        fd.set(key, input._mphBlob, input._mphBlobName || filename || 'voice.webm');
        return true;
      }
      return false;
    }
    if (inputOrBlob && typeof inputOrBlob.size === 'number') {
      var name = filename || ('voice-' + Date.now() + '.' + extensionFor(inputOrBlob.type));
      fd.set(key, inputOrBlob, name);
      return true;
    }
    return false;
  }

  function clearInput(input) {
    if (!input) return;
    try { input.value = ''; } catch (e) {}
    delete input._mphBlob;
    delete input._mphBlobName;
    delete input._mphBlobType;
  }

  /**
   * Create a recorder controller.
   * opts: {
   *   onStatus(text, meta),
   *   onStart(),
   *   onStop(result),  // { blob, file, mimeType, extension, size, url, filename }
   *   onError(err, message),
   *   timeslice: 200,
   *   audioConstraints: true | MediaTrackConstraints
   * }
   */
  function createRecorder(opts) {
    opts = opts || {};
    var timeslice = typeof opts.timeslice === 'number' ? opts.timeslice : 200;
    var audioConstraints = opts.audioConstraints != null ? opts.audioConstraints : true;

    var state = {
      recording: false,
      stream: null,
      recorder: null,
      chunks: [],
      mimeType: '',
      startedAt: 0
    };

    function emitStatus(text, meta) {
      if (typeof opts.onStatus === 'function') {
        try { opts.onStatus(text, meta || {}); } catch (e) {}
      }
    }

    function emitError(err) {
      var msg = errorMessage(err);
      emitStatus(msg, { level: 'error', error: err });
      if (typeof opts.onError === 'function') {
        try { opts.onError(err, msg); } catch (e) {}
      }
      return msg;
    }

    function cleanupStream() {
      stopStream(state.stream);
      state.stream = null;
    }

    function isRecording() {
      return !!state.recording;
    }

    function stop() {
      if (!state.recording) return Promise.resolve(null);
      return new Promise(function (resolve) {
        var rec = state.recorder;
        if (!rec) {
          state.recording = false;
          cleanupStream();
          resolve(null);
          return;
        }
        var finished = false;
        function finish(result) {
          if (finished) return;
          finished = true;
          resolve(result || null);
        }
        var prev = rec.onstop;
        rec.onstop = function (ev) {
          try { if (typeof prev === 'function') prev.call(rec, ev); } catch (e) {}
          // onstop handler below builds result asynchronously via same tick
        };
        // Monkey-patch once: wait for our internal onstop pipeline
        var origChunks = state.chunks;
        var stopTimer = setTimeout(function () {
          // safety if onstop never fires
          state.recording = false;
          cleanupStream();
          finish(null);
        }, 8000);

        var userOnStop = opts.onStop;
        opts.onStop = function (result) {
          clearTimeout(stopTimer);
          opts.onStop = userOnStop;
          if (typeof userOnStop === 'function') {
            try { userOnStop(result); } catch (e) {}
          }
          finish(result);
        };

        try {
          if (rec.state && rec.state !== 'inactive') rec.stop();
          else {
            clearTimeout(stopTimer);
            state.recording = false;
            cleanupStream();
            finish(null);
          }
        } catch (e) {
          clearTimeout(stopTimer);
          state.recording = false;
          cleanupStream();
          emitError(e);
          finish(null);
        }
      });
    }

    function start() {
      var cap = capabilities();
      if (!cap.secure) {
        return Promise.reject(Object.assign(new Error(fa.insecure), { name: 'SecurityError', code: 'insecure' }));
      }
      if (!cap.mediaDevices) {
        return Promise.reject(Object.assign(new Error(fa.unsupported), { name: 'NotSupportedError', code: 'no-media-devices' }));
      }
      if (!cap.mediaRecorder) {
        return Promise.reject(Object.assign(new Error(fa.noRecorder), { name: 'NotSupportedError', code: 'no-media-recorder' }));
      }
      if (state.recording) {
        return stop();
      }

      return navigator.mediaDevices.getUserMedia({ audio: audioConstraints, video: false })
        .then(function (stream) {
          state.stream = stream;
          state.chunks = [];
          state.mimeType = pickMimeType();
          state.startedAt = Date.now();

          var rec;
          try {
            rec = state.mimeType
              ? new MediaRecorder(stream, { mimeType: state.mimeType })
              : new MediaRecorder(stream);
          } catch (e1) {
            try {
              rec = new MediaRecorder(stream);
              state.mimeType = '';
            } catch (e2) {
              cleanupStream();
              throw e2;
            }
          }

          state.recorder = rec;
          try {
            if (rec.mimeType) state.mimeType = rec.mimeType;
          } catch (e) {}

          rec.ondataavailable = function (e) {
            if (e && e.data && e.data.size) state.chunks.push(e.data);
          };

          rec.onerror = function (e) {
            state.recording = false;
            cleanupStream();
            emitError((e && e.error) || e || new Error(fa.generic));
          };

          rec.onstop = function () {
            state.recording = false;
            var mime = state.mimeType || (rec.mimeType || 'audio/webm');
            var blob = new Blob(state.chunks.slice(), { type: mime });
            state.chunks = [];
            cleanupStream();
            state.recorder = null;

            if (!blob.size) {
              emitStatus(fa.empty, { level: 'error' });
              if (typeof opts.onStop === 'function') {
                try { opts.onStop(null); } catch (e) {}
              }
              return;
            }

            var ext = extensionFor(mime);
            var filename = 'voice-' + Date.now() + '.' + ext;
            var file = blobToFile(blob, filename);
            var url = '';
            try { url = URL.createObjectURL(blob); } catch (e) {}

            var result = {
              blob: blob,
              file: file,
              mimeType: mime,
              extension: ext,
              filename: filename,
              size: blob.size,
              url: url,
              durationMs: state.startedAt ? (Date.now() - state.startedAt) : 0
            };

            var kb = Math.max(1, Math.round(blob.size / 1024));
            emitStatus(fa.ready + ' (' + kb + ' KB)', { level: 'ok', result: result });
            if (typeof opts.onStop === 'function') {
              try { opts.onStop(result); } catch (e) {}
            }
          };

          try {
            if (timeslice > 0) rec.start(timeslice);
            else rec.start();
          } catch (eStart) {
            // Some engines lie on isTypeSupported then fail start()
            try {
              rec.start();
            } catch (eStart2) {
              cleanupStream();
              state.recorder = null;
              throw eStart2;
            }
          }

          state.recording = true;
          emitStatus(fa.recording, { level: 'recording' });
          if (typeof opts.onStart === 'function') {
            try { opts.onStart(); } catch (e) {}
          }
          return true;
        })
        .catch(function (err) {
          state.recording = false;
          cleanupStream();
          state.recorder = null;
          emitError(err);
          return Promise.reject(err);
        });
    }

    /** Toggle: if recording → stop; else → start. */
    function toggle() {
      if (state.recording) return stop();
      return start();
    }

    function destroy() {
      try {
        if (state.recorder && state.recorder.state && state.recorder.state !== 'inactive') {
          state.recorder.stop();
        }
      } catch (e) {}
      state.recording = false;
      cleanupStream();
      state.recorder = null;
      state.chunks = [];
    }

    return {
      start: start,
      stop: stop,
      toggle: toggle,
      isRecording: isRecording,
      destroy: destroy,
      capabilities: capabilities,
      pickMimeType: pickMimeType
    };
  }

  /**
   * Wire a mic button + optional file input + status node (forum-style).
   * root may be a composer box; selectors are optional overrides.
   */
  function bindMicButton(config) {
    config = config || {};
    var button = config.button;
    if (!button) return null;

    var input = config.input || null;
    var statusEl = config.status || null;
    var fileFallback = config.fileFallback !== false;

    function setStatus(text, hidden) {
      if (!statusEl) return;
      if (text) {
        statusEl.hidden = !!hidden;
        statusEl.textContent = text;
      } else {
        statusEl.hidden = true;
        statusEl.textContent = '';
      }
    }

    function openFilePicker() {
      if (!fileFallback || !input) return;
      try { input.click(); } catch (e) {}
    }

    var recorder = createRecorder({
      timeslice: config.timeslice,
      audioConstraints: config.audioConstraints,
      onStatus: function (text) { setStatus(text, false); },
      onStart: function () {
        button.classList.add('is-recording');
        button.setAttribute('aria-pressed', 'true');
      },
      onStop: function (result) {
        button.classList.remove('is-recording');
        button.setAttribute('aria-pressed', 'false');
        if (result && input) {
          assignToInput(input, result.blob, result.filename);
        }
        if (typeof config.onRecorded === 'function' && result) {
          try { config.onRecorded(result); } catch (e) {}
        }
      },
      onError: function (err, message) {
        button.classList.remove('is-recording');
        button.setAttribute('aria-pressed', 'false');
        setStatus(message || fa.generic, false);
        var code = (err && err.code) || (err && err.name) || '';
        if (fileFallback && (
          code === 'insecure' ||
          code === 'no-media-devices' ||
          code === 'no-media-recorder' ||
          (err && (err.name === 'NotSupportedError' || err.name === 'SecurityError'))
        )) {
          openFilePicker();
        }
        if (typeof config.onError === 'function') {
          try { config.onError(err, message); } catch (e) {}
        }
      }
    });

    if (button.tagName === 'BUTTON') {
      try { button.type = 'button'; } catch (e) {}
    }
    button.setAttribute('aria-pressed', 'false');

    var onClick = function (ev) {
      if (ev) {
        ev.preventDefault();
        ev.stopPropagation();
        if (typeof ev.stopImmediatePropagation === 'function') ev.stopImmediatePropagation();
      }
      var cap = capabilities();
      if (!cap.canLiveRecord) {
        if (!cap.secure) setStatus(fa.insecure, false);
        else if (!cap.mediaDevices) setStatus(fa.unsupported, false);
        else setStatus(fa.noRecorder, false);
        openFilePicker();
        return;
      }
      recorder.toggle().catch(function () {
        // onError already handled message + optional fallback
      });
    };

    button.addEventListener('click', onClick);

    if (input) {
      input.addEventListener('change', function () {
        if (input.files && input.files[0]) {
          setStatus('فایل: ' + input.files[0].name, false);
          delete input._mphBlob;
          delete input._mphBlobName;
        }
      });
    }

    return {
      recorder: recorder,
      unbind: function () {
        button.removeEventListener('click', onClick);
        recorder.destroy();
        button.classList.remove('is-recording');
      },
      setStatus: setStatus,
      openFilePicker: openFilePicker
    };
  }

  var api = {
    version: '1.0.0',
    messages: fa,
    capabilities: capabilities,
    isSecure: isSecure,
    pickMimeType: pickMimeType,
    extensionFor: extensionFor,
    errorMessage: errorMessage,
    stopStream: stopStream,
    blobToFile: blobToFile,
    assignToInput: assignToInput,
    appendToFormData: appendToFormData,
    clearInput: clearInput,
    createRecorder: createRecorder,
    bindMicButton: bindMicButton
  };

  root.MPHMicrophone = api;

  // UMD-ish export
  if (typeof module !== 'undefined' && module.exports) {
    module.exports = api;
  }
})(typeof window !== 'undefined' ? window : this);
