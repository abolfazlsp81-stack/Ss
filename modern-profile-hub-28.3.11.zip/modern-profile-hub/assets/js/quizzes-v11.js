(function(){
  'use strict';
  const one=(selector,context)=>(context||document).querySelector(selector);
  const all=(selector,context)=>Array.from((context||document).querySelectorAll(selector));
  const escapeHtml=value=>String(value||'').replace(/[&<>'"]/g,char=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#039;','"':'&quot;'}[char]));
  const answerTypes=['true_false','single_choice','multiple_choice','fill_in_the_blank','ordering','matching','image_answering','image_matching'];
  const singleTypes=['true_false','single_choice'];

  function answerRow(index,title){
    return '<div class="mph-question-answer" data-answer-row><span class="mph-answer-order">'+(index+1)+'</span><input type="hidden" name="answer_id['+index+']" value="0"><input type="text" name="answer_title['+index+']" value="'+escapeHtml(title||'')+'" placeholder="متن پاسخ"><input class="mph-answer-match" type="text" name="answer_match['+index+']" value="" placeholder="جفت متناظر / جواب‌های مجاز"><label class="mph-answer-correct"><input type="checkbox" name="answer_correct['+index+']" value="1"> پاسخ صحیح</label><span class="mph-answer-image"><input type="hidden" name="answer_image['+index+']" value="0" data-answer-image-id><span data-answer-image-preview></span><button type="button" class="mph-secondary" data-answer-media>تصویر</button></span><button type="button" class="mph-danger" data-remove-answer>×</button></div>';
  }

  function reindex(form){
    all('[data-answer-row]',form).forEach((row,index)=>{
      one('.mph-answer-order',row).textContent=index+1;
      all('[name]',row).forEach(input=>{input.name=input.name.replace(/\[\d+\]/,'['+index+']');});
    });
  }

  function syncType(form){
    const select=one('[data-question-type]',form);if(!select)return;
    const type=select.value,answers=one('[data-question-answers]',form),list=one('[data-answer-list]',form),add=one('[data-add-answer]',form),help=one('[data-answer-help]',form);
    if(answers)answers.hidden=!answerTypes.includes(type);
    if(!answerTypes.includes(type))return;
    if(!all('[data-answer-row]',list).length){
      if(type==='true_false')list.innerHTML=answerRow(0,'درست')+answerRow(1,'نادرست');
      else if(type==='fill_in_the_blank')list.innerHTML=answerRow(0,'پاسخ صحیح');
      else list.innerHTML=answerRow(0,'')+answerRow(1,'');
    }
    all('[data-answer-row]',form).forEach(row=>{
      const match=one('.mph-answer-match',row),correct=one('.mph-answer-correct',row),image=one('.mph-answer-image',row),title=one('input[name^="answer_title["]',row);
      if(match){match.hidden=!['fill_in_the_blank','matching','image_matching'].includes(type);match.placeholder=type==='fill_in_the_blank'?'پاسخ‌های مجاز با | جدا شوند':'جفت متناظر';}
      if(correct)correct.hidden=!['true_false','single_choice','multiple_choice'].includes(type);
      if(image)image.hidden=!['image_answering','image_matching'].includes(type);
      if(title)title.placeholder=type==='fill_in_the_blank'?'عنوان پاسخ':type==='matching'||type==='image_matching'?'عبارت اول':'متن پاسخ';
    });
    if(add)add.hidden=type==='true_false';
    if(help){
      const labels={true_false:'یکی از «درست» یا «نادرست» را صحیح انتخاب کنید.',single_choice:'فقط یک گزینه را به‌عنوان پاسخ صحیح انتخاب کنید.',multiple_choice:'یک یا چند گزینه صحیح را انتخاب کنید.',fill_in_the_blank:'پاسخ‌های قابل قبول را در ستون دوم با علامت | جدا کنید.',ordering:'گزینه‌ها را به ترتیب صحیح از بالا به پایین وارد کنید.',matching:'هر عبارت را با جفت متناظر آن در ستون دوم بنویسید.',image_answering:'برای هر پاسخ یک تصویر انتخاب و پاسخ صحیح را مشخص کنید.',image_matching:'متن و تصویر یا جفت متناظر هر ردیف را وارد کنید.'};help.textContent=labels[type]||'';
    }
    reindex(form);
  }

  function openEditor(card){
    all('.mph-question-card.is-editing',card.closest('.mph-quiz-editor')).forEach(item=>{if(item!==card)item.classList.remove('is-editing');});
    card.hidden=false;card.classList.add('is-editing');const form=one('.mph-question-editor-form',card);if(form){syncType(form);const title=one('[name="question_title"]',form);if(title)window.setTimeout(()=>title.focus(),80);}
  }

  function syncScoreMode(root){
    all('[data-quiz-score-mode]',root||document).forEach(box=>{
      const selected=one('input[name="quiz_score_mode"]:checked',box),maximum=one('input[name="quiz_max_score"]',box);
      if(!maximum)return;
      maximum.disabled=!selected||selected.value!=='points';
      maximum.closest('label')?.classList.toggle('is-disabled',maximum.disabled);
    });
  }

  document.addEventListener('submit',event=>{
    const form=event.target.closest('form[data-confirm]');if(!form||event.mphConfirmed)return;event.mphConfirmed=true;if(!window.confirm(form.dataset.confirm)){event.preventDefault();event.stopImmediatePropagation();}
  },true);

  document.addEventListener('change',event=>{
    if(event.target.matches('[data-question-type]'))syncType(event.target.closest('form'));
    if(event.target.matches('input[name="quiz_score_mode"]'))syncScoreMode(event.target.closest('[data-quiz-score-mode]'));
    if(event.target.matches('.mph-answer-correct input')){
      const form=event.target.closest('form'),type=(one('[data-question-type]',form)||{}).value;
      if(event.target.checked&&singleTypes.includes(type))all('.mph-answer-correct input',form).forEach(input=>{if(input!==event.target)input.checked=false;});
    }
  });

  document.addEventListener('click',event=>{
    const fresh=event.target.closest('[data-new-question]');if(fresh){const editor=fresh.closest('.mph-quiz-editor'),card=one('.mph-new-question-card',editor);if(card)openEditor(card);return;}
    const edit=event.target.closest('[data-edit-question]');if(edit){openEditor(edit.closest('[data-question-card]'));return;}
    const cancel=event.target.closest('[data-cancel-question]');if(cancel){const card=cancel.closest('[data-question-card]');card.classList.remove('is-editing');if(card.classList.contains('mph-new-question-card'))card.hidden=true;return;}
    const add=event.target.closest('[data-add-answer]');if(add){const form=add.closest('form'),list=one('[data-answer-list]',form),index=all('[data-answer-row]',list).length;list.insertAdjacentHTML('beforeend',answerRow(index,''));syncType(form);return;}
    const remove=event.target.closest('[data-remove-answer]');if(remove){const form=remove.closest('form'),row=remove.closest('[data-answer-row]');row.remove();reindex(form);return;}
    const media=event.target.closest('[data-answer-media]');if(media){
      if(!window.wp||!wp.media){window.alert('کتابخانه رسانه وردپرس بارگذاری نشده است. صفحه را تازه‌سازی کنید.');return;}
      const row=media.closest('[data-answer-row]'),frame=wp.media({title:'انتخاب تصویر پاسخ',button:{text:'استفاده از تصویر'},library:{type:'image'},multiple:false});
      frame.on('select',()=>{const item=frame.state().get('selection').first().toJSON(),url=item.sizes&&item.sizes.thumbnail?item.sizes.thumbnail.url:item.url;one('[data-answer-image-id]',row).value=item.id;one('[data-answer-image-preview]',row).innerHTML='<img src="'+escapeHtml(url)+'" alt="">';});frame.open();
    }
  });

  function start(){all('.mph-question-editor-form').forEach(syncType);syncScoreMode(document);}
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start);else start();
})();
