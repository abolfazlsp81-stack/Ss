(function(){
  'use strict';
  const one=(selector,context)=>(context||document).querySelector(selector);
  const all=(selector,context)=>Array.from((context||document).querySelectorAll(selector));
  const escapeHtml=value=>String(value||'').replace(/[&<>'"]/g,char=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#039;','"':'&quot;'}[char]));

  function mediaField(name,index){
    return '<div class="mph-media-field"><input type="hidden" name="'+name+'['+index+']" value="0" data-media-id><span class="mph-media-preview">بدون تصویر</span><button type="button" class="button" data-media-upload>انتخاب تصویر</button><button type="button" class="button-link-delete" data-media-remove>حذف</button></div>';
  }

  function menuRow(index){
    return '<div class="mph-menu-row mph-admin-enter" data-menu-row><div class="mph-row-top"><b>مورد منوی جدید</b><label class="mph-mini-check"><input type="checkbox" name="enabled['+index+']" checked> فعال</label><label class="mph-mini-check"><input type="checkbox" name="show_card['+index+']" checked> کارت پیشخوان</label><button type="button" class="button-link-delete" data-remove-row>حذف</button></div><div class="mph-menu-grid"><label>شناسه<input name="item_id['+index+']" placeholder="custom_item"></label><label>عنوان<input name="item_title['+index+']" placeholder="عنوان منو"></label><label>آیکون آماده ستون راست<input name="sidebar_icon['+index+']" value="dashicons-menu"></label><label>آیکون آماده کارت<input name="card_icon['+index+']" value="dashicons-star-filled"></label><label>تصویر ستون راست'+mediaField('sidebar_image_id',index)+'</label><label>تصویر کارت'+mediaField('card_image_id',index)+'</label><label>توضیح کارت<input name="item_hint['+index+']" placeholder="توضیح کوتاه"></label></div><div class="mph-role-checks"><span>نمایش برای:</span><label><input type="checkbox" name="roles['+index+'][user]" checked> کاربر</label><label><input type="checkbox" name="roles['+index+'][instructor]"> مدرس</label><label><input type="checkbox" name="roles['+index+'][therapist]"> درمانگر</label><label><input type="checkbox" name="roles['+index+'][manager]"> مدیر</label></div></div>';
  }

  function setBusy(form){
    if(form.dataset.mphSubmitting)return false;
    form.dataset.mphSubmitting='1';form.classList.add('mph-admin-busy');
    const button=form.querySelector('button[type="submit"],input[type="submit"],button:not([type])');
    if(button){button.disabled=true;button.dataset.mphOld=button.innerHTML||button.value;if(button.tagName==='BUTTON')button.innerHTML='<span class="mph-admin-spinner"></span> در حال انجام…';else button.value='در حال انجام…';}
    return true;
  }

  document.addEventListener('DOMContentLoaded',()=>{
    const menuBox=one('.mph-menu-rows'),addMenu=one('[data-add-menu]');
    if(menuBox&&addMenu)addMenu.addEventListener('click',()=>{menuBox.insertAdjacentHTML('beforeend',menuRow(all('[data-menu-row]',menuBox).length));const rows=all('[data-menu-row]',menuBox);rows[rows.length-1].scrollIntoView({behavior:'smooth',block:'center'});});
    all('.mph-admin form').forEach(form=>form.addEventListener('submit',()=>setBusy(form)));
    document.addEventListener('click',event=>{
      const remove=event.target.closest('[data-remove-row]');if(remove){const row=remove.closest('[data-menu-row]');if(row){row.classList.add('mph-admin-leave');window.setTimeout(()=>row.remove(),180);}}
      const upload=event.target.closest('[data-media-upload]');if(upload){event.preventDefault();const field=upload.closest('.mph-media-field'),frame=wp.media({title:'انتخاب تصویر آیکون',button:{text:'استفاده از تصویر'},multiple:false});frame.on('select',()=>{const item=frame.state().get('selection').first().toJSON();one('[data-media-id]',field).value=item.id;one('.mph-media-preview',field).innerHTML='<img src="'+escapeHtml(item.sizes&&item.sizes.thumbnail?item.sizes.thumbnail.url:item.url)+'" alt="">';field.classList.add('is-selected');});frame.open();}
      const clear=event.target.closest('[data-media-remove]');if(clear){event.preventDefault();const field=clear.closest('.mph-media-field');one('[data-media-id]',field).value='0';one('.mph-media-preview',field).textContent='بدون تصویر';field.classList.remove('is-selected');}
    });
  });
})();
