(function(){
  'use strict';
  const one=(s,c)=>(c||document).querySelector(s);
  const supported='Notification' in window;
  let audioContext=null,busy=false;

  function storage(key,value){
    try{
      if(arguments.length===2){localStorage.setItem(key,JSON.stringify(value));return value;}
      const raw=localStorage.getItem(key);
      return raw?JSON.parse(raw):null;
    }catch(e){return null;}
  }
  function seenMap(){const map=storage('mphWebNotificationSeen');return map&&typeof map==='object'?map:{};}
  function markSeen(id){
    const map=seenMap();map[id]=Date.now();
    const cutoff=Date.now()-30*86400000;
    Object.keys(map).forEach(key=>{if(Number(map[key])<cutoff)delete map[key];});
    storage('mphWebNotificationSeen',map);
  }
  function tone(){
    try{
      const Audio=window.AudioContext||window.webkitAudioContext;if(!Audio)return;
      audioContext=audioContext||new Audio();
      if(audioContext.state==='suspended')audioContext.resume();
      const now=audioContext.currentTime;
      [0,.13].forEach((delay,index)=>{
        const osc=audioContext.createOscillator(),gain=audioContext.createGain();
        osc.type='sine';osc.frequency.value=index?880:660;
        gain.gain.setValueAtTime(.0001,now+delay);
        gain.gain.exponentialRampToValueAtTime(.12,now+delay+.015);
        gain.gain.exponentialRampToValueAtTime(.0001,now+delay+.18);
        osc.connect(gain);gain.connect(audioContext.destination);
        osc.start(now+delay);osc.stop(now+delay+.2);
      });
    }catch(e){}
  }
  function openItem(item){
    window.focus();
    if(item.panel&&typeof window.MPHLoadPanel==='function')window.MPHLoadPanel(item.panel);
    else if(item.url)window.location.assign(item.url);
  }
  function inPage(item){
    const stack=one('[data-mph-notification-stack]');if(!stack)return;
    const card=document.createElement('button');
    card.type='button';
    card.className='mph-web-notification is-'+String(item.type||'system');
    card.innerHTML='<span class="dashicons '+(item.icon||'dashicons-bell')+'"></span><span><b></b><small></small></span><i>×</i>';
    one('b',card).textContent=item.title||'اعلان جدید';
    one('small',card).textContent=item.body||'';
    card.addEventListener('click',()=>{card.remove();openItem(item);});
    stack.prepend(card);
    requestAnimationFrame(()=>card.classList.add('is-show'));
    window.setTimeout(()=>{card.classList.remove('is-show');window.setTimeout(()=>card.remove(),260);},8500);
  }
  function notify(item){
    if(!item||!item.id)return;
    // Forum: badge only — no sound / no toast from this feed
    if(item.type==='forum' || item.panel==='course_forum' || item.silent){
      markSeen(item.id);
      return;
    }
    const map=seenMap();if(map[item.id])return;
    markSeen(item.id);tone();inPage(item);
    try{
      const note=new Notification(item.title||(window.MPH_WEB_NOTIFY&&MPH_WEB_NOTIFY.site)||'اعلان',{
        body:item.body||'',
        icon:(window.MPH_WEB_NOTIFY&&MPH_WEB_NOTIFY.icon)||undefined,
        tag:'mph-'+item.id,renotify:false,silent:true,
        data:{panel:item.panel||'',url:item.url||''}
      });
      note.onclick=()=>{note.close();openItem(item);};
    }catch(e){}
  }
  async function feed(){
    if(!supported||Notification.permission!=='granted'||busy)return;
    if(!window.MPH_WEB_NOTIFY)return;
    busy=true;
    const dashboard=one('.mph-dashboard'),body=new URLSearchParams();
    body.set('action','mph_web_notifications');
    body.set('nonce',MPH_WEB_NOTIFY.nonce);
    body.set('notification_mode',(dashboard&&dashboard.dataset.mode)||MPH_WEB_NOTIFY.mode||'user');
    try{
      const response=await fetch(MPH_WEB_NOTIFY.ajaxUrl,{
        method:'POST',credentials:'same-origin',cache:'no-store',
        headers:{'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest'},
        body:body.toString()
      });
      const result=await response.json();
      if(result.success&&result.data&&Array.isArray(result.data.items))
        result.data.items.slice().reverse().forEach(notify);
    }catch(e){}
    finally{busy=false;}
  }
  function dismissedRecently(){
    const value=Number(storage('mphWebNotificationDismissed')||0);
    return value>Date.now()-7*86400000;
  }
  function syncPrompt(){
    const prompt=one('[data-mph-notification-consent]');
    if(!prompt)return;
    if(!supported||Notification.permission==='granted'||Notification.permission==='denied'||dismissedRecently())prompt.hidden=true;
    else prompt.hidden=false;
    if(supported&&Notification.permission==='granted')feed();
  }
  function bind(){
    const prompt=one('[data-mph-notification-consent]');
    if(!prompt)return;
    if(prompt.dataset.mphNotificationBound==='1'){syncPrompt();return;}
    prompt.dataset.mphNotificationBound='1';
    const enable=one('[data-mph-notification-enable]',prompt);
    const dismiss=one('[data-mph-notification-dismiss]',prompt);
    if(enable)enable.addEventListener('click',async()=>{
      enable.disabled=true;
      try{
        const permission=await Notification.requestPermission();
        if(permission==='granted'){storage('mphWebNotificationDismissed',0);tone();await feed();}
      }finally{enable.disabled=false;syncPrompt();}
    });
    if(dismiss)dismiss.addEventListener('click',()=>{storage('mphWebNotificationDismissed',Date.now());prompt.hidden=true;});
    syncPrompt();
  }
  function start(){
    bind();
    if(window.MPH_WEB_NOTIFY){
      window.setInterval(feed,Math.max(20000,Number(MPH_WEB_NOTIFY.pollInterval)||45000));
    }
    document.addEventListener('visibilitychange',()=>{if(!document.hidden)feed();});
    window.addEventListener('focus',feed);
  }
  window.MPHInitWebNotifications=bind;
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start);
  else start();
})();
