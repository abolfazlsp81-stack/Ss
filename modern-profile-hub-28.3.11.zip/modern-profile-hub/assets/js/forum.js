(function(){
  'use strict';
  const one=(s,c)=>(c||document).querySelector(s);
  const all=(s,c)=>Array.prototype.slice.call((c||document).querySelectorAll(s));
  function ajax(){ return (window.MPH_FORUM&&MPH_FORUM.ajaxUrl)||(window.MPH_DATA&&MPH_DATA.ajaxUrl)||window.ajaxurl||'/wp-admin/admin-ajax.php'; }
  function nonce(){ return (window.MPH_FORUM&&MPH_FORUM.nonce)||(window.MPH_DATA&&MPH_DATA.nonce)||''; }

  function loadThread(root, courseId){
    const thread = one('[data-forum-thread]', root);
    if (!thread || !courseId) return Promise.resolve();
    const btn = one('[data-forum-course="'+courseId+'"]', root);
    if (btn && (btn.disabled || btn.classList.contains('is-ended'))) {
      thread.innerHTML = '<div class="mph-empty">این دوره به پایان رسیده است.</div>';
      return Promise.resolve();
    }
    thread.dataset.courseId = String(courseId);
    thread.classList.add('is-loading');
    const fd = new FormData();
    fd.set('action', 'mph_forum_thread');
    fd.set('course_id', String(courseId));
    fd.set('nonce', nonce());
    return fetch(ajax(), { method:'POST', credentials:'same-origin', body: fd })
      .then(r => r.json())
      .then(res => {
        thread.classList.remove('is-loading');
        if (!res || !res.success) throw new Error((res && res.data && res.data.message) || 'بارگذاری ناموفق');
        thread.innerHTML = res.data.html || '<div class="mph-empty">پیامی نیست.</div>';
        thread.scrollTop = thread.scrollHeight;
      })
      .catch(err => {
        thread.classList.remove('is-loading');
        thread.innerHTML = '<div class="mph-empty">' + (err.message || 'خطا در بارگذاری') + '</div>';
      });
  }

  function appendFile(fd, input){
    if (!input) return;
    if (input.files && input.files[0]) {
      fd.set('image', input.files[0], input.files[0].name || 'file.bin');
    }
  }

  function setProgress(box, state){
    // state: null/hide | {pct, text, done, error}
    const wrap = one('[data-forum-upload-progress]', box);
    const bar = one('[data-forum-upload-bar]', box);
    const status = one('[data-forum-upload-status]', box);
    const attach = one('.mph-forum-attach', box);
    if (!wrap) return;
    // NEVER change document icon inside attach label
    if (!state) {
      wrap.hidden = true;
      wrap.classList.remove('is-done', 'is-error', 'is-active');
      if (bar) bar.style.width = '0%';
      if (status) status.textContent = '';
      if (attach) attach.classList.remove('is-uploading');
      return;
    }
    wrap.hidden = false;
    wrap.classList.add('is-active');
    wrap.classList.toggle('is-done', !!state.done);
    wrap.classList.toggle('is-error', !!state.error);
    if (attach) attach.classList.toggle('is-uploading', !state.done && !state.error);
    const pct = Math.max(0, Math.min(100, Number(state.pct) || 0));
    if (bar) bar.style.width = pct + '%';
    if (status) {
      if (state.done) {
        status.innerHTML = '<span class="mph-forum-upload-check" aria-hidden="true">✓</span> فایل آپلود شد';
      } else if (state.error) {
        status.textContent = state.text || 'خطا در آپلود';
      } else {
        status.textContent = state.text || ('در حال آپلود… ' + pct + '٪');
      }
    }
  }

  function xhrSend(fd, onProgress){
    return new Promise(function(resolve, reject){
      const xhr = new XMLHttpRequest();
      xhr.open('POST', ajax(), true);
      xhr.withCredentials = true;
      xhr.responseType = 'json';
      if (xhr.upload && typeof onProgress === 'function') {
        xhr.upload.onprogress = function(ev){
          if (!ev.lengthComputable) return;
          const pct = Math.round((ev.loaded / ev.total) * 100);
          onProgress(pct, ev.loaded, ev.total);
        };
      }
      xhr.onload = function(){
        let res = xhr.response;
        if (typeof res === 'string') {
          try { res = JSON.parse(res); } catch (e) { res = null; }
        }
        if (xhr.status >= 200 && xhr.status < 300) resolve(res);
        else reject(new Error((res && res.data && res.data.message) || ('خطای سرور ' + xhr.status)));
      };
      xhr.onerror = function(){ reject(new Error('ارتباط با سرور برقرار نشد.')); };
      xhr.send(fd);
    });
  }

  function sendComposer(box, composer){
    const courseField = one('[data-forum-course-field]', box);
    const replyTo = one('[data-forum-reply-to]', box);
    const ta = one('textarea[name="message"]', composer) || one('textarea', composer);
    const fileInput = one('[data-forum-file],[data-forum-image-file]', box);
    const msg = one('.mph-message', composer);
    const active = one('[data-forum-course].is-active', box);
    if (active && (active.disabled || active.classList.contains('is-ended'))) {
      if (msg) msg.textContent = 'این دوره به پایان رسیده است.';
      return Promise.reject(new Error('ended'));
    }
    const fd = new FormData();
    fd.set('action', 'mph_forum_send');
    fd.set('nonce', nonce());
    fd.set('course_id', (courseField && courseField.value) || '');
    fd.set('reply_to', (replyTo && replyTo.value) || '0');
    fd.set('message', (ta && ta.value) || '');
    appendFile(fd, fileInput);
    const hasText = !!(ta && ta.value && ta.value.trim());
    const hasFile = !!(fileInput && fileInput.files && fileInput.files[0]);
    if (!hasText && !hasFile) {
      if (msg) msg.textContent = 'متن یا فایل پیوست لازم است.';
      return Promise.reject(new Error('متن یا فایل پیوست لازم است.'));
    }
    if (msg) msg.textContent = 'در حال ارسال…';
    const btns = all('button', composer);
    btns.forEach(b => { b.disabled = true; });
    if (hasFile) setProgress(box, { pct: 0, text: 'در حال آپلود… 0٪' });

    return xhrSend(fd, function(pct){
      if (hasFile) setProgress(box, { pct: pct, text: 'در حال آپلود… ' + pct + '٪' });
    })
      .then(res => {
        btns.forEach(b => { b.disabled = false; });
        if (!res || !res.success) throw new Error((res && res.data && res.data.message) || 'ارسال ناموفق');
        if (hasFile) setProgress(box, { pct: 100, done: true });
        const thread = one('[data-forum-thread]', box);
        if (thread && res.data && res.data.html) {
          thread.innerHTML = res.data.html;
          thread.scrollTop = thread.scrollHeight;
        } else if (courseField) loadThread(box, courseField.value);
        if (ta) ta.value = '';
        if (replyTo) replyTo.value = '0';
        const replyBar = one('[data-forum-reply-bar]', box);
        if (replyBar) replyBar.hidden = true;
        if (fileInput) fileInput.value = '';
        if (msg) msg.textContent = (res.data && res.data.message) || 'ارسال شد.';
        // keep success line under attach a few seconds
        if (hasFile) {
          window.setTimeout(function(){ setProgress(box, null); }, 4500);
        }
        return res;
      })
      .catch(err => {
        btns.forEach(b => { b.disabled = false; });
        if (hasFile) setProgress(box, { pct: 100, error: true, text: err.message || 'خطا در آپلود' });
        if (msg) msg.textContent = err.message || 'خطا در ارسال';
        throw err;
      });
  }

  function bind(root){
    root = root || document;
    all('[data-mph-forum]', root).forEach(box => {
      if (box.dataset.forumBound === '1') return;
      box.dataset.forumBound = '1';

      const composer = one('[data-forum-composer]', box);
      const courseField = one('[data-forum-course-field]', box);
      const replyTo = one('[data-forum-reply-to]', box);
      const replyBar = one('[data-forum-reply-bar]', box);
      const replyPreview = one('[data-forum-reply-preview]', box);
      const fileInput = one('[data-forum-file],[data-forum-image-file]', box);
      const ta = composer && (one('textarea[name="message"]', composer) || one('textarea', composer));

      box.addEventListener('click', function(ev){
        const courseBtn = ev.target.closest('[data-forum-course]');
        if (courseBtn) {
          if (courseBtn.disabled || courseBtn.classList.contains('is-ended')) {
            ev.preventDefault();
            return;
          }
          all('[data-forum-course]', box).forEach(b => b.classList.toggle('is-active', b === courseBtn));
          const id = courseBtn.getAttribute('data-forum-course');
          if (courseField) courseField.value = id;
          if (replyTo) replyTo.value = '0';
          if (replyBar) replyBar.hidden = true;
          loadThread(box, id);
          return;
        }
        const reply = ev.target.closest('[data-forum-reply]');
        if (reply) {
          if (replyTo) replyTo.value = reply.getAttribute('data-forum-reply') || '0';
          if (replyBar) {
            replyBar.hidden = false;
            if (replyPreview) replyPreview.textContent = 'پاسخ: ' + (reply.getAttribute('data-reply-excerpt') || '');
          }
          if (ta) ta.focus();
          return;
        }
        if (ev.target.closest('[data-forum-reply-clear]')) {
          if (replyTo) replyTo.value = '0';
          if (replyBar) replyBar.hidden = true;
        }
      });

      if (composer) {
        composer.addEventListener('submit', function(ev){
          ev.preventDefault();
          ev.stopPropagation();
          if (typeof ev.stopImmediatePropagation === 'function') ev.stopImmediatePropagation();
          sendComposer(box, composer).catch(function(){});
        }, true);
      }

      if (ta) {
        ta.addEventListener('keydown', function(ev){
          if (ev.key === 'Enter' && !ev.shiftKey) {
            ev.preventDefault();
            sendComposer(box, composer).catch(function(){});
          }
        });
      }

      if (fileInput) {
        fileInput.addEventListener('change', function(){
          // Only show filename in message area — do NOT swap attach icon
          const msg = one('.mph-message', composer || box);
          if (fileInput.files && fileInput.files[0] && msg) {
            msg.textContent = 'آماده ارسال: ' + fileInput.files[0].name;
          }
          setProgress(box, null);
        });
      }

      const first = one('[data-forum-course].is-active:not(.is-ended)', box) || one('[data-forum-course]:not(.is-ended)', box) || one('[data-forum-course].is-active', box);
      if (first && courseField) courseField.value = first.getAttribute('data-forum-course') || courseField.value;
      if (first) {
        const thread = one('[data-forum-thread]', box);
        if (thread && /در حال بارگذاری/.test(thread.textContent || '')) {
          loadThread(box, first.getAttribute('data-forum-course'));
        }
      }
    });
  }

  function boot(){ bind(document); }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();
  document.addEventListener('mph:panel-loaded', function(e){ bind(e.target || document); });
  document.addEventListener('mph:rebind', function(){ bind(document); });
  window.MPHBindForum = bind;
})();
