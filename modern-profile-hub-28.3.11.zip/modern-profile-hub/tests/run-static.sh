#!/usr/bin/env bash
set -euo pipefail

plugin_root="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
php_count=0
js_count=0

if command -v php >/dev/null 2>&1; then
  while IFS= read -r -d '' file; do
    php -l "$file" >/dev/null
    php_count=$((php_count + 1))
  done < <(find "$plugin_root" -type f -name '*.php' -print0)
else
  printf 'PHP CLI is unavailable; PHP lint skipped in this environment.\n' >&2
fi

while IFS= read -r -d '' file; do
  node --check "$file" >/dev/null
  js_count=$((js_count + 1))
done < <(find "$plugin_root/assets/js" "$plugin_root/tests" -type f -name '*.js' -print0)

node "$plugin_root/tests/php-balance.js" >/dev/null

required=(
  "includes/class-mph-security.php"
  "includes/class-mph-appointment-lock.php"
  "includes/class-mph-appointment-repository.php"
  "includes/class-mph-password-recovery.php"
  "includes/class-mph-factory-reset.php"
  "includes/class-mph-health.php"
  "includes/class-mph-backup.php"
  "includes/class-mph-web-notifications.php"
  "includes/class-mph-bale-sync.php"
  "includes/class-mph-xlsx.php"
  "assets/css/frontend-release.css"
  "assets/css/admin-release.css"
  "assets/css/calendar-release.css"
  "assets/css/header-account.css"
  "assets/css/web-notifications.css"
)
for relative in "${required[@]}"; do
  test -s "$plugin_root/$relative" || { printf 'Missing required file: %s\n' "$relative" >&2; exit 1; }
done

if rg -n "wp_ajax_nopriv_mph_appointment_book" "$plugin_root/includes" "$plugin_root/modern-profile-hub.php" >/dev/null; then
  printf 'Appointment booking must never be exposed to guests.\n' >&2
  exit 1
fi

if rg -n "wp_ajax_nopriv_mph_calendar_delete_event" "$plugin_root/includes" "$plugin_root/modern-profile-hub.php" >/dev/null; then
  printf 'Calendar deletion must never be exposed to guests.\n' >&2
  exit 1
fi

if ! rg -n "wp_mail\(" "$plugin_root/includes/class-mph-password-recovery.php" >/dev/null; then
  printf 'Management recovery codes must be emailed after manual approval.\n' >&2
  exit 1
fi

if rg -n "register_(activation|deactivation)_hook\([^\n]*factory_reset|MPH_Factory_Reset::(ajax_start|ajax_step)\(\)" "$plugin_root/modern-profile-hub.php" >/dev/null; then
  printf 'Factory reset must never run during installation or update.\n' >&2
  exit 1
fi

if ! rg -n "wp_check_password\(" "$plugin_root/includes/class-mph-factory-reset.php" >/dev/null; then
  printf 'Factory reset must verify the current superadmin password.\n' >&2
  exit 1
fi

if rg -n "wp_remote_(get|post)\([^\n]*sslverify[^\n]*false" "$plugin_root/includes" >/dev/null; then
  printf 'Unsafe remote request with sslverify=false detected.\n' >&2
  exit 1
fi

rg -n 'wp_set_auth_cookie\(\$signed->ID' "$plugin_root/includes/class-mph-auth.php" >/dev/null || { printf 'Normal login must create an authentication cookie.\n' >&2; exit 1; }
if rg -n "update_option\(MPH_Helpers::DB_VERSION" "$plugin_root/includes/class-mph-admin.php" >/dev/null; then
  printf 'Module defaults must not mark the whole database upgrade complete.\n' >&2
  exit 1
fi
rg -n "schema_restore" "$plugin_root/includes/class-mph-factory-reset.php" >/dev/null || { printf 'Factory reset must verify restored schemas.\n' >&2; exit 1; }
rg -n "mph_notice_legacy_migrated_v25" "$plugin_root/includes/class-mph-notices.php" >/dev/null || { printf 'Recoverable announcement migration is missing.\n' >&2; exit 1; }
for ticket_column in assigned_therapist_id manager_unread therapist_unread; do
  rg -n "$ticket_column" "$plugin_root/includes/class-mph-tickets.php" >/dev/null || { printf 'Therapist ticket schema is incomplete: %s.\n' "$ticket_column" >&2; exit 1; }
done
rg -n "mph_ticket_legacy_migrated_v25" "$plugin_root/includes/class-mph-tickets.php" >/dev/null || { printf 'Recoverable legacy ticket migration is missing.\n' >&2; exit 1; }
rg -n "data-ticket-sort" "$plugin_root/includes/class-mph-tickets.php" "$plugin_root/assets/js/tickets.js" >/dev/null || { printf 'Ticket sorting controls are missing.\n' >&2; exit 1; }
rg -n "MPH_Tickets::enqueue_assets" "$plugin_root/includes/class-mph-dashboard.php" >/dev/null || { printf 'Ticket runtime is not globally available to the AJAX account shell.\n' >&2; exit 1; }
rg -n "new_ticket_form\(\$mode\)|name=\"ticket_mode\"" "$plugin_root/includes/class-mph-tickets.php" >/dev/null || { printf 'Role-aware ticket creation is missing.\n' >&2; exit 1; }
rg -n "mph-ticket-file-progress|phase: 'complete'" "$plugin_root/assets/js/tickets.js" "$plugin_root/assets/css/frontend-release.css" >/dev/null || { printf 'Percentage ticket-upload progress is missing.\n' >&2; exit 1; }
rg -n "assigned_staff" "$plugin_root/includes/class-mph-tickets.php" "$plugin_root/assets/js/tickets.js" >/dev/null || { printf 'Manager staff assignment is missing.\n' >&2; exit 1; }
if command -v php >/dev/null 2>&1; then php "$plugin_root/tests/test-cart-payments.php"; fi
if rg -n 'foreach\(\$old as\$key\).*remove_cart_item' "$plugin_root/includes/class-mph-commerce.php" >/dev/null; then
  printf 'Legacy same-course cart replacement logic is still present.\n' >&2
  exit 1
fi
rg -n "controlStates.*WeakMap" "$plugin_root/assets/js/cart-v32.js" >/dev/null || { printf 'Cart controls do not preserve their disabled state.\n' >&2; exit 1; }
# Unpaid receipt submissions must preserve the account cart; covered above by behavior tests.
rg -n "Modern Profile Hub 25.0 — unified glass system" "$plugin_root/assets/css/frontend-release.css" >/dev/null || { printf 'Frontend glass layer is missing.\n' >&2; exit 1; }
rg -n "curriculum_is_complete" "$plugin_root/includes/class-mph-courses.php" >/dev/null || { printf 'Offline publishing validation is missing.\n' >&2; exit 1; }
rg -n "mph_offline_lesson_progress" "$plugin_root/includes/class-mph-courses.php" >/dev/null || { printf 'Offline lesson progress is missing.\n' >&2; exit 1; }
rg -n "data-mph-notice-sort" "$plugin_root/includes/class-mph-notices.php" "$plugin_root/assets/js/frontend.js" >/dev/null || { printf 'Announcement sorting controls are missing.\n' >&2; exit 1; }
rg -n "valid_public_username|valid_person_name" "$plugin_root/includes/class-mph-helpers.php" >/dev/null || { printf 'Non-numeric display-name validation is missing.\n' >&2; exit 1; }
rg -n "mph-file-state|در حال بارگذاری فایل" "$plugin_root/assets/js/frontend.js" "$plugin_root/assets/css/frontend-release.css" >/dev/null || { printf 'Generic file-upload loading feedback is missing.\n' >&2; exit 1; }
rg -n "bindJalaliCourseDate" "$plugin_root/assets/js/course-admin.js" >/dev/null || { printf 'Manager course date is not bound to the Jalali editor.\n' >&2; exit 1; }
rg -n "mph_course_progress_save|mph_course_progress_delete" "$plugin_root/includes/class-mph-courses.php" >/dev/null || { printf 'Manual online/in-person progress management is incomplete.\n' >&2; exit 1; }
rg -n "mph_reminder_save|یادآوری مشترک" "$plugin_root/includes/class-mph-growth.php" >/dev/null || { printf 'Manual/system reminder merging is missing.\n' >&2; exit 1; }
rg -n "mph_manager_user_roles|mph_manager_public_profile" "$plugin_root/includes/class-mph-manager.php" >/dev/null || { printf 'Manager role or public-profile controls are missing.\n' >&2; exit 1; }
rg -n "SUPER_ADMIN_OPTION|mph_manager_super_admin|is_portal_super_admin" "$plugin_root/includes/class-mph-manager.php" >/dev/null || { printf 'Protected portal superadmin selection is missing.\n' >&2; exit 1; }
rg -n -F "array('user'=>'کاربر','instructor'=>'مدرس','therapist'=>'درمانگر','manager'=>'مدیر')" "$plugin_root/includes/class-mph-manager.php" >/dev/null || { printf 'Manual role editor is not limited to four logical roles.\n' >&2; exit 1; }
rg -n -F 'public_profile_controls($user,$mode)' "$plugin_root/includes/class-mph-dashboard.php" >/dev/null && rg -n -F "in_array(\$mode,array('instructor','therapist'),true)" "$plugin_root/includes/class-mph-dashboard.php" >/dev/null || { printf 'Public-profile controls are not restricted by the active staff role.\n' >&2; exit 1; }
rg -n "mph_quiz_review_save" "$plugin_root/includes/class-mph-quizzes.php" >/dev/null && rg -n -F 'count($history)>=3' "$plugin_root/includes/class-mph-quizzes.php" >/dev/null || { printf 'Three-pass read-only quiz review is missing.\n' >&2; exit 1; }
rg -n "mph_therapist_appointments_export|آخرین وضعیت پرداخت" "$plugin_root/includes/class-mph-appointments.php" >/dev/null || { printf 'Therapist appointment export is incomplete.\n' >&2; exit 1; }
rg -n -F 'hash_equals($expected,$raw)' "$plugin_root/includes/class-mph-discounts.php" >/dev/null || { printf 'Case-sensitive coupon validation is missing.\n' >&2; exit 1; }
rg -n "mph_backup_export|mph_backup_import|hash_equals" "$plugin_root/includes/class-mph-backup.php" >/dev/null || { printf 'Verified ZIP backup import/export is missing.\n' >&2; exit 1; }
rg -n "admin_post_mph_delete_member|wp_delete_user" "$plugin_root/includes/class-mph-admin.php" >/dev/null || { printf 'Protected WordPress member deletion is missing.\n' >&2; exit 1; }
rg -n "ready_for_otp|این سرویس در حال حاضر وجود ندارد" "$plugin_root/includes/class-mph-sms.php" "$plugin_root/includes/class-mph-auth.php" >/dev/null || { printf 'Conditional login OTP handling is missing.\n' >&2; exit 1; }
rg -n "mph_web_notifications|Notification.requestPermission|AudioContext" "$plugin_root/includes/class-mph-web-notifications.php" "$plugin_root/assets/js/web-notifications.js" >/dev/null || { printf 'Browser notification runtime is missing.\n' >&2; exit 1; }
rg -n "mph-bale/v1|X-MPH|hash_hmac\('sha256'|claimUpdate|asset_upload" "$plugin_root/includes/class-mph-bale-sync.php" >/dev/null || { printf 'Bale synchronization bridge is incomplete.\n' >&2; exit 1; }
rg -n "mph_bale_states|mph_bale_assets|mph_bale_updates" "$plugin_root/includes/class-mph-bale-sync.php" >/dev/null || { printf 'Bale site-backed state tables are incomplete.\n' >&2; exit 1; }
rg -n "rpc_linkAccount|contact_user_id|rpc_updatePhoneByContact|phone_users" "$plugin_root/includes/class-mph-bale-sync.php" >/dev/null || { printf 'Verified Bale account linking is incomplete.\n' >&2; exit 1; }
rg -n "enrollment_id.*order_mismatch|_mph_bale_access_synced|product_unavailable|course_unavailable" "$plugin_root/includes/class-mph-bale-sync.php" >/dev/null || { printf 'Bale exact-order or availability guards are incomplete.\n' >&2; exit 1; }
rg -n "if\(!is_user_logged_in\(\)\)return" "$plugin_root/includes/class-mph-web-notifications.php" >/dev/null || { printf 'Notification assets must not poll for guests.\n' >&2; exit 1; }
rg -n "فیش ۱.*فیش ۲.*فیش ۳.*فیش ۴|drawing1.xml|pdf_frames" "$plugin_root/includes/class-mph-xlsx.php" >/dev/null || { printf 'Embedded four-column receipt XLSX is missing.\n' >&2; exit 1; }
test ! -e "$plugin_root/includes/class-mph-portal-design.php" || { printf 'Removed manager customization module is still packaged.\n' >&2; exit 1; }
if rg -n "get_edit_post_link" "$plugin_root/includes/class-mph-manager.php" >/dev/null; then
  printf 'Manager course editing must use the plugin editor.\n' >&2
  exit 1
fi
if rg -n "data-mph-theme-toggle" "$plugin_root/includes" >/dev/null; then
  printf 'The removed light/dark toggle is still rendered.\n' >&2
  exit 1
fi

for css in "$plugin_root/assets/css/frontend-release.css" "$plugin_root/assets/css/admin-release.css" "$plugin_root/assets/css/calendar-release.css" "$plugin_root/assets/css/header-account.css" "$plugin_root/assets/css/web-notifications.css"; do
  read -r opens closes < <(awk 'BEGIN{o=0;c=0}{o+=gsub(/\{/,"{");c+=gsub(/\}/,"}")}END{print o,c}' "$css")
  test "$opens" -eq "$closes" || { printf 'Unbalanced CSS braces: %s\n' "$css" >&2; exit 1; }
done

printf 'Static suite completed: %d PHP files linted, %d JavaScript files checked.\n' "$php_count" "$js_count"
if command -v php >/dev/null 2>&1; then
  php "$plugin_root/tests/test-kavenegar.php"
  php "$plugin_root/tests/test-bale-runtime.php"
fi
