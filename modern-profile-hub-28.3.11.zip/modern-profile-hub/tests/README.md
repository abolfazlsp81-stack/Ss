# Quality suite

`bash tests/run-static.sh` validates PHP syntax, JavaScript syntax, required release assets, guest-booking exposure and unsafe TLS overrides.

For browser tests on a staging site:

```bash
npm install
MPH_BASE_URL=https://staging.example.com \
MPH_ACCOUNT_PATH=/account/ \
MPH_TEST_PHONE=09xxxxxxxxx \
MPH_TEST_PASSWORD='strong-password' \
npm run test:e2e
```

Use a dedicated staging user and sandbox payment credentials. Real gateway verification must be run on the target staging site because it depends on its WooCommerce, Tutor LMS, SMTP, gateway keys, callbacks and server cron.
