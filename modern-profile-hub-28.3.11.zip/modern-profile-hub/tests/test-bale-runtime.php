<?php
require __DIR__.'/otp-fixtures.php';
require dirname(__DIR__).'/includes/class-mph-bale-runtime.php';

// Execute real inbox/receipt logic against a disposable SQL store; emulate only MySQL locks.
class RuntimeDB {
    public $prefix='wp_'; public $db;
    public function __construct() {
        $this->db=new PDO('sqlite::memory:'); $this->db->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
        $this->db->exec("CREATE TABLE wp_mph_bale_jobs(job_key TEXT PRIMARY KEY,chat_id TEXT,update_id TEXT,status TEXT DEFAULT 'retry',token TEXT DEFAULT '',lease_until INTEGER DEFAULT 0,attempts INTEGER DEFAULT 0,available_at INTEGER DEFAULT 0,payload TEXT,snapshot TEXT,error_code TEXT DEFAULT '',created_at INTEGER,updated_at INTEGER)");
        $this->db->exec("CREATE TABLE wp_mph_bale_operations(op_key TEXT PRIMARY KEY,job_key TEXT,status TEXT DEFAULT 'running',result TEXT,created_at INTEGER)");
    }
    public function prepare($sql,...$args) { $i=0;return preg_replace_callback('/%[sd]/',function($m)use(&$i,$args){$v=$args[$i++];return $m[0]==='%d'?(string)(int)$v:$this->db->quote((string)$v);},$sql); }
    public function query($sql) {
        if(strpos($sql,'DELETE o FROM')===0)return 0;
        return $this->db->exec($sql);
    }
    public function get_var($sql) { if(strpos($sql,'GET_LOCK')!==false || strpos($sql,'RELEASE_LOCK')!==false)return '1';return $this->db->query($sql)->fetchColumn(); }
    public function get_row($sql,$mode=null){return $this->db->query($sql)->fetch(PDO::FETCH_ASSOC)?:null;}
    public function get_results($sql,$mode=null){return $this->db->query($sql)->fetchAll(PDO::FETCH_ASSOC);}
    public function insert($table,$data) { $q=$this->db->prepare('INSERT INTO '.$table.' ('.implode(',',array_keys($data)).') VALUES ('.implode(',',array_fill(0,count($data),'?')).')');$q->execute(array_values($data));return $q->rowCount(); }
    public function update($table,$data,$where) { $set=implode(',',array_map(function($x){return $x.'=?';},array_keys($data)));$filter=implode(' AND ',array_map(function($x){return $x.'=?';},array_keys($where)));$q=$this->db->prepare('UPDATE '.$table.' SET '.$set.' WHERE '.$filter);$q->execute(array_merge(array_values($data),array_values($where)));return $q->rowCount(); }
}
$wpdb=new RuntimeDB(); $options['mph_bale_runtime_version']='1';
$contextCalls=0;$context=function($p)use(&$contextCalls){$contextCalls++;return ['user'=>['id'=>$p['chat_id']]];};
$state=function($p){return ['step'=>'new_ticket','data'=>['title'=>'Test']];};
function input_update($id,$chat='123') {return ['_actor_chat_id'=>$chat,'update_id'=>(string)$id,'update'=>['update_id'=>$id,'message'=>['from'=>['id'=>(int)$chat],'chat'=>['id'=>(int)$chat],'text'=>'test']]];}
function leased($id,$token){return ['_actor_chat_id'=>'123','_job_id'=>(string)$id,'_job_token'=>$token,'text'=>'test'];}
function finish_job($id,$token,$success,$code='network_error'){return MPH_Bale_Runtime::finish(['_actor_chat_id'=>'123','update_id'=>(string)$id,'token'=>$token,'success'=>$success,'error_code'=>$code]);}
$begin=MPH_Bale_Runtime::begin(input_update(100),$context,$state);
verify($begin['status']==='processing' && $begin['state']['step']==='new_ticket','Bootstrap must preserve original form state');
verify(MPH_Bale_Runtime::heartbeat(['_actor_chat_id'=>'123','update_id'=>'100','token'=>$begin['token']])===true,'Live worker must renew lease');
verify(is_wp_error(MPH_Bale_Runtime::heartbeat(['_actor_chat_id'=>'123','update_id'=>'100','token'=>'wrong'])),'Wrong worker cannot renew lease');
$changed=input_update(100);$changed['update']['message']['text']='different';
verify(is_wp_error(MPH_Bale_Runtime::begin($changed,$context,$state)),'An update ID cannot be reused with a different body');
verify(is_wp_error(MPH_Bale_Runtime::begin(input_update(100),$context,$state)),'Duplicate in-flight update must not run concurrently');
$count=0;$write=function($p)use(&$count){$count++;return ['ticket_id'=>42];};
$result=MPH_Bale_Runtime::execute('saveMessage',leased(100,$begin['token']),$write);
verify($result['ticket_id']===42 && $count===1,'Initial mutation must execute');
verify(is_wp_error(MPH_Bale_Runtime::execute('saveMessage',leased(100,'wrong-token'),$write)),'Stale worker token must fail');
verify(finish_job(100,$begin['token'],false)['status']==='retry','Network failure must schedule retry');
$wpdb->query("UPDATE wp_mph_bale_jobs SET available_at=0 WHERE update_id='100'");
$pending=MPH_Bale_Runtime::pending();
verify($pending[0]['update_id']===100,'Worker must retrieve original update from WordPress');
$retry=MPH_Bale_Runtime::begin(input_update(100),$context,function(){throw new RuntimeException('Live state should not replace snapshot');});
verify($retry['token']!==$begin['token'],'Retry must receive new lease token');
$result=MPH_Bale_Runtime::execute('saveMessage',leased(100,$retry['token']),$write);
verify($result['ticket_id']===42 && $count===1,'Retry after reply loss must reuse result without a duplicate ticket');
verify(finish_job(100,$retry['token'],true)['status']==='done','Successful processing must complete');
verify(MPH_Bale_Runtime::begin(input_update(100),$context,$state)['status']==='done','Completed update must be deduplicated');
verify(MPH_Bale_Runtime::pending()===[],'Completed payload must leave retry queue');
$j=MPH_Bale_Runtime::begin(input_update(101),$context,$state);
try { MPH_Bale_Runtime::execute('createCourse',leased(101,$j['token']),function(){throw new RuntimeException('simulate crash after action');}); } catch(RuntimeException $e){}
finish_job(101,$j['token'],false); $wpdb->query("UPDATE wp_mph_bale_jobs SET available_at=0 WHERE update_id='101'");
$j2=MPH_Bale_Runtime::begin(input_update(101),$context,$state);
$uncertain=MPH_Bale_Runtime::execute('createCourse',leased(101,$j2['token']),function(){throw new RuntimeException('Unsafe duplicate execution');});
verify(is_wp_error($uncertain) && $uncertain->get_error_code()==='operation_uncertain','Unknown outcome must stop automatic duplication');
verify(finish_job(101,$j2['token'],false,'operation_uncertain')['status']==='review','Uncertain action must remain visible for review');
verify(count(MPH_Bale_Runtime::diagnostics([])['review'])===1,'Operator diagnostics must list review item');
verify(MPH_Bale_Runtime::pending()===[],'Uncertain action must not loop in cron');
$a=MPH_Bale_Runtime::begin(input_update(102),$context,$state);
verify(is_wp_error(MPH_Bale_Runtime::begin(input_update(103),$context,$state)),'Later conversation update must wait for previous request');
finish_job(102,$a['token'],true);
verify(MPH_Bale_Runtime::begin(input_update(103),$context,$state)['status']==='processing','Waiting request must resume after earlier completion');
$bad=input_update(104);$bad['update']['message']['from']['id']=999;
verify(is_wp_error(MPH_Bale_Runtime::begin($bad,$context,$state)),'Actor mismatch must be rejected');
echo "Durable inbox and operation receipts: {$checks} assertions passed.\n";
