'use strict';

const fs = require('fs');
const path = require('path');

const root = path.resolve(__dirname, '..');
const files = [];

function walk(dir) {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    if (entry.name === 'node_modules' || entry.name === 'vendor') continue;
    const target = path.join(dir, entry.name);
    if (entry.isDirectory()) walk(target);
    else if (entry.name.endsWith('.php')) files.push(target);
  }
}

function check(file) {
  const source = fs.readFileSync(file, 'utf8');
  const stack = [];
  let php = false;
  let quote = '';
  let lineComment = false;
  let blockComment = false;
  let line = 1;

  for (let i = 0; i < source.length; i += 1) {
    const char = source[i];
    const next = source[i + 1] || '';
    if (char === '\n') {
      line += 1;
      lineComment = false;
    }

    if (!php) {
      if (char === '<' && next === '?' && !/^<\?xml/i.test(source.slice(i, i + 5))) {
        php = true;
        i += 1;
      }
      continue;
    }

    if (!quote && !lineComment && !blockComment && char === '?' && next === '>') {
      php = false;
      i += 1;
      continue;
    }
    if (lineComment) continue;
    if (blockComment) {
      if (char === '*' && next === '/') {
        blockComment = false;
        i += 1;
      }
      continue;
    }
    if (quote) {
      if (char === '\\') {
        i += 1;
        continue;
      }
      if (char === quote) quote = '';
      continue;
    }
    if ((char === '/' && next === '/') || char === '#') {
      lineComment = true;
      if (char === '/') i += 1;
      continue;
    }
    if (char === '/' && next === '*') {
      blockComment = true;
      i += 1;
      continue;
    }
    if (char === "'" || char === '"' || char === '`') {
      quote = char;
      continue;
    }

    if ('({['.includes(char)) stack.push({ char, line });
    if (')}]'.includes(char)) {
      const expected = { ')': '(', '}': '{', ']': '[' }[char];
      const opened = stack.pop();
      if (!opened || opened.char !== expected) throw new Error(`${file}:${line}: unexpected ${char}`);
    }
  }

  if (quote) throw new Error(`${file}:${line}: unterminated string`);
  if (blockComment) throw new Error(`${file}:${line}: unterminated comment`);
  if (stack.length) {
    const opened = stack[stack.length - 1];
    throw new Error(`${file}:${opened.line}: unclosed ${opened.char}`);
  }
}

walk(root);
files.forEach(check);
process.stdout.write(`PHP delimiter check completed: ${files.length} files checked.\n`);
