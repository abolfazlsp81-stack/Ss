<?php
/** Behavioral regression tests; all gateway responses are local fixtures. */
define('ABSPATH',__DIR__.'/');define('MPH_VERSION','test');define('DAY_IN_SECONDS',86400);
$checks=0;$meta=array();$users=array(7,8);$orders=array();$options=array();$queue=array();$calls=array();$uid=7;
function check($value,$message){global $checks;$checks++;if(!$value)throw new RuntimeException($message);}
class WP_Error{private $c,$m,$d;function __construct($c,$m,$d=null){$this->c=$c;$this->m=$m;$this->d=$d;}function get_error_code(){return $this->c;}function get_error_message(){return $this->m;}function get_error_data(){return $this->d;}}
function is_wp_error($v){return $v instanceof WP_Error;}function absint($v){return abs((int)$v);}function wp_json_encode($v,$flags=0){return json_encode($v,$flags);}function wp_parse_args($a,$b){return array_merge($b,$a);}function wp_cache_delete(...$args){}
function get_user_by($type,$id){return in_array($id,$GLOBALS['users'],true)?(object)array('ID'=>$id):false;}
function get_user_meta($id,$key,$single=true){return $GLOBALS['meta'][$id][$key]??'';}function update_user_meta($id,$key,$value){$GLOBALS['meta'][$id][$key]=$value;return true;}
function get_option($key,$default=''){return $GLOBALS['options'][$key]??$default;}function update_option($key,$value,$auto=false){$GLOBALS['options'][$key]=$value;return true;}
function get_current_user_id(){return $GLOBALS['uid'];}function is_user_logged_in(){return get_current_user_id()>0;}function sanitize_key($v){return preg_replace('/[^a-z0-9_-]/','',strtolower((string)$v));}function sanitize_text_field($v){return trim(strip_tags((string)$v));}function get_post_status($id){return 'publish';}
function wc_get_order($id){return $GLOBALS['orders'][$id]??false;}function wc_get_product($id){return isset($GLOBALS['products'][$id])?$GLOBALS['products'][$id]:false;}
function add_query_arg($key,$value,$url){return $url.'?'.$key.'='.$value;}function home_url(){return 'https://example.test';}
function wp_remote_post($url,$args){$GLOBALS['calls'][]=array($url,$args);if(!$GLOBALS['queue'])throw new RuntimeException('Unexpected real HTTP attempt');return array_shift($GLOBALS['queue']);}
function wp_remote_retrieve_response_code($r){return $r['response']['code'];}function wp_remote_retrieve_body($r){return $r['body'];}
class MPH_Security{static function encrypt($v){return 'cipher:'.base64_encode($v);}static function decrypt($v){return strpos($v,'cipher:')===0?base64_decode(substr($v,7)):$v;}static function audit(...$args){}}
class MPH_Helpers{static function audit(...$args){}}
class MPH_Courses{const COURSE_META='_mph_course_id';const MODE_META='_mph_delivery_type';}
class MPH_Appointments{const SERVICE_PRODUCT_OPTION='service';}
class Product{public $id,$mode;function __construct($id,$mode){$this->id=$id;$this->mode=$mode;}function is_purchasable(){return true;}function is_in_stock(){return true;}function get_id(){return $this->id;}function get_meta($key){return $key===MPH_Courses::COURSE_META?50:$this->mode;}}
class Order{public $id,$user=7,$paid=false,$total=1000,$ref='',$completed=0,$meta=array(),$method='mph_zarinpal';function __construct($id){$this->id=$id;}function get_id(){return $this->id;}function get_customer_id(){return $this->user;}function get_meta($key){return $this->meta[$key]??'';}function update_meta_data($key,$v){$this->meta[$key]=$v;}function save(){}function needs_payment(){return !$this->paid;}function is_paid(){return $this->paid;}function get_total(){return $this->total;}function get_currency(){return 'IRT';}function get_order_number(){return $this->id;}function get_billing_phone(){return '09120000000';}function get_billing_email(){return '';}function set_payment_method($m){$this->method=$m;}function get_payment_method(){return $this->method;}function get_transaction_id(){return $this->ref;}function payment_complete($ref){$this->paid=true;$this->ref=$ref;$this->completed++;}}
class FakeDB{public $options='wp_options',$values=array();function prepare($sql,...$args){return array($sql,$args);}function get_var($q){return $this->values[$q[1][0]]??null;}function query($q){list($sql,$a)=$q;if(strpos($sql,'INSERT IGNORE')===0){if(isset($this->values[$a[0]]))return 0;$this->values[$a[0]]=$a[1];return 1;}if(strpos($sql,'DELETE')===0){if(isset($this->values[$a[0]])&&$this->values[$a[0]]===$a[1]){unset($this->values[$a[0]]);return 1;}return 0;}throw new RuntimeException('Unmocked SQL');}}
$wpdb=new FakeDB();$wc=(object)array('cart'=>null);function WC(){return $GLOBALS['wc'];}
$wc=new class {public $cart=null;function api_request_url($name){return 'https://example.test/callback';}};
require dirname(__DIR__).'/includes/class-mph-operation-lock.php';
require dirname(__DIR__).'/includes/class-mph-shared-cart.php';
require dirname(__DIR__).'/includes/class-mph-payment-attempts.php';
require dirname(__DIR__).'/includes/class-mph-payments.php';
$products=array(101=>new Product(101,'offline'),102=>new Product(102,'online'),103=>new Product(103,'inperson'));
$a=MPH_Shared_Cart::add(7,array('product_id'=>101));$b=MPH_Shared_Cart::add(7,array('product_id'=>102));
check(count($b['items'])===2,'Two modes of one course must coexist');
check(count(MPH_Shared_Cart::add(7,array('product_id'=>101))['items'])===2,'Repeat add must be idempotent');
check(!MPH_Shared_Cart::read(8)['items'],'Cart must be private to each account');
$old_key=key($a['items']);$old_instance=$a['items'][$old_key]['instance'];
$order=$orders[1]=new Order(1);$order->meta['_mph_cart_snapshot']=array($old_key=>$old_instance);
MPH_Shared_Cart::consume_order(1);check(count(MPH_Shared_Cart::read(7)['items'])===2,'Unpaid order must not clear cart');
MPH_Shared_Cart::remove(7,$old_key,$old_instance);$new=MPH_Shared_Cart::add(7,array('product_id'=>101));
check($new['items'][$old_key]['instance']!==$old_instance,'A re-added purchase needs a new identity');
$order->paid=true;MPH_Shared_Cart::consume_order(1);check(count(MPH_Shared_Cart::read(7)['items'])===2,'Old callback must not clear a later re-added item');
$order->meta['_mph_cart_snapshot']=array($old_key=>$new['items'][$old_key]['instance']);MPH_Shared_Cart::consume_order(1);
check(count(MPH_Shared_Cart::read(7)['items'])===1,'Payment must remove only matching purchased snapshot');MPH_Shared_Cart::consume_order(1);check(count(MPH_Shared_Cart::read(7)['items'])===1,'Repeated payment callback must not remove another selection');
$lease=MPH_Operation_Lock::acquire('race');check((bool)$lease,'Lease must be acquired');check(MPH_Operation_Lock::acquire('race')===false,'Concurrent lease must be rejected');MPH_Operation_Lock::release(array('name'=>$lease['name'],'value'=>'wrong-owner'));check(MPH_Operation_Lock::acquire('race')===false,'Wrong owner must not release lease');MPH_Operation_Lock::release($lease);check((bool)MPH_Operation_Lock::acquire('race'),'Lease can be acquired after release');
check(!MPH_Payment_Attempts::valid_merchant('invalid'),'Malformed Merchant ID must be rejected');
$options[MPH_Payments::OPTION]=array('zarinpal_merchant'=>MPH_Security::encrypt('11111111-2222-3333-4444-555555555555'));
$order=$orders[2]=new Order(2);$authority='A'.str_repeat('1',35);
function gateway($data,$http=200){return array('response'=>array('code'=>$http),'body'=>json_encode($data));}
$queue[]=gateway(array('data'=>array('code'=>100,'authority'=>$authority)));
$requested=MPH_Payment_Attempts::request(2);check(!is_wp_error($requested),'Valid request must produce bank redirect');
$body=json_decode(end($calls)[1]['body'],true);check($body['amount']===10000&&$body['currency']==='IRR','Toman amount must be sent as exact rial amount');
$before=count($calls);MPH_Payment_Attempts::request(2);check(count($calls)===$before,'Repeated checkout must reuse active authority');
check(is_wp_error(MPH_Payment_Attempts::verify(2,'wrong')),'Unrelated authority must be rejected before bank call');
$queue[]=new WP_Error('timeout','private-network-error');$r=MPH_Payment_Attempts::verify(2,$authority);
check(is_wp_error($r)&&$r->get_error_code()==='mph_payment_unknown','Timeout must be unknown, not failed');
check(!$order->paid,'Network failure cannot activate purchase');
check(is_wp_error(MPH_Payment_Attempts::request(2)),'Unknown attempt must block a second payment');
$queue[]=gateway(array('data'=>array('code'=>101,'ref_id'=>'991122')));$r=MPH_Payment_Attempts::verify(2,$authority,'NOK');
check(!is_wp_error($r)&&$order->paid,'Late NOK must not overwrite an uncertain successful payment');
check($order->ref==='991122','Real bank reference must be kept');
MPH_Payment_Attempts::verify(2,$authority);check($order->completed===1,'Repeated verify must activate exactly once');
check(is_wp_error(MPH_Payment_Attempts::verify(2,'other')),'Paid-order shortcut must still check authority');
$order=$orders[3]=new Order(3);$queue[]=gateway(array('data'=>array('code'=>100,'authority'=>$authority)));MPH_Payment_Attempts::request(3);$order->total=2000;$queue[]=gateway(array('data'=>array('code'=>100,'ref_id'=>'998877')));$r=MPH_Payment_Attempts::verify(3,$authority);
check(is_wp_error($r)&&$r->get_error_code()==='mph_amount_changed'&&!$order->paid,'Changed amount must require review, never grant underpaid access');
check($order->get_meta('_mph_payment_review')==='998877','Amount review must retain real reference');
$order=$orders[4]=new Order(4);$queue[]=gateway(array('data'=>array('code'=>100,'authority'=>$authority)));MPH_Payment_Attempts::request(4);$queue[]=gateway(array('errors'=>array('code'=>-51)));$r=MPH_Payment_Attempts::verify(4,$authority);
check($r->get_error_code()==='mph_payment_failed','Definitive unpaid response must be identified');
check(!$queue,'No unused network fixture or unexpected gateway call');
echo "Cart/payment/lease: {$checks} assertions passed.\n";
